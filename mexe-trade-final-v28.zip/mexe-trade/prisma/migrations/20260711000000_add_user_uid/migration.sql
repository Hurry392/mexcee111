-- Human-friendly numeric UID for users (e.g. 600001, 600002, ...)
-- Backed by a Postgres sequence starting at a 6-digit base so UIDs
-- look like the ones shown in the app UI.

-- 1) Create the sequence (first nextval returns 600000, so UIDs are 6 digits)
CREATE SEQUENCE IF NOT EXISTS user_uid_seq START WITH 600000 INCREMENT BY 1;

-- 2) Add the column (nullable first so we can backfill existing rows)
ALTER TABLE "User" ADD COLUMN "uid" INTEGER;

-- 3) Backfill existing users in stable creation order
WITH ordered AS (
  SELECT "id", ROW_NUMBER() OVER (ORDER BY "createdAt" ASC, "id" ASC) AS rn
  FROM "User"
)
UPDATE "User" u
SET "uid" = nextval('user_uid_seq')
FROM ordered o
WHERE u."id" = o."id";

-- 4) Enforce NOT NULL + uniqueness + default for new rows
ALTER TABLE "User" ALTER COLUMN "uid" SET NOT NULL;
ALTER TABLE "User" ALTER COLUMN "uid" SET DEFAULT nextval('user_uid_seq');
CREATE UNIQUE INDEX "User_uid_key" ON "User"("uid");

-- 5) Tie sequence ownership to the column (clean drop semantics)
ALTER SEQUENCE user_uid_seq OWNED BY "User"."uid";
