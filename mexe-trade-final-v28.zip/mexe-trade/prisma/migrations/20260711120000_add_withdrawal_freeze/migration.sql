-- Withdrawal hold / freeze (TOS enforcement)
-- Admin can freeze a user's withdrawals with a reason that is
-- displayed to the user in the withdraw panel.

ALTER TABLE "User" ADD COLUMN "withdrawalsFrozen" BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE "User" ADD COLUMN "withdrawalFreezeReason" TEXT;
ALTER TABLE "User" ADD COLUMN "withdrawalFrozenAt" TIMESTAMP(3);
