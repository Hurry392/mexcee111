-- Add WhatsApp-style soft deletion flags to ChatMessage
ALTER TABLE "ChatMessage" ADD COLUMN IF NOT EXISTS "deletedForEveryone" BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE "ChatMessage" ADD COLUMN IF NOT EXISTS "deletedByUser"       BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE "ChatMessage" ADD COLUMN IF NOT EXISTS "deletedByAdmin"      BOOLEAN NOT NULL DEFAULT false;

-- Add admin-only edit fields (editedMessage is what the user sees; original message is preserved)
ALTER TABLE "ChatMessage" ADD COLUMN IF NOT EXISTS "editedMessage" TEXT;
ALTER TABLE "ChatMessage" ADD COLUMN IF NOT EXISTS "editedAt"      TIMESTAMP(3);
