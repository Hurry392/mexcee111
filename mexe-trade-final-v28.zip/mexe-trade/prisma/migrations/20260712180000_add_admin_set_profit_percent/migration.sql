-- Admin-set trade result
-- Lets an admin pre-set a profit percentage (or an equivalent exit price,
-- converted to a percentage) on an OPEN trade without closing it. When the
-- client later closes the trade themselves, this percentage is applied
-- instead of live market price P&L. Purely a payout override — never
-- surfaced to the client.

ALTER TABLE "Trade" ADD COLUMN "adminSetProfitPercent" DOUBLE PRECISION;
