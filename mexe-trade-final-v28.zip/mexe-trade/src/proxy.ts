// src/proxy.ts
import { NextRequest, NextResponse } from "next/server";
import { isDeploymentActive } from "@/lib/platformSettings";

// ─── Public routes (accessible without login) ───
const PUBLIC_ROUTES = ["/login", "/signup", "/privacy", "/terms", "/forgot-password"];

// ─── Routes that require user authentication ───
const PROTECTED_ROUTES = [
  "/",
  "/markets",
  "/trade",
  "/wallet",
  "/funds",
  "/records",
  "/kyc",
  "/referrals",
  "/security",
  "/chat",
];

// ─── Admin public route (admin login page) ───
const ADMIN_PUBLIC = "/admin/login";

/**
 * Edge-safe JWT payload decoder.
 * Full signature verification happens in API routes.
 */
function decodeJwtPayload(token: string): { role?: string } | null {
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return null;
    const payload = parts[1];
    const base64 = payload.replace(/-/g, "+").replace(/_/g, "/");
    const padded = base64.padEnd(base64.length + ((4 - (base64.length % 4)) % 4), "=");
    const decoded = atob(padded);
    return JSON.parse(decoded);
  } catch {
    return null;
  }
}

export function proxy(req: NextRequest) {
  const { pathname } = req.nextUrl;

  // ─── Get SEPARATE cookies for user and admin ───
  const userToken = req.cookies.get("pe-session")?.value;
  const adminToken = req.cookies.get("pe-admin-session")?.value;

  if (!isDeploymentActive()) {
    return new NextResponse(null, { status: 404 });
  }

  const isUserAuthenticated = !!userToken;
  const isAdminAuthenticated = !!adminToken;

  // ─── Allow API routes & static files ───
  if (
    pathname.startsWith("/api") ||
    pathname.startsWith("/_next") ||
    pathname.startsWith("/favicon") ||
    pathname.includes(".")
  ) {
    return NextResponse.next();
  }

  // ══════════════════════════════════════════════
  // ADMIN ROUTES PROTECTION (uses admin cookie only)
  // ══════════════════════════════════════════════
  if (pathname.startsWith("/admin")) {
    // Admin login page — accessible without auth
    if (pathname === ADMIN_PUBLIC) {
      // If already authenticated as admin, redirect to dashboard
      if (adminToken) {
        const payload = decodeJwtPayload(adminToken);
        if (payload?.role === "ADMIN") {
          return NextResponse.redirect(new URL("/admin/dashboard", req.url));
        }
      }
      return NextResponse.next();
    }

    // All other /admin/* routes — require ADMIN role
    if (!adminToken) {
      return NextResponse.redirect(new URL("/admin/login", req.url));
    }

    const payload = decodeJwtPayload(adminToken);
    if (!payload || payload.role !== "ADMIN") {
      return NextResponse.redirect(new URL("/admin/login", req.url));
    }

    return NextResponse.next();
  }

  // ══════════════════════════════════════════════
  // USER ROUTES PROTECTION (uses user cookie only)
  // ══════════════════════════════════════════════
  const isPublicRoute = PUBLIC_ROUTES.includes(pathname);
  const isProtectedRoute = PROTECTED_ROUTES.some((route) =>
    route === "/" ? pathname === "/" : pathname.startsWith(route)
  );

  // Authenticated user trying to access /login or /signup → redirect to home
  if (isUserAuthenticated && (pathname === "/login" || pathname === "/signup")) {
    return NextResponse.redirect(new URL("/", req.url));
  }

  // Unauthenticated user trying to access protected route → redirect to /signup
  if (!isUserAuthenticated && isProtectedRoute) {
    const url = new URL("/signup", req.url);
    url.searchParams.set("from", pathname);
    return NextResponse.redirect(url);
  }

  if (isPublicRoute) {
    return NextResponse.next();
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico|.*\\.).*)"],
};
