// ============================================================
// MEXC TRADE — Global Platform Configuration
// ============================================================

export const PLATFORM_CONFIG = {
  name: "MEXC Trade",
  tagline: "Global Crypto Exchange",
  version: "1.0.0",
  SUPPORT_EMAIL: "support@mexctrade.online",

  // API Config (used in Phase 4 for live markets)
  COINGECKO_BASE_URL: "https://api.coingecko.com/api/v3",
  BINANCE_WS_URL: "wss://stream.binance.com:9443/ws",

  // Simulation
  SIMULATION_MODE: true,
  STARTING_PAPER_BALANCE: 10000,

  // Legacy single wallet (kept for backward compat)
  CENTRAL_ADMIN_WALLET: "TSG7K6nrDdAzPPuDHTFEHucfA35yHhEWMZ",
};

// ============================================================
// SUPPORTED TRADING PAIRS (used Phase 4)
// ============================================================
export const SUPPORTED_PAIRS = [
  { symbol: "BTCUSDT", name: "Bitcoin",  display: "BTC/USDT" },
  { symbol: "ETHUSDT", name: "Ethereum", display: "ETH/USDT" },
  { symbol: "SOLUSDT", name: "Solana",   display: "SOL/USDT" },
  { symbol: "BNBUSDT", name: "BNB",      display: "BNB/USDT" },
  { symbol: "XRPUSDT", name: "XRP",      display: "XRP/USDT" },
];

// ============================================================
// DEPOSIT CONFIGURATION (TRC20 ONLY — client requirement)
// ============================================================
export const DEPOSIT_NETWORKS = [
  {
    id: "TRC20",
    name: "USDT — TRC20",
    network: "TRON (TRC20)",
    address: "TSG7K6nrDdAzPPuDHTFEHucfA35yHhEWMZ",
    minDeposit: 10,
    fee: 1,
    processingTime: "1-3 minutes",
    icon: "🔴",
  },
];

// ============================================================
// WITHDRAWAL METHODS (6 methods — fully configurable by admin)
// ============================================================
export type WithdrawalMethodCategory = "CRYPTO" | "BANK" | "UPI" | "PAYPAL";

export interface WithdrawalMethod {
  id: string;
  name: string;
  category: WithdrawalMethodCategory;
  network?: string;
  icon: string;
  fee: number;          // in USD
  feePercent?: number;  // optional percentage fee
  minWithdrawal: number;
  maxWithdrawal: number;
  processingTime: string;
  description: string;
  fields: WithdrawalField[];
}

export interface WithdrawalField {
  id: string;
  label: string;
  type: "text" | "email" | "tel";
  placeholder: string;
  required: boolean;
  monospace?: boolean;
  helperText?: string;
}

export const WITHDRAWAL_METHODS: WithdrawalMethod[] = [
  // ─── CRYPTO ───
  {
    id: "TRC20",
    name: "USDT — TRC20",
    category: "CRYPTO",
    network: "TRON (TRC20)",
    icon: "🔴",
    fee: 1,
    minWithdrawal: 0,
    maxWithdrawal: 50000,
    processingTime: "1-3 minutes",
    description: "Fastest and cheapest USDT network",
    fields: [
      {
        id: "walletAddress",
        label: "TRC20 Wallet Address",
        type: "text",
        placeholder: "Enter your TRC20 wallet address (starts with T)",
        required: true,
        monospace: true,
        helperText: "Double-check address — incorrect addresses result in permanent loss",
      },
    ],
  },
  {
    id: "BEP20",
    name: "USDT — BEP20",
    category: "CRYPTO",
    network: "BNB Smart Chain (BEP20)",
    icon: "🟡",
    fee: 0.5,
    minWithdrawal: 0,
    maxWithdrawal: 50000,
    processingTime: "2-5 minutes",
    description: "Low fees on Binance Smart Chain",
    fields: [
      {
        id: "walletAddress",
        label: "BEP20 Wallet Address",
        type: "text",
        placeholder: "Enter your BEP20 wallet address (starts with 0x)",
        required: true,
        monospace: true,
        helperText: "Double-check address — incorrect addresses result in permanent loss",
      },
    ],
  },
  {
    id: "ERC20",
    name: "USDT — ERC20",
    category: "CRYPTO",
    network: "Ethereum (ERC20)",
    icon: "🔵",
    fee: 5,
    minWithdrawal: 0,
    maxWithdrawal: 50000,
    processingTime: "5-15 minutes",
    description: "Ethereum network — higher fees but widely supported",
    fields: [
      {
        id: "walletAddress",
        label: "ERC20 Wallet Address",
        type: "text",
        placeholder: "Enter your ERC20 wallet address (starts with 0x)",
        required: true,
        monospace: true,
        helperText: "Double-check address — incorrect addresses result in permanent loss",
      },
    ],
  },

  // ─── BANK ───
  {
    id: "BANK",
    name: "Bank Transfer",
    category: "BANK",
    icon: "🏦",
    fee: 5,
    minWithdrawal: 0,
    maxWithdrawal: 50000,
    processingTime: "1-3 business days",
    description: "Direct bank transfer to your account",
    fields: [
      {
        id: "bankName",
        label: "Bank Name",
        type: "text",
        placeholder: "e.g., HDFC Bank, Chase Bank",
        required: true,
      },
      {
        id: "accountTitle",
        label: "Account Holder Name",
        type: "text",
        placeholder: "Full name as on bank account",
        required: true,
      },
      {
        id: "accountNumber",
        label: "Account Number",
        type: "text",
        placeholder: "Bank account number",
        required: true,
        monospace: true,
      },
      {
        id: "ibanNumber",
        label: "IBAN / SWIFT Code",
        type: "text",
        placeholder: "IBAN or SWIFT/BIC code (if applicable)",
        required: false,
        monospace: true,
        helperText: "Required for international transfers",
      },
    ],
  },

  // ─── UPI (India) ───
  {
    id: "UPI",
    name: "UPI (India)",
    category: "UPI",
    icon: "📱",
    fee: 0,
    minWithdrawal: 0,
    maxWithdrawal: 25000,
    processingTime: "1-2 hours",
    description: "Instant transfer via UPI (India only)",
    fields: [
      {
        id: "upiId",
        label: "UPI ID",
        type: "text",
        placeholder: "yourname@paytm / yourname@oksbi",
        required: true,
        monospace: true,
        helperText: "Enter your UPI ID exactly as registered",
      },
      {
        id: "accountTitle",
        label: "Account Holder Name",
        type: "text",
        placeholder: "Name registered with UPI",
        required: true,
      },
    ],
  },

  // ─── PAYPAL ───
  {
    id: "PAYPAL",
    name: "PayPal",
    category: "PAYPAL",
    icon: "💳",
    fee: 2,
    feePercent: 2.5,
    minWithdrawal: 0,
    maxWithdrawal: 10000,
    processingTime: "24-48 hours",
    description: "Withdraw to your PayPal account",
    fields: [
      {
        id: "paypalEmail",
        label: "PayPal Email",
        type: "email",
        placeholder: "your-paypal@email.com",
        required: true,
        helperText: "Must be a verified PayPal account",
      },
    ],
  },
];

// ============================================================
// DEPOSIT/WITHDRAWAL LIMITS (Global defaults)
// ============================================================
export const TRANSACTION_LIMITS = {
  MIN_DEPOSIT_USD: 10,
  MAX_DEPOSIT_USD: 100000,
  MIN_WITHDRAWAL_USD: 0,
  MAX_WITHDRAWAL_USD: 50000,
  PROCESSING_TIME: "1-3 business days",
  DAILY_WITHDRAWAL_LIMIT: 10000,
};

// ============================================================
// SUPPORTED CURRENCIES (for deposit/withdrawal)
// ============================================================
export const SUPPORTED_CURRENCIES = [
  { id: "USDT", name: "Tether USD", symbol: "USDT", decimals: 2 },
  { id: "BTC", name: "Bitcoin", symbol: "BTC", decimals: 8 },
  { id: "ETH", name: "Ethereum", symbol: "ETH", decimals: 6 },
];