// src/app/kyc/page.tsx
"use client";

import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  ShieldCheck,
  Upload,
  X,
  Loader2,
  AlertCircle,
  CheckCircle2,
  Clock,
  XCircle,
  IdCard,
  Car,
  BookUser,
  ChevronRight,
  ChevronLeft,
  User,
  Calendar,
  Hash,
  Camera,
  FileImage,
} from "lucide-react";
import Link from "next/link";
import { useAuthStore } from "@/store/authStore";
import { kycAPI } from "@/lib/api";
import { compressImage } from "@/lib/imageCompress";

type DocumentType = "NATIONAL_ID" | "DRIVING_LICENSE" | "PASSPORT";
type Step = 1 | 2 | 3 | 4;

const DOCUMENT_TYPES: {
  id: DocumentType;
  label: string;
  icon: React.ElementType;
  needsBack: boolean;
  color: string;
  bg: string;
}[] = [
  { id: "NATIONAL_ID", label: "National ID", icon: IdCard, needsBack: true, color: "text-blue-400", bg: "bg-blue-500/10" },
  { id: "DRIVING_LICENSE", label: "Driving License", icon: Car, needsBack: true, color: "text-green-400", bg: "bg-green-500/10" },
  { id: "PASSPORT", label: "Passport", icon: BookUser, needsBack: false, color: "text-purple-400", bg: "bg-purple-500/10" },
];

export default function KYCPage() {
  const { user, updateUser } = useAuthStore();
  const [step, setStep] = useState<Step>(1);
  const [statusLoading, setStatusLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [processingImage, setProcessingImage] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);

  // Form data
  const [documentType, setDocumentType] = useState<DocumentType>("NATIONAL_ID");
  const [fullName, setFullName] = useState("");
  const [dateOfBirth, setDateOfBirth] = useState("");
  const [documentNumber, setDocumentNumber] = useState("");
  const [documentFront, setDocumentFront] = useState<File | null>(null);
  const [documentBack, setDocumentBack] = useState<File | null>(null);
  const [selfie, setSelfie] = useState<File | null>(null);
  const [frontPreview, setFrontPreview] = useState<string | null>(null);
  const [backPreview, setBackPreview] = useState<string | null>(null);
  const [selfiePreview, setSelfiePreview] = useState<string | null>(null);

  // ─── Fetch initial KYC status ───
  useEffect(() => {
    kycAPI.getStatus().then((result) => {
      if (result.kycStatus && user) {
        updateUser({ kycStatus: result.kycStatus });
      }
      setStatusLoading(false);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const selectedDocType = DOCUMENT_TYPES.find((d) => d.id === documentType)!;

  // ─── File handlers ───
  const handleFileChange = async (
    e: React.ChangeEvent<HTMLInputElement>,
    setter: (f: File | null) => void,
    previewSetter: (s: string | null) => void
  ) => {
    const original = e.target.files?.[0];
    if (!original) return;

    setError("");

    // Auto-compress/resize in the browser so any photo — however large —
    // ends up under the server limit. The user never sees a "too large"
    // error; they just pick a photo and it works.
    let file = original;
    setProcessingImage(true);
    try {
      file = await compressImage(original);
    } catch {
      file = original; // fall back to the original on any failure
    } finally {
      setProcessingImage(false);
    }

    // Safety net: if it's somehow STILL over the limit after compression
    // (e.g. a format the browser couldn't decode), show a clear message.
    if (file.size > 5 * 1024 * 1024) {
      setError("This image is too large and couldn't be optimized. Please try a different photo.");
      return;
    }

    // Accepted types (compression outputs JPEG, so this normally always passes;
    // it only catches originals the browser couldn't decode/convert).
    const allowed = ["image/jpeg", "image/jpg", "image/png", "image/webp"];
    if (!allowed.includes(file.type)) {
      setError(
        "Please use a JPG, PNG, or WEBP image. If you're on an iPhone, set Camera → Formats to \"Most Compatible\", or take a screenshot of the photo and upload that."
      );
      return;
    }

    setter(file);
    const reader = new FileReader();
    reader.onloadend = () => previewSetter(reader.result as string);
    reader.readAsDataURL(file);
  };

  // ─── Step navigation ───
  const canProceedStep = (s: Step): boolean => {
    if (s === 1) return !!documentType;
    if (s === 2) {
      return (
        fullName.trim().length >= 2 &&
        dateOfBirth.trim().length > 0 &&
        documentNumber.trim().length > 0
      );
    }
    if (s === 3) {
      if (selectedDocType.needsBack) {
        return !!documentFront && !!documentBack;
      }
      return !!documentFront;
    }
    return !!selfie;
  };

  const handleNext = () => {
    if (!canProceedStep(step)) {
      setError("Please complete all required fields");
      return;
    }
    setError("");
    if (step < 4) setStep((step + 1) as Step);
  };

  const handleBack = () => {
    setError("");
    if (step > 1) setStep((step - 1) as Step);
  };

  // ─── Submit ───
  const handleSubmit = async () => {
    if (!canProceedStep(4)) {
      setError("Selfie is required");
      return;
    }

    setSubmitting(true);
    setError("");

    const formData = new FormData();
    formData.append("documentType", documentType);
    formData.append("fullName", fullName);
    formData.append("dateOfBirth", dateOfBirth);
    formData.append("documentNumber", documentNumber);
    formData.append("documentFront", documentFront!);
    if (documentBack) formData.append("documentBack", documentBack);
    formData.append("selfie", selfie!);

    const result = await kycAPI.submit(formData);
    setSubmitting(false);

    if (result.error) {
      setError(result.error);
      return;
    }

    // Update auth store
    if (user) updateUser({ kycStatus: "PENDING" });
    setSuccess(true);
  };

  // ─── Loading initial status ───
  if (statusLoading) {
    return (
      <div className="min-h-full flex items-center justify-center">
        <Loader2 className="w-6 h-6 text-[var(--accent)] animate-spin" />
      </div>
    );
  }

  // ─── If APPROVED, PENDING, or just submitted — show status screen ───
  if (user?.kycStatus === "APPROVED" || user?.kycStatus === "PENDING" || success) {
    return <KYCStatusScreen status={success ? "PENDING" : user!.kycStatus} />;
  }

  return (
    <div className="min-h-full mesh-bg">
      <div className="max-w-3xl mx-auto p-4 sm:p-6 lg:p-8 space-y-5">
        {/* ═══════════ HEADER ═══════════ */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <h1 className="text-2xl sm:text-3xl font-bold text-foreground mb-1.5">
            KYC Verification
          </h1>
          <p className="text-sm text-gray-500">
            Verify your identity to unlock withdrawals and higher limits
          </p>
        </motion.div>

        {/* ═══════════ REJECTED NOTICE ═══════════ */}
        {user?.kycStatus === "REJECTED" && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-start gap-3 p-4 rounded-xl bg-red-500/[0.07] border border-red-500/20"
          >
            <XCircle size={18} className="text-red-400 shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-red-300 mb-0.5">
                Previous Submission Rejected
              </p>
              <p className="text-xs text-red-200/70">
                Please re-submit with clearer documents and correct information.
              </p>
            </div>
          </motion.div>
        )}

        {/* ═══════════ PROGRESS STEPS ═══════════ */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="glass-panel rounded-xl p-4"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-foreground">
              Step {step} of 4
            </span>
            <span className="text-[10px] text-gray-500">
              {step === 1 && "Document Type"}
              {step === 2 && "Personal Details"}
              {step === 3 && "Upload Document"}
              {step === 4 && "Selfie Verification"}
            </span>
          </div>
          <div className="flex gap-1.5">
            {[1, 2, 3, 4].map((s) => (
              <div
                key={s}
                className={`flex-1 h-1.5 rounded-full transition-all ${
                  s <= step ? "bg-[var(--accent)]" : "bg-white/[0.05]"
                }`}
              />
            ))}
          </div>
        </motion.div>

        {/* ═══════════ ERROR BANNER ═══════════ */}
        <AnimatePresence>
          {error && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="flex items-start gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/20"
            >
              <AlertCircle size={14} className="text-red-400 shrink-0 mt-0.5" />
              <p className="text-xs text-red-400">{error}</p>
            </motion.div>
          )}
          {processingImage && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="flex items-center gap-2 p-3 rounded-lg bg-[var(--accent)]/10 border border-[var(--accent)]/20"
            >
              <Loader2 size={14} className="text-[var(--accent)] shrink-0 animate-spin" />
              <p className="text-xs text-[var(--accent)]">Optimizing image…</p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* ═══════════ STEP CONTENT ═══════════ */}
        <AnimatePresence mode="wait">
          <motion.div
            key={step}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.2 }}
          >
            {step === 1 && (
              <StepDocumentType
                selected={documentType}
                onSelect={setDocumentType}
              />
            )}
            {step === 2 && (
              <StepPersonalDetails
                fullName={fullName}
                setFullName={setFullName}
                dateOfBirth={dateOfBirth}
                setDateOfBirth={setDateOfBirth}
                documentNumber={documentNumber}
                setDocumentNumber={setDocumentNumber}
              />
            )}
            {step === 3 && (
              <StepDocumentUpload
                docType={selectedDocType}
                front={documentFront}
                frontPreview={frontPreview}
                back={documentBack}
                backPreview={backPreview}
                onFrontChange={(e) =>
                  handleFileChange(e, setDocumentFront, setFrontPreview)
                }
                onBackChange={(e) =>
                  handleFileChange(e, setDocumentBack, setBackPreview)
                }
                onRemoveFront={() => {
                  setDocumentFront(null);
                  setFrontPreview(null);
                }}
                onRemoveBack={() => {
                  setDocumentBack(null);
                  setBackPreview(null);
                }}
              />
            )}
            {step === 4 && (
              <StepSelfie
                selfie={selfie}
                selfiePreview={selfiePreview}
                onChange={(e) =>
                  handleFileChange(e, setSelfie, setSelfiePreview)
                }
                onRemove={() => {
                  setSelfie(null);
                  setSelfiePreview(null);
                }}
              />
            )}
          </motion.div>
        </AnimatePresence>

        {/* ═══════════ NAVIGATION BUTTONS ═══════════ */}
        <div className="flex items-center gap-3">
          {step > 1 && (
            <button
              type="button"
              onClick={handleBack}
              disabled={submitting}
              className="flex items-center gap-2 px-5 py-3 rounded-xl border border-[var(--border)] text-sm font-semibold text-foreground hover:bg-white/[0.03] transition-all disabled:opacity-50"
            >
              <ChevronLeft size={16} />
              Back
            </button>
          )}
          {step < 4 ? (
            <button
              type="button"
              onClick={handleNext}
              className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl bg-gradient-to-r from-[var(--accent)] to-purple-500 text-white font-semibold text-sm hover:opacity-95 transition-all active:scale-[0.98] shadow-lg shadow-[var(--accent)]/20"
            >
              Next Step
              <ChevronRight size={16} />
            </button>
          ) : (
            <button
              type="button"
              onClick={handleSubmit}
              disabled={submitting}
              className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl bg-gradient-to-r from-green-500 to-emerald-500 text-white font-semibold text-sm hover:opacity-95 transition-all active:scale-[0.98] shadow-lg shadow-green-500/20 disabled:opacity-50"
            >
              {submitting ? (
                <>
                  <Loader2 size={16} className="animate-spin" />
                  Submitting...
                </>
              ) : (
                <>
                  <CheckCircle2 size={16} />
                  Submit for Review
                </>
              )}
            </button>
          )}
        </div>

        {/* ═══════════ INFO FOOTER ═══════════ */}
        <div className="flex items-start gap-2.5 p-4 rounded-xl bg-white/[0.02] border border-[var(--border)]">
          <ShieldCheck size={14} className="text-gray-500 shrink-0 mt-0.5" />
          <p className="text-xs text-gray-500 leading-relaxed">
            Your information is encrypted and secure. We use industry-standard security to protect your data. Documents are reviewed within 1-3 business days. Read our{" "}
            <Link href="/privacy" className="text-[var(--accent)] hover:underline">
              Privacy Policy
            </Link>
            .
          </p>
        </div>
      </div>
    </div>
  );
}

// ============================================================
// STATUS SCREEN
// ============================================================
function KYCStatusScreen({ status }: { status: string }) {
  const config = {
    APPROVED: {
      icon: CheckCircle2,
      title: "Identity Verified",
      message: "Your KYC has been approved. You now have full access to all features including withdrawals.",
      color: "text-green-400",
      bg: "bg-green-500/10",
      border: "border-green-500/20",
      cta: { label: "Make Withdrawal", href: "/funds" },
    },
    PENDING: {
      icon: Clock,
      title: "Under Review",
      message: "Your KYC submission is being reviewed. This typically takes 1-3 business days. You'll be notified once complete.",
      color: "text-amber-400",
      bg: "bg-amber-500/10",
      border: "border-amber-500/20",
      cta: { label: "Back to Dashboard", href: "/" },
    },
  }[status] || {
    icon: Clock,
    title: "Status Unknown",
    message: "Please contact support.",
    color: "text-gray-400",
    bg: "bg-gray-500/10",
    border: "border-gray-500/20",
    cta: { label: "Contact Support", href: "/chat" },
  };

  const Icon = config.icon;

  return (
    <div className="min-h-full mesh-bg flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 20, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.4 }}
        className="max-w-md w-full"
      >
        <div className={`relative overflow-hidden rounded-2xl border ${config.border} ${config.bg} p-8 text-center`}>
          <div className="absolute -top-20 -right-20 w-64 h-64 rounded-full bg-current opacity-5 blur-3xl pointer-events-none" />

          <div className="relative z-10">
            <div className={`w-16 h-16 rounded-2xl ${config.bg} ${config.color} flex items-center justify-center mx-auto mb-4 border ${config.border}`}>
              <Icon size={32} />
            </div>
            <h2 className="text-xl font-bold text-foreground mb-2">
              {config.title}
            </h2>
            <p className="text-sm text-gray-400 leading-relaxed mb-6">
              {config.message}
            </p>
            <Link href={config.cta.href}>
              <button className="w-full py-3 rounded-xl bg-gradient-to-r from-[var(--accent)] to-purple-500 text-white font-semibold text-sm hover:opacity-95 transition-all active:scale-[0.98]">
                {config.cta.label}
              </button>
            </Link>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

// ============================================================
// STEP 1 — Document Type
// ============================================================
function StepDocumentType({
  selected,
  onSelect,
}: {
  selected: DocumentType;
  onSelect: (t: DocumentType) => void;
}) {
  return (
    <div className="space-y-3">
      <div>
        <h3 className="text-base font-semibold text-foreground mb-1">
          Select Document Type
        </h3>
        <p className="text-xs text-gray-500">
          Choose the document you&apos;ll use for verification
        </p>
      </div>

      <div className="space-y-2">
        {DOCUMENT_TYPES.map((doc) => {
          const Icon = doc.icon;
          const isSelected = selected === doc.id;
          return (
            <button
              key={doc.id}
              type="button"
              onClick={() => onSelect(doc.id)}
              className={`w-full flex items-center gap-4 p-4 rounded-xl border transition-all text-left ${
                isSelected
                  ? "border-[var(--accent)]/40 bg-[var(--accent)]/[0.05]"
                  : "border-[var(--border)] bg-white/[0.02] hover:bg-white/[0.04]"
              }`}
            >
              <div className={`w-11 h-11 rounded-xl ${doc.bg} flex items-center justify-center shrink-0`}>
                <Icon size={20} className={doc.color} />
              </div>
              <div className="flex-1">
                <div className="text-sm font-semibold text-foreground">
                  {doc.label}
                </div>
                <div className="text-[11px] text-gray-500">
                  {doc.needsBack
                    ? "Front and back required"
                    : "Front side only"}
                </div>
              </div>
              <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all ${
                isSelected
                  ? "border-[var(--accent)] bg-[var(--accent)]"
                  : "border-gray-600"
              }`}>
                {isSelected && (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="w-2 h-2 rounded-full bg-white"
                  />
                )}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}

// ============================================================
// STEP 2 — Personal Details
// ============================================================
function StepPersonalDetails({
  fullName,
  setFullName,
  dateOfBirth,
  setDateOfBirth,
  documentNumber,
  setDocumentNumber,
}: {
  fullName: string;
  setFullName: (v: string) => void;
  dateOfBirth: string;
  setDateOfBirth: (v: string) => void;
  documentNumber: string;
  setDocumentNumber: (v: string) => void;
}) {
  return (
    <div className="space-y-4">
      <div>
        <h3 className="text-base font-semibold text-foreground mb-1">
          Personal Details
        </h3>
        <p className="text-xs text-gray-500">
          Enter your information exactly as it appears on your document
        </p>
      </div>

      <div>
        <label className="block text-xs font-medium text-gray-400 mb-2">
          Full Name <span className="text-red-400">*</span>
        </label>
        <div className="relative">
          <User size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-500" />
          <input
            type="text"
            value={fullName}
            onChange={(e) => setFullName(e.target.value)}
            placeholder="John Michael Doe"
            className="w-full pl-10 pr-4 py-3 bg-white/[0.03] border border-[var(--border)] rounded-xl text-sm text-foreground placeholder:text-gray-600 focus:outline-none focus:border-[var(--accent)]/50 focus:bg-white/[0.05] transition-all"
          />
        </div>
      </div>

      <div>
        <label className="block text-xs font-medium text-gray-400 mb-2">
          Date of Birth <span className="text-red-400">*</span>
        </label>
        <div className="relative">
          <Calendar size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-500 pointer-events-none" />
          <input
            type="date"
            value={dateOfBirth}
            onChange={(e) => setDateOfBirth(e.target.value)}
            max={new Date(new Date().setFullYear(new Date().getFullYear() - 18)).toISOString().split("T")[0]}
            className="w-full pl-10 pr-4 py-3 bg-white/[0.03] border border-[var(--border)] rounded-xl text-sm text-foreground focus:outline-none focus:border-[var(--accent)]/50 focus:bg-white/[0.05] transition-all"
            style={{ colorScheme: "dark" }}
          />
        </div>
        <div className="text-[10px] text-gray-500 mt-1.5">
          You must be 18 or older
        </div>
      </div>

      <div>
        <label className="block text-xs font-medium text-gray-400 mb-2">
          Document Number <span className="text-red-400">*</span>
        </label>
        <div className="relative">
          <Hash size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-500" />
          <input
            type="text"
            value={documentNumber}
            onChange={(e) => setDocumentNumber(e.target.value)}
            placeholder="ID/License/Passport number"
            className="w-full pl-10 pr-4 py-3 bg-white/[0.03] border border-[var(--border)] rounded-xl text-sm text-foreground placeholder:text-gray-600 focus:outline-none focus:border-[var(--accent)]/50 focus:bg-white/[0.05] transition-all font-mono"
          />
        </div>
      </div>
    </div>
  );
}

// ============================================================
// STEP 3 — Document Upload
// ============================================================
function StepDocumentUpload({
  docType,
  front,
  frontPreview,
  back,
  backPreview,
  onFrontChange,
  onBackChange,
  onRemoveFront,
  onRemoveBack,
}: {
  docType: typeof DOCUMENT_TYPES[number];
  front: File | null;
  frontPreview: string | null;
  back: File | null;
  backPreview: string | null;
  onFrontChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onBackChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onRemoveFront: () => void;
  onRemoveBack: () => void;
}) {
  return (
    <div className="space-y-4">
      <div>
        <h3 className="text-base font-semibold text-foreground mb-1">
          Upload {docType.label}
        </h3>
        <p className="text-xs text-gray-500">
          Make sure the document is clear, readable, and all corners are visible
        </p>
      </div>

      <DocumentUploadBox
        label="Front Side"
        file={front}
        preview={frontPreview}
        onChange={onFrontChange}
        onRemove={onRemoveFront}
        icon={FileImage}
      />

      {docType.needsBack && (
        <DocumentUploadBox
          label="Back Side"
          file={back}
          preview={backPreview}
          onChange={onBackChange}
          onRemove={onRemoveBack}
          icon={FileImage}
        />
      )}

      <div className="flex items-start gap-2 p-3 rounded-lg bg-amber-500/[0.05] border border-amber-500/15">
        <AlertCircle size={12} className="text-amber-400 shrink-0 mt-0.5" />
        <p className="text-[11px] text-amber-200/80 leading-relaxed">
          Ensure good lighting, no glare, and all text is clearly readable. Blurry or cropped images will be rejected.
        </p>
      </div>
    </div>
  );
}

// ============================================================
// STEP 4 — Selfie
// ============================================================
function StepSelfie({
  selfie,
  selfiePreview,
  onChange,
  onRemove,
}: {
  selfie: File | null;
  selfiePreview: string | null;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onRemove: () => void;
}) {
  return (
    <div className="space-y-4">
      <div>
        <h3 className="text-base font-semibold text-foreground mb-1">
          Selfie Verification
        </h3>
        <p className="text-xs text-gray-500">
          Take a clear selfie holding your document
        </p>
      </div>

      <DocumentUploadBox
        label="Your Selfie"
        file={selfie}
        preview={selfiePreview}
        onChange={onChange}
        onRemove={onRemove}
        icon={Camera}
      />

      <div className="space-y-2">
        {[
          "Face clearly visible (no sunglasses or hat)",
          "Hold your document next to your face",
          "Good lighting, no shadows on face",
          "Look directly at the camera",
        ].map((tip, i) => (
          <div key={i} className="flex items-start gap-2 text-[11px] text-gray-400">
            <CheckCircle2 size={11} className="text-green-400 shrink-0 mt-0.5" />
            <span>{tip}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ============================================================
// REUSABLE UPLOAD BOX
// ============================================================
function DocumentUploadBox({
  label,
  file,
  preview,
  onChange,
  onRemove,
  icon: Icon,
}: {
  label: string;
  file: File | null;
  preview: string | null;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onRemove: () => void;
  icon: React.ElementType;
}) {
  const inputRef = useRef<HTMLInputElement>(null);

  return (
    <div>
      <label className="block text-xs font-medium text-gray-400 mb-2">
        {label} <span className="text-red-400">*</span>
      </label>

      {!preview ? (
        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          className="w-full flex flex-col items-center justify-center gap-2 py-10 px-4 rounded-xl border-2 border-dashed border-[var(--border)] hover:border-[var(--accent)]/40 hover:bg-white/[0.02] transition-all"
        >
          <div className="w-12 h-12 rounded-xl bg-[var(--accent)]/10 flex items-center justify-center">
            <Icon size={20} className="text-[var(--accent)]" />
          </div>
          <div className="text-center">
            <p className="text-sm font-medium text-foreground">
              Click to upload
            </p>
            <p className="text-[10px] text-gray-500 mt-0.5">
              PNG, JPG, JPEG up to 5MB
            </p>
          </div>
          <input
            ref={inputRef}
            type="file"
            accept="image/*"
            onChange={onChange}
            className="sr-only"
          />
        </button>
      ) : (
        <div className="relative rounded-xl border border-[var(--border)] overflow-hidden">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={preview}
            alt={label}
            className="w-full max-h-64 object-contain bg-black/40"
          />
          <button
            type="button"
            onClick={onRemove}
            className="absolute top-2 right-2 flex items-center justify-center w-7 h-7 rounded-lg bg-black/60 backdrop-blur-sm text-white hover:bg-red-500/80 transition-colors"
          >
            <X size={14} />
          </button>
          <div className="px-3 py-2 bg-black/60 backdrop-blur-sm text-[10px] text-gray-300 flex items-center gap-2">
            <Upload size={10} />
            {file?.name} ({((file?.size ?? 0) / 1024).toFixed(1)} KB)
          </div>
        </div>
      )}
    </div>
  );
}