// src/app/trade/page.tsx
"use client";

import OpenPositions from "@/components/trade/OpenPositions";
import TradeHistory from "@/components/trade/TradeHistory";
import { useState, useEffect, useRef, Suspense } from "react";
import { createPortal } from "react-dom";
import { useSearchParams } from "next/navigation";
import { motion } from "framer-motion";
import { TrendingUp, TrendingDown, Loader2, ChevronDown } from "lucide-react";
import { useMarkets } from "@/hooks/useMarkets";
import { formatPrice, formatPercent, MarketCoin } from "@/lib/markets";
import CandlestickChart from "@/components/trade/CandlestickChart";
import TradingPanel from "@/components/trade/TradingPanel";
import OrderBook from "@/components/trade/OrderBook";

const TIMEFRAMES = [
  { label: "1D", days: 1 },
  { label: "7D", days: 7 },
  { label: "30D", days: 30 },
  { label: "90D", days: 90 },
];

function TradePageContent() {
  const searchParams = useSearchParams();
  const initialCoin = searchParams.get("coin") || "bitcoin";
  const { markets, loading } = useMarkets(30000);
  const [selectedCoinId, setSelectedCoinId] = useState(initialCoin);
  const [timeframe, setTimeframe] = useState(1);
  const [coinSelectorOpen, setCoinSelectorOpen] = useState(false);

  const selectedCoin = markets.find((m) => m.id === selectedCoinId);

  useEffect(() => {
    if (markets.length > 0 && !markets.find((m) => m.id === selectedCoinId)) {
      setSelectedCoinId(markets[0].id);
    }
  }, [markets, selectedCoinId]);

  if (loading && !selectedCoin) {
    return (
      <div className="flex items-center justify-center min-h-[80vh]">
        <div className="flex flex-col items-center gap-3">
          <Loader2 className="w-8 h-8 text-[var(--accent)] animate-spin" />
          <span className="text-sm text-gray-500">Loading trading data...</span>
        </div>
      </div>
    );
  }

  if (!selectedCoin) {
    return (
      <div className="flex items-center justify-center min-h-[80vh] text-gray-500">
        No coin data available
      </div>
    );
  }

  const isUp = selectedCoin.price_change_percentage_24h >= 0;

  return (
    <div className="min-h-full mesh-bg">
      <div className="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8 space-y-4">
        {/* ═══════════ HEADER ═══════════ */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-panel rounded-2xl p-4 sm:p-5"
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            {/* Coin Info + Selector */}
            <div className="flex items-center gap-3">
              {/* Coin selector dropdown */}
              <CoinSelector
                markets={markets}
                selectedId={selectedCoinId}
                onSelect={setSelectedCoinId}
                open={coinSelectorOpen}
                setOpen={setCoinSelectorOpen}
              />

              <div className="flex items-baseline gap-2">
                <div className="text-2xl sm:text-3xl font-bold text-foreground font-mono">
                  ${formatPrice(selectedCoin.current_price)}
                </div>
                <div
                  className={`flex items-center gap-1 text-sm font-bold ${
                    isUp ? "text-green-400" : "text-red-400"
                  }`}
                >
                  {isUp ? <TrendingUp size={14} /> : <TrendingDown size={14} />}
                  {formatPercent(selectedCoin.price_change_percentage_24h)}
                </div>
              </div>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-3 gap-3 sm:gap-6">
              <Stat label="24h High" value={`$${formatPrice(selectedCoin.high_24h)}`} color="text-green-400" />
              <Stat label="24h Low" value={`$${formatPrice(selectedCoin.low_24h)}`} color="text-red-400" />
              <Stat label="Volume" value={`$${(selectedCoin.total_volume / 1_000_000).toFixed(1)}M`} />
            </div>
          </div>
        </motion.div>

        {/* ═══════════ MAIN LAYOUT (Chart + Trading) ═══════════ */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* LEFT: Chart + Positions + Order Book */}
          <div className="lg:col-span-2 space-y-4">
            {/* Chart Card */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="glass-panel rounded-2xl p-4 sm:p-5"
            >
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-sm font-bold text-foreground">Price Chart</h2>
                <div className="flex gap-1">
                  {TIMEFRAMES.map((tf) => (
                    <button
                      key={tf.label}
                      onClick={() => setTimeframe(tf.days)}
                      className={`px-2.5 py-1 text-[11px] font-bold rounded-md transition-all ${
                        timeframe === tf.days
                          ? "bg-[var(--accent)] text-white"
                          : "bg-white/[0.03] text-gray-500 hover:text-gray-300"
                      }`}
                    >
                      {tf.label}
                    </button>
                  ))}
                </div>
              </div>
              <CandlestickChart coinId={selectedCoinId} days={timeframe} />
            </motion.div>

            {/* Trading Panel — Mobile shows here (right below chart, above positions), Desktop in right column */}
            <div className="lg:hidden">
              <TradingPanel
                coinId={selectedCoinId}
                coinSymbol={selectedCoin.symbol.toUpperCase()}
                coinPrice={selectedCoin.current_price}
              />
            </div>

            {/* ═══════════ OPEN POSITIONS (NEW!) ═══════════ */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.15 }}
            >
              <OpenPositions />
            </motion.div>

            {/* ═══════════ TRADE HISTORY ═══════════ */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.18 }}
            >
              <TradeHistory />
            </motion.div>

            {/* Order Book — Mobile shows below chart, Desktop in right column */}
            <div className="lg:hidden">
              <OrderBook
                currentPrice={selectedCoin.current_price}
                symbol={selectedCoin.symbol.toUpperCase()}
                coinId={selectedCoinId}
              />
            </div>
          </div>

          {/* RIGHT: Trading Panel + Order Book (Desktop) */}
          <div className="space-y-4">
            <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15 }}
            className="hidden lg:block"
          >
            <TradingPanel
              coinId={selectedCoinId}
              coinSymbol={selectedCoin.symbol.toUpperCase()}
              coinPrice={selectedCoin.current_price}
            />
           </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="hidden lg:block"
            >
              <OrderBook
                currentPrice={selectedCoin.current_price}
                symbol={selectedCoin.symbol.toUpperCase()}
                coinId={selectedCoinId}
              />
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Coin Selector ───
function CoinSelector({
  markets,
  selectedId,
  onSelect,
  open,
  setOpen,
}: {
  markets: MarketCoin[];
  selectedId: string;
  onSelect: (id: string) => void;
  open: boolean;
  setOpen: (v: boolean) => void;
}) {
  const selected = markets.find((m) => m.id === selectedId);
  const buttonRef = useRef<HTMLButtonElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const [dropdownPos, setDropdownPos] = useState<{ top: number; left: number } | null>(null);

  // Compute dropdown position from the trigger button's viewport rect
  // whenever it opens (and keep it in sync on scroll/resize).
  //
  // WHY A PORTAL: the trigger lives inside a Framer Motion-animated,
  // backdrop-filtered header card. Both transforms and
  // -webkit-backdrop-filter on ancestors have long-standing WebKit
  // (iOS Safari) bugs that break hit-testing for descendants that
  // overflow the ancestor's box — which is exactly what an absolute
  // dropdown does. Rendering the dropdown at document.body via a
  // portal removes every problematic ancestor at once.
  useEffect(() => {
    if (!open) return;

    const updatePos = () => {
      const rect = buttonRef.current?.getBoundingClientRect();
      if (!rect) return;
      const dropdownWidth = 288; // w-72
      const left = Math.min(rect.left, Math.max(8, window.innerWidth - dropdownWidth - 8));
      setDropdownPos({ top: rect.bottom + 8, left });
    };

    updatePos();
    window.addEventListener("scroll", updatePos, true);
    window.addEventListener("resize", updatePos);
    return () => {
      window.removeEventListener("scroll", updatePos, true);
      window.removeEventListener("resize", updatePos);
    };
  }, [open]);

  // Close on outside click/tap — checks both the trigger and the
  // portaled dropdown, since they're no longer in the same subtree.
  useEffect(() => {
    if (!open) return;
    function handleOutside(e: MouseEvent | TouchEvent) {
      const target = e.target as Node;
      if (buttonRef.current?.contains(target)) return;
      if (dropdownRef.current?.contains(target)) return;
      setOpen(false);
    }
    document.addEventListener("mousedown", handleOutside);
    document.addEventListener("touchstart", handleOutside);
    return () => {
      document.removeEventListener("mousedown", handleOutside);
      document.removeEventListener("touchstart", handleOutside);
    };
  }, [open, setOpen]);

  if (!selected) return null;

  return (
    <div className="relative">
      <button
        ref={buttonRef}
        onClick={() => setOpen(!open)}
        className="flex items-center gap-2.5 px-3 py-2 rounded-xl bg-white/[0.03] border border-[var(--border)] hover:bg-white/[0.06] transition-all"
        style={{ touchAction: "manipulation" }}
      >
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={selected.image} alt={selected.name} className="w-7 h-7 rounded-full" />
        <div className="text-left">
          <div className="text-sm font-bold text-foreground uppercase leading-tight">
            {selected.symbol}/USDT
          </div>
          <div className="text-[10px] text-gray-500 leading-tight">{selected.name}</div>
        </div>
        <ChevronDown size={14} className={`text-gray-500 transition-transform ${open ? "rotate-180" : ""}`} />
      </button>

      {open && dropdownPos &&
        createPortal(
          <div
            ref={dropdownRef}
            style={{
              position: "fixed",
              top: dropdownPos.top,
              left: dropdownPos.left,
              width: 288,
              zIndex: 9999,
              touchAction: "manipulation",
            }}
            className="max-h-80 overflow-y-auto rounded-xl glass-panel shadow-2xl border border-[var(--border)] p-1.5"
          >
            {markets.map((coin) => {
              const isSelected = coin.id === selectedId;
              const isUp = coin.price_change_percentage_24h >= 0;
              return (
                <button
                  key={coin.id}
                  onClick={() => {
                    onSelect(coin.id);
                    setOpen(false);
                  }}
                  style={{ touchAction: "manipulation" }}
                  className={`w-full flex items-center gap-3 p-2.5 rounded-lg transition-all ${
                    isSelected ? "bg-[var(--accent)]/15" : "hover:bg-white/[0.03]"
                  }`}
                >
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={coin.image} alt={coin.name} className="w-7 h-7 rounded-full" />
                  <div className="flex-1 text-left">
                    <div className="text-sm font-semibold text-foreground uppercase">
                      {coin.symbol}
                    </div>
                    <div className="text-[10px] text-gray-500">{coin.name}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs font-bold text-foreground font-mono">
                      ${formatPrice(coin.current_price)}
                    </div>
                    <div className={`text-[10px] font-semibold ${isUp ? "text-green-400" : "text-red-400"}`}>
                      {formatPercent(coin.price_change_percentage_24h)}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>,
          document.body
        )}
    </div>
  );
}

function Stat({ label, value, color = "text-foreground" }: { label: string; value: string; color?: string }) {
  return (
    <div>
      <div className="text-[10px] text-gray-500 uppercase tracking-wider font-semibold">
        {label}
      </div>
      <div className={`text-sm font-bold ${color} font-mono mt-0.5`}>
        {value}
      </div>
    </div>
  );
}

// ─── Wrapped in Suspense for useSearchParams ───
export default function TradePage() {
  return (
    <Suspense fallback={
      <div className="flex items-center justify-center min-h-[80vh]">
        <Loader2 className="w-8 h-8 text-[var(--accent)] animate-spin" />
      </div>
    }>
      <TradePageContent />
    </Suspense>
  );
}