// src/app/security/page.tsx
"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Lock,
  Eye,
  EyeOff,
  Loader2,
  AlertCircle,
  CheckCircle2,
  Shield,
  Key,
  KeyRound,
  ShieldCheck,
  AlertTriangle,
} from "lucide-react";
import Link from "next/link";
import { useAuthStore } from "@/store/authStore";
import { securityAPI } from "@/lib/api";

type SecurityTab = "account" | "withdrawal";

export default function SecurityPage() {
  const { user } = useAuthStore();
  const [tab, setTab] = useState<SecurityTab>("account");
  const [withdrawalPasswordSet, setWithdrawalPasswordSet] = useState(false);
  const [checkingStatus, setCheckingStatus] = useState(true);

  useEffect(() => {
    securityAPI.checkWithdrawalPassword().then((result) => {
      setWithdrawalPasswordSet(!!result.isSet);
      setCheckingStatus(false);
    });
  }, []);

  return (
    <div className="min-h-full mesh-bg">
      <div className="max-w-3xl mx-auto p-4 sm:p-6 lg:p-8 space-y-5">
        {/* ═══════════ HEADER ═══════════ */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <h1 className="text-2xl sm:text-3xl font-bold text-foreground mb-1.5">
            Security Center
          </h1>
          <p className="text-sm text-gray-500">
            Manage your account passwords and security settings
          </p>
        </motion.div>

        {/* ═══════════ SECURITY OVERVIEW ═══════════ */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-1 sm:grid-cols-2 gap-3"
        >
          <SecurityCard
            icon={Key}
            title="Account Password"
            status="Active"
            description="Used for login and account access"
            statusColor="green"
          />
          <SecurityCard
            icon={KeyRound}
            title="Withdrawal Password"
            status={checkingStatus ? "Checking..." : withdrawalPasswordSet ? "Set" : "Not Set"}
            description="Required for withdrawal requests"
            statusColor={withdrawalPasswordSet ? "green" : "amber"}
          />
        </motion.div>

        {/* ═══════════ KYC STATUS BANNER ═══════════ */}
        {user?.kycStatus !== "APPROVED" && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-start gap-3 p-4 rounded-xl bg-amber-500/[0.07] border border-amber-500/20"
          >
            <ShieldCheck size={18} className="text-amber-400 shrink-0 mt-0.5" />
            <div className="flex-1">
              <p className="text-sm font-semibold text-amber-300 mb-0.5">
                Complete KYC for Full Security
              </p>
              <p className="text-xs text-amber-200/70 mb-2">
                Verify your identity to enable withdrawals and 2FA features.
              </p>
              <Link href="/kyc">
                <button className="text-xs font-semibold text-amber-400 hover:text-amber-300 underline underline-offset-2">
                  Complete KYC →
                </button>
              </Link>
            </div>
          </motion.div>
        )}

        {/* ═══════════ TAB SWITCHER ═══════════ */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="relative flex p-1 rounded-xl bg-card border border-[var(--border)]"
        >
          {([
            { id: "account" as SecurityTab, label: "Account Password", icon: Key },
            { id: "withdrawal" as SecurityTab, label: "Withdrawal Password", icon: KeyRound },
          ]).map((t) => {
            const Icon = t.icon;
            return (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`relative flex-1 flex items-center justify-center gap-2 py-3 text-sm font-semibold rounded-lg transition-colors z-10 ${
                  tab === t.id ? "text-foreground" : "text-gray-500 hover:text-gray-300"
                }`}
              >
                {tab === t.id && (
                  <motion.div
                    layoutId="securityTabPill"
                    className="absolute inset-0 rounded-lg bg-white/[0.05] border border-[var(--border)]"
                    transition={{ type: "spring", stiffness: 300, damping: 30 }}
                  />
                )}
                <Icon size={14} className="relative z-10" />
                <span className="relative z-10 text-xs sm:text-sm">{t.label}</span>
              </button>
            );
          })}
        </motion.div>

        {/* ═══════════ TAB CONTENT ═══════════ */}
        <AnimatePresence mode="wait">
          {tab === "account" ? (
            <motion.div
              key="account"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 10 }}
              transition={{ duration: 0.2 }}
            >
              <ChangePasswordPanel />
            </motion.div>
          ) : (
            <motion.div
              key="withdrawal"
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -10 }}
              transition={{ duration: 0.2 }}
            >
              <WithdrawalPasswordPanel
                isSet={withdrawalPasswordSet}
                onSuccess={() => setWithdrawalPasswordSet(true)}
              />
            </motion.div>
          )}
        </AnimatePresence>

        {/* ═══════════ FOOTER ═══════════ */}
        <div className="flex items-start gap-2.5 p-4 rounded-xl bg-white/[0.02] border border-[var(--border)]">
          <Shield size={14} className="text-gray-500 shrink-0 mt-0.5" />
          <p className="text-xs text-gray-500 leading-relaxed">
            Never share your passwords with anyone, including support staff. We will never ask for your password via email or chat. If you suspect unauthorized access, contact{" "}
            <Link href="/chat" className="text-[var(--accent)] hover:underline">
              support
            </Link>{" "}
            immediately.
          </p>
        </div>
      </div>
    </div>
  );
}

// ============================================================
// SECURITY OVERVIEW CARD
// ============================================================
function SecurityCard({
  icon: Icon,
  title,
  status,
  description,
  statusColor,
}: {
  icon: React.ElementType;
  title: string;
  status: string;
  description: string;
  statusColor: "green" | "amber" | "red";
}) {
  const colors = {
    green: { bg: "bg-green-500/10", text: "text-green-400", border: "border-green-500/20" },
    amber: { bg: "bg-amber-500/10", text: "text-amber-400", border: "border-amber-500/20" },
    red: { bg: "bg-red-500/10", text: "text-red-400", border: "border-red-500/20" },
  }[statusColor];

  return (
    <div className="glass-panel rounded-xl p-4">
      <div className="flex items-start justify-between mb-2">
        <div className="w-9 h-9 rounded-lg bg-[var(--accent)]/10 flex items-center justify-center">
          <Icon size={16} className="text-[var(--accent)]" />
        </div>
        <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-md border ${colors.bg} ${colors.text} ${colors.border}`}>
          {status}
        </span>
      </div>
      <div className="text-sm font-semibold text-foreground mb-0.5">
        {title}
      </div>
      <div className="text-[11px] text-gray-500">
        {description}
      </div>
    </div>
  );
}

// ============================================================
// CHANGE ACCOUNT PASSWORD PANEL
// ============================================================
function ChangePasswordPanel() {
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);

  const getStrength = () => {
    if (!newPassword) return { score: 0, label: "", color: "" };
    let score = 0;
    if (newPassword.length >= 8) score++;
    if (/[A-Z]/.test(newPassword)) score++;
    if (/[a-z]/.test(newPassword)) score++;
    if (/[0-9]/.test(newPassword)) score++;
    if (/[^A-Za-z0-9]/.test(newPassword)) score++;

    if (score <= 2) return { score, label: "Weak", color: "bg-red-500" };
    if (score <= 3) return { score, label: "Fair", color: "bg-yellow-500" };
    if (score <= 4) return { score, label: "Good", color: "bg-blue-500" };
    return { score, label: "Strong", color: "bg-green-500" };
  };

  const strength = getStrength();
  const passwordsMatch = newPassword && confirmPassword && newPassword === confirmPassword;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (newPassword !== confirmPassword) {
      setError("New passwords do not match");
      return;
    }

    setLoading(true);
    const result = await securityAPI.changePassword({
      currentPassword,
      newPassword,
    });
    setLoading(false);

    if (result.error) {
      setError(result.error);
      return;
    }

    setSuccess(true);
    setCurrentPassword("");
    setNewPassword("");
    setConfirmPassword("");
    setTimeout(() => setSuccess(false), 4000);
  };

  return (
    <div className="space-y-4">
      <AnimatePresence>
        {success && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="flex items-start gap-3 p-4 rounded-xl bg-green-500/10 border border-green-500/30"
          >
            <CheckCircle2 size={18} className="text-green-400 shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-green-300 mb-0.5">Password Changed</p>
              <p className="text-xs text-green-200/70">Your account password has been updated successfully.</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="flex items-start gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/20"
          >
            <AlertCircle size={14} className="text-red-400 shrink-0 mt-0.5" />
            <p className="text-xs text-red-400">{error}</p>
          </motion.div>
        )}
      </AnimatePresence>

      <form onSubmit={handleSubmit} className="space-y-4">
        <PasswordField
          label="Current Password"
          value={currentPassword}
          onChange={setCurrentPassword}
          show={showCurrent}
          onToggle={() => setShowCurrent(!showCurrent)}
          placeholder="Enter your current password"
        />

        <div>
          <PasswordField
            label="New Password"
            value={newPassword}
            onChange={setNewPassword}
            show={showNew}
            onToggle={() => setShowNew(!showNew)}
            placeholder="Create a strong password"
          />
          {newPassword && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              className="mt-2 flex items-center gap-2"
            >
              <div className="flex-1 grid grid-cols-5 gap-1">
                {[1, 2, 3, 4, 5].map((bar) => (
                  <div
                    key={bar}
                    className={`h-1 rounded-full transition-colors ${
                      bar <= strength.score ? strength.color : "bg-white/10"
                    }`}
                  />
                ))}
              </div>
              <span className={`text-[10px] font-semibold ${
                strength.score <= 2 ? "text-red-400" :
                strength.score <= 3 ? "text-yellow-400" :
                strength.score <= 4 ? "text-blue-400" : "text-green-400"
              }`}>
                {strength.label}
              </span>
            </motion.div>
          )}
        </div>

        <div>
          <PasswordField
            label="Confirm New Password"
            value={confirmPassword}
            onChange={setConfirmPassword}
            show={showConfirm}
            onToggle={() => setShowConfirm(!showConfirm)}
            placeholder="Re-enter new password"
          />
          {passwordsMatch && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="mt-2 flex items-center gap-1.5 text-[11px] text-green-400"
            >
              <CheckCircle2 size={12} />
              <span>Passwords match</span>
            </motion.div>
          )}
        </div>

        <button
          type="submit"
          disabled={loading || !currentPassword || !newPassword || !confirmPassword}
          className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-gradient-to-r from-[var(--accent)] to-purple-500 text-white font-semibold text-sm hover:opacity-95 transition-all active:scale-[0.98] shadow-lg shadow-[var(--accent)]/20 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {loading ? (
            <>
              <Loader2 size={16} className="animate-spin" />
              Changing Password...
            </>
          ) : (
            <>
              <Lock size={16} />
              Change Password
            </>
          )}
        </button>
      </form>
    </div>
  );
}

// ============================================================
// WITHDRAWAL PASSWORD PANEL
// ============================================================
function WithdrawalPasswordPanel({
  isSet,
  onSuccess,
}: {
  isSet: boolean;
  onSuccess: () => void;
}) {
  const [showAccount, setShowAccount] = useState(false);
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  const [accountPassword, setAccountPassword] = useState("");
  const [currentWithdrawalPassword, setCurrentWithdrawalPassword] = useState("");
  const [newWithdrawalPassword, setNewWithdrawalPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (newWithdrawalPassword !== confirmPassword) {
      setError("New passwords do not match");
      return;
    }

    setLoading(true);
    const result = await securityAPI.setWithdrawalPassword({
      accountPassword,
      newWithdrawalPassword,
      currentWithdrawalPassword: isSet ? currentWithdrawalPassword : undefined,
    });
    setLoading(false);

    if (result.error) {
      setError(result.error);
      return;
    }

    setSuccess(true);
    setAccountPassword("");
    setCurrentWithdrawalPassword("");
    setNewWithdrawalPassword("");
    setConfirmPassword("");
    onSuccess();
    setTimeout(() => setSuccess(false), 4000);
  };

  return (
    <div className="space-y-4">
      {!isSet && (
        <div className="flex items-start gap-3 p-4 rounded-xl bg-blue-500/[0.07] border border-blue-500/20">
          <AlertTriangle size={18} className="text-blue-400 shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-semibold text-blue-300 mb-0.5">
              First-Time Setup
            </p>
            <p className="text-xs text-blue-200/70">
              Set a dedicated withdrawal password for added security. Currently, your account password is used as fallback.
            </p>
          </div>
        </div>
      )}

      <AnimatePresence>
        {success && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="flex items-start gap-3 p-4 rounded-xl bg-green-500/10 border border-green-500/30"
          >
            <CheckCircle2 size={18} className="text-green-400 shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-green-300 mb-0.5">
                {isSet ? "Withdrawal Password Changed" : "Withdrawal Password Set"}
              </p>
              <p className="text-xs text-green-200/70">
                Your withdrawal password has been {isSet ? "updated" : "configured"} successfully.
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="flex items-start gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/20"
          >
            <AlertCircle size={14} className="text-red-400 shrink-0 mt-0.5" />
            <p className="text-xs text-red-400">{error}</p>
          </motion.div>
        )}
      </AnimatePresence>

      <form onSubmit={handleSubmit} className="space-y-4">
        <PasswordField
          label="Account Password (for verification)"
          value={accountPassword}
          onChange={setAccountPassword}
          show={showAccount}
          onToggle={() => setShowAccount(!showAccount)}
          placeholder="Enter your account password"
        />

        {isSet && (
          <PasswordField
            label="Current Withdrawal Password"
            value={currentWithdrawalPassword}
            onChange={setCurrentWithdrawalPassword}
            show={showCurrent}
            onToggle={() => setShowCurrent(!showCurrent)}
            placeholder="Enter current withdrawal password"
          />
        )}

        <PasswordField
          label={isSet ? "New Withdrawal Password" : "Withdrawal Password"}
          value={newWithdrawalPassword}
          onChange={setNewWithdrawalPassword}
          show={showNew}
          onToggle={() => setShowNew(!showNew)}
          placeholder="Create withdrawal password"
        />

        <PasswordField
          label="Confirm Withdrawal Password"
          value={confirmPassword}
          onChange={setConfirmPassword}
          show={showConfirm}
          onToggle={() => setShowConfirm(!showConfirm)}
          placeholder="Re-enter withdrawal password"
        />

        <button
          type="submit"
          disabled={loading}
          className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-gradient-to-r from-[var(--accent)] to-purple-500 text-white font-semibold text-sm hover:opacity-95 transition-all active:scale-[0.98] shadow-lg shadow-[var(--accent)]/20 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {loading ? (
            <>
              <Loader2 size={16} className="animate-spin" />
              {isSet ? "Updating..." : "Setting..."}
            </>
          ) : (
            <>
              <KeyRound size={16} />
              {isSet ? "Change Withdrawal Password" : "Set Withdrawal Password"}
            </>
          )}
        </button>
      </form>
    </div>
  );
}

// ============================================================
// REUSABLE PASSWORD FIELD
// ============================================================
function PasswordField({
  label,
  value,
  onChange,
  show,
  onToggle,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  show: boolean;
  onToggle: () => void;
  placeholder: string;
}) {
  return (
    <div>
      <label className="block text-xs font-medium text-gray-400 mb-2">
        {label} <span className="text-red-400">*</span>
      </label>
      <div className="relative">
        <Lock size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-500" />
        <input
          type={show ? "text" : "password"}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          required
          className="w-full pl-10 pr-11 py-3 bg-white/[0.03] border border-[var(--border)] rounded-xl text-sm text-foreground placeholder:text-gray-600 focus:outline-none focus:border-[var(--accent)]/50 focus:bg-white/[0.05] transition-all"
        />
        <button
          type="button"
          onClick={onToggle}
          className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300 transition-colors"
        >
          {show ? <EyeOff size={14} /> : <Eye size={14} />}
        </button>
      </div>
    </div>
  );
}