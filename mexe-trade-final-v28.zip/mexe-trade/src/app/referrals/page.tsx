// src/app/referrals/page.tsx
"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Users,
  Copy,
  Check,
  Share2,
  Gift,
  TrendingUp,
  UserCheck,
  Clock,
  DollarSign,
  Sparkles,
  Loader2,
  AlertCircle,
  ChevronRight,
  Mail,
  Calendar,
  ShieldCheck,
  UserX,
  Info,
  Link as LinkIcon,
} from "lucide-react";
import Link from "next/link";
import { useAuthStore } from "@/store/authStore";
import { referralsAPI } from "@/lib/api";

interface InvitedUser {
  id: string;
  maskedEmail: string;
  username: string | null;
  kycStatus: string;
  isActive: boolean;
  joinedAt: string | Date;
}

interface ReferralStats {
  totalInvited: number;
  activeUsers: number;
  pendingUsers: number;
  totalEarnings: number;
}

export default function ReferralsPage() {
  const { user } = useAuthStore();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [referralCode, setReferralCode] = useState("");
  const [stats, setStats] = useState<ReferralStats>({
    totalInvited: 0,
    activeUsers: 0,
    pendingUsers: 0,
    totalEarnings: 0,
  });
  const [invitedUsers, setInvitedUsers] = useState<InvitedUser[]>([]);
  const [copiedField, setCopiedField] = useState<"code" | "link" | null>(null);

  // ─── Fetch referrals data ───
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      const result = await referralsAPI.getStats();

      if (result.error) {
        setError(result.error);
        setLoading(false);
        return;
      }

      setReferralCode(result.referralCode || user?.referralCode || "");
      if (result.stats) setStats(result.stats as unknown as ReferralStats);
      if (result.invitedUsers) setInvitedUsers(result.invitedUsers as InvitedUser[]);
      setLoading(false);
    };

    fetchData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ─── Build referral link ───
  const referralLink =
    typeof window !== "undefined"
      ? `${window.location.origin}/signup?ref=${referralCode}`
      : `/signup?ref=${referralCode}`;

  // ─── Copy handlers ───
  const handleCopy = (text: string, field: "code" | "link") => {
    navigator.clipboard.writeText(text);
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 2000);
  };

  // ─── Share handler (uses native share API if available) ───
  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: "Join Premium Exchange",
          text: `Sign up using my referral code: ${referralCode}`,
          url: referralLink,
        });
      } catch {
        // User cancelled — silent
      }
    } else {
      handleCopy(referralLink, "link");
    }
  };

  // ─── Loading state ───
  if (loading) {
    return (
      <div className="min-h-full flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <Loader2 className="w-6 h-6 text-[var(--accent)] animate-spin" />
          <span className="text-xs text-gray-500">Loading referrals...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-full mesh-bg">
      <div className="max-w-5xl mx-auto p-4 sm:p-6 lg:p-8 space-y-5">
        {/* ═══════════ HEADER ═══════════ */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <h1 className="text-2xl sm:text-3xl font-bold text-foreground mb-1.5">
            Referrals Program
          </h1>
          <p className="text-sm text-gray-500">
            Invite friends and earn rewards for every successful referral
          </p>
        </motion.div>

        {/* ═══════════ ERROR BANNER ═══════════ */}
        <AnimatePresence>
          {error && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="flex items-start gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/20"
            >
              <AlertCircle size={14} className="text-red-400 shrink-0 mt-0.5" />
              <p className="text-xs text-red-400">{error}</p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* ═══════════ HERO CARD — REFERRAL CODE ═══════════ */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="relative overflow-hidden rounded-2xl border border-[var(--accent)]/20 bg-gradient-to-br from-[var(--accent)]/10 via-purple-500/5 to-transparent p-6 sm:p-8"
        >
          <div className="absolute -top-20 -right-20 w-64 h-64 rounded-full bg-[var(--accent)]/15 blur-3xl pointer-events-none" />
          <div className="absolute -bottom-20 -left-20 w-64 h-64 rounded-full bg-purple-500/10 blur-3xl pointer-events-none" />

          <div className="relative z-10">
            {/* Badge */}
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[var(--accent)]/10 border border-[var(--accent)]/20 mb-4">
              <Sparkles className="w-3 h-3 text-[var(--accent)]" />
              <span className="text-[10px] uppercase tracking-wider font-semibold text-[var(--accent)]">
                Your Referral Code
              </span>
            </div>

            {/* Code Display */}
            <div className="mb-5">
              <div className="flex items-center gap-3 mb-3">
                <div className="flex-1 flex items-center gap-3 p-4 rounded-xl bg-black/30 border border-[var(--border)] backdrop-blur-sm">
                  <Gift className="w-5 h-5 text-[var(--accent)] shrink-0" />
                  <code className="flex-1 text-xl sm:text-2xl font-bold gradient-text font-mono tracking-wider">
                    {referralCode || "—"}
                  </code>
                  <button
                    onClick={() => handleCopy(referralCode, "code")}
                    disabled={!referralCode}
                    className="shrink-0 flex items-center justify-center w-10 h-10 rounded-lg bg-[var(--accent)]/15 hover:bg-[var(--accent)]/25 text-[var(--accent)] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {copiedField === "code" ? <Check size={16} /> : <Copy size={16} />}
                  </button>
                </div>
              </div>

              {/* Referral Link */}
              <div className="flex items-center gap-2 p-3 rounded-lg bg-white/[0.02] border border-[var(--border)]">
                <LinkIcon size={13} className="text-gray-500 shrink-0" />
                <code className="flex-1 text-[11px] text-gray-400 font-mono truncate">
                  {referralLink}
                </code>
                <button
                  onClick={() => handleCopy(referralLink, "link")}
                  className="shrink-0 flex items-center gap-1 px-2.5 py-1.5 rounded-md bg-white/[0.05] hover:bg-white/[0.08] text-[10px] font-semibold text-gray-300 transition-colors"
                >
                  {copiedField === "link" ? (
                    <>
                      <Check size={11} />
                      Copied
                    </>
                  ) : (
                    <>
                      <Copy size={11} />
                      Copy
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Share Buttons */}
            <div className="flex flex-col sm:flex-row gap-3">
              <button
                onClick={handleShare}
                disabled={!referralCode}
                className="flex-1 flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-r from-[var(--accent)] to-purple-500 text-white font-semibold text-sm hover:opacity-95 transition-all active:scale-[0.98] shadow-lg shadow-[var(--accent)]/20 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Share2 size={16} />
                Share Referral
              </button>
              <button
                onClick={() => handleCopy(referralLink, "link")}
                disabled={!referralCode}
                className="flex-1 sm:flex-initial sm:px-6 flex items-center justify-center gap-2 px-5 py-3 rounded-xl border border-[var(--border)] text-foreground font-semibold text-sm hover:bg-white/[0.03] hover:border-[var(--accent)]/30 transition-all active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Copy size={16} />
                Copy Link
              </button>
            </div>
          </div>
        </motion.div>

        {/* ═══════════ STATS GRID ═══════════ */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4"
        >
          <StatCard
            icon={Users}
            label="Total Invited"
            value={stats.totalInvited.toString()}
            iconBg="bg-blue-500/10"
            iconColor="text-blue-400"
          />
          <StatCard
            icon={UserCheck}
            label="Active Users"
            value={stats.activeUsers.toString()}
            iconBg="bg-green-500/10"
            iconColor="text-green-400"
            subtitle="KYC verified"
          />
          <StatCard
            icon={Clock}
            label="Pending"
            value={stats.pendingUsers.toString()}
            iconBg="bg-amber-500/10"
            iconColor="text-amber-400"
            subtitle="Awaiting KYC"
          />
          <StatCard
            icon={DollarSign}
            label="Total Earnings"
            value={`$${stats.totalEarnings.toFixed(2)}`}
            iconBg="bg-purple-500/10"
            iconColor="text-purple-400"
            subtitle="Lifetime"
          />
        </motion.div>

        {/* ═══════════ HOW IT WORKS ═══════════ */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="glass-panel rounded-2xl p-5 sm:p-6"
        >
          <div className="flex items-center gap-2 mb-4">
            <div className="w-8 h-8 rounded-lg bg-[var(--accent)]/10 flex items-center justify-center">
              <Info size={15} className="text-[var(--accent)]" />
            </div>
            <h2 className="text-base font-bold text-foreground">How It Works</h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <HowItWorksStep
              step="1"
              icon={Share2}
              title="Share Your Code"
              description="Send your unique referral code or link to friends"
            />
            <HowItWorksStep
              step="2"
              icon={UserCheck}
              title="They Sign Up"
              description="Friends register using your code and complete KYC"
            />
            <HowItWorksStep
              step="3"
              icon={Gift}
              title="Earn Rewards"
              description="Get bonuses when they trade and deposit"
            />
          </div>
        </motion.div>

        {/* ═══════════ INVITED USERS LIST ═══════════ */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
        >
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-base sm:text-lg font-bold text-foreground">
              Invited Users
            </h2>
            <span className="text-xs text-gray-500">
              {invitedUsers.length} {invitedUsers.length === 1 ? "user" : "users"}
            </span>
          </div>

          <div className="glass-panel rounded-2xl overflow-hidden">
            {/* Empty State */}
            {invitedUsers.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 px-4 text-center">
                <div className="w-14 h-14 rounded-2xl bg-[var(--accent)]/10 flex items-center justify-center mb-3">
                  <Users size={24} className="text-[var(--accent)]" />
                </div>
                <h3 className="text-sm font-semibold text-foreground mb-1">
                  No Referrals Yet
                </h3>
                <p className="text-xs text-gray-500 max-w-xs mb-5">
                  Share your referral code with friends to start earning rewards
                </p>
                <button
                  onClick={handleShare}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-[var(--accent)] to-purple-500 text-white font-semibold text-xs hover:opacity-95 transition-all active:scale-[0.98]"
                >
                  <Share2 size={13} />
                  Share Now
                </button>
              </div>
            ) : (
              <>
                {/* Table Header (Desktop) */}
                <div className="hidden sm:grid grid-cols-12 gap-4 px-5 py-3 border-b border-[var(--border)] text-[10px] uppercase tracking-wider font-semibold text-gray-500">
                  <div className="col-span-5">User</div>
                  <div className="col-span-3">Status</div>
                  <div className="col-span-4 text-right">Joined</div>
                </div>

                {/* Users List */}
                <div className="divide-y divide-[var(--border)]">
                  {invitedUsers.map((u, idx) => (
                    <InvitedUserRow key={u.id} user={u} index={idx} />
                  ))}
                </div>
              </>
            )}
          </div>
        </motion.div>

        {/* ═══════════ FOOTER NOTE ═══════════ */}
        <div className="flex items-start gap-2.5 p-4 rounded-xl bg-white/[0.02] border border-[var(--border)]">
          <ShieldCheck size={14} className="text-gray-500 shrink-0 mt-0.5" />
          <p className="text-xs text-gray-500 leading-relaxed">
            Referral bonuses are credited automatically once invited users complete KYC verification and make their first deposit. Earnings are calculated based on referral program terms. For questions, contact{" "}
            <Link href="/chat" className="text-[var(--accent)] hover:underline">
              support
            </Link>
            .
          </p>
        </div>
      </div>
    </div>
  );
}

// ============================================================
// STAT CARD
// ============================================================
function StatCard({
  icon: Icon,
  label,
  value,
  iconBg,
  iconColor,
  subtitle,
}: {
  icon: React.ElementType;
  label: string;
  value: string;
  iconBg: string;
  iconColor: string;
  subtitle?: string;
}) {
  return (
    <div className="glass-panel rounded-2xl p-4 sm:p-5 hover:border-[var(--accent)]/30 transition-all duration-300">
      <div className={`w-9 h-9 rounded-lg ${iconBg} flex items-center justify-center mb-3`}>
        <Icon size={18} className={iconColor} />
      </div>
      <div className="text-[11px] text-gray-500 mb-1 uppercase tracking-wider font-medium">
        {label}
      </div>
      <div className="text-lg sm:text-xl font-bold text-foreground mb-0.5">
        {value}
      </div>
      {subtitle && (
        <div className="text-[10px] text-gray-500">{subtitle}</div>
      )}
    </div>
  );
}

// ============================================================
// HOW IT WORKS STEP
// ============================================================
function HowItWorksStep({
  step,
  icon: Icon,
  title,
  description,
}: {
  step: string;
  icon: React.ElementType;
  title: string;
  description: string;
}) {
  return (
    <div className="relative p-4 rounded-xl bg-white/[0.02] border border-[var(--border)]">
      <div className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-[var(--accent)] flex items-center justify-center text-[10px] font-bold text-white shadow-lg">
        {step}
      </div>
      <div className="w-10 h-10 rounded-xl bg-[var(--accent)]/10 flex items-center justify-center mb-3">
        <Icon size={18} className="text-[var(--accent)]" />
      </div>
      <h3 className="text-sm font-semibold text-foreground mb-1">{title}</h3>
      <p className="text-[11px] text-gray-500 leading-relaxed">{description}</p>
    </div>
  );
}

// ============================================================
// INVITED USER ROW
// ============================================================
function InvitedUserRow({
  user,
  index,
}: {
  user: InvitedUser;
  index: number;
}) {
  const joinedDate = new Date(user.joinedAt);
  const formattedDate = joinedDate.toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
  const formattedTime = joinedDate.toLocaleTimeString("en-US", {
    hour: "2-digit",
    minute: "2-digit",
  });

  // ─── Status badge config ───
  const statusConfig = {
    APPROVED: {
      label: "Verified",
      icon: ShieldCheck,
      color: "text-green-400",
      bg: "bg-green-500/10",
      border: "border-green-500/20",
    },
    PENDING: {
      label: "Pending",
      icon: Clock,
      color: "text-amber-400",
      bg: "bg-amber-500/10",
      border: "border-amber-500/20",
    },
    REJECTED: {
      label: "Rejected",
      icon: UserX,
      color: "text-red-400",
      bg: "bg-red-500/10",
      border: "border-red-500/20",
    },
    NONE: {
      label: "Unverified",
      icon: Clock,
      color: "text-gray-400",
      bg: "bg-gray-500/10",
      border: "border-gray-500/20",
    },
  }[user.kycStatus] || {
    label: "Unknown",
    icon: Clock,
    color: "text-gray-400",
    bg: "bg-gray-500/10",
    border: "border-gray-500/20",
  };

  const StatusIcon = statusConfig.icon;
  const initial = user.maskedEmail.charAt(0).toUpperCase();

  return (
    <motion.div
      initial={{ opacity: 0, x: -10 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: index * 0.03 }}
      className="grid grid-cols-12 gap-2 sm:gap-4 px-4 sm:px-5 py-3.5 hover:bg-white/[0.02] transition-colors items-center"
    >
      {/* User Info */}
      <div className="col-span-7 sm:col-span-5 flex items-center gap-3">
        <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[var(--accent)] to-purple-500 flex items-center justify-center text-white font-bold text-xs shrink-0">
          {initial}
        </div>
        <div className="min-w-0 flex-1">
          <div className="text-sm font-medium text-foreground truncate flex items-center gap-1.5">
            <Mail size={11} className="text-gray-500 shrink-0" />
            <span className="font-mono text-xs">{user.maskedEmail}</span>
          </div>
          {user.username && (
            <div className="text-[10px] text-gray-500 truncate">
              @{user.username}
            </div>
          )}
        </div>
      </div>

      {/* Status Badge */}
      <div className="col-span-5 sm:col-span-3">
        <div
          className={`inline-flex items-center gap-1 px-2 py-1 rounded-md text-[10px] font-semibold border ${statusConfig.bg} ${statusConfig.color} ${statusConfig.border}`}
        >
          <StatusIcon size={10} />
          {statusConfig.label}
        </div>
      </div>

      {/* Date (Desktop only) */}
      <div className="hidden sm:block col-span-4 text-right">
        <div className="text-xs font-medium text-foreground flex items-center justify-end gap-1.5">
          <Calendar size={11} className="text-gray-500" />
          {formattedDate}
        </div>
        <div className="text-[10px] text-gray-500 mt-0.5">{formattedTime}</div>
      </div>
    </motion.div>
  );
}