// src/app/api/trades/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getAuthToken } from "@/lib/cookies";
import { getUserFromToken } from "@/lib/auth";
import { COINGECKO_TO_BINANCE, fetchLivePrice, isPriceWithinTolerance } from "@/lib/markets";

// Binance blocks requests from US datacenter IPs (default Vercel region).
// Pin this function to a region Binance doesn't block. fetchLivePrice()
// also falls back to CoinGecko if Binance still fails.
export const preferredRegion = ["sin1", "hnd1", "fra1"];

// ─── Trading fee ───
// No fee is charged on open. (Previously this scaled with leveraged
// position size, which silently ate into the user's balance beyond the
// margin they intended to commit — e.g. a $500 margin at 20x leverage
// was charged a $10 fee, leaving $490 instead of $500 deducted.)
const TRADING_FEE_PERCENT = 0; // 0% — no opening fee

// ─── POST: Open a new trade ───
export async function POST(req: NextRequest) {
  try {
    const token = await getAuthToken();
    const user = await getUserFromToken(token);

    if (!user) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }

    const body = await req.json();
    const {
      coinId,
      coinSymbol,
      side,
      orderType,
      leverage,
      marginAmount,
      entryPrice,
    }: {
      coinId: string;
      coinSymbol: string;
      side: "BUY" | "SELL";
      orderType: "MARKET" | "LIMIT";
      leverage: number;
      marginAmount: number;
      entryPrice: number;
    } = body;

    // ─── Validation ───
    if (!coinId || !coinSymbol) {
      return NextResponse.json(
        { error: "Coin information is required" },
        { status: 400 }
      );
    }

    if (!["BUY", "SELL"].includes(side)) {
      return NextResponse.json({ error: "Invalid trade side" }, { status: 400 });
    }

    if (!leverage || leverage < 1 || leverage > 100) {
      return NextResponse.json(
        { error: "Leverage must be between 1x and 100x" },
        { status: 400 }
      );
    }

    if (!marginAmount || marginAmount <= 0) {
      return NextResponse.json(
        { error: "Invalid margin amount" },
        { status: 400 }
      );
    }

    if (marginAmount < 1) {
      return NextResponse.json(
        { error: "Minimum trade amount is $1" },
        { status: 400 }
      );
    }

    if (marginAmount > user.balance) {
      return NextResponse.json(
        { error: "Insufficient balance" },
        { status: 400 }
      );
    }

    if (!entryPrice || entryPrice <= 0) {
      return NextResponse.json(
        { error: "Invalid entry price" },
        { status: 400 }
      );
    }

    // ─── Get Binance symbol for reference ───
    const binanceSymbol = COINGECKO_TO_BINANCE[coinId] || `${coinSymbol.toUpperCase()}USDT`;

    // ─── SECURITY: Verify price server-side (never trust client price) ───
    const livePrice = await fetchLivePrice(binanceSymbol);
    if (!livePrice) {
      return NextResponse.json(
        { error: "Unable to verify market price right now. Please try again." },
        { status: 503 }
      );
    }
    if (!isPriceWithinTolerance(entryPrice, livePrice)) {
      return NextResponse.json(
        { error: "Price has moved. Please refresh and try again." },
        { status: 409 }
      );
    }
    const verifiedEntryPrice = livePrice; // authoritative server price

    // ─── Calculate trade values ───
    const positionSize = marginAmount * leverage;
    const quantity = positionSize / verifiedEntryPrice;
    const fee = (positionSize * TRADING_FEE_PERCENT) / 100; // always $0 — no opening fee
    const totalDeduction = marginAmount + fee;

    if (totalDeduction > user.balance) {
      return NextResponse.json(
        { error: "Insufficient balance" },
        { status: 400 }
      );
    }

    // ─── Atomic transaction: deduct balance + create trade ───
    // Conditional decrement prevents race conditions (concurrent trades
    // can no longer drive the balance negative).
    const result = await prisma.$transaction(async (tx) => {
      const deducted = await tx.user.updateMany({
        where: { id: user.id, balance: { gte: totalDeduction } },
        data: { balance: { decrement: totalDeduction } },
      });

      if (deducted.count === 0) {
        throw new Error("INSUFFICIENT_BALANCE");
      }

      // Create trade record
      const trade = await tx.trade.create({
        data: {
          userId: user.id,
          coinId,
          coinSymbol: coinSymbol.toUpperCase(),
          binanceSymbol,
          side,
          orderType: orderType || "MARKET",
          leverage,
          marginAmount,
          positionSize,
          quantity,
          entryPrice: verifiedEntryPrice,
          fee,
          status: "OPEN",
        },
      });

      return trade;
    });

    return NextResponse.json(
      {
        success: true,
        message: `${side === "BUY" ? "Long" : "Short"} position opened successfully`,
        trade: result,
      },
      { status: 201 }
    );
  } catch (error) {
    if (error instanceof Error && error.message === "INSUFFICIENT_BALANCE") {
      return NextResponse.json(
        { error: "Insufficient balance" },
        { status: 400 }
      );
    }
    console.error("Trade open error:", error);
    return NextResponse.json(
      { error: "Failed to open trade" },
      { status: 500 }
    );
  }
}

// ─── GET: Fetch user's trades (with optional status filter) ───
export async function GET(req: NextRequest) {
  try {
    const token = await getAuthToken();
    const user = await getUserFromToken(token);

    if (!user) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const statusFilter = searchParams.get("status"); // "OPEN" | "CLOSED" | null (all)

    const whereClause: { userId: string; status?: string } = {
      userId: user.id,
    };
    if (statusFilter && ["OPEN", "CLOSED", "LIQUIDATED"].includes(statusFilter)) {
      whereClause.status = statusFilter;
    }

    const trades = await prisma.trade.findMany({
      where: whereClause,
      orderBy: [
        { status: "asc" }, // OPEN first
        { openedAt: "desc" },
      ],
    });

    // Calculate stats
    const openTrades = trades.filter((t) => t.status === "OPEN");
    const closedTrades = trades.filter((t) => t.status !== "OPEN");
    const totalMarginInPositions = openTrades.reduce((sum, t) => sum + t.marginAmount, 0);
    const totalRealizedPnL = closedTrades.reduce((sum, t) => sum + t.pnl, 0);

    return NextResponse.json(
      {
        success: true,
        trades,
        stats: {
          openCount: openTrades.length,
          closedCount: closedTrades.length,
          totalMarginInPositions,
          totalRealizedPnL,
        },
      },
      { status: 200 }
    );
  } catch (error) {
    console.error("Fetch trades error:", error);
    return NextResponse.json(
      { error: "Failed to fetch trades" },
      { status: 500 }
    );
  }
}