// src/app/api/trades/close/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getAuthToken } from "@/lib/cookies";
import { getUserFromToken } from "@/lib/auth";
import { fetchLivePrice, isPriceWithinTolerance } from "@/lib/markets";

// Binance blocks requests from US datacenter IPs (default Vercel region).
// Pin this function to a region Binance doesn't block. fetchLivePrice()
// also falls back to CoinGecko if Binance still fails.
export const preferredRegion = ["sin1", "hnd1", "fra1"];

// ─── POST: Close an open trade (client self-close) ───
export async function POST(req: NextRequest) {
  try {
    const token = await getAuthToken();
    const user = await getUserFromToken(token);

    if (!user) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }

    const body = await req.json();
    const { tradeId, exitPrice }: { tradeId: string; exitPrice: number } = body;

    if (!tradeId) {
      return NextResponse.json({ error: "Trade ID is required" }, { status: 400 });
    }

    if (!exitPrice || exitPrice <= 0) {
      return NextResponse.json(
        { error: "Invalid exit price" },
        { status: 400 }
      );
    }

    // ─── Fetch the trade ───
    const trade = await prisma.trade.findUnique({
      where: { id: tradeId },
    });

    if (!trade) {
      return NextResponse.json({ error: "Trade not found" }, { status: 404 });
    }

    if (trade.userId !== user.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
    }

    if (trade.status !== "OPEN") {
      return NextResponse.json(
        { error: "This trade is already closed" },
        { status: 400 }
      );
    }

    // ─── SECURITY: Verify exit price server-side (never trust client price) ───
    let pnl: number;
    let pnlPercent: number;
    let recordedExitPrice: number;

    const livePrice = await fetchLivePrice(trade.binanceSymbol);
    if (!livePrice) {
      return NextResponse.json(
        { error: "Unable to verify market price right now. Please try again." },
        { status: 503 }
      );
    }
    if (!isPriceWithinTolerance(exitPrice, livePrice)) {
      return NextResponse.json(
        { error: "Price has moved. Please refresh and try again." },
        { status: 409 }
      );
    }
    const verifiedExitPrice = livePrice; // authoritative server price
    recordedExitPrice = verifiedExitPrice;

    // For BUY (long): profit when exitPrice > entryPrice
    // For SELL (short): profit when exitPrice < entryPrice
    let priceChangePercent: number;
    if (trade.side === "BUY") {
      priceChangePercent = ((verifiedExitPrice - trade.entryPrice) / trade.entryPrice) * 100;
    } else {
      priceChangePercent = ((trade.entryPrice - verifiedExitPrice) / trade.entryPrice) * 100;
    }

    // P&L in dollars = (priceChangePercent × positionSize) / 100
    pnl = (priceChangePercent * trade.positionSize) / 100;
    pnlPercent = priceChangePercent * trade.leverage; // leveraged return %

    // No closing fee — full margin + P&L returned to user.
    let amountToReturn = trade.marginAmount + pnl;

    // Prevent negative return (partial liquidation)
    let closeReason = "MANUAL";
    if (amountToReturn < 0) {
      amountToReturn = 0;
      closeReason = "LIQUIDATED";
    }

    // ─── Atomic transaction: update trade + credit balance ───
    const result = await prisma.$transaction(async (tx) => {
      // Conditional update: only closes if still OPEN. This prevents a
      // double-close race from crediting the balance twice.
      const closed = await tx.trade.updateMany({
        where: { id: tradeId, status: "OPEN" },
        data: {
          status: "CLOSED",
          exitPrice: recordedExitPrice,
          pnl,
          pnlPercent,
          closedAt: new Date(),
          closeReason,
        },
      });

      if (closed.count === 0) {
        throw new Error("ALREADY_CLOSED");
      }

      // Credit user balance
      if (amountToReturn > 0) {
        await tx.user.update({
          where: { id: user.id },
          data: { balance: { increment: amountToReturn } },
        });
      }

      return tx.trade.findUnique({ where: { id: tradeId } });
    });

    return NextResponse.json(
      {
        success: true,
        message:
          closeReason === "LIQUIDATED"
            ? "Position liquidated (losses exceeded margin)"
            : `Position closed. ${pnl >= 0 ? "Profit" : "Loss"}: $${Math.abs(pnl).toFixed(2)}`,
        trade: result,
        pnl,
        pnlPercent,
        amountReturned: amountToReturn,
      },
      { status: 200 }
    );
  } catch (error) {
    if (error instanceof Error && error.message === "ALREADY_CLOSED") {
      return NextResponse.json(
        { error: "This trade is already closed" },
        { status: 400 }
      );
    }
    console.error("Trade close error:", error);
    return NextResponse.json(
      { error: "Failed to close trade" },
      { status: 500 }
    );
  }
}