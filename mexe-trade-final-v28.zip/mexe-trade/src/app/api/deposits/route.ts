// src/app/api/deposits/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getAuthToken } from "@/lib/cookies";
import { getUserFromToken } from "@/lib/auth";
import { saveUploadedFile, validateFile } from "@/lib/upload";
import { TRANSACTION_LIMITS } from "@/config/constants";

// ─── POST: Create deposit request ───
export async function POST(req: NextRequest) {
  try {
    // Auth check
    const token = await getAuthToken();
    const user = await getUserFromToken(token);

    if (!user) {
      return NextResponse.json(
        { error: "Not authenticated" },
        { status: 401 }
      );
    }

    // Parse multipart form data
    const formData = await req.formData();
    const amount = parseFloat(formData.get("amount") as string);
    const txId = formData.get("txId") as string;
    const method = formData.get("method") as string; // crypto | bank
    const network = formData.get("network") as string;
    const screenshot = formData.get("screenshot") as File | null;

    // Validation
    if (!amount || amount < TRANSACTION_LIMITS.MIN_DEPOSIT_USD) {
      return NextResponse.json(
        { error: `Minimum deposit is $${TRANSACTION_LIMITS.MIN_DEPOSIT_USD}` },
        { status: 400 }
      );
    }

    if (amount > TRANSACTION_LIMITS.MAX_DEPOSIT_USD) {
      return NextResponse.json(
        { error: `Maximum deposit is $${TRANSACTION_LIMITS.MAX_DEPOSIT_USD}` },
        { status: 400 }
      );
    }

    if (!txId || !txId.trim()) {
      return NextResponse.json(
        { error: "Transaction ID is required" },
        { status: 400 }
      );
    }

    if (!screenshot) {
      return NextResponse.json(
        { error: "Payment screenshot is required" },
        { status: 400 }
      );
    }

    // Validate screenshot file
    const fileValidation = validateFile(screenshot, { maxSizeMB: 5 });
    if (!fileValidation.valid) {
      return NextResponse.json({ error: fileValidation.error }, { status: 400 });
    }

    // Save screenshot to disk
    const screenshotUrl = await saveUploadedFile(screenshot, "deposits");

    // Create deposit record
    const deposit = await prisma.deposit.create({
      data: {
        userId: user.id,
        amount,
        currency: "USDT",
        network: network || "TRC20",
        method: method === "bank" ? "BANK_TRANSFER" : "CRYPTO",
        txId: txId.trim(),
        screenshotUrl,
        status: "PENDING",
      },
    });

    return NextResponse.json(
      {
        success: true,
        message: "Deposit request submitted successfully",
        deposit,
      },
      { status: 201 }
    );
  } catch (error) {
    console.error("Deposit error:", error);
    return NextResponse.json(
      { error: "Failed to submit deposit request" },
      { status: 500 }
    );
  }
}

// ─── GET: Fetch user's deposits ───
export async function GET() {
  try {
    const token = await getAuthToken();
    const user = await getUserFromToken(token);

    if (!user) {
      return NextResponse.json(
        { error: "Not authenticated" },
        { status: 401 }
      );
    }

    const deposits = await prisma.deposit.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: "desc" },
    });

    return NextResponse.json({ deposits }, { status: 200 });
  } catch (error) {
    console.error("Fetch deposits error:", error);
    return NextResponse.json(
      { error: "Failed to fetch deposits" },
      { status: 500 }
    );
  }
}