// src/app/api/kyc/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getAuthToken } from "@/lib/cookies";
import { getUserFromToken } from "@/lib/auth";
import { saveUploadedFile, validateFile } from "@/lib/upload";

// KYC uploads several images (front, back, selfie) to Cloudinary in one
// request. The default 10s serverless timeout can kill that mid-upload on
// slower connections, which surfaces to the user as a generic
// "Network error". Give it plenty of headroom.
export const maxDuration = 60;

// Run in Singapore, next to the Neon database (ap-southeast-1). The default
// US region added a US<->Asia round-trip to every DB call, which — stacked
// on top of the user's own latency from India/UAE — pushed total request
// time over the timeout. Running here removes that entirely.
export const preferredRegion = ["sin1", "hnd1"];

// ─── POST: Submit KYC ───
export async function POST(req: NextRequest) {
  try {
    const token = await getAuthToken();
    const user = await getUserFromToken(token);

    if (!user) {
      return NextResponse.json(
        { error: "Not authenticated" },
        { status: 401 }
      );
    }

    // Prevent re-submission if already approved
    if (user.kycStatus === "APPROVED") {
      return NextResponse.json(
        { error: "Your KYC is already approved" },
        { status: 400 }
      );
    }

    // Prevent submission if already pending
    if (user.kycStatus === "PENDING") {
      return NextResponse.json(
        { error: "You already have a pending KYC submission. Please wait for review." },
        { status: 400 }
      );
    }

    const formData = await req.formData();
    const documentType = formData.get("documentType") as string;
    const fullName = formData.get("fullName") as string;
    const dateOfBirth = formData.get("dateOfBirth") as string;
    const documentNumber = formData.get("documentNumber") as string;
    const documentFront = formData.get("documentFront") as File | null;
    const documentBack = formData.get("documentBack") as File | null;
    const selfie = formData.get("selfie") as File | null;

    // Validation
    if (!documentType || !["NATIONAL_ID", "DRIVING_LICENSE", "PASSPORT"].includes(documentType)) {
      return NextResponse.json(
        { error: "Invalid document type" },
        { status: 400 }
      );
    }

    if (!fullName?.trim() || fullName.trim().length < 2) {
      return NextResponse.json(
        { error: "Full name is required (minimum 2 characters)" },
        { status: 400 }
      );
    }

    if (!dateOfBirth?.trim()) {
      return NextResponse.json(
        { error: "Date of birth is required" },
        { status: 400 }
      );
    }

    if (!documentNumber?.trim()) {
      return NextResponse.json(
        { error: "Document number is required" },
        { status: 400 }
      );
    }

    if (!documentFront) {
      return NextResponse.json(
        { error: "Document front image is required" },
        { status: 400 }
      );
    }

    if (!selfie) {
      return NextResponse.json(
        { error: "Selfie image is required" },
        { status: 400 }
      );
    }

    // PASSPORT doesn't need back side
    if (documentType !== "PASSPORT" && !documentBack) {
      return NextResponse.json(
        { error: "Document back image is required" },
        { status: 400 }
      );
    }

    // Validate files
    const frontValidation = validateFile(documentFront, { maxSizeMB: 5 });
    if (!frontValidation.valid) {
      return NextResponse.json({ error: `Front image: ${frontValidation.error}` }, { status: 400 });
    }

    const selfieValidation = validateFile(selfie, { maxSizeMB: 5 });
    if (!selfieValidation.valid) {
      return NextResponse.json({ error: `Selfie: ${selfieValidation.error}` }, { status: 400 });
    }

    if (documentBack) {
      const backValidation = validateFile(documentBack, { maxSizeMB: 5 });
      if (!backValidation.valid) {
        return NextResponse.json({ error: `Back image: ${backValidation.error}` }, { status: 400 });
      }
    }

    // Upload all images to Cloudinary in parallel (not one-by-one).
    // Sequential awaits meant total time = front + back + selfie, which
    // on slow connections could exceed the function timeout and surface
    // as a "Network error". Parallel = roughly the time of the slowest one.
    const [documentFrontUrl, selfieUrl, documentBackUrl] = await Promise.all([
      saveUploadedFile(documentFront, "kyc"),
      saveUploadedFile(selfie, "kyc"),
      documentBack ? saveUploadedFile(documentBack, "kyc") : Promise.resolve(null),
    ]);

    // Create KYC submission + update user status atomically
    const submission = await prisma.$transaction(async (tx) => {
      const kyc = await tx.kYCSubmission.create({
        data: {
          userId: user.id,
          documentType,
          fullName: fullName.trim(),
          dateOfBirth: dateOfBirth.trim(),
          documentNumber: documentNumber.trim(),
          documentFrontUrl,
          documentBackUrl,
          selfieUrl,
          status: "PENDING",
        },
      });

      await tx.user.update({
        where: { id: user.id },
        data: { kycStatus: "PENDING" },
      });

      return kyc;
    });

    return NextResponse.json(
      {
        success: true,
        message: "KYC submitted successfully. Review takes 1-3 business days.",
        submission,
      },
      { status: 201 }
    );
  } catch (error) {
    console.error("KYC submission error:", error);
    return NextResponse.json(
      { error: "Failed to submit KYC. Please try again." },
      { status: 500 }
    );
  }
}

// ─── GET: Fetch user's latest KYC status ───
export async function GET() {
  try {
    const token = await getAuthToken();
    const user = await getUserFromToken(token);

    if (!user) {
      return NextResponse.json(
        { error: "Not authenticated" },
        { status: 401 }
      );
    }

    // Get most recent submission
    const submission = await prisma.kYCSubmission.findFirst({
      where: { userId: user.id },
      orderBy: { createdAt: "desc" },
    });

    return NextResponse.json(
      {
        kycStatus: user.kycStatus,
        submission,
      },
      { status: 200 }
    );
  } catch (error) {
    console.error("Fetch KYC error:", error);
    return NextResponse.json(
      { error: "Failed to fetch KYC status" },
      { status: 500 }
    );
  }
}