// src/app/api/markets/route.ts
import { NextResponse } from "next/server";
import { fetchMarkets } from "@/lib/markets";

// Tell Next.js not to statically cache this at build time
export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const markets = await fetchMarkets();

    if (markets.length === 0) {
      return NextResponse.json(
        { error: "Failed to fetch market data" },
        { status: 503 }
      );
    }

    return NextResponse.json(
      { markets },
      {
        status: 200,
        headers: {
          // Allow CDN / browser to serve a cached response for up to 30 s
          "Cache-Control": "public, s-maxage=30, stale-while-revalidate=60",
        },
      }
    );
  } catch (error) {
    console.error("Markets API error:", error);
    return NextResponse.json(
      { error: "Failed to fetch markets" },
      { status: 500 }
    );
  }
}
