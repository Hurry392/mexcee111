// src/app/api/markets/chart/route.ts
import { NextRequest, NextResponse } from "next/server";
import {
  fetchBinanceKlines,
  COINGECKO_TO_BINANCE,
  fetchOHLC,
} from "@/lib/markets";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const coinId = searchParams.get("coin") || "bitcoin";
    const days = parseInt(searchParams.get("days") || "1");

    const binanceSymbol = COINGECKO_TO_BINANCE[coinId];

    // ─── Primary: Try Binance (works for all supported coins) ───
    if (binanceSymbol) {
      const candles = await fetchBinanceKlines(binanceSymbol, days);
      if (candles.length > 0) {
        return NextResponse.json(
          { candles, source: "binance" },
          { status: 200 }
        );
      }
    }

    // ─── Fallback: CoinGecko OHLC (if Binance fails for some reason) ───
    const candles = await fetchOHLC(coinId, days);
    if (candles.length > 0) {
      return NextResponse.json(
        { candles, source: "coingecko" },
        { status: 200 }
      );
    }

    return NextResponse.json(
      { error: "No chart data available for this coin" },
      { status: 404 }
    );
  } catch (error) {
    console.error("Chart API error:", error);
    return NextResponse.json(
      { error: "Failed to fetch chart data" },
      { status: 500 }
    );
  }
}