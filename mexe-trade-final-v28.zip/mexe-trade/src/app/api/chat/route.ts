// src/app/api/chat/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getAuthToken } from "@/lib/cookies";
import { getUserFromToken } from "@/lib/auth";
import { saveUploadedFile, validateFile } from "@/lib/upload";

// ─── GET: Fetch user's chat messages ───
export async function GET() {
  try {
    const token = await getAuthToken();
    const user = await getUserFromToken(token);

    if (!user) {
      return NextResponse.json(
        { error: "Not authenticated" },
        { status: 401 }
      );
    }

    // Fetch all messages for this user (both USER and ADMIN messages)
    // Exclude messages the user deleted for themselves; transform
    // "deleted for everyone" messages into a tombstone stub.
    const rawMessages = await prisma.chatMessage.findMany({
      where: {
        userId: user.id,
        deletedByUser: false, // hide messages the user removed from their view
      },
      orderBy: { createdAt: "asc" },
    });

    const messages = rawMessages.map((m) => {
      // Tombstone for "deleted for everyone"
      if (m.deletedForEveryone) {
        return { ...m, message: "", imageUrl: null, deletedForEveryone: true };
      }
      // If the admin edited this message, deliver the edited text to the user.
      // The original (m.message) is never exposed to the user side.
      if (m.editedMessage) {
        return { ...m, message: m.editedMessage, isEdited: true };
      }
      return m;
    });

    // Mark unread ADMIN messages as read (user has seen them now)
    await prisma.chatMessage.updateMany({
      where: {
        userId: user.id,
        sender: "ADMIN",
        isRead: false,
      },
      data: { isRead: true },
    });

    return NextResponse.json({ messages }, { status: 200 });
  } catch (error) {
    console.error("Chat GET error:", error);
    return NextResponse.json(
      { error: "Failed to fetch messages" },
      { status: 500 }
    );
  }
}

// ─── POST: Send a new message ───
export async function POST(req: NextRequest) {
  try {
    const token = await getAuthToken();
    const user = await getUserFromToken(token);

    if (!user) {
      return NextResponse.json(
        { error: "Not authenticated" },
        { status: 401 }
      );
    }

    // Check content type for FormData vs JSON
    const contentType = req.headers.get("content-type") || "";

    let message = "";
    let imageUrl: string | null = null;

    if (contentType.includes("multipart/form-data")) {
      // Handle FormData (message + optional image)
      const formData = await req.formData();
      message = (formData.get("message") as string) || "";
      const imageFile = formData.get("image") as File | null;

      if (imageFile && imageFile.size > 0) {
        // Validate image
        const validation = validateFile(imageFile, { maxSizeMB: 5 });
        if (!validation.valid) {
          return NextResponse.json(
            { error: validation.error },
            { status: 400 }
          );
        }
        // Save to public/uploads/chat/
        imageUrl = await saveUploadedFile(imageFile, "chat");
      }
    } else {
      // Handle JSON body
      const body = await req.json();
      message = body.message || "";
    }

    // Validate message
    if (!message.trim() && !imageUrl) {
      return NextResponse.json(
        { error: "Message cannot be empty" },
        { status: 400 }
      );
    }

    if (message.length > 2000) {
      return NextResponse.json(
        { error: "Message too long (max 2000 characters)" },
        { status: 400 }
      );
    }

    // Create message in DB
    const chatMessage = await prisma.chatMessage.create({
      data: {
        userId: user.id,
        message: message.trim(),
        imageUrl,
        sender: "USER",
        isRead: false,
      },
    });

    return NextResponse.json(
      {
        success: true,
        message: "Message sent",
        chatMessage,
      },
      { status: 201 }
    );
  } catch (error) {
    console.error("Chat POST error:", error);
    return NextResponse.json(
      { error: "Failed to send message" },
      { status: 500 }
    );
  }
}