// src/app/api/chat/admin-reply/route.ts
// ⚠️ TEMPORARY DEV-ONLY ENDPOINT
// Disabled in production. Will be replaced with admin-auth-protected version in Phase 7.
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function POST(req: NextRequest) {
  // 🛡️ Security: Block in production builds
  if (process.env.NODE_ENV === "production") {
    return NextResponse.json(
      { error: "This endpoint is disabled in production" },
      { status: 403 }
    );
  }

  try {
    const body = await req.json();
    const { userId, message } = body;

    if (!userId || !message) {
      return NextResponse.json(
        { error: "userId and message are required" },
        { status: 400 }
      );
    }

    const user = await prisma.user.findUnique({
      where: { id: userId },
    });

    if (!user) {
      return NextResponse.json(
        { error: "User not found" },
        { status: 404 }
      );
    }

    const chatMessage = await prisma.chatMessage.create({
      data: {
        userId,
        message: message.trim(),
        sender: "ADMIN",
        isRead: false,
      },
    });

    return NextResponse.json(
      {
        success: true,
        message: "Admin reply sent (DEV MODE)",
        chatMessage,
      },
      { status: 201 }
    );
  } catch (error) {
    console.error("Admin reply error:", error);
    return NextResponse.json(
      { error: "Failed to send admin reply" },
      { status: 500 }
    );
  }
}