// src/app/api/chat/[messageId]/route.ts
// User: delete a chat message either only for themselves, or for everyone
// (only allowed for messages they sent themselves).

import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getAuthToken } from "@/lib/cookies";
import { getUserFromToken } from "@/lib/auth";

export async function PATCH(
  req: NextRequest,
  context: { params: Promise<{ messageId: string }> }
) {
  // ── Auth ──────────────────────────────────────────────────────
  const token = await getAuthToken();
  const user = await getUserFromToken(token);

  if (!user) {
    return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
  }

  const { messageId } = await context.params;

  try {
    const body = await req.json();
    const { type } = body as { type: "forMe" | "forEveryone" };

    if (!["forMe", "forEveryone"].includes(type)) {
      return NextResponse.json(
        { error: "Invalid type. Use forMe or forEveryone." },
        { status: 400 }
      );
    }

    // ── Verify the message belongs to this user's conversation ───
    const existing = await prisma.chatMessage.findFirst({
      where: { id: messageId, userId: user.id },
      select: {
        id: true,
        sender: true,
        deletedForEveryone: true,
        deletedByUser: true,
      },
    });

    if (!existing) {
      return NextResponse.json({ error: "Message not found." }, { status: 404 });
    }

    if (type === "forEveryone") {
      // Users can only "delete for everyone" their own messages
      if (existing.sender !== "USER") {
        return NextResponse.json(
          { error: "You can only delete your own messages for everyone." },
          { status: 403 }
        );
      }

      await prisma.chatMessage.update({
        where: { id: messageId },
        data: { deletedForEveryone: true },
      });
    } else {
      // forMe — hide only from this user's view
      await prisma.chatMessage.update({
        where: { id: messageId },
        data: { deletedByUser: true },
      });
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("User delete message error:", error);
    return NextResponse.json(
      { error: "Failed to delete message. Please try again." },
      { status: 500 }
    );
  }
}
