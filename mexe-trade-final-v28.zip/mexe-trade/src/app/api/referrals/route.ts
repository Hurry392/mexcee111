// src/app/api/referrals/route.ts
import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getAuthToken } from "@/lib/cookies";
import { getUserFromToken } from "@/lib/auth";

export async function GET() {
  try {
    // ─── Auth check ───
    const token = await getAuthToken();
    if (!token) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }

    const user = await getUserFromToken(token);
    if (!user) {
      return NextResponse.json({ error: "Invalid session" }, { status: 401 });
    }

    // ─── Fetch all users referred by current user's code ───
    const invitedUsers = await prisma.user.findMany({
      where: {
        referredBy: user.referralCode,
      },
      select: {
        id: true,
        email: true,
        username: true,
        kycStatus: true,
        isActive: true,
        createdAt: true,
      },
      orderBy: {
        createdAt: "desc",
      },
    });

    // ─── Calculate stats ───
    const totalInvited = invitedUsers.length;
    const activeUsers = invitedUsers.filter(
      (u) => u.isActive && u.kycStatus === "APPROVED"
    ).length;
    const pendingUsers = invitedUsers.filter(
      (u) => u.kycStatus === "PENDING" || u.kycStatus === "NONE"
    ).length;

    // ─── Mask emails for privacy (show first 2 chars + domain) ───
    const maskedUsers = invitedUsers.map((u) => {
      const email = u.email;
      let maskedEmail = email;

      // Don't mask phone-placeholder emails — show as "Phone User"
      if (email.endsWith("@phone.pe")) {
        maskedEmail = "Phone User";
      } else {
        const [local, domain] = email.split("@");
        if (local && domain) {
          const visible = local.slice(0, 2);
          const masked = "*".repeat(Math.max(local.length - 2, 3));
          maskedEmail = `${visible}${masked}@${domain}`;
        }
      }

      return {
        id: u.id,
        maskedEmail,
        username: u.username,
        kycStatus: u.kycStatus,
        isActive: u.isActive,
        joinedAt: u.createdAt,
      };
    });

    // ─── Earnings placeholder (Phase 7 will calculate real earnings) ───
    const totalEarnings = 0;

    return NextResponse.json(
      {
        success: true,
        referralCode: user.referralCode,
        stats: {
          totalInvited,
          activeUsers,
          pendingUsers,
          totalEarnings,
        },
        invitedUsers: maskedUsers,
      },
      { status: 200 }
    );
  } catch (error) {
    console.error("Referrals API error:", error);
    return NextResponse.json(
      { error: "Failed to fetch referrals data" },
      { status: 500 }
    );
  }
}