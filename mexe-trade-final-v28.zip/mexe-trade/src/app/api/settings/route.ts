// src/app/api/settings/route.ts
import { NextResponse } from "next/server";
import { getPlatformSettings } from "@/lib/platformSettings";

/**
 * Public endpoint — returns only user-facing settings.
 * Filters out sensitive admin-only info.
 */
export async function GET() {
  try {
    const settings = await getPlatformSettings();

    // Return user-safe subset
    return NextResponse.json({
      success: true,
      settings: {
        trc20WalletAddress: settings.trc20WalletAddress,
        minDeposit: settings.minDeposit,
        maxDeposit: settings.maxDeposit,
        minWithdrawal: settings.minWithdrawal,
        maxWithdrawal: settings.maxWithdrawal,
        dailyWithdrawalLimit: settings.dailyWithdrawalLimit,
      },
    });
  } catch (error) {
    console.error("Public settings error:", error);
    return NextResponse.json(
      { error: "Failed to fetch settings" },
      { status: 500 }
    );
  }
}