// src/app/api/admin/kyc/[id]/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin, logAdminAction } from "@/lib/adminHelpers";

export async function PATCH(
  req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  const authResult = await requireAdmin();
  if (authResult.error) return authResult.error;

  const admin = authResult.admin;

  try {
    const { id } = await context.params;
    const body = await req.json();
    const { action, rejectionReason } = body;
    // action: "APPROVE" | "REJECT"

    if (!action || !["APPROVE", "REJECT"].includes(action)) {
      return NextResponse.json(
        { error: "Invalid action. Must be 'APPROVE' or 'REJECT'" },
        { status: 400 }
      );
    }

    if (action === "REJECT" && !rejectionReason?.trim()) {
      return NextResponse.json(
        { error: "Rejection reason is required" },
        { status: 400 }
      );
    }

    // ─── Find KYC submission ───
    const submission = await prisma.kYCSubmission.findUnique({
      where: { id },
      include: {
        user: {
          select: { id: true, email: true, kycStatus: true },
        },
      },
    });

    if (!submission) {
      return NextResponse.json(
        { error: "KYC submission not found" },
        { status: 404 }
      );
    }

    if (submission.status !== "PENDING") {
      return NextResponse.json(
        { error: `This submission is already ${submission.status.toLowerCase()}` },
        { status: 400 }
      );
    }

    // ═══════════════════════════════════
    // APPROVE FLOW
    // ═══════════════════════════════════
    if (action === "APPROVE") {
      await prisma.$transaction([
        // Update submission
        prisma.kYCSubmission.update({
          where: { id },
          data: {
            status: "APPROVED",
            rejectionReason: null,
            reviewedAt: new Date(),
          },
        }),
        // Update user's kycStatus
        prisma.user.update({
          where: { id: submission.userId },
          data: {
            kycStatus: "APPROVED",
          },
        }),
      ]);

      await logAdminAction({
        adminId: admin.id,
        adminEmail: admin.email,
        action: "APPROVE_KYC",
        category: "KYC",
        targetUserId: submission.userId,
        targetId: submission.id,
        note: "KYC submission approved",
        metadata: {
          userEmail: submission.user.email,
          documentType: submission.documentType,
          fullName: submission.fullName,
        },
      });

      return NextResponse.json({
        success: true,
        message: "KYC approved. User's withdrawals are now unlocked.",
      });
    }

    // ═══════════════════════════════════
    // REJECT FLOW
    // ═══════════════════════════════════
    await prisma.$transaction([
      prisma.kYCSubmission.update({
        where: { id },
        data: {
          status: "REJECTED",
          rejectionReason: rejectionReason.trim(),
          reviewedAt: new Date(),
        },
      }),
      prisma.user.update({
        where: { id: submission.userId },
        data: {
          kycStatus: "REJECTED",
        },
      }),
    ]);

    await logAdminAction({
      adminId: admin.id,
      adminEmail: admin.email,
      action: "REJECT_KYC",
      category: "KYC",
      targetUserId: submission.userId,
      targetId: submission.id,
      note: rejectionReason.trim(),
      metadata: {
        userEmail: submission.user.email,
        documentType: submission.documentType,
        fullName: submission.fullName,
      },
    });

    return NextResponse.json({
      success: true,
      message: "KYC rejected. User will be notified and can re-submit.",
    });
  } catch (error) {
    console.error("Admin KYC update error:", error);
    return NextResponse.json(
      { error: "Failed to process KYC submission" },
      { status: 500 }
    );
  }
}