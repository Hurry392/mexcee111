// src/app/api/admin/kyc/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/adminHelpers";

export async function GET(req: NextRequest) {
  const authResult = await requireAdmin();
  if (authResult.error) return authResult.error;

  try {
    const { searchParams } = new URL(req.url);
    const status = searchParams.get("status") || ""; // PENDING | APPROVED | REJECTED
    const documentType = searchParams.get("documentType") || ""; // NATIONAL_ID | DRIVING_LICENSE | PASSPORT
    const search = searchParams.get("search") || "";
    const page = parseInt(searchParams.get("page") || "1");
    const limit = parseInt(searchParams.get("limit") || "20");
    const skip = (page - 1) * limit;

    // ─── Build filters ───
    const where: Record<string, unknown> = {};
    if (status) where.status = status;
    if (documentType) where.documentType = documentType;
    if (search) {
      where.OR = [
        { fullName: { contains: search, mode: "insensitive" } },
        { documentNumber: { contains: search, mode: "insensitive" } },
        { user: { email: { contains: search, mode: "insensitive" } } },
        { user: { username: { contains: search, mode: "insensitive" } } },
      ];
    }

    const [submissions, total, pendingCount] = await Promise.all([
      prisma.kYCSubmission.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: "desc" },
        include: {
          user: {
            select: {
              id: true,
              email: true,
              username: true,
              country: true,
              kycStatus: true,
              balance: true,
              createdAt: true,
            },
          },
        },
      }),
      prisma.kYCSubmission.count({ where }),
      prisma.kYCSubmission.count({ where: { status: "PENDING" } }),
    ]);

    return NextResponse.json({
      success: true,
      submissions,
      pagination: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
      pendingCount,
    });
  } catch (error) {
    console.error("Admin KYC list error:", error);
    return NextResponse.json(
      { error: "Failed to fetch KYC submissions" },
      { status: 500 }
    );
  }
}