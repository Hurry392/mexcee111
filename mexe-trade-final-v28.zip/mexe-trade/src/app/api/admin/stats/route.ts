// src/app/api/admin/stats/route.ts
import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/adminHelpers"; // ✅ Use admin helper (checks admin cookie)

export async function GET() {
  // ─── Verify admin using proper helper ───
  const authResult = await requireAdmin();
  if (authResult.error) return authResult.error;

  try {
    // ─── Fetch all stats in parallel ───
    const [
      totalUsers,
      activeUsers,
      verifiedUsers,
      pendingKyc,
      pendingDeposits,
      pendingWithdrawals,
      totalDepositsAmount,
      totalWithdrawalsAmount,
      openTrades,
      totalTrades,
      totalBalance,
      unreadMessages,
      recentUsers,
      recentDeposits,
    ] = await Promise.all([
      // Users
      prisma.user.count(),
      prisma.user.count({ where: { isActive: true } }),
      prisma.user.count({ where: { kycStatus: "APPROVED" } }),

      // Pending items
      prisma.kYCSubmission.count({ where: { status: "PENDING" } }),
      prisma.deposit.count({ where: { status: "PENDING" } }),
      prisma.withdrawal.count({ where: { status: "PENDING" } }),

      // Financial totals
      prisma.deposit.aggregate({
        _sum: { amount: true },
        where: { status: "APPROVED" },
      }),
      prisma.withdrawal.aggregate({
        _sum: { amount: true },
        where: { status: { in: ["APPROVED", "COMPLETED"] } },
      }),

      // Trades
      prisma.trade.count({ where: { status: "OPEN" } }),
      prisma.trade.count(),

      // Total user balance (virtual)
      prisma.user.aggregate({
        _sum: { balance: true },
      }),

      // Chat
      prisma.chatMessage.count({
        where: {
          sender: "USER",
          isRead: false,
        },
      }),

      // Recent activity — last 5 users
      prisma.user.findMany({
        take: 5,
        orderBy: { createdAt: "desc" },
        select: {
          id: true,
          email: true,
          username: true,
          kycStatus: true,
          balance: true,
          createdAt: true,
        },
      }),

      // Recent deposits (pending)
      prisma.deposit.findMany({
        take: 5,
        where: { status: "PENDING" },
        orderBy: { createdAt: "desc" },
        include: {
          user: {
            select: {
              email: true,
              username: true,
            },
          },
        },
      }),
    ]);

    return NextResponse.json({
      success: true,
      stats: {
        users: {
          total: totalUsers,
          active: activeUsers,
          verified: verifiedUsers,
        },
        pending: {
          kyc: pendingKyc,
          deposits: pendingDeposits,
          withdrawals: pendingWithdrawals,
          messages: unreadMessages,
        },
        financial: {
          totalDeposits: totalDepositsAmount._sum.amount || 0,
          totalWithdrawals: totalWithdrawalsAmount._sum.amount || 0,
          totalBalance: totalBalance._sum.balance || 0,
        },
        trades: {
          open: openTrades,
          total: totalTrades,
        },
      },
      recentUsers,
      recentDeposits,
    });
  } catch (error) {
    console.error("Admin stats error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}