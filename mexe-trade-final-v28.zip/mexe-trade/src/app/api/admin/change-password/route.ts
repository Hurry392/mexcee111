// src/app/api/admin/change-password/route.ts
// Allows the currently-logged-in admin to change their own password.
// Requires the correct current password before accepting a new one.

import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import {
  hashPassword,
  verifyPassword,
  validatePassword,
} from "@/lib/auth";
import { requireAdmin, logAdminAction } from "@/lib/adminHelpers";

export async function POST(req: NextRequest) {
  // Step 1 — Verify the caller is a valid, active admin
  const authResult = await requireAdmin();
  if (authResult.error) return authResult.error;

  const admin = authResult.admin;

  try {
    const body = await req.json();
    const { currentPassword, newPassword, confirmPassword } = body;

    // ── Input validation ──
    if (!currentPassword || !newPassword || !confirmPassword) {
      return NextResponse.json(
        { error: "All three fields (current password, new password, confirm password) are required." },
        { status: 400 }
      );
    }

    if (newPassword !== confirmPassword) {
      return NextResponse.json(
        { error: "New password and confirm password do not match." },
        { status: 400 }
      );
    }

    if (currentPassword === newPassword) {
      return NextResponse.json(
        { error: "New password must be different from the current password." },
        { status: 400 }
      );
    }

    // ── Password strength check ──
    const strength = validatePassword(newPassword);
    if (!strength.valid) {
      return NextResponse.json(
        { error: strength.message || "New password does not meet requirements." },
        { status: 400 }
      );
    }

    // ── Fetch the admin's current password hash ──
    const adminUser = await prisma.user.findUnique({
      where: { id: admin.id },
      select: { passwordHash: true },
    });

    if (!adminUser) {
      return NextResponse.json(
        { error: "Admin account not found." },
        { status: 404 }
      );
    }

    // ── Verify current password is correct ──
    const isCurrentValid = await verifyPassword(currentPassword, adminUser.passwordHash);
    if (!isCurrentValid) {
      return NextResponse.json(
        { error: "Current password is incorrect." },
        { status: 400 }
      );
    }

    // ── Hash and save new password ──
    const newHash = await hashPassword(newPassword);

    await prisma.user.update({
      where: { id: admin.id },
      data: { passwordHash: newHash },
    });

    // ── Audit log ──
    await logAdminAction({
      adminId: admin.id,
      adminEmail: admin.email,
      action: "CHANGE_ADMIN_PASSWORD",
      category: "GENERAL",
      note: "Admin changed their own password",
    });

    return NextResponse.json({
      success: true,
      message: "Password changed successfully.",
    });
  } catch (error) {
    console.error("Change admin password error:", error);
    return NextResponse.json(
      { error: "Failed to change password. Please try again." },
      { status: 500 }
    );
  }
}
