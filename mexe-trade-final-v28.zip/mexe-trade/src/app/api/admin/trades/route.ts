// src/app/api/admin/trades/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/adminHelpers";

export async function GET(req: NextRequest) {
  const authResult = await requireAdmin();
  if (authResult.error) return authResult.error;

  try {
    const { searchParams } = new URL(req.url);
    const status = searchParams.get("status") || "";
    const side = searchParams.get("side") || "";
    const coin = searchParams.get("coin") || "";
    const search = searchParams.get("search") || "";
    const page = parseInt(searchParams.get("page") || "1");
    const limit = parseInt(searchParams.get("limit") || "20");
    const skip = (page - 1) * limit;

    const where: Record<string, unknown> = {};
    if (status) where.status = status;
    if (side) where.side = side;
    if (coin) where.coinSymbol = coin;
    if (search) {
      where.user = {
        OR: [
          { email: { contains: search, mode: "insensitive" } },
          { username: { contains: search, mode: "insensitive" } },
        ],
      };
    }

    const [trades, total, openCount, aggregates] = await Promise.all([
      prisma.trade.findMany({
        where,
        skip,
        take: limit,
        orderBy: { openedAt: "desc" },
        include: {
          user: {
            select: {
              id: true,
              email: true,
              username: true,
            },
          },
        },
      }),
      prisma.trade.count({ where }),
      prisma.trade.count({ where: { status: "OPEN" } }),
      prisma.trade.aggregate({
        _sum: {
          marginAmount: true,
          pnl: true,
          fee: true,
        },
      }),
    ]);

    return NextResponse.json({
      success: true,
      trades,
      pagination: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
      stats: {
        openCount,
        totalMargin: aggregates._sum.marginAmount || 0,
        totalPnL: aggregates._sum.pnl || 0,
        totalFees: aggregates._sum.fee || 0,
      },
    });
  } catch (error) {
    console.error("Admin trades list error:", error);
    return NextResponse.json(
      { error: "Failed to fetch trades" },
      { status: 500 }
    );
  }
}