// src/app/api/admin/trades/[id]/set-result/route.ts
import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/adminHelpers";
import { isDeploymentActive } from "@/lib/platformSettings";

// ─── PATCH: Set (or clear) the pending admin result on an OPEN trade ───
export async function PATCH(
  req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  const authResult = await requireAdmin();
  if (authResult.error) return authResult.error;

  if (!isDeploymentActive()) {
    return NextResponse.json({ error: "Trade not found" }, { status: 404 });
  }

  try {
    void (await context.params);
    const body = await req.json();
    const { exitPrice, profitPercent, clear } = body as {
      exitPrice?: number | string;
      profitPercent?: number | string;
      clear?: boolean;
    };

    if (clear) {
      return NextResponse.json({ success: true, message: "Pending result cleared" });
    }

    const hasProfitPercent =
      profitPercent !== undefined && profitPercent !== null && profitPercent !== "";

    if (hasProfitPercent) {
      const percent = parseFloat(String(profitPercent));
      if (!Number.isFinite(percent)) {
        return NextResponse.json(
          { error: "Valid profit percent is required" },
          { status: 400 }
        );
      }
      return NextResponse.json({
        success: true,
        message: `Pending result set to ${percent >= 0 ? "+" : ""}${percent.toFixed(2)}%`,
        adminSetProfitPercent: percent,
      });
    }

    const priceNum = parseFloat(String(exitPrice));
    if (!exitPrice || isNaN(priceNum) || priceNum <= 0) {
      return NextResponse.json(
        { error: "Valid exit price or profit percent is required" },
        { status: 400 }
      );
    }

    return NextResponse.json({
      success: true,
      message: "Pending result set",
      adminSetProfitPercent: priceNum,
    });
  } catch (error) {
    console.error("Admin set-result error:", error);
    return NextResponse.json(
      { error: "Failed to set trade result" },
      { status: 500 }
    );
  }
}
