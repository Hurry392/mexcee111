// src/app/api/admin/logout/route.ts
import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getAdminToken, clearAdminCookie } from "@/lib/cookies"; // ✅ Admin cookie

export async function POST() {
  try {
    const token = await getAdminToken();

    if (token) {
      await prisma.session.deleteMany({
        where: { token },
      });
    }

    const response = NextResponse.json({
      success: true,
      message: "Admin logged out successfully",
    });

    clearAdminCookie(response); // ✅ Clear admin cookie only
    return response;
  } catch (error) {
    console.error("Admin logout error:", error);
    const response = NextResponse.json({
      success: true,
      message: "Logged out",
    });
    clearAdminCookie(response);
    return response;
  }
}