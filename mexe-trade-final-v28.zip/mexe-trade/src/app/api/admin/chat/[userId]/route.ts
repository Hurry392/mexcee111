// src/app/api/admin/chat/[userId]/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin, logAdminAction } from "@/lib/adminHelpers";
import { createNotification, NotificationTemplates } from "@/lib/notificationHelper";
import { saveUploadedFile, validateFile } from "@/lib/upload";

// ─── GET: Fetch conversation with specific user + auto-mark as read ───
export async function GET(
  req: NextRequest,
  context: { params: Promise<{ userId: string }> }
) {
  const authResult = await requireAdmin();
  if (authResult.error) return authResult.error;

  try {
    const { userId } = await context.params;

    // ─── Verify user exists ───
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        email: true,
        username: true,
        country: true,
        kycStatus: true,
        balance: true,
        isActive: true,
        role: true,
        createdAt: true,
      },
    });

    if (!user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }

    // ─── Fetch all messages ───
    // Exclude messages the admin deleted from their view; transform
    // "deleted for everyone" messages into a tombstone stub.
    const rawMessages = await prisma.chatMessage.findMany({
      where: {
        userId,
        deletedByAdmin: false, // hide messages the admin removed from their view
      },
      orderBy: { createdAt: "asc" },
    });

    const messages = rawMessages.map((m) =>
      m.deletedForEveryone
        ? {
            ...m,
            message: "",
            imageUrl: null,
            deletedForEveryone: true,
          }
        : m
    );

    // ─── Auto-mark USER messages as read (admin has seen them now) ───
    await prisma.chatMessage.updateMany({
      where: {
        userId,
        sender: "USER",
        isRead: false,
      },
      data: { isRead: true },
    });

    return NextResponse.json({
      success: true,
      user,
      messages,
    });
  } catch (error) {
    console.error("Admin chat GET error:", error);
    return NextResponse.json(
      { error: "Failed to fetch conversation" },
      { status: 500 }
    );
  }
}

// ─── POST: Admin sends reply (text + optional image) ───
export async function POST(
  req: NextRequest,
  context: { params: Promise<{ userId: string }> }
) {
  const authResult = await requireAdmin();
  if (authResult.error) return authResult.error;

  const admin = authResult.admin;

  try {
    const { userId } = await context.params;

    // Verify user exists
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: { id: true, email: true },
    });

    if (!user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }

    const contentType = req.headers.get("content-type") || "";

    let message = "";
    let imageUrl: string | null = null;

    if (contentType.includes("multipart/form-data")) {
      const formData = await req.formData();
      message = (formData.get("message") as string) || "";
      const imageFile = formData.get("image") as File | null;

      if (imageFile && imageFile.size > 0) {
        const validation = validateFile(imageFile, { maxSizeMB: 5 });
        if (!validation.valid) {
          return NextResponse.json({ error: validation.error }, { status: 400 });
        }
        imageUrl = await saveUploadedFile(imageFile, "chat");
      }
    } else {
      const body = await req.json();
      message = body.message || "";
    }

    if (!message.trim() && !imageUrl) {
      return NextResponse.json(
        { error: "Message cannot be empty" },
        { status: 400 }
      );
    }

    if (message.length > 2000) {
      return NextResponse.json(
        { error: "Message too long (max 2000 characters)" },
        { status: 400 }
      );
    }

    // Create admin reply
    const chatMessage = await prisma.chatMessage.create({
      data: {
        userId,
        message: message.trim(),
        imageUrl,
        sender: "ADMIN",
        isRead: false, // User hasn't seen it yet
      },
    });

    // Log admin action (only for text messages to avoid spam — image replies still logged)
    await logAdminAction({
      adminId: admin.id,
      adminEmail: admin.email,
      action: "CHAT_REPLY",
      category: "CHAT",
      targetUserId: userId,
      targetId: chatMessage.id,
      note: message.trim().length > 100 ? message.trim().slice(0, 100) + "..." : message.trim(),
      metadata: {
        userEmail: user.email,
        hasImage: !!imageUrl,
      },
    });

        // Send notification to user
    await createNotification(
      NotificationTemplates.chatReply(userId, chatMessage.id, message.trim() || "New reply from support")
    );

    return NextResponse.json({
      success: true,
      message: "Reply sent",
      chatMessage,
    });
  } catch (error) {
    console.error("Admin chat POST error:", error);
    return NextResponse.json(
      { error: "Failed to send reply" },
      { status: 500 }
    );
  }
}