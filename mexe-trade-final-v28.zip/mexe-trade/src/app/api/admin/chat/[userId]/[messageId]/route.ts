// src/app/api/admin/chat/[userId]/[messageId]/route.ts
// Admin: delete or edit a specific chat message.
//
//  DELETE_FOR_ME       → hide from admin view only
//  DELETE_FOR_EVERYONE → tombstone for both sides
//  EDIT                → store editedMessage; user sees edited text, admin keeps original

import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin, logAdminAction } from "@/lib/adminHelpers";

const VALID_ACTIONS = ["DELETE_FOR_ME", "DELETE_FOR_EVERYONE", "EDIT"] as const;
type Action = (typeof VALID_ACTIONS)[number];

export async function PATCH(
  req: NextRequest,
  context: { params: Promise<{ userId: string; messageId: string }> }
) {
  // ── Auth ──────────────────────────────────────────────────────
  const authResult = await requireAdmin();
  if (authResult.error) return authResult.error;
  const admin = authResult.admin;

  const { userId, messageId } = await context.params;

  try {
    const body = await req.json();
    const { action, newMessage } = body as { action: Action; newMessage?: string };

    if (!VALID_ACTIONS.includes(action)) {
      return NextResponse.json(
        { error: "Invalid action. Use DELETE_FOR_ME, DELETE_FOR_EVERYONE, or EDIT." },
        { status: 400 }
      );
    }

    // ── Verify the message belongs to the requested conversation ─
    const existing = await prisma.chatMessage.findFirst({
      where: { id: messageId, userId },
      select: {
        id: true,
        sender: true,
        message: true,
        deletedForEveryone: true,
        deletedByAdmin: true,
      },
    });

    if (!existing) {
      return NextResponse.json({ error: "Message not found." }, { status: 404 });
    }

    // ── Apply the requested action ───────────────────────────────

    if (action === "EDIT") {
      // Only ADMIN-sent messages can be edited this way
      if (existing.sender !== "ADMIN") {
        return NextResponse.json(
          { error: "Only admin-sent messages can be edited." },
          { status: 403 }
        );
      }

      const trimmed = (newMessage ?? "").trim();
      if (!trimmed) {
        return NextResponse.json(
          { error: "Edited message cannot be empty." },
          { status: 400 }
        );
      }

      if (trimmed.length > 2000) {
        return NextResponse.json(
          { error: "Edited message too long (max 2000 characters)." },
          { status: 400 }
        );
      }

      await prisma.chatMessage.update({
        where: { id: messageId },
        data: {
          editedMessage: trimmed,
          editedAt: new Date(),
        },
      });

      await logAdminAction({
        adminId: admin.id,
        adminEmail: admin.email,
        action: "EDIT_CHAT_MESSAGE",
        category: "CHAT",
        targetUserId: userId,
        targetId: messageId,
        note: `Admin edited message (original: "${existing.message.slice(0, 60)}${existing.message.length > 60 ? "…" : ""}")`,
      });

    } else if (action === "DELETE_FOR_EVERYONE") {
      await prisma.chatMessage.update({
        where: { id: messageId },
        data: { deletedForEveryone: true },
      });

      await logAdminAction({
        adminId: admin.id,
        adminEmail: admin.email,
        action: "DELETE_CHAT_MESSAGE_FOR_ALL",
        category: "CHAT",
        targetUserId: userId,
        targetId: messageId,
        note: "Admin deleted message for everyone",
      });

    } else {
      // DELETE_FOR_ME — hide only from the admin side
      await prisma.chatMessage.update({
        where: { id: messageId },
        data: { deletedByAdmin: true },
      });

      await logAdminAction({
        adminId: admin.id,
        adminEmail: admin.email,
        action: "DELETE_CHAT_MESSAGE_FOR_ADMIN",
        category: "CHAT",
        targetUserId: userId,
        targetId: messageId,
        note: "Admin hid message from admin view",
      });
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Admin message action error:", error);
    return NextResponse.json(
      { error: "Failed to process message action. Please try again." },
      { status: 500 }
    );
  }
}
