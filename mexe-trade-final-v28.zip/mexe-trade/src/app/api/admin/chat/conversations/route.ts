// src/app/api/admin/chat/conversations/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/adminHelpers";

export async function GET(req: NextRequest) {
  const authResult = await requireAdmin();
  if (authResult.error) return authResult.error;

  try {
    const { searchParams } = new URL(req.url);
    const search = searchParams.get("search") || "";

    // ─── Get all users who have at least one chat message ───
    // Group by userId, get last message + unread count per user

    // Fetch all unique userIds that have chat messages
    const userIdsWithMessages = await prisma.chatMessage.findMany({
      distinct: ["userId"],
      select: { userId: true },
    });

    if (userIdsWithMessages.length === 0) {
      return NextResponse.json({
        success: true,
        conversations: [],
        totalUnread: 0,
      });
    }

    const userIds = userIdsWithMessages.map((m) => m.userId);

    // ─── Build user filter (search) ───
    const userWhere: Record<string, unknown> = {
      id: { in: userIds },
    };

    if (search) {
      userWhere.OR = [
        { email: { contains: search, mode: "insensitive" } },
        { username: { contains: search, mode: "insensitive" } },
      ];
    }

    // Fetch users
    const users = await prisma.user.findMany({
      where: userWhere,
      select: {
        id: true,
        email: true,
        username: true,
        country: true,
        kycStatus: true,
        balance: true,
        isActive: true,
      },
    });

    // ─── For each user, get their last message + unread count ───
    const conversations = await Promise.all(
      users.map(async (user) => {
        const [lastMessage, unreadCount] = await Promise.all([
          // Last message — skip admin-hidden and "deleted for everyone" messages
          // so the preview shows the most recent visible message.
          prisma.chatMessage.findFirst({
            where: {
              userId: user.id,
              deletedByAdmin: false,
              deletedForEveryone: false,
            },
            orderBy: { createdAt: "desc" },
            select: {
              id: true,
              message: true,
              imageUrl: true,
              sender: true,
              createdAt: true,
            },
          }),
          // Unread — exclude "deleted for everyone" messages so they don't
          // inflate the badge after being deleted.
          prisma.chatMessage.count({
            where: {
              userId: user.id,
              sender: "USER",
              isRead: false,
              deletedForEveryone: false,
            },
          }),
        ]);

        return {
          user,
          lastMessage,
          unreadCount,
        };
      })
    );

    // ─── Sort: unread first, then by latest message timestamp ───
    conversations.sort((a, b) => {
      // Unread first
      if (a.unreadCount > 0 && b.unreadCount === 0) return -1;
      if (a.unreadCount === 0 && b.unreadCount > 0) return 1;

      // Then by last message time (newest first)
      const aTime = a.lastMessage ? new Date(a.lastMessage.createdAt).getTime() : 0;
      const bTime = b.lastMessage ? new Date(b.lastMessage.createdAt).getTime() : 0;
      return bTime - aTime;
    });

    // ─── Total unread count (across all conversations) ───
    const totalUnread = conversations.reduce((sum, c) => sum + c.unreadCount, 0);

    return NextResponse.json({
      success: true,
      conversations,
      totalUnread,
    });
  } catch (error) {
    console.error("Admin conversations error:", error);
    return NextResponse.json(
      { error: "Failed to fetch conversations" },
      { status: 500 }
    );
  }
}