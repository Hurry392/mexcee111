// src/app/api/admin/users/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/adminHelpers";

export async function GET(req: NextRequest) {
  // ─── Auth check ───
  const authResult = await requireAdmin();
  if (authResult.error) return authResult.error;

  try {
    const { searchParams } = new URL(req.url);
    const search = searchParams.get("search") || "";
    const kycFilter = searchParams.get("kyc") || ""; // NONE | PENDING | APPROVED | REJECTED
    const statusFilter = searchParams.get("status") || ""; // active | suspended
    const roleFilter = searchParams.get("role") || ""; // USER | ADMIN
    const page = parseInt(searchParams.get("page") || "1");
    const limit = parseInt(searchParams.get("limit") || "20");
    const skip = (page - 1) * limit;

    // ─── Build filters ───
    const where: Record<string, unknown> = {};

    if (search) {
      const or: Record<string, unknown>[] = [
        { email: { contains: search, mode: "insensitive" } },
        { username: { contains: search, mode: "insensitive" } },
        { referralCode: { contains: search, mode: "insensitive" } },
      ];
      // If the query is numeric, also match the user's UID exactly
      const asNumber = Number(search.trim());
      if (Number.isInteger(asNumber) && search.trim() !== "") {
        or.push({ uid: asNumber });
      }
      where.OR = or;
    }

    if (kycFilter) where.kycStatus = kycFilter;
    if (roleFilter) where.role = roleFilter;
    if (statusFilter === "active") where.isActive = true;
    if (statusFilter === "suspended") where.isActive = false;

    // ─── Fetch users with counts ───
    const [users, total] = await Promise.all([
      prisma.user.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: "desc" },
        select: {
          id: true,
          uid: true,
          email: true,
          username: true,
          phone: true,
          country: true,
          balance: true,
          role: true,
          isActive: true,
          isVerified: true,
          kycStatus: true,
          referralCode: true,
          referredBy: true,
          createdAt: true,
          lastLoginAt: true,
          _count: {
            select: {
              deposits: true,
              withdrawals: true,
              trades: true,
              kycSubmissions: true,
            },
          },
        },
      }),
      prisma.user.count({ where }),
    ]);

    return NextResponse.json({
      success: true,
      users,
      pagination: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error("Admin users list error:", error);
    return NextResponse.json(
      { error: "Failed to fetch users" },
      { status: 500 }
    );
  }
}