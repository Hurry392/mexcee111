// src/app/api/admin/users/[id]/balance/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin, logAdminAction } from "@/lib/adminHelpers";
import { createNotification, NotificationTemplates } from "@/lib/notificationHelper";

export async function POST(
  req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  const authResult = await requireAdmin();
  if (authResult.error) return authResult.error;

  const admin = authResult.admin;

  try {
    const { id } = await context.params;
    const body = await req.json();
    const { action, amount, note } = body; // action: "ADD" | "DEDUCT"

    // ─── Validation ───
    if (!action || !["ADD", "DEDUCT"].includes(action)) {
      return NextResponse.json(
        { error: "Invalid action. Must be 'ADD' or 'DEDUCT'" },
        { status: 400 }
      );
    }

    const parsedAmount = parseFloat(amount);
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      return NextResponse.json(
        { error: "Amount must be a positive number" },
        { status: 400 }
      );
    }

    if (parsedAmount > 10000000) {
      return NextResponse.json(
        { error: "Amount exceeds maximum limit ($10M)" },
        { status: 400 }
      );
    }

    // ─── Find target user ───
    const targetUser = await prisma.user.findUnique({
      where: { id },
      select: { id: true, email: true, balance: true },
    });

    if (!targetUser) {
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }

    // ─── Apply balance change atomically (increment/decrement instead of
    // read-modify-write, so concurrent deposits/trades aren't clobbered) ───
    const changeAmount = action === "ADD" ? parsedAmount : -parsedAmount;

    if (action === "DEDUCT") {
      const deducted = await prisma.user.updateMany({
        where: { id, balance: { gte: parsedAmount } },
        data: { balance: { decrement: parsedAmount } },
      });
      if (deducted.count === 0) {
        return NextResponse.json(
          {
            error: `Insufficient balance. User has $${targetUser.balance.toFixed(
              2
            )}, cannot deduct $${parsedAmount.toFixed(2)}`,
          },
          { status: 400 }
        );
      }
    } else {
      await prisma.user.update({
        where: { id },
        data: { balance: { increment: parsedAmount } },
      });
    }

    const updatedUser = await prisma.user.findUnique({
      where: { id },
      select: { id: true, email: true, balance: true },
    });
    const newBalance = updatedUser?.balance ?? targetUser.balance + changeAmount;

    // Log admin action (outside transaction, non-critical)
    await logAdminAction({
      adminId: admin.id,
      adminEmail: admin.email,
      action: action === "ADD" ? "ADD_BALANCE" : "DEDUCT_BALANCE",
      category: "BALANCE",
      targetUserId: id,
      amount: changeAmount,
      note: note || (action === "ADD" ? "Balance credited" : "Balance debited"),
      metadata: {
        targetEmail: targetUser.email,
        previousBalance: targetUser.balance,
        newBalance,
      },
    });

        // Send notification to user
    if (action === "ADD") {
      await createNotification(
        NotificationTemplates.balanceAdded(id, parsedAmount, note?.trim())
      );
    } else {
      await createNotification(
        NotificationTemplates.balanceDeducted(id, parsedAmount, note?.trim())
      );
    }

    return NextResponse.json({
      success: true,
      message: `Balance ${action === "ADD" ? "added" : "deducted"} successfully`,
      user: updatedUser,
      change: {
        previousBalance: targetUser.balance,
        newBalance,
        amount: changeAmount,
      },
    });
  } catch (error) {
    console.error("Admin balance update error:", error);
    return NextResponse.json(
      { error: "Failed to update balance" },
      { status: 500 }
    );
  }
}