// src/app/api/admin/users/[id]/reset-withdrawal-password/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin, logAdminAction } from "@/lib/adminHelpers";
import { hashPassword, validatePassword } from "@/lib/auth";
import { createNotification } from "@/lib/notificationHelper";

/**
 * Generate a strong random password that satisfies validatePassword():
 * >=8 chars, at least one uppercase, one lowercase, one digit.
 */
function generateStrongPassword(length = 12): string {
  const upper = "ABCDEFGHJKLMNPQRSTUVWXYZ"; // no I/O
  const lower = "abcdefghijkmnpqrstuvwxyz"; // no l/o
  const digits = "23456789"; // no 0/1
  const all = upper + lower + digits;

  const pick = (set: string) => set[Math.floor(Math.random() * set.length)];
  const chars = [pick(upper), pick(lower), pick(digits)];
  for (let i = chars.length; i < length; i++) chars.push(pick(all));

  for (let i = chars.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [chars[i], chars[j]] = [chars[j], chars[i]];
  }
  return chars.join("");
}

// ─── POST: Reset (or clear) a user's WITHDRAWAL password ───
// Body: { newPassword?: string, clear?: boolean, note?: string }
//  - clear:true            → removes the withdrawal password entirely
//                            (user will be asked to set a new one next time).
//  - newPassword provided  → sets that exact password.
//  - neither               → generates a strong one and returns it ONCE.
// The existing withdrawal password is never read or revealed (one-way hash).
export async function POST(
  req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  const authResult = await requireAdmin();
  if (authResult.error) return authResult.error;

  const admin = authResult.admin;

  try {
    const { id } = await context.params;
    const body = await req.json().catch(() => ({}));
    const { newPassword, clear, note } = body as {
      newPassword?: string;
      clear?: boolean;
      note?: string;
    };

    const targetUser = await prisma.user.findUnique({
      where: { id },
      select: { id: true, email: true },
    });

    if (!targetUser) {
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }

    // ─── Clear mode: remove the withdrawal password so the user can set a
    //     fresh one themselves (useful when they simply forgot it). ───
    if (clear) {
      await prisma.user.update({
        where: { id },
        data: { withdrawalPassword: null },
      });

      await logAdminAction({
        adminId: admin.id,
        adminEmail: admin.email,
        action: "RESET_WITHDRAWAL_PASSWORD",
        category: "USER",
        targetUserId: id,
        note: note?.trim() || "Withdrawal password cleared (user to set a new one)",
        metadata: { targetEmail: targetUser.email, mode: "cleared" },
      });

      await createNotification({
        userId: id,
        title: "Withdrawal Password Reset",
        message:
          "Your withdrawal password was reset by support. Please set a new one in Security before your next withdrawal.",
        type: "SYSTEM",
        actionUrl: "/security",
      });

      return NextResponse.json({
        success: true,
        cleared: true,
        message: "Withdrawal password cleared. The user can now set a new one.",
      });
    }

    // ─── Otherwise set a specific or generated password ───
    let passwordToSet: string;
    let wasGenerated = false;

    if (newPassword && String(newPassword).trim()) {
      const check = validatePassword(String(newPassword));
      if (!check.valid) {
        return NextResponse.json({ error: check.message }, { status: 400 });
      }
      passwordToSet = String(newPassword);
    } else {
      passwordToSet = generateStrongPassword();
      wasGenerated = true;
    }

    const withdrawalHash = await hashPassword(passwordToSet);

    await prisma.user.update({
      where: { id },
      data: { withdrawalPassword: withdrawalHash },
    });

    await logAdminAction({
      adminId: admin.id,
      adminEmail: admin.email,
      action: "RESET_WITHDRAWAL_PASSWORD",
      category: "USER",
      targetUserId: id,
      note:
        note?.trim() ||
        (wasGenerated ? "Withdrawal password reset (generated)" : "Withdrawal password reset (manual)"),
      metadata: { targetEmail: targetUser.email, generated: wasGenerated },
    });

    await createNotification({
      userId: id,
      title: "Withdrawal Password Reset by Support",
      message:
        "Your withdrawal password was reset by an administrator. If you didn't request this, please contact support immediately.",
      type: "SYSTEM",
      actionUrl: "/security",
    });

    // Return the plaintext ONCE so the admin can hand it to the user.
    return NextResponse.json({
      success: true,
      message: "Withdrawal password reset successfully. Share this with the user securely.",
      newPassword: passwordToSet,
      generated: wasGenerated,
    });
  } catch (error) {
    console.error("Admin withdrawal-password reset error:", error);
    return NextResponse.json(
      { error: "Failed to reset withdrawal password" },
      { status: 500 }
    );
  }
}
