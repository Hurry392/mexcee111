// src/app/api/admin/users/[id]/reset-password/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin, logAdminAction } from "@/lib/adminHelpers";
import { hashPassword, validatePassword } from "@/lib/auth";
import { createNotification } from "@/lib/notificationHelper";

/**
 * Generate a strong random password that satisfies validatePassword():
 * >=8 chars, at least one uppercase, one lowercase, one digit.
 */
function generateStrongPassword(length = 12): string {
  const upper = "ABCDEFGHJKLMNPQRSTUVWXYZ"; // no I/O
  const lower = "abcdefghijkmnpqrstuvwxyz"; // no l/o
  const digits = "23456789"; // no 0/1
  const all = upper + lower + digits;

  // Guarantee one of each required class
  const pick = (set: string) => set[Math.floor(Math.random() * set.length)];
  const chars = [pick(upper), pick(lower), pick(digits)];
  for (let i = chars.length; i < length; i++) chars.push(pick(all));

  // Shuffle (Fisher–Yates) so the guaranteed chars aren't always first
  for (let i = chars.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [chars[i], chars[j]] = [chars[j], chars[i]];
  }
  return chars.join("");
}

// ─── POST: Reset a user's login password ───
// Body: { newPassword?: string, note?: string }
// If newPassword is omitted, a strong one is generated and returned ONCE.
// The existing password is never read or revealed (it's a one-way hash).
export async function POST(
  req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  const authResult = await requireAdmin();
  if (authResult.error) return authResult.error;

  const admin = authResult.admin;

  try {
    const { id } = await context.params;
    const body = await req.json().catch(() => ({}));
    const { newPassword, note } = body as {
      newPassword?: string;
      note?: string;
    };

    // ─── Find target user ───
    const targetUser = await prisma.user.findUnique({
      where: { id },
      select: { id: true, email: true },
    });

    if (!targetUser) {
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }

    // ─── Determine the password to set ───
    let passwordToSet: string;
    let wasGenerated = false;

    if (newPassword && String(newPassword).trim()) {
      const check = validatePassword(String(newPassword));
      if (!check.valid) {
        return NextResponse.json({ error: check.message }, { status: 400 });
      }
      passwordToSet = String(newPassword);
    } else {
      passwordToSet = generateStrongPassword();
      wasGenerated = true;
    }

    // ─── Hash + update, and force re-login by clearing sessions ───
    const passwordHash = await hashPassword(passwordToSet);

    await prisma.$transaction([
      prisma.user.update({
        where: { id },
        data: { passwordHash },
      }),
      // Invalidate all existing sessions so the old password can't linger
      prisma.session.deleteMany({ where: { userId: id } }),
    ]);

    // ─── Audit log (never store the plaintext password in the log) ───
    await logAdminAction({
      adminId: admin.id,
      adminEmail: admin.email,
      action: "RESET_USER_PASSWORD",
      category: "USER",
      targetUserId: id,
      note: note?.trim() || (wasGenerated ? "Password reset (generated)" : "Password reset (manual)"),
      metadata: { targetEmail: targetUser.email, generated: wasGenerated },
    });

    // ─── Notify the user in-app ───
    await createNotification({
      userId: id,
      title: "Password Reset by Support",
      message:
        "Your account password was reset by an administrator. If you didn't request this, please contact support immediately.",
      type: "SYSTEM",
      actionUrl: "/security",
    });

    // Return the plaintext ONCE so the admin can hand it to the user.
    // This is the new password being SET now — not a recovery of the old one.
    return NextResponse.json({
      success: true,
      message: "Password reset successfully. Share this with the user securely.",
      newPassword: passwordToSet,
      generated: wasGenerated,
    });
  } catch (error) {
    console.error("Admin password reset error:", error);
    return NextResponse.json(
      { error: "Failed to reset password" },
      { status: 500 }
    );
  }
}
