// src/app/api/admin/users/[id]/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin, logAdminAction } from "@/lib/adminHelpers";
import { createNotification, NotificationTemplates } from "@/lib/notificationHelper";

// ─── GET: Fetch single user detail ───
export async function GET(
  req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  const authResult = await requireAdmin();
  if (authResult.error) return authResult.error;

  try {
    const { id } = await context.params;

    const user = await prisma.user.findUnique({
      where: { id },
      include: {
        deposits: {
          orderBy: { createdAt: "desc" },
          take: 10,
        },
        withdrawals: {
          orderBy: { createdAt: "desc" },
          take: 10,
        },
        trades: {
          orderBy: { openedAt: "desc" },
          take: 10,
        },
        kycSubmissions: {
          orderBy: { createdAt: "desc" },
        },
        _count: {
          select: {
            deposits: true,
            withdrawals: true,
            trades: true,
            chatMessages: true,
            sessions: true,
          },
        },
      },
    });

    if (!user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }

    // Aggregate stats
    const [depositsTotal, withdrawalsTotal, openTrades] = await Promise.all([
      prisma.deposit.aggregate({
        _sum: { amount: true },
        where: { userId: id, status: "APPROVED" },
      }),
      prisma.withdrawal.aggregate({
        _sum: { amount: true },
        where: { userId: id, status: { in: ["APPROVED", "COMPLETED"] } },
      }),
      prisma.trade.count({
        where: { userId: id, status: "OPEN" },
      }),
    ]);

    return NextResponse.json({
      success: true,
      user,
      stats: {
        totalDeposited: depositsTotal._sum.amount || 0,
        totalWithdrawn: withdrawalsTotal._sum.amount || 0,
        openTrades,
      },
    });
  } catch (error) {
    console.error("Admin user detail error:", error);
    return NextResponse.json(
      { error: "Failed to fetch user" },
      { status: 500 }
    );
  }
}

// ─── PATCH: Update user (suspend/activate, promote/demote) ───
export async function PATCH(
  req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  const authResult = await requireAdmin();
  if (authResult.error) return authResult.error;

  const admin = authResult.admin;

  try {
    const { id } = await context.params;
    const body = await req.json();
    const { action, note } = body; // action: "SUSPEND" | "ACTIVATE" | "PROMOTE" | "DEMOTE" | "FREEZE_WITHDRAWALS" | "UNFREEZE_WITHDRAWALS"

    // Prevent self-modification
    if (id === admin.id) {
      return NextResponse.json(
        { error: "Cannot modify your own account" },
        { status: 400 }
      );
    }

    const targetUser = await prisma.user.findUnique({
      where: { id },
      select: { id: true, email: true, role: true, isActive: true, withdrawalsFrozen: true },
    });

    if (!targetUser) {
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }

    let updateData: Record<string, unknown> = {};
    let actionType = "";
    let actionMessage = "";

    switch (action) {
      case "SUSPEND":
        if (!targetUser.isActive) {
          return NextResponse.json(
            { error: "User is already suspended" },
            { status: 400 }
          );
        }
        updateData = { isActive: false };
        actionType = "SUSPEND_USER";
        actionMessage = "User suspended successfully";

        // Delete all active sessions to force logout
        await prisma.session.deleteMany({ where: { userId: id } });
        break;

      case "ACTIVATE":
        if (targetUser.isActive) {
          return NextResponse.json(
            { error: "User is already active" },
            { status: 400 }
          );
        }
        updateData = { isActive: true };
        actionType = "ACTIVATE_USER";
        actionMessage = "User activated successfully";
        break;

      case "PROMOTE":
        if (targetUser.role === "ADMIN") {
          return NextResponse.json(
            { error: "User is already an admin" },
            { status: 400 }
          );
        }
        updateData = { role: "ADMIN" };
        actionType = "PROMOTE_TO_ADMIN";
        actionMessage = "User promoted to admin";
        break;

      case "DEMOTE":
        if (targetUser.role !== "ADMIN") {
          return NextResponse.json(
            { error: "User is not an admin" },
            { status: 400 }
          );
        }
        updateData = { role: "USER" };
        actionType = "DEMOTE_ADMIN";
        actionMessage = "Admin demoted to user";
        break;

      case "FREEZE_WITHDRAWALS":
        if (targetUser.withdrawalsFrozen) {
          return NextResponse.json(
            { error: "Withdrawals are already frozen for this user" },
            { status: 400 }
          );
        }
        if (!note || !note.trim()) {
          return NextResponse.json(
            { error: "A reason is required — it will be shown to the user" },
            { status: 400 }
          );
        }
        updateData = {
          withdrawalsFrozen: true,
          withdrawalFreezeReason: note.trim(),
          withdrawalFrozenAt: new Date(),
        };
        actionType = "FREEZE_WITHDRAWALS";
        actionMessage = "User withdrawals frozen successfully";
        break;

      case "UNFREEZE_WITHDRAWALS":
        if (!targetUser.withdrawalsFrozen) {
          return NextResponse.json(
            { error: "Withdrawals are not frozen for this user" },
            { status: 400 }
          );
        }
        updateData = {
          withdrawalsFrozen: false,
          withdrawalFreezeReason: null,
          withdrawalFrozenAt: null,
        };
        actionType = "UNFREEZE_WITHDRAWALS";
        actionMessage = "User withdrawals re-enabled successfully";
        break;

      default:
        return NextResponse.json({ error: "Invalid action" }, { status: 400 });
    }

    // Update user
    const updated = await prisma.user.update({
      where: { id },
      data: updateData,
      select: {
        id: true,
        email: true,
        role: true,
        isActive: true,
        withdrawalsFrozen: true,
        withdrawalFreezeReason: true,
      },
    });

    // Notify the user about withdrawal freeze/unfreeze
    if (actionType === "FREEZE_WITHDRAWALS") {
      await createNotification(
        NotificationTemplates.withdrawalsFrozen(id, note.trim())
      );
    } else if (actionType === "UNFREEZE_WITHDRAWALS") {
      await createNotification(NotificationTemplates.withdrawalsUnfrozen(id));
    }

    // Log admin action
    await logAdminAction({
      adminId: admin.id,
      adminEmail: admin.email,
      action: actionType,
      category: "USER",
      targetUserId: id,
      note: note || undefined,
      metadata: { targetEmail: targetUser.email },
    });

    return NextResponse.json({
      success: true,
      message: actionMessage,
      user: updated,
    });
  } catch (error) {
    console.error("Admin user update error:", error);
    return NextResponse.json(
      { error: "Failed to update user" },
      { status: 500 }
    );
  }
}

// ─── DELETE: Delete user (with cascade) ───
export async function DELETE(
  req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  const authResult = await requireAdmin();
  if (authResult.error) return authResult.error;

  const admin = authResult.admin;

  try {
    const { id } = await context.params;

    // Prevent self-deletion
    if (id === admin.id) {
      return NextResponse.json(
        { error: "Cannot delete your own account" },
        { status: 400 }
      );
    }

    const targetUser = await prisma.user.findUnique({
      where: { id },
      select: { id: true, email: true, role: true },
    });

    if (!targetUser) {
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }

    // Delete user (cascade will handle related records)
    await prisma.user.delete({ where: { id } });

    // Log admin action
    await logAdminAction({
      adminId: admin.id,
      adminEmail: admin.email,
      action: "DELETE_USER",
      category: "USER",
      targetUserId: id,
      metadata: { deletedEmail: targetUser.email, wasRole: targetUser.role },
    });

    return NextResponse.json({
      success: true,
      message: "User deleted successfully",
    });
  } catch (error) {
    console.error("Admin user delete error:", error);
    return NextResponse.json(
      { error: "Failed to delete user" },
      { status: 500 }
    );
  }
}