// src/app/api/admin/logs/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/adminHelpers";

export async function GET(req: NextRequest) {
  const authResult = await requireAdmin();
  if (authResult.error) return authResult.error;

  try {
    const { searchParams } = new URL(req.url);
    const category = searchParams.get("category") || "";
    const action = searchParams.get("action") || "";
    const adminEmail = searchParams.get("adminEmail") || "";
    const search = searchParams.get("search") || "";
    const page = parseInt(searchParams.get("page") || "1");
    const limit = parseInt(searchParams.get("limit") || "30");
    const skip = (page - 1) * limit;

    const where: Record<string, unknown> = {};
    if (category) where.category = category;
    if (action) where.action = action;
    if (adminEmail) where.adminEmail = { contains: adminEmail, mode: "insensitive" };
    if (search) {
      where.OR = [
        { action: { contains: search, mode: "insensitive" } },
        { adminEmail: { contains: search, mode: "insensitive" } },
        { note: { contains: search, mode: "insensitive" } },
      ];
    }

    const [logs, total, categoryStats] = await Promise.all([
      prisma.adminAction.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: "desc" },
      }),
      prisma.adminAction.count({ where }),
      prisma.adminAction.groupBy({
        by: ["category"],
        _count: { category: true },
      }),
    ]);

    // Enrich logs with target user info
    const enrichedLogs = await Promise.all(
      logs.map(async (log) => {
        let targetUser = null;
        if (log.targetUserId) {
          targetUser = await prisma.user.findUnique({
            where: { id: log.targetUserId },
            select: { id: true, email: true, username: true },
          });
        }

        // Parse metadata safely
        let parsedMetadata = null;
        if (log.metadata) {
          try {
            parsedMetadata = JSON.parse(log.metadata);
          } catch {
            parsedMetadata = null;
          }
        }

        return {
          ...log,
          targetUser,
          parsedMetadata,
        };
      })
    );

    // Category statistics
    const categoryCounts: Record<string, number> = {};
    categoryStats.forEach((stat) => {
      categoryCounts[stat.category] = stat._count.category;
    });

    return NextResponse.json({
      success: true,
      logs: enrichedLogs,
      pagination: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
      categoryCounts,
    });
  } catch (error) {
    console.error("Admin logs error:", error);
    return NextResponse.json(
      { error: "Failed to fetch audit logs" },
      { status: 500 }
    );
  }
}