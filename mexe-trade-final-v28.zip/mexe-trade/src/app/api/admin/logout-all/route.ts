// src/app/api/admin/logout-all/route.ts
// Invalidates every active session for the currently-logged-in admin,
// then clears their auth cookie — forcing re-login on all devices/browsers.

import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { clearAdminCookie } from "@/lib/cookies";
import { requireAdmin, logAdminAction } from "@/lib/adminHelpers";

export async function POST() {
  // Step 1 — Verify the caller is a valid, active admin
  const authResult = await requireAdmin();
  if (authResult.error) return authResult.error;

  const admin = authResult.admin;

  try {
    // Step 2 — Delete ALL sessions for this admin user (across all devices)
    const deleted = await prisma.session.deleteMany({
      where: { userId: admin.id },
    });

    // Step 3 — Audit log
    await logAdminAction({
      adminId: admin.id,
      adminEmail: admin.email,
      action: "LOGOUT_ALL_SESSIONS",
      category: "GENERAL",
      note: `Force-invalidated ${deleted.count} session(s) — all devices logged out`,
    });

    // Step 4 — Clear this device's admin cookie and respond
    const response = NextResponse.json({
      success: true,
      message: `Successfully logged out ${deleted.count} active session(s).`,
      sessionsRevoked: deleted.count,
    });

    clearAdminCookie(response);
    return response;
  } catch (error) {
    console.error("Logout-all sessions error:", error);
    return NextResponse.json(
      { error: "Failed to revoke sessions. Please try again." },
      { status: 500 }
    );
  }
}
