// src/app/api/admin/deposits/[id]/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin, logAdminAction } from "@/lib/adminHelpers";
import { createNotification, NotificationTemplates } from "@/lib/notificationHelper";

export async function PATCH(
  req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  const authResult = await requireAdmin();
  if (authResult.error) return authResult.error;

  const admin = authResult.admin;

  try {
    const { id } = await context.params;
    const body = await req.json();
    const { action, note } = body; // action: "APPROVE" | "REJECT"

    if (!action || !["APPROVE", "REJECT"].includes(action)) {
      return NextResponse.json(
        { error: "Invalid action. Must be 'APPROVE' or 'REJECT'" },
        { status: 400 }
      );
    }

    if (action === "REJECT" && !note?.trim()) {
      return NextResponse.json(
        { error: "Rejection reason is required" },
        { status: 400 }
      );
    }

    // ─── Find deposit ───
    const deposit = await prisma.deposit.findUnique({
      where: { id },
      include: {
        user: {
          select: { id: true, email: true, balance: true },
        },
      },
    });

    if (!deposit) {
      return NextResponse.json({ error: "Deposit not found" }, { status: 404 });
    }

    if (deposit.status !== "PENDING") {
      return NextResponse.json(
        { error: `Deposit is already ${deposit.status.toLowerCase()}` },
        { status: 400 }
      );
    }

    // ─── Handle approval: auto-credit balance ───
    if (action === "APPROVE") {
      // Atomic transaction: credit balance + update deposit
      // Conditional update prevents double-approval race (two admin
      // clicks/tabs can no longer credit the balance twice).
      await prisma.$transaction(async (tx) => {
        const approved = await tx.deposit.updateMany({
          where: { id, status: "PENDING" },
          data: {
            status: "APPROVED",
            adminNote: note?.trim() || null,
            processedAt: new Date(),
          },
        });

        if (approved.count === 0) {
          throw new Error("ALREADY_PROCESSED");
        }

        await tx.user.update({
          where: { id: deposit.userId },
          data: {
            balance: { increment: deposit.amount },
          },
        });
      });

      // Log admin action
      await logAdminAction({
        adminId: admin.id,
        adminEmail: admin.email,
        action: "APPROVE_DEPOSIT",
        category: "DEPOSIT",
        targetUserId: deposit.userId,
        targetId: deposit.id,
        amount: deposit.amount,
        note: note?.trim() || `Approved ${deposit.currency} deposit`,
        metadata: {
          userEmail: deposit.user.email,
          previousBalance: deposit.user.balance,
          newBalance: deposit.user.balance + deposit.amount,
          currency: deposit.currency,
          network: deposit.network,
          txId: deposit.txId,
        },
      });

      // Send notification to user
      await createNotification(
        NotificationTemplates.depositApproved(
          deposit.userId,
          deposit.amount,
          deposit.id
        )
      );

      return NextResponse.json({
        success: true,
        message: `Deposit approved. $${deposit.amount.toFixed(2)} credited to user.`,
      });
    }

    // ─── Handle rejection ───
    await prisma.deposit.update({
      where: { id },
      data: {
        status: "REJECTED",
        adminNote: note.trim(),
        processedAt: new Date(),
      },
    });

    await logAdminAction({
      adminId: admin.id,
      adminEmail: admin.email,
      action: "REJECT_DEPOSIT",
      category: "DEPOSIT",
      targetUserId: deposit.userId,
      targetId: deposit.id,
      amount: deposit.amount,
      note: note.trim(),
      metadata: {
        userEmail: deposit.user.email,
        currency: deposit.currency,
        network: deposit.network,
        txId: deposit.txId,
      },
    });

    // Send notification to user
    await createNotification(
      NotificationTemplates.depositRejected(
        deposit.userId,
        deposit.amount,
        deposit.id,
        note.trim()
      )
    );

    return NextResponse.json({
      success: true,
      message: "Deposit rejected. User will be notified.",
    });
  } catch (error) {
    if (error instanceof Error && error.message === "ALREADY_PROCESSED") {
      return NextResponse.json(
        { error: "This deposit has already been processed" },
        { status: 400 }
      );
    }
    console.error("Admin deposit update error:", error);
    return NextResponse.json(
      { error: "Failed to process deposit" },
      { status: 500 }
    );
  }
}