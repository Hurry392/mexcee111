// src/app/api/admin/withdrawals/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/adminHelpers";

export async function GET(req: NextRequest) {
  const authResult = await requireAdmin();
  if (authResult.error) return authResult.error;

  try {
    const { searchParams } = new URL(req.url);
    const status = searchParams.get("status") || "";
    const method = searchParams.get("method") || ""; // CRYPTO | BANK | UPI | PAYPAL
    const search = searchParams.get("search") || "";
    const page = parseInt(searchParams.get("page") || "1");
    const limit = parseInt(searchParams.get("limit") || "20");
    const skip = (page - 1) * limit;

    const where: Record<string, unknown> = {};
    if (status) where.status = status;
    if (method) where.method = method;
    if (search) {
      where.OR = [
        { user: { email: { contains: search, mode: "insensitive" } } },
        { user: { username: { contains: search, mode: "insensitive" } } },
      ];
    }

    const [withdrawals, total, pendingCount] = await Promise.all([
      prisma.withdrawal.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: "desc" },
        include: {
          user: {
            select: {
              id: true,
              email: true,
              username: true,
              balance: true,
              kycStatus: true,
              country: true,
            },
          },
        },
      }),
      prisma.withdrawal.count({ where }),
      prisma.withdrawal.count({ where: { status: "PENDING" } }),
    ]);

    return NextResponse.json({
      success: true,
      withdrawals,
      pagination: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
      pendingCount,
    });
  } catch (error) {
    console.error("Admin withdrawals list error:", error);
    return NextResponse.json(
      { error: "Failed to fetch withdrawals" },
      { status: 500 }
    );
  }
}