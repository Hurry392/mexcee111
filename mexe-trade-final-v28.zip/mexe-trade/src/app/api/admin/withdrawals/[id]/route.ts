// src/app/api/admin/withdrawals/[id]/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin, logAdminAction } from "@/lib/adminHelpers";
import { createNotification, NotificationTemplates } from "@/lib/notificationHelper";

export async function PATCH(
  req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  const authResult = await requireAdmin();
  if (authResult.error) return authResult.error;

  const admin = authResult.admin;

  try {
    const { id } = await context.params;
    const body = await req.json();
    const { action, note, txId } = body;
    // action: "APPROVE" | "REJECT" | "COMPLETE"
    // txId: optional, for COMPLETE action (blockchain tx hash)

    if (!action || !["APPROVE", "REJECT", "COMPLETE"].includes(action)) {
      return NextResponse.json(
        { error: "Invalid action. Must be 'APPROVE', 'REJECT', or 'COMPLETE'" },
        { status: 400 }
      );
    }

    if (action === "REJECT" && !note?.trim()) {
      return NextResponse.json(
        { error: "Rejection reason is required" },
        { status: 400 }
      );
    }

    // ─── Find withdrawal ───
    const withdrawal = await prisma.withdrawal.findUnique({
      where: { id },
      include: {
        user: {
          select: { id: true, email: true, balance: true },
        },
      },
    });

    if (!withdrawal) {
      return NextResponse.json({ error: "Withdrawal not found" }, { status: 404 });
    }

    // ─── State machine ───
    // PENDING → APPROVED / REJECTED
    // APPROVED → COMPLETED / REJECTED
    // REJECTED → (final)
    // COMPLETED → (final)

    if (action === "APPROVE") {
      if (withdrawal.status !== "PENDING") {
        return NextResponse.json(
          { error: `Cannot approve a ${withdrawal.status.toLowerCase()} withdrawal` },
          { status: 400 }
        );
      }

      await prisma.withdrawal.update({
        where: { id },
        data: {
          status: "APPROVED",
          adminNote: note?.trim() || null,
          processedAt: new Date(),
        },
      });

      await logAdminAction({
        adminId: admin.id,
        adminEmail: admin.email,
        action: "APPROVE_WITHDRAWAL",
        category: "WITHDRAWAL",
        targetUserId: withdrawal.userId,
        targetId: withdrawal.id,
        amount: withdrawal.amount,
        note: note?.trim() || "Withdrawal approved for processing",
        metadata: {
          userEmail: withdrawal.user.email,
          method: withdrawal.method,
          network: withdrawal.network,
        },
      });

      await createNotification(
        NotificationTemplates.withdrawalApproved(
          withdrawal.userId,
          withdrawal.amount,
          withdrawal.id
        )
      );

      return NextResponse.json({
        success: true,
        message: "Withdrawal approved. Ready to be processed.",
      });
    }

    if (action === "COMPLETE") {
      if (!["PENDING", "APPROVED"].includes(withdrawal.status)) {
        return NextResponse.json(
          { error: `Cannot complete a ${withdrawal.status.toLowerCase()} withdrawal` },
          { status: 400 }
        );
      }

      await prisma.withdrawal.update({
        where: { id },
        data: {
          status: "COMPLETED",
          adminNote: note?.trim() || withdrawal.adminNote,
          txId: txId?.trim() || null,
          processedAt: new Date(),
        },
      });

      await logAdminAction({
        adminId: admin.id,
        adminEmail: admin.email,
        action: "COMPLETE_WITHDRAWAL",
        category: "WITHDRAWAL",
        targetUserId: withdrawal.userId,
        targetId: withdrawal.id,
        amount: withdrawal.amount,
        note: note?.trim() || `Completed with txId: ${txId || "N/A"}`,
        metadata: {
          userEmail: withdrawal.user.email,
          method: withdrawal.method,
          network: withdrawal.network,
          txId: txId?.trim(),
        },
      });

      await createNotification(
        NotificationTemplates.withdrawalCompleted(
          withdrawal.userId,
          withdrawal.amount,
          withdrawal.id,
          txId?.trim()
        )
      );

      return NextResponse.json({
        success: true,
        message: "Withdrawal marked as completed.",
      });
    }

    // ─── REJECT: Refund balance to user ───
    if (withdrawal.status === "REJECTED" || withdrawal.status === "COMPLETED") {
      return NextResponse.json(
        { error: `Cannot reject a ${withdrawal.status.toLowerCase()} withdrawal` },
        { status: 400 }
      );
    }

    // Atomic: refund balance + update status.
    // Conditional update prevents double-reject race (double refund).
    await prisma.$transaction(async (tx) => {
      const rejected = await tx.withdrawal.updateMany({
        where: { id, status: { in: ["PENDING", "APPROVED"] } },
        data: {
          status: "REJECTED",
          adminNote: note.trim(),
          processedAt: new Date(),
        },
      });

      if (rejected.count === 0) {
        throw new Error("ALREADY_PROCESSED");
      }

      await tx.user.update({
        where: { id: withdrawal.userId },
        data: {
          balance: { increment: withdrawal.amount },
        },
      });
    });

    await logAdminAction({
      adminId: admin.id,
      adminEmail: admin.email,
      action: "REJECT_WITHDRAWAL",
      category: "WITHDRAWAL",
      targetUserId: withdrawal.userId,
      targetId: withdrawal.id,
      amount: withdrawal.amount,
      note: note.trim(),
      metadata: {
        userEmail: withdrawal.user.email,
        method: withdrawal.method,
        network: withdrawal.network,
        refunded: true,
        previousBalance: withdrawal.user.balance,
        newBalance: withdrawal.user.balance + withdrawal.amount,
      },
    });

    await createNotification(
      NotificationTemplates.withdrawalRejected(
        withdrawal.userId,
        withdrawal.amount,
        withdrawal.id,
        note.trim()
      )
    );

    return NextResponse.json({
      success: true,
      message: `Withdrawal rejected. $${withdrawal.amount.toFixed(2)} refunded to user.`,
    });
  } catch (error) {
    if (error instanceof Error && error.message === "ALREADY_PROCESSED") {
      return NextResponse.json(
        { error: "This withdrawal has already been processed" },
        { status: 400 }
      );
    }
    console.error("Admin withdrawal update error:", error);
    return NextResponse.json(
      { error: "Failed to process withdrawal" },
      { status: 500 }
    );
  }
}