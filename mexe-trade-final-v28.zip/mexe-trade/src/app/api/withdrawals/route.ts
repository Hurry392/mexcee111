// src/app/api/withdrawals/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getAuthToken } from "@/lib/cookies";
import { getUserFromToken, verifyPassword } from "@/lib/auth";
import { TRANSACTION_LIMITS, WITHDRAWAL_METHODS } from "@/config/constants";

// ─── POST: Create withdrawal request ───
export async function POST(req: NextRequest) {
  try {
    const token = await getAuthToken();
    const user = await getUserFromToken(token);

    if (!user) {
      return NextResponse.json(
        { error: "Not authenticated" },
        { status: 401 }
      );
    }

    // ─── Withdrawal hold check (TOS enforcement) ───
    if (user.withdrawalsFrozen) {
      return NextResponse.json(
        {
          error: user.withdrawalFreezeReason
            ? `Withdrawals are currently on hold for your account. Reason: ${user.withdrawalFreezeReason}`
            : "Withdrawals are currently on hold for your account. Please contact support.",
          withdrawalsFrozen: true,
          reason: user.withdrawalFreezeReason || null,
        },
        { status: 403 }
      );
    }

    const body = await req.json();
    const {
      amount,
      methodId,
      methodFields,
      withdrawalPassword,
    }: {
      amount: number | string;
      methodId: string;
      methodFields: Record<string, string>;
      withdrawalPassword: string;
    } = body;

    // ─── Validate method ───
    if (!methodId) {
      return NextResponse.json(
        { error: "Withdrawal method is required" },
        { status: 400 }
      );
    }

    const method = WITHDRAWAL_METHODS.find((m) => m.id === methodId);
    if (!method) {
      return NextResponse.json(
        { error: "Invalid withdrawal method" },
        { status: 400 }
      );
    }

    // ─── Amount validation (no minimum — any positive amount is allowed) ───
    const amountNum = parseFloat(String(amount));
    if (!amountNum || amountNum <= 0) {
      return NextResponse.json(
        { error: "Please enter a valid withdrawal amount" },
        { status: 400 }
      );
    }

    if (amountNum > user.balance) {
      return NextResponse.json(
        { error: "Insufficient balance" },
        { status: 400 }
      );
    }

    if (amountNum > method.maxWithdrawal) {
      return NextResponse.json(
        {
          error: `Maximum withdrawal for ${method.name} is $${method.maxWithdrawal.toLocaleString()}`,
        },
        { status: 400 }
      );
    }

    if (amountNum > TRANSACTION_LIMITS.MAX_WITHDRAWAL_USD) {
      return NextResponse.json(
        {
          error: `Maximum withdrawal is $${TRANSACTION_LIMITS.MAX_WITHDRAWAL_USD.toLocaleString()}`,
        },
        { status: 400 }
      );
    }

    // ─── Password check ───
    if (!withdrawalPassword) {
      return NextResponse.json(
        { error: "Withdrawal password is required" },
        { status: 400 }
      );
    }

    // ─── KYC check ───
    if (user.kycStatus !== "APPROVED") {
      return NextResponse.json(
        { error: "KYC verification is required for withdrawals" },
        { status: 403 }
      );
    }

    // ─── Validate method-specific fields ───
    if (!methodFields || typeof methodFields !== "object") {
      return NextResponse.json(
        { error: "Method details are required" },
        { status: 400 }
      );
    }

    for (const field of method.fields) {
      const value = methodFields[field.id]?.trim();
      if (field.required && !value) {
        return NextResponse.json(
          { error: `${field.label} is required` },
          { status: 400 }
        );
      }

      // Email validation for PayPal
      if (field.type === "email" && value) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(value)) {
          return NextResponse.json(
            { error: `${field.label} must be a valid email address` },
            { status: 400 }
          );
        }
      }
    }

    // ─── Verify withdrawal password ───
    const fullUser = await prisma.user.findUnique({
      where: { id: user.id },
      select: { withdrawalPassword: true, passwordHash: true },
    });

    if (!fullUser) {
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }

    const passwordToCheck = fullUser.withdrawalPassword || fullUser.passwordHash;
    const isValid = await verifyPassword(withdrawalPassword, passwordToCheck);

    if (!isValid) {
      return NextResponse.json(
        { error: "Invalid withdrawal password" },
        { status: 401 }
      );
    }

    // ─── Determine DB fields based on method category ───
    // For crypto: walletAddress goes to its own field
    // For bank/upi/paypal: details get serialized into walletAddress as JSON
    //   (this avoids schema migration — admin panel will parse it)
    let walletAddressForDB: string | null = null;
    let networkForDB: string = method.network || method.id;
    const methodForDB: string = method.category === "CRYPTO" ? "CRYPTO" : "BANK_TRANSFER";

    if (method.category === "CRYPTO") {
      walletAddressForDB = methodFields.walletAddress?.trim() || null;
    } else {
      // Pack all non-crypto details into walletAddress as JSON
      // Admin panel will parse this on display
      const details: Record<string, string> = {};
      for (const field of method.fields) {
        const value = methodFields[field.id]?.trim();
        if (value) details[field.id] = value;
      }
      walletAddressForDB = JSON.stringify({
        methodId: method.id,
        methodName: method.name,
        category: method.category,
        ...details,
      });
      networkForDB = method.id; // e.g., "BANK", "UPI", "PAYPAL"
    }

    // ─── Atomic transaction: deduct balance + create record ───
    const result = await prisma.$transaction(async (tx) => {
      // Conditional decrement prevents concurrent withdrawals from
      // overdrawing the balance (race-condition safe).
      const deducted = await tx.user.updateMany({
        where: { id: user.id, balance: { gte: amountNum } },
        data: { balance: { decrement: amountNum } },
      });

      if (deducted.count === 0) {
        throw new Error("INSUFFICIENT_BALANCE");
      }

      const withdrawal = await tx.withdrawal.create({
        data: {
          userId: user.id,
          amount: amountNum,
          currency: "USDT",
          network: networkForDB,
          method: methodForDB,
          walletAddress: walletAddressForDB,
          status: "PENDING",
        },
      });

      return withdrawal;
    });

    return NextResponse.json(
      {
        success: true,
        message: "Withdrawal request submitted successfully",
        withdrawal: result,
      },
      { status: 201 }
    );
  } catch (error) {
    if (error instanceof Error && error.message === "INSUFFICIENT_BALANCE") {
      return NextResponse.json(
        { error: "Insufficient balance" },
        { status: 400 }
      );
    }
    console.error("Withdrawal error:", error);
    return NextResponse.json(
      { error: "Failed to submit withdrawal request" },
      { status: 500 }
    );
  }
}

// ─── GET: Fetch user's withdrawals ───
export async function GET() {
  try {
    const token = await getAuthToken();
    const user = await getUserFromToken(token);

    if (!user) {
      return NextResponse.json(
        { error: "Not authenticated" },
        { status: 401 }
      );
    }

    const withdrawals = await prisma.withdrawal.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: "desc" },
    });

    return NextResponse.json({ withdrawals }, { status: 200 });
  } catch (error) {
    console.error("Fetch withdrawals error:", error);
    return NextResponse.json(
      { error: "Failed to fetch withdrawals" },
      { status: 500 }
    );
  }
}