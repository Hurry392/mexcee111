// src/app/api/security/withdrawal-password/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getAuthToken } from "@/lib/cookies";
import {
  getUserFromToken,
  verifyPassword,
  hashPassword,
  validatePassword,
} from "@/lib/auth";

// ─── POST: Set or change withdrawal password ───
export async function POST(req: NextRequest) {
  try {
    const token = await getAuthToken();
    const user = await getUserFromToken(token);

    if (!user) {
      return NextResponse.json(
        { error: "Not authenticated" },
        { status: 401 }
      );
    }

    const body = await req.json();
    const { accountPassword, newWithdrawalPassword, currentWithdrawalPassword } = body;

    if (!accountPassword || !newWithdrawalPassword) {
      return NextResponse.json(
        { error: "Account password and new withdrawal password are required" },
        { status: 400 }
      );
    }

    // Validate new withdrawal password strength
    const validation = validatePassword(newWithdrawalPassword);
    if (!validation.valid) {
      return NextResponse.json(
        { error: validation.message },
        { status: 400 }
      );
    }

    // Get full user
    const fullUser = await prisma.user.findUnique({
      where: { id: user.id },
      select: { passwordHash: true, withdrawalPassword: true },
    });

    if (!fullUser) {
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }

    // Verify account password
    const isAccountValid = await verifyPassword(accountPassword, fullUser.passwordHash);
    if (!isAccountValid) {
      return NextResponse.json(
        { error: "Account password is incorrect" },
        { status: 401 }
      );
    }

    // If changing existing withdrawal password, verify old one
    if (fullUser.withdrawalPassword) {
      if (!currentWithdrawalPassword) {
        return NextResponse.json(
          { error: "Current withdrawal password is required to change it" },
          { status: 400 }
        );
      }
      const isCurrentValid = await verifyPassword(
        currentWithdrawalPassword,
        fullUser.withdrawalPassword
      );
      if (!isCurrentValid) {
        return NextResponse.json(
          { error: "Current withdrawal password is incorrect" },
          { status: 401 }
        );
      }
    }

    // Prevent same as account password
    const sameAsAccount = await verifyPassword(newWithdrawalPassword, fullUser.passwordHash);
    if (sameAsAccount) {
      return NextResponse.json(
        { error: "Withdrawal password must be different from your account password" },
        { status: 400 }
      );
    }

    // Hash and save
    const newHash = await hashPassword(newWithdrawalPassword);
    await prisma.user.update({
      where: { id: user.id },
      data: { withdrawalPassword: newHash },
    });

    return NextResponse.json(
      {
        success: true,
        message: fullUser.withdrawalPassword
          ? "Withdrawal password changed successfully"
          : "Withdrawal password set successfully",
        isSet: true,
      },
      { status: 200 }
    );
  } catch (error) {
    console.error("Withdrawal password error:", error);
    return NextResponse.json(
      { error: "Failed to update withdrawal password" },
      { status: 500 }
    );
  }
}

// ─── GET: Check if withdrawal password is set ───
export async function GET() {
  try {
    const token = await getAuthToken();
    const user = await getUserFromToken(token);

    if (!user) {
      return NextResponse.json(
        { error: "Not authenticated" },
        { status: 401 }
      );
    }

    const fullUser = await prisma.user.findUnique({
      where: { id: user.id },
      select: { withdrawalPassword: true },
    });

    return NextResponse.json(
      { isSet: !!fullUser?.withdrawalPassword },
      { status: 200 }
    );
  } catch (error) {
    console.error("Withdrawal password check error:", error);
    return NextResponse.json(
      { error: "Failed to check status" },
      { status: 500 }
    );
  }
}