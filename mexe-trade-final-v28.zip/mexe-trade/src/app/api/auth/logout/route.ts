// src/app/api/auth/logout/route.ts
import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getAuthToken, clearAuthCookie } from "@/lib/cookies";

export async function POST() {
  try {
    const token = await getAuthToken();

    // Delete session from database
    if (token) {
      await prisma.session.deleteMany({
        where: { token },
      });
    }

    const response = NextResponse.json(
      { success: true, message: "Logged out successfully" },
      { status: 200 }
    );

    return clearAuthCookie(response);
  } catch (error) {
    console.error("Logout error:", error);
    return NextResponse.json(
      { error: "Logout failed" },
      { status: 500 }
    );
  }
}