// src/app/api/auth/register/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import {
  hashPassword,
  generateToken,
  generateUniqueReferralCode,
  validateEmail,
  validatePassword,
} from "@/lib/auth";
import { setAuthCookie } from "@/lib/cookies";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { email, phone, password, referralCode, method } = body;

    // ─── Validation ───
    if (method !== "email" && method !== "phone") {
      return NextResponse.json(
        { error: "Invalid registration method" },
        { status: 400 }
      );
    }

    if (method === "email") {
      if (!email || !validateEmail(email)) {
        return NextResponse.json(
          { error: "Please provide a valid email address" },
          { status: 400 }
        );
      }
    } else if (method === "phone") {
      if (!phone || phone.length < 7) {
        return NextResponse.json(
          { error: "Please provide a valid phone number" },
          { status: 400 }
        );
      }
    }

    const passwordCheck = validatePassword(password);
    if (!passwordCheck.valid) {
      return NextResponse.json({ error: passwordCheck.message }, { status: 400 });
    }

    // ─── Check if user already exists ───
    const identifier = method === "email" ? email.toLowerCase() : phone;

    const existingUser = await prisma.user.findFirst({
      where: method === "email" ? { email: identifier } : { phone: identifier },
    });

    if (existingUser) {
      return NextResponse.json(
        {
          error:
            method === "email"
              ? "An account with this email already exists"
              : "An account with this phone number already exists",
        },
        { status: 409 }
      );
    }

    // ─── Validate referral code (if provided) ───
    let referredByCode: string | null = null;
    if (referralCode && referralCode.trim()) {
      const referrer = await prisma.user.findUnique({
        where: { referralCode: referralCode.trim().toUpperCase() },
      });
      if (!referrer) {
        return NextResponse.json(
          { error: "Invalid referral code" },
          { status: 400 }
        );
      }
      referredByCode = referrer.referralCode;
    }

    // ─── Create user ───
    const passwordHash = await hashPassword(password);
    const newReferralCode = await generateUniqueReferralCode();

    const user = await prisma.user.create({
      data: {
        email: method === "email" ? identifier : `${phone}@phone.pe`, // Placeholder for phone users
        phone: method === "phone" ? identifier : null,
        passwordHash,
        referralCode: newReferralCode,
        referredBy: referredByCode,
        lastLoginAt: new Date(),
      },
      select: {
        id: true,
        uid: true,
        email: true,
        phone: true,
        username: true,
        balance: true,
        role: true,
        isVerified: true,
        kycStatus: true,
        referralCode: true,
        createdAt: true,
      },
    });

    // ─── Generate JWT token ───
    const token = generateToken({
      userId: user.id,
      email: user.email,
      role: user.role,
    });

    // ─── Create session record ───
    await prisma.session.create({
      data: {
        token,
        userId: user.id,
        ipAddress: req.headers.get("x-forwarded-for") || "unknown",
        userAgent: req.headers.get("user-agent") || "unknown",
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days
      },
    });

    // ─── Set cookie + return ───
    const response = NextResponse.json(
      {
        success: true,
        message: "Account created successfully",
        user,
        token,
      },
      { status: 201 }
    );

    return setAuthCookie(response, token);
  } catch (error) {
    // Handle unique-constraint race (two simultaneous signups with same email/phone)
    if (
      error &&
      typeof error === "object" &&
      "code" in error &&
      (error as { code?: string }).code === "P2002"
    ) {
      return NextResponse.json(
        { error: "An account with this email or phone already exists" },
        { status: 409 }
      );
    }
    console.error("Register error:", error);
    return NextResponse.json(
      { error: "Something went wrong. Please try again." },
      { status: 500 }
    );
  }
}