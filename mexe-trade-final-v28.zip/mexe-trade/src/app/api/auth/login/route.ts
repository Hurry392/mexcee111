// src/app/api/auth/login/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyPassword, generateToken } from "@/lib/auth";
import { setAuthCookie } from "@/lib/cookies";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { email, phone, password, method } = body;

    // ─── Validation ───
    if (!password) {
      return NextResponse.json(
        { error: "Password is required" },
        { status: 400 }
      );
    }

    const identifier = method === "email" ? email?.toLowerCase() : phone;

    if (!identifier) {
      return NextResponse.json(
        { error: `${method === "email" ? "Email" : "Phone"} is required` },
        { status: 400 }
      );
    }

    // ─── Find user ───
    const user = await prisma.user.findFirst({
      where: method === "email" ? { email: identifier } : { phone: identifier },
    });

    if (!user) {
      return NextResponse.json(
        { error: "Invalid credentials" },
        { status: 401 }
      );
    }

    if (!user.isActive) {
      return NextResponse.json(
        { error: "Your account has been suspended. Please contact support." },
        { status: 403 }
      );
    }

    // ─── Verify password ───
    const isValid = await verifyPassword(password, user.passwordHash);
    if (!isValid) {
      return NextResponse.json(
        { error: "Invalid credentials" },
        { status: 401 }
      );
    }

    // ─── Generate token ───
    const token = generateToken({
      userId: user.id,
      email: user.email,
      role: user.role,
    });

    // ─── Update last login + create session ───
    await prisma.user.update({
      where: { id: user.id },
      data: { lastLoginAt: new Date() },
    });

    await prisma.session.create({
      data: {
        token,
        userId: user.id,
        ipAddress: req.headers.get("x-forwarded-for") || "unknown",
        userAgent: req.headers.get("user-agent") || "unknown",
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      },
    });

    // ─── Return safe user data ───
    const safeUser = {
      id: user.id,
      uid: user.uid,
      email: user.email,
      phone: user.phone,
      username: user.username,
      balance: user.balance,
      role: user.role,
      isVerified: user.isVerified,
      kycStatus: user.kycStatus,
      withdrawalsFrozen: user.withdrawalsFrozen,
      withdrawalFreezeReason: user.withdrawalFreezeReason,
      referralCode: user.referralCode,
      createdAt: user.createdAt,
    };

    const response = NextResponse.json(
      {
        success: true,
        message: "Logged in successfully",
        user: safeUser,
        token,
      },
      { status: 200 }
    );

    return setAuthCookie(response, token);
  } catch (error) {
    console.error("Login error:", error);
    return NextResponse.json(
      { error: "Something went wrong. Please try again." },
      { status: 500 }
    );
  }
}