// src/app/page.tsx
"use client";

import { useMarkets } from "@/hooks/useMarkets";
import { formatPrice, formatPercent } from "@/lib/markets";
import { useAuthStore } from "@/store/authStore";
import Footer from "@/components/Footer";
import InstallApp from "@/components/InstallApp";
import { motion } from "framer-motion";
import Link from "next/link";
import {
  TrendingUp,
  TrendingDown,
  Wallet,
  ArrowDownUp,
  ShieldCheck,
  Zap,
  ArrowUpRight,
  Activity,
  DollarSign,
  BarChart3,
  Sparkles,
  ChevronRight,
} from "lucide-react";

// ─── Quick action shortcuts ───
const QUICK_ACTIONS = [
  {
    label: "Deposit",
    description: "Add funds to your wallet",
    icon: ArrowDownUp,
    href: "/funds",
    color: "from-blue-500 to-cyan-500",
  },
  {
    label: "Trade Now",
    description: "Start trading instantly",
    icon: Zap,
    href: "/trade",
    color: "from-purple-500 to-pink-500",
  },
  {
    label: "View Markets",
    description: "Explore live prices",
    icon: BarChart3,
    href: "/markets",
    color: "from-green-500 to-emerald-500",
  },
  {
    label: "Verify Identity",
    description: "Complete KYC",
    icon: ShieldCheck,
    href: "/kyc",
    color: "from-amber-500 to-orange-500",
  },
];

// ─── Animation variants ───
const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.08 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.4, ease: "easeOut" as const },
  },
};

export default function Home() {
  const { user, isAuthenticated } = useAuthStore();
  const userBalance = user?.balance ?? 0;

  // ─── Smart hero CTA based on auth state ───
  const heroCTA = isAuthenticated
    ? { label: "Start Trading", href: "/trade" }
    : { label: "Get Started", href: "/signup" };

  // ─── Smart stats based on auth state ───
  const QUICK_STATS = [
    {
      label: "Total Balance",
      value: `$${userBalance.toFixed(2)}`,
      change: "+0.00%",
      isPositive: true,
      icon: Wallet,
      iconBg: "bg-blue-500/10",
      iconColor: "text-blue-400",
    },
    {
      label: "24h P&L",
      value: "$0.00",
      change: "+0.00%",
      isPositive: true,
      icon: TrendingUp,
      iconBg: "bg-green-500/10",
      iconColor: "text-green-400",
    },
    {
      label: "Active Trades",
      value: "0",
      change: "0 Open",
      isPositive: true,
      icon: Activity,
      iconBg: "bg-purple-500/10",
      iconColor: "text-purple-400",
    },
    {
      label: "Total Deposits",
      value: "$0.00",
      change: "0 Total",
      isPositive: true,
      icon: DollarSign,
      iconBg: "bg-amber-500/10",
      iconColor: "text-amber-400",
    },
  ];

  return (
    <div className="min-h-full mesh-bg">
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8 space-y-6"
      >
        {/* ═══════════ HERO BANNER ═══════════ */}
        <motion.section variants={itemVariants}>
          <div className="relative overflow-hidden rounded-2xl border border-[var(--border)] bg-gradient-to-br from-[var(--accent)]/10 via-purple-500/5 to-transparent p-6 sm:p-8 lg:p-10">
            <div className="absolute -top-20 -right-20 w-64 h-64 rounded-full bg-[var(--accent)]/10 blur-3xl pointer-events-none" />
            <div className="absolute -bottom-20 -left-20 w-64 h-64 rounded-full bg-purple-500/10 blur-3xl pointer-events-none" />

            <div className="relative z-10 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
              <div className="flex-1">
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[var(--accent)]/10 border border-[var(--accent)]/20 mb-4">
                  <Sparkles className="w-3 h-3 text-[var(--accent)]" />
                  <span className="text-[10px] uppercase tracking-wider font-semibold text-[var(--accent)]">
                    {isAuthenticated ? "Welcome Back" : "Get Started"}
                  </span>
                </div>
                <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-foreground mb-2 leading-tight">
                  Trade <span className="gradient-text">Crypto</span> with Confidence
                </h1>
                <p className="text-sm sm:text-base text-gray-400 max-w-xl">
                  Real-time markets, secure deposits, and professional trading tools — all in one premium platform.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-3">
                <Link href={heroCTA.href}>
                  <button className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-gradient-to-r from-yellow-500 to-amber-500 text-black font-bold text-sm hover:from-yellow-400 hover:to-amber-400 transition-all active:scale-95 shadow-lg shadow-yellow-500/20 flex items-center justify-center gap-2">
                    {heroCTA.label}
                    <ArrowUpRight size={16} />
                  </button>
                </Link>
                <Link href="/markets">
                  <button className="w-full sm:w-auto px-5 py-2.5 rounded-xl border border-[var(--border)] text-foreground font-medium text-sm hover:bg-white/5 transition-all active:scale-95">
                    Explore Markets
                  </button>
                </Link>
              </div>
            </div>
          </div>
        </motion.section>

        {/* ═══════════ QUICK STATS GRID ═══════════ */}
        <motion.section variants={itemVariants}>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
            {QUICK_STATS.map((stat) => {
              const Icon = stat.icon;
              return (
                <div
                  key={stat.label}
                  className="group glass-panel rounded-2xl p-4 sm:p-5 hover:border-[var(--accent)]/30 transition-all duration-300 cursor-pointer"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className={`w-9 h-9 rounded-lg ${stat.iconBg} flex items-center justify-center`}>
                      <Icon size={18} className={stat.iconColor} />
                    </div>
                    <span
                      className={`text-[10px] font-semibold px-2 py-0.5 rounded-md ${
                        stat.isPositive
                          ? "bg-green-500/10 text-green-400"
                          : "bg-red-500/10 text-red-400"
                      }`}
                    >
                      {stat.change}
                    </span>
                  </div>
                  <div className="text-[11px] text-gray-500 mb-1 uppercase tracking-wider font-medium">
                    {stat.label}
                  </div>
                  <div className="text-lg sm:text-xl font-bold text-foreground">
                    {stat.value}
                  </div>
                </div>
              );
            })}
          </div>
        </motion.section>

        {/* ═══════════ QUICK ACTIONS ═══════════ */}
        <motion.section variants={itemVariants}>
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-base sm:text-lg font-bold text-foreground">
              Quick Actions
            </h2>
          </div>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
            {QUICK_ACTIONS.map((action) => {
              const Icon = action.icon;
              return (
                <Link key={action.label} href={action.href}>
                  <motion.div
                    whileHover={{ y: -2 }}
                    whileTap={{ scale: 0.98 }}
                    className="group relative overflow-hidden rounded-2xl border border-[var(--border)] bg-card p-4 sm:p-5 cursor-pointer hover:border-[var(--accent)]/30 transition-all duration-300 h-full"
                  >
                    <div
                      className={`w-10 h-10 rounded-xl bg-gradient-to-br ${action.color} flex items-center justify-center mb-3 shadow-lg`}
                    >
                      <Icon size={18} className="text-white" />
                    </div>
                    <div className="text-sm font-semibold text-foreground mb-0.5">
                      {action.label}
                    </div>
                    <div className="text-[11px] text-gray-500">
                      {action.description}
                    </div>
                    <ChevronRight
                      size={14}
                      className="absolute top-4 right-4 text-gray-600 group-hover:text-[var(--accent)] group-hover:translate-x-0.5 transition-all"
                    />
                  </motion.div>
                </Link>
              );
            })}
          </div>
        </motion.section>

        {/* ═══════════ TOP MARKETS (LIVE) ═══════════ */}
        <motion.section variants={itemVariants}>
          <TopMarketsLive />
        </motion.section>

        {/* ═══════════ INSTALL APP ═══════════ */}
        <motion.section variants={itemVariants}>
          <InstallApp />
        </motion.section>

        {/* ═══════════ INFO CARDS BOTTOM ═══════════ */}
        <motion.section variants={itemVariants}>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[
              {
                icon: ShieldCheck,
                title: "Bank-Grade Security",
                description: "Your funds are protected with industry-leading security protocols.",
                color: "text-blue-400",
                bg: "bg-blue-500/10",
              },
              {
                icon: Zap,
                title: "Lightning Fast",
                description: "Execute trades in milliseconds with our optimized engine.",
                color: "text-yellow-400",
                bg: "bg-yellow-500/10",
              },
              {
                icon: Activity,
                title: "24/7 Live Markets",
                description: "Real-time price updates from global crypto markets.",
                color: "text-green-400",
                bg: "bg-green-500/10",
              },
            ].map((item) => {
              const Icon = item.icon;
              return (
                <div
                  key={item.title}
                  className="glass-panel rounded-2xl p-5 hover:border-[var(--accent)]/30 transition-all"
                >
                  <div className={`w-10 h-10 rounded-xl ${item.bg} flex items-center justify-center mb-3`}>
                    <Icon size={20} className={item.color} />
                  </div>
                  <h3 className="text-sm font-semibold text-foreground mb-1">
                    {item.title}
                  </h3>
                  <p className="text-xs text-gray-500 leading-relaxed">
                    {item.description}
                  </p>
                </div>
              );
            })}
          </div>
        </motion.section>

        <div className="h-4" />
      </motion.div>

      <Footer />
    </div>
  );
}

// ─── Live Top Markets Component ───
function TopMarketsLive() {
  const { markets, loading } = useMarkets(30000);
  const topMarkets = markets.slice(0, 5);

  return (
    <>
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-base sm:text-lg font-bold text-foreground">
          Top Markets
        </h2>
        <Link href="/markets" className="flex items-center gap-1 text-xs font-medium text-[var(--accent)] hover:gap-2 transition-all">
          View All
          <ChevronRight size={14} />
        </Link>
      </div>

      <div className="glass-panel rounded-2xl overflow-hidden">
        <div className="hidden sm:grid grid-cols-12 gap-4 px-5 py-3 border-b border-[var(--border)] text-[10px] uppercase tracking-wider font-semibold text-gray-500">
          <div className="col-span-5">Asset</div>
          <div className="col-span-4 text-right">Price</div>
          <div className="col-span-3 text-right">24h Change</div>
        </div>

        {loading && (
          <div className="flex items-center justify-center py-12">
            <div className="text-xs text-gray-500">Loading markets...</div>
          </div>
        )}

        {!loading && topMarkets.length > 0 && (
          <div className="divide-y divide-[var(--border)]">
            {topMarkets.map((coin) => {
              const isUp = coin.price_change_percentage_24h >= 0;
              return (
                <Link key={coin.id} href={`/trade?coin=${coin.id}`}>
                  <div className="grid grid-cols-12 gap-2 sm:gap-4 px-4 sm:px-5 py-3.5 hover:bg-white/[0.02] transition-colors cursor-pointer items-center">
                    <div className="col-span-6 sm:col-span-5 flex items-center gap-3">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={coin.image}
                        alt={coin.name}
                        className="w-9 h-9 rounded-full"
                      />
                      <div>
                        <div className="text-sm font-semibold text-foreground uppercase">
                          {coin.symbol}
                        </div>
                        <div className="text-[11px] text-gray-500">
                          {coin.name}
                        </div>
                      </div>
                    </div>

                    <div className="col-span-3 sm:col-span-4 text-right">
                      <div className="text-sm font-semibold text-foreground font-mono">
                        ${formatPrice(coin.current_price)}
                      </div>
                    </div>

                    <div className="col-span-3 text-right">
                      <div
                        className={`inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs font-semibold ${
                          isUp
                            ? "bg-green-500/10 text-green-400"
                            : "bg-red-500/10 text-red-400"
                        }`}
                      >
                        {isUp ? <TrendingUp size={11} /> : <TrendingDown size={11} />}
                        {formatPercent(coin.price_change_percentage_24h)}
                      </div>
                    </div>
                  </div>
                </Link>
              );
            })}
          </div>
        )}
      </div>
    </>
  );
}