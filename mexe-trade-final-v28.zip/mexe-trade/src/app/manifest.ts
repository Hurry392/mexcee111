// src/app/manifest.ts
import type { MetadataRoute } from "next";

// Web App Manifest — makes the site installable as a home-screen app on
// Android ("Install app") and iOS ("Add to Home Screen"). Launches
// fullscreen (no browser UI) with the icon, name, and theme below.
export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "MEXC Trade — Global Crypto Exchange",
    short_name: "MEXC Trade",
    description:
      "Trade cryptocurrencies with confidence — secure deposits, real-time markets, and professional trading tools.",
    id: "/",
    start_url: "/",
    scope: "/",
    display: "standalone", // fullscreen, no browser chrome
    background_color: "#030712", // splash screen background
    theme_color: "#030712", // status/nav bar tint
    orientation: "portrait",
    icons: [
      {
        src: "/icon-192.png",
        sizes: "192x192",
        type: "image/png",
        purpose: "any",
      },
      {
        src: "/icon-512.png",
        sizes: "512x512",
        type: "image/png",
        purpose: "any",
      },
      {
        // Maskable icon with safe padding so Android's adaptive icon
        // shapes (circle/squircle) don't crop the logo.
        src: "/icon-maskable-512.png",
        sizes: "512x512",
        type: "image/png",
        purpose: "maskable",
      },
    ],
  };
}
