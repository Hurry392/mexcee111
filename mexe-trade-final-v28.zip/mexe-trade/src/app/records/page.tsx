// src/app/records/page.tsx
"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Link from "next/link";
import {
  ArrowDownLeft,
  ArrowUpRight,
  Clock,
  CheckCircle2,
  XCircle,
  Inbox,
  ExternalLink,
  Loader2,
  TrendingUp,
  TrendingDown,
  Zap,
  Activity,
} from "lucide-react";
import { depositsAPI, withdrawalsAPI, tradesAPI } from "@/lib/api";
import { formatPrice } from "@/lib/markets";

type RecordsTab = "deposits" | "withdrawals" | "trades";

interface Transaction {
  id: string;
  amount: number;
  currency: string;
  network: string;
  method: string;
  status: string;
  txId?: string | null;
  walletAddress?: string | null;
  screenshotUrl?: string | null;
  adminNote?: string | null;
  createdAt: string;
  processedAt?: string | null;
}

interface Trade {
  id: string;
  coinId: string;
  coinSymbol: string;
  side: "BUY" | "SELL";
  leverage: number;
  marginAmount: number;
  positionSize: number;
  quantity: number;
  entryPrice: number;
  exitPrice: number | null;
  fee: number;
  pnl: number;
  pnlPercent: number;
  status: string;
  closeReason?: string | null;
  openedAt: string;
  closedAt?: string | null;
}

export default function RecordsPage() {
  const [tab, setTab] = useState<RecordsTab>("deposits");
  const [deposits, setDeposits] = useState<Transaction[]>([]);
  const [withdrawals, setWithdrawals] = useState<Transaction[]>([]);
  const [trades, setTrades] = useState<Trade[]>([]);
  const [tradeStats, setTradeStats] = useState<{
    openCount: number;
    closedCount: number;
    totalRealizedPnL: number;
  } | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      const [depResult, wdResult, tradesResult] = await Promise.all([
        depositsAPI.list(),
        withdrawalsAPI.list(),
        tradesAPI.list(),
      ]);

      if (depResult.deposits) {
        setDeposits(depResult.deposits as Transaction[]);
      }
      if (wdResult.withdrawals) {
        setWithdrawals(wdResult.withdrawals as Transaction[]);
      }
      if (tradesResult.trades) {
        setTrades(tradesResult.trades as Trade[]);
      }
      if (tradesResult.stats) {
        setTradeStats(
          tradesResult.stats as {
            openCount: number;
            closedCount: number;
            totalRealizedPnL: number;
          }
        );
      }
      setLoading(false);
    };

    fetchData();
  }, []);

  return (
    <div className="min-h-full mesh-bg">
      <div className="max-w-3xl mx-auto p-4 sm:p-6 lg:p-8 space-y-5">
        {/* ═══════════ HEADER ═══════════ */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <h1 className="text-2xl sm:text-3xl font-bold text-foreground mb-1.5">
            Transaction Records
          </h1>
          <p className="text-sm text-gray-500">
            View your deposits, withdrawals, and trade history
          </p>
        </motion.div>

        {/* ═══════════ TAB SWITCHER (3 tabs) ═══════════ */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="relative flex p-1 rounded-xl bg-card border border-[var(--border)]"
        >
          {([
            {
              id: "deposits" as RecordsTab,
              label: "Deposits",
              count: deposits.length,
              icon: ArrowDownLeft,
              color: "text-green-400",
            },
            {
              id: "withdrawals" as RecordsTab,
              label: "Withdrawals",
              count: withdrawals.length,
              icon: ArrowUpRight,
              color: "text-red-400",
            },
            {
              id: "trades" as RecordsTab,
              label: "Trades",
              count: trades.length,
              icon: Activity,
              color: "text-[var(--accent)]",
            },
          ]).map((t) => {
            const Icon = t.icon;
            return (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`relative flex-1 flex items-center justify-center gap-1.5 py-2.5 sm:py-3 text-xs sm:text-sm font-semibold rounded-lg transition-colors z-10 ${
                  tab === t.id ? "text-foreground" : "text-gray-500 hover:text-gray-300"
                }`}
              >
                {tab === t.id && (
                  <motion.div
                    layoutId="recordsTabPill"
                    className="absolute inset-0 rounded-lg bg-white/[0.05] border border-[var(--border)]"
                    transition={{ type: "spring", stiffness: 300, damping: 30 }}
                  />
                )}
                <Icon size={14} className={`relative z-10 ${tab === t.id ? t.color : ""}`} />
                <span className="relative z-10 hidden sm:inline">{t.label}</span>
                <span className="relative z-10 sm:hidden text-[11px]">{t.label}</span>
                {t.count > 0 && (
                  <span className="relative z-10 ml-0.5 px-1.5 py-0.5 rounded-md text-[9px] font-bold bg-white/10">
                    {t.count}
                  </span>
                )}
              </button>
            );
          })}
        </motion.div>

        {/* ═══════════ RECORDS LIST ═══════════ */}
        <AnimatePresence mode="wait">
          <motion.div
            key={tab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
          >
            {loading ? (
              <div className="flex items-center justify-center py-20">
                <Loader2 className="w-6 h-6 text-[var(--accent)] animate-spin" />
              </div>
            ) : tab === "deposits" ? (
              deposits.length === 0 ? (
                <EmptyState tab="deposits" />
              ) : (
                <div className="space-y-2">
                  {deposits.map((record, idx) => (
                    <RecordCard
                      key={record.id}
                      record={record}
                      type="deposits"
                      delay={idx * 0.05}
                    />
                  ))}
                </div>
              )
            ) : tab === "withdrawals" ? (
              withdrawals.length === 0 ? (
                <EmptyState tab="withdrawals" />
              ) : (
                <div className="space-y-2">
                  {withdrawals.map((record, idx) => (
                    <RecordCard
                      key={record.id}
                      record={record}
                      type="withdrawals"
                      delay={idx * 0.05}
                    />
                  ))}
                </div>
              )
            ) : trades.length === 0 ? (
              <EmptyTradesState />
            ) : (
              <div className="space-y-2">
                {tradeStats && (
                  <TradeSummary
                    trades={trades}
                    openCount={tradeStats.openCount}
                    closedCount={tradeStats.closedCount}
                    totalRealizedPnL={tradeStats.totalRealizedPnL}
                  />
                )}
                {trades.map((trade, idx) => (
                  <TradeCard key={trade.id} trade={trade} delay={idx * 0.05} />
                ))}
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}

// ─── Empty State (Deposits/Withdrawals) ───
function EmptyState({ tab }: { tab: "deposits" | "withdrawals" }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 px-4 rounded-2xl border border-dashed border-[var(--border)]">
      <div className="w-14 h-14 rounded-2xl bg-white/[0.03] border border-[var(--border)] flex items-center justify-center mb-4">
        <Inbox size={24} className="text-gray-500" />
      </div>
      <p className="text-sm font-semibold text-foreground mb-1">
        No {tab} records found
      </p>
      <p className="text-xs text-gray-500 mb-5">
        Your {tab} history will appear here
      </p>
      <Link href="/funds">
        <button className="px-4 py-2 rounded-lg bg-[var(--accent)]/15 border border-[var(--accent)]/20 text-[var(--accent)] text-xs font-semibold hover:bg-[var(--accent)]/25 transition-all">
          {tab === "deposits" ? "Make a Deposit" : "Withdraw Funds"}
        </button>
      </Link>
    </div>
  );
}

// ─── Empty Trades State ───
function EmptyTradesState() {
  return (
    <div className="flex flex-col items-center justify-center py-16 px-4 rounded-2xl border border-dashed border-[var(--border)]">
      <div className="w-14 h-14 rounded-2xl bg-white/[0.03] border border-[var(--border)] flex items-center justify-center mb-4">
        <Activity size={24} className="text-gray-500" />
      </div>
      <p className="text-sm font-semibold text-foreground mb-1">
        No trades yet
      </p>
      <p className="text-xs text-gray-500 mb-5">
        Your trading history will appear here
      </p>
      <Link href="/trade">
        <button className="px-4 py-2 rounded-lg bg-[var(--accent)]/15 border border-[var(--accent)]/20 text-[var(--accent)] text-xs font-semibold hover:bg-[var(--accent)]/25 transition-all">
          Start Trading
        </button>
      </Link>
    </div>
  );
}

// ─── Parse withdrawal details (JSON-packed non-crypto methods) ───
interface ParsedDetails {
  isJson: boolean;
  methodName?: string;
  category?: string;
  fields?: Record<string, string>;
  raw?: string;
}

function parseWithdrawalDetails(walletAddress: string | null | undefined): ParsedDetails {
  if (!walletAddress) return { isJson: false };

  try {
    const parsed = JSON.parse(walletAddress);
    if (parsed && typeof parsed === "object" && parsed.methodId) {
      const { methodId, methodName, category, ...fields } = parsed;
      void methodId;
      return {
        isJson: true,
        methodName,
        category,
        fields,
      };
    }
  } catch {
    // Not JSON — plain crypto address
  }

  return { isJson: false, raw: walletAddress };
}

// ─── Get method badge ───
function getMethodBadge(record: Transaction, isDeposit: boolean) {
  if (isDeposit) return { label: "TRC20", icon: "🔴" };

  const network = record.network?.toUpperCase();
  switch (network) {
    case "TRC20":
      return { label: "TRC20", icon: "🔴" };
    case "BEP20":
      return { label: "BEP20", icon: "🟡" };
    case "ERC20":
      return { label: "ERC20", icon: "🔵" };
    case "BANK":
      return { label: "Bank", icon: "🏦" };
    case "UPI":
      return { label: "UPI", icon: "📱" };
    case "PAYPAL":
      return { label: "PayPal", icon: "💳" };
    default:
      return { label: network || "Unknown", icon: "💎" };
  }
}

// ─── Record Card (Deposits/Withdrawals) ───
function RecordCard({
  record,
  type,
  delay,
}: {
  record: Transaction;
  type: "deposits" | "withdrawals";
  delay: number;
}) {
  const isDeposit = type === "deposits";
  const methodBadge = getMethodBadge(record, isDeposit);
  const parsedDetails = !isDeposit ? parseWithdrawalDetails(record.walletAddress) : null;

  const statusConfig = {
    PENDING: { label: "Pending", icon: Clock, color: "text-amber-400", bg: "bg-amber-500/10", border: "border-amber-500/20" },
    APPROVED: { label: "Approved", icon: CheckCircle2, color: "text-green-400", bg: "bg-green-500/10", border: "border-green-500/20" },
    COMPLETED: { label: "Completed", icon: CheckCircle2, color: "text-green-400", bg: "bg-green-500/10", border: "border-green-500/20" },
    REJECTED: { label: "Rejected", icon: XCircle, color: "text-red-400", bg: "bg-red-500/10", border: "border-red-500/20" },
  }[record.status] || {
    label: record.status,
    icon: Clock,
    color: "text-gray-400",
    bg: "bg-gray-500/10",
    border: "border-gray-500/20",
  };

  const StatusIcon = statusConfig.icon;
  const date = new Date(record.createdAt);
  const formattedDate = date.toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
      className="glass-panel rounded-xl p-4 hover:border-[var(--accent)]/20 transition-all"
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-start gap-3 flex-1 min-w-0">
          <div
            className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
              isDeposit
                ? "bg-green-500/15 text-green-400"
                : "bg-red-500/15 text-red-400"
            }`}
          >
            {isDeposit ? <ArrowDownLeft size={18} /> : <ArrowUpRight size={18} />}
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1 flex-wrap">
              <span className="text-sm font-semibold text-foreground">
                {isDeposit ? "Deposit" : "Withdrawal"}
              </span>
              <span className="inline-flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded bg-white/[0.05] text-gray-300 font-medium">
                <span>{methodBadge.icon}</span>
                <span>{methodBadge.label}</span>
              </span>
            </div>

            <div className="text-[11px] text-gray-500 mb-2">
              {formattedDate}
            </div>

            {record.txId && (
              <div className="flex items-center gap-1.5 text-[11px]">
                <span className="text-gray-500">TxID:</span>
                <code className="text-foreground font-mono truncate max-w-[150px] sm:max-w-[250px]">
                  {record.txId}
                </code>
              </div>
            )}

            {!parsedDetails?.isJson && record.walletAddress && (
              <div className="flex items-center gap-1.5 text-[11px] mt-1">
                <span className="text-gray-500">To:</span>
                <code className="text-foreground font-mono truncate max-w-[150px] sm:max-w-[250px]">
                  {record.walletAddress}
                </code>
              </div>
            )}

            {parsedDetails?.isJson && parsedDetails.fields && (
              <div className="mt-2 p-2.5 rounded-md bg-white/[0.02] border border-[var(--border)] space-y-1">
                <div className="text-[10px] text-gray-500 font-semibold uppercase tracking-wider mb-1">
                  {parsedDetails.methodName} Details
                </div>
                {Object.entries(parsedDetails.fields).map(([key, value]) => (
                  <div key={key} className="flex items-start gap-2 text-[11px]">
                    <span className="text-gray-500 capitalize shrink-0">
                      {key.replace(/([A-Z])/g, " $1").trim()}:
                    </span>
                    <code className="text-foreground font-mono break-all">
                      {value}
                    </code>
                  </div>
                ))}
              </div>
            )}

            {record.adminNote && (
              <div className="mt-2 p-2 rounded-md bg-white/[0.02] border border-[var(--border)]">
                <div className="text-[10px] text-gray-500 mb-0.5">Admin Note:</div>
                <div className="text-[11px] text-gray-300">{record.adminNote}</div>
              </div>
            )}

            {record.screenshotUrl && (
              <a
                href={record.screenshotUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 mt-2 text-[11px] text-[var(--accent)] hover:underline"
              >
                <ExternalLink size={10} />
                View Screenshot
              </a>
            )}
          </div>
        </div>

        <div className="text-right shrink-0">
          <div
            className={`text-base font-bold font-mono mb-1 ${
              isDeposit ? "text-green-400" : "text-red-400"
            }`}
          >
            {isDeposit ? "+" : "-"}${record.amount.toFixed(2)}
          </div>
          <div className="text-[10px] text-gray-500 mb-2">
            {record.currency}
          </div>
          <div
            className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-semibold border ${statusConfig.bg} ${statusConfig.color} ${statusConfig.border}`}
          >
            <StatusIcon size={10} />
            {statusConfig.label}
          </div>
        </div>
      </div>
    </motion.div>
  );
}

// ─── TRADE SUMMARY (realized P&L, win rate) ───
function TradeSummary({
  trades,
  openCount,
  closedCount,
  totalRealizedPnL,
}: {
  trades: Trade[];
  openCount: number;
  closedCount: number;
  totalRealizedPnL: number;
}) {
  const closed = trades.filter((t) => t.status !== "OPEN");
  const wins = closed.filter((t) => t.pnl > 0).length;
  const winRate = closed.length > 0 ? (wins / closed.length) * 100 : 0;
  const pnlPositive = totalRealizedPnL >= 0;

  return (
    <div className="glass-panel rounded-xl p-4 mb-1">
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div>
          <div className="text-[10px] text-gray-500 uppercase tracking-wider font-semibold mb-0.5">
            Realized P&L
          </div>
          <div
            className={`text-sm font-bold font-mono ${
              pnlPositive ? "text-green-400" : "text-red-400"
            }`}
          >
            {pnlPositive ? "+" : "-"}${Math.abs(totalRealizedPnL).toFixed(2)}
          </div>
        </div>
        <div>
          <div className="text-[10px] text-gray-500 uppercase tracking-wider font-semibold mb-0.5">
            Win Rate
          </div>
          <div className="text-sm font-bold font-mono text-foreground">
            {winRate.toFixed(0)}%
            <span className="text-[10px] text-gray-500 font-normal ml-1">
              ({wins}/{closed.length})
            </span>
          </div>
        </div>
        <div>
          <div className="text-[10px] text-gray-500 uppercase tracking-wider font-semibold mb-0.5">
            Open
          </div>
          <div className="text-sm font-bold font-mono text-blue-400">
            {openCount}
          </div>
        </div>
        <div>
          <div className="text-[10px] text-gray-500 uppercase tracking-wider font-semibold mb-0.5">
            Closed
          </div>
          <div className="text-sm font-bold font-mono text-foreground">
            {closedCount}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── TRADE CARD (New!) ───
function TradeCard({ trade, delay }: { trade: Trade; delay: number }) {
  const isLong = trade.side === "BUY";
  const isOpen = trade.status === "OPEN";
  const isProfit = trade.pnl >= 0;
  const isLiquidated = trade.closeReason === "LIQUIDATED";
  const closeReasonLabel =
    trade.closeReason === "LIQUIDATED"
      ? "Liquidated"
      : trade.closeReason === "ADMIN_CLOSE" || trade.closeReason === "MANUAL"
      ? "Closed"
      : null;

  const openedDate = new Date(trade.openedAt);
  const openedFormatted = openedDate.toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });

  const closedDate = trade.closedAt ? new Date(trade.closedAt) : null;
  const closedFormatted = closedDate?.toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
      className="glass-panel rounded-xl p-4 hover:border-[var(--accent)]/20 transition-all"
    >
      <div className="flex items-start justify-between gap-3 mb-3">
        {/* Left: Icon + Coin + Side */}
        <div className="flex items-start gap-3 flex-1 min-w-0">
          <div
            className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
              isLong
                ? "bg-green-500/15 text-green-400"
                : "bg-red-500/15 text-red-400"
            }`}
          >
            {isLong ? <TrendingUp size={18} /> : <TrendingDown size={18} />}
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1 flex-wrap">
              <span className="text-sm font-bold text-foreground">
                {trade.coinSymbol}
              </span>
              <span
                className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${
                  isLong
                    ? "bg-green-500/15 text-green-400"
                    : "bg-red-500/15 text-red-400"
                }`}
              >
                {isLong ? "LONG" : "SHORT"}
              </span>
              <span className="inline-flex items-center gap-0.5 text-[9px] font-bold px-1.5 py-0.5 rounded bg-[var(--accent)]/15 text-[var(--accent)]">
                <Zap size={8} />
                {trade.leverage}x
              </span>
              {isLiquidated && (
                <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-red-500/20 text-red-400">
                  LIQUIDATED
                </span>
              )}
            </div>
            <div className="text-[11px] text-gray-500">
              Opened: {openedFormatted}
            </div>
            {closedFormatted && (
              <div className="text-[11px] text-gray-500">
                Closed: {closedFormatted}
              </div>
            )}
          </div>
        </div>

        {/* Right: P&L or Status */}
        <div className="text-right shrink-0">
          {isOpen ? (
            <div className="inline-flex items-center gap-1 px-2 py-1 rounded-md bg-[var(--accent)]/10 border border-[var(--accent)]/20 text-[10px] font-bold text-[var(--accent)]">
              <Activity size={10} className="animate-pulse" />
              OPEN
            </div>
          ) : (
            <>
              <div
                className={`text-base font-bold font-mono ${
                  isProfit ? "text-green-400" : "text-red-400"
                }`}
              >
                {isProfit ? "+" : "-"}${Math.abs(trade.pnl).toFixed(2)}
              </div>
              <div
                className={`text-[10px] font-semibold ${
                  isProfit ? "text-green-400" : "text-red-400"
                }`}
              >
                {isProfit ? "+" : "-"}
                {Math.abs(trade.pnlPercent).toFixed(2)}% ROI
              </div>
            </>
          )}
        </div>
      </div>

      {/* Trade Details Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-2">
        <TradeDetail label="Margin" value={`$${trade.marginAmount.toFixed(2)}`} />
        <TradeDetail label="Size" value={`$${trade.positionSize.toFixed(2)}`} />
        <TradeDetail label="Entry" value={`$${formatPrice(trade.entryPrice)}`} />
        {trade.exitPrice ? (
          <TradeDetail
            label="Exit"
            value={`$${formatPrice(trade.exitPrice)}`}
          />
        ) : (
          <TradeDetail label="Status" value="Open" highlight />
        )}
      </div>

      {/* Additional info */}
      <div className="flex items-center justify-between text-[10px] text-gray-500 pt-2 border-t border-[var(--border)]">
        <span>Quantity: <span className="text-gray-400 font-mono">{trade.quantity.toFixed(6)} {trade.coinSymbol}</span></span>
        <span>Fee: <span className="text-gray-400 font-mono">${trade.fee.toFixed(2)}</span></span>
      </div>
      {!isOpen && closeReasonLabel && (
        <div className="text-[10px] text-gray-500 pt-1.5">
          {closeReasonLabel}
        </div>
      )}
    </motion.div>
  );
}

// ─── Trade Detail Mini Component ───
function TradeDetail({
  label,
  value,
  highlight = false,
}: {
  label: string;
  value: string;
  highlight?: boolean;
}) {
  return (
    <div className="p-2 rounded-md bg-white/[0.02] border border-[var(--border)]">
      <div className="text-[9px] text-gray-500 uppercase tracking-wider font-semibold mb-0.5">
        {label}
      </div>
      <div
        className={`text-[11px] font-bold font-mono truncate ${
          highlight ? "text-[var(--accent)]" : "text-foreground"
        }`}
      >
        {value}
      </div>
    </div>
  );
}