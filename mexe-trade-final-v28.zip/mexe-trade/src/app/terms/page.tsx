// src/app/terms/page.tsx
"use client";

import { motion } from "framer-motion";
import Link from "next/link";
import {
  FileText,
  Scale,
  AlertTriangle,
  UserCheck,
  CreditCard,
  Ban,
  Gavel,
  Shield,
  Globe,
  Mail,
  ChevronRight,
  ArrowLeft,
} from "lucide-react";
import { PLATFORM_CONFIG } from "@/config/constants";

const LAST_UPDATED = "January 2026";

const SECTIONS = [
  {
    id: "acceptance",
    title: "1. Acceptance of Terms",
    icon: FileText,
    color: "text-blue-400",
    bg: "bg-blue-500/10",
    content: [
      `By creating an account, accessing, or using ${PLATFORM_CONFIG.name} ("the Platform"), you agree to be bound by these Terms of Service ("Terms"). If you do not agree to these Terms, please do not use the Platform.`,
      'These Terms constitute a legally binding agreement between you ("User") and the Platform operator. Please read them carefully before proceeding.',
    ],
  },
  {
    id: "eligibility",
    title: "2. Eligibility",
    icon: UserCheck,
    color: "text-purple-400",
    bg: "bg-purple-500/10",
    content: ["To use the Platform, you must meet all of the following requirements:"],
    list: [
      { label: "Age Requirement", text: "Be at least 18 years old or the legal age of majority in your jurisdiction." },
      { label: "Legal Capacity", text: "Have the legal capacity to enter into binding agreements." },
      { label: "Jurisdiction", text: "Reside in a jurisdiction where cryptocurrency trading is legal." },
      { label: "Compliance", text: "Not be on any government sanctions or restricted-persons lists." },
      { label: "Truthful Information", text: "Provide accurate and truthful information during registration and KYC." },
    ],
  },
  {
    id: "account",
    title: "3. Account Registration & Security",
    icon: Shield,
    color: "text-green-400",
    bg: "bg-green-500/10",
    content: ["When you create an account, you agree to the following responsibilities:"],
    list: [
      { label: "Confidentiality", text: "Keep your login credentials and withdrawal password confidential at all times." },
      { label: "Account Activity", text: "You are responsible for all activities that occur under your account." },
      { label: "Single Account", text: "Maintain only one account. Multiple accounts may result in suspension." },
      { label: "Unauthorized Access", text: "Immediately notify us of any unauthorized access or security breach." },
      { label: "KYC Compliance", text: "Complete identity verification before performing withdrawals." },
    ],
  },
  {
    id: "deposits-withdrawals",
    title: "4. Deposits & Withdrawals",
    icon: CreditCard,
    color: "text-amber-400",
    bg: "bg-amber-500/10",
    content: [
      "All deposits and withdrawals are subject to the following terms:",
    ],
    list: [
      { label: "Supported Network", text: "Currently, we only support USDT transactions via the TRC20 (TRON) network." },
      { label: "Network Risk", text: "Sending funds via incorrect networks (ERC20, BEP20, etc.) may result in permanent loss." },
      { label: "Minimum Amounts", text: "Minimum deposit: $10. Minimum withdrawal: $20." },
      { label: "Processing Time", text: "All transactions are reviewed manually and typically processed within 1-3 business days." },
      { label: "Verification", text: "Withdrawals require KYC verification to be approved." },
      { label: "Daily Limits", text: "Withdrawals are limited to $10,000 per day and $50,000 per transaction." },
      { label: "Final Decisions", text: "We reserve the right to reject any deposit or withdrawal that violates these Terms or applicable law." },
    ],
  },
  {
    id: "trading",
    title: "5. Trading Activity",
    icon: Scale,
    color: "text-cyan-400",
    bg: "bg-cyan-500/10",
    content: [
      "Trading on the Platform is conducted at your own risk and discretion.",
    ],
    list: [
      { label: "Market Risk", text: "Cryptocurrency prices are highly volatile. You may lose all of your invested capital." },
      { label: "No Investment Advice", text: "We do not provide investment, tax, or financial advice. All trading decisions are your own." },
      { label: "Leverage Risk", text: "Leveraged trading amplifies both gains and losses. Use with extreme caution." },
      { label: "Order Execution", text: "Orders are executed at prevailing market rates. We cannot guarantee specific execution prices." },
      { label: "Technical Issues", text: "Trading may be temporarily unavailable due to maintenance, network issues, or system upgrades." },
    ],
  },
  {
    id: "prohibited",
    title: "6. Prohibited Activities",
    icon: Ban,
    color: "text-red-400",
    bg: "bg-red-500/10",
    content: ["You agree NOT to engage in any of the following activities:"],
    list: [
      { label: "Illegal Use", text: "Using the Platform for money laundering, terrorism financing, or any illegal activity." },
      { label: "Fraud", text: "Providing false information, identity theft, or fake KYC documents." },
      { label: "Market Manipulation", text: "Engaging in wash trading, spoofing, or other market manipulation tactics." },
      { label: "Account Abuse", text: "Creating multiple accounts, exploiting bonuses, or bypassing verification." },
      { label: "System Abuse", text: "Attempting to hack, reverse-engineer, or disrupt Platform operations." },
      { label: "Automated Access", text: "Using bots, scrapers, or unauthorized automated tools without permission." },
      { label: "Impersonation", text: "Impersonating staff, support agents, or other users." },
    ],
  },
  {
    id: "fees",
    title: "7. Fees & Charges",
    icon: CreditCard,
    color: "text-pink-400",
    bg: "bg-pink-500/10",
    content: [
      "The Platform may charge fees for certain services, including deposits, withdrawals, and trading.",
      "All applicable fees are displayed before you confirm a transaction. By proceeding, you agree to the displayed fees.",
      "We reserve the right to modify fees at any time. Significant fee changes will be announced in advance.",
    ],
  },
  {
    id: "risks",
    title: "8. Risk Disclosure",
    icon: AlertTriangle,
    color: "text-orange-400",
    bg: "bg-orange-500/10",
    content: [
      "Cryptocurrency trading involves substantial risk. You acknowledge and accept the following risks:",
    ],
    list: [
      { label: "Price Volatility", text: "Cryptocurrency values can fluctuate dramatically within short periods." },
      { label: "Total Loss", text: "You may lose all or part of your invested capital." },
      { label: "Regulatory Risk", text: "Changes in laws or regulations may affect your ability to trade or withdraw." },
      { label: "Technical Risk", text: "Blockchain networks, exchanges, and wallets may experience downtime or failures." },
      { label: "No Insurance", text: "Funds on the Platform are not insured by any government or third-party insurer." },
    ],
  },
  {
    id: "intellectual",
    title: "9. Intellectual Property",
    icon: Shield,
    color: "text-indigo-400",
    bg: "bg-indigo-500/10",
    content: [
      `All content on the Platform — including logos, designs, code, text, and graphics — is the property of ${PLATFORM_CONFIG.name} and protected by intellectual property laws.`,
      "You may not copy, modify, distribute, or create derivative works from any Platform content without our prior written consent.",
    ],
  },
  {
    id: "termination",
    title: "10. Account Termination",
    icon: Ban,
    color: "text-rose-400",
    bg: "bg-rose-500/10",
    content: [
      "We reserve the right to suspend or terminate your account at our sole discretion, including but not limited to:",
    ],
    list: [
      { label: "Terms Violation", text: "Breaching any provision of these Terms." },
      { label: "Fraudulent Activity", text: "Engaging in fraud, money laundering, or illegal conduct." },
      { label: "Regulatory Order", text: "Court orders, government directives, or compliance requirements." },
      { label: "Inactivity", text: "Prolonged account inactivity (24+ months) without notice." },
      { label: "Voluntary Closure", text: "You may close your account at any time by contacting support." },
    ],
  },
  {
    id: "disclaimer",
    title: "11. Disclaimer of Warranties",
    icon: AlertTriangle,
    color: "text-yellow-400",
    bg: "bg-yellow-500/10",
    content: [
      `The Platform is provided "AS IS" and "AS AVAILABLE" without warranties of any kind, express or implied.`,
      "We do not guarantee that the Platform will be uninterrupted, error-free, secure, or free from viruses. You use the Platform at your own risk.",
      "To the maximum extent permitted by law, we disclaim all warranties, including merchantability, fitness for a particular purpose, and non-infringement.",
    ],
  },
  {
    id: "liability",
    title: "12. Limitation of Liability",
    icon: Gavel,
    color: "text-violet-400",
    bg: "bg-violet-500/10",
    content: [
      "To the maximum extent permitted by applicable law, the Platform and its operators shall NOT be liable for:",
    ],
    list: [
      { label: "Indirect Damages", text: "Loss of profits, data, business, or opportunity arising from Platform use." },
      { label: "Third-Party Actions", text: "Damages caused by third-party services, blockchain networks, or external factors." },
      { label: "User Errors", text: "Losses resulting from incorrect wallet addresses, lost passwords, or user mistakes." },
      { label: "Force Majeure", text: "Events beyond our reasonable control (natural disasters, government actions, etc.)." },
    ],
  },
  {
    id: "governing-law",
    title: "13. Governing Law & Disputes",
    icon: Globe,
    color: "text-teal-400",
    bg: "bg-teal-500/10",
    content: [
      "These Terms are governed by the laws of the jurisdiction in which the Platform operates.",
      "Any disputes arising from these Terms or your use of the Platform shall be resolved through binding arbitration, except where prohibited by law.",
      "You waive your right to participate in class-action lawsuits or class-wide arbitration against the Platform.",
    ],
  },
  {
    id: "modifications",
    title: "14. Modifications to Terms",
    icon: FileText,
    color: "text-emerald-400",
    bg: "bg-emerald-500/10",
    content: [
      "We may modify these Terms at any time. Material changes will be communicated via email or in-app notification.",
      "Your continued use of the Platform after changes are posted constitutes acceptance of the modified Terms.",
      "If you do not agree to the changes, you must stop using the Platform and may close your account.",
    ],
  },
  {
    id: "contact-legal",
    title: "15. Contact & Legal Notices",
    icon: Mail,
    color: "text-sky-400",
    bg: "bg-sky-500/10",
    content: [
      "For questions, complaints, or legal notices related to these Terms, contact us at:",
    ],
    contactInfo: true,
  },
];

export default function TermsPage() {
  return (
    <div className="min-h-full mesh-bg">
      <div className="max-w-4xl mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
        {/* ═══════════ BACK LINK ═══════════ */}
        <motion.div
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 1, x: 0 }}
        >
          <Link href="/">
            <button className="inline-flex items-center gap-1.5 text-xs text-gray-500 hover:text-[var(--accent)] transition-colors">
              <ArrowLeft size={14} />
              Back to Home
            </button>
          </Link>
        </motion.div>

        {/* ═══════════ HEADER ═══════════ */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="relative overflow-hidden rounded-2xl border border-[var(--border)] bg-gradient-to-br from-[var(--accent)]/10 via-purple-500/5 to-transparent p-6 sm:p-8"
        >
          <div className="absolute -top-20 -right-20 w-64 h-64 rounded-full bg-[var(--accent)]/10 blur-3xl pointer-events-none" />

          <div className="relative z-10">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-xl bg-[var(--accent)]/15 flex items-center justify-center">
                <Scale size={22} className="text-[var(--accent)]" />
              </div>
              <div>
                <h1 className="text-2xl sm:text-3xl font-bold text-foreground">
                  Terms of Service
                </h1>
                <p className="text-xs text-gray-500 mt-0.5">
                  Last Updated: {LAST_UPDATED}
                </p>
              </div>
            </div>

            <p className="text-sm text-gray-400 leading-relaxed max-w-2xl">
              These Terms govern your use of {PLATFORM_CONFIG.name}. Please read them carefully before using our services. By using the Platform, you agree to abide by these Terms.
            </p>
          </div>
        </motion.div>

        {/* ═══════════ IMPORTANT NOTICE ═══════════ */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="flex items-start gap-3 p-4 rounded-xl bg-amber-500/[0.07] border border-amber-500/20"
        >
          <AlertTriangle size={18} className="text-amber-400 shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-semibold text-amber-300 mb-1">
              Important Legal Notice
            </p>
            <p className="text-xs text-amber-200/80 leading-relaxed">
              Cryptocurrency trading involves substantial risk and may not be suitable for all investors. You should carefully consider your financial situation before using the Platform. Past performance does not guarantee future results.
            </p>
          </div>
        </motion.div>

        {/* ═══════════ TABLE OF CONTENTS ═══════════ */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="glass-panel rounded-xl p-5"
        >
          <div className="text-[10px] uppercase tracking-wider text-gray-500 font-semibold mb-3">
            Table of Contents
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
            {SECTIONS.map((section) => (
              <a
                key={section.id}
                href={`#${section.id}`}
                className="flex items-center gap-2 px-2 py-1.5 rounded-lg text-xs text-gray-400 hover:text-[var(--accent)] hover:bg-white/[0.03] transition-colors"
              >
                <ChevronRight size={12} className="opacity-50" />
                <span>{section.title}</span>
              </a>
            ))}
          </div>
        </motion.div>

        {/* ═══════════ SECTIONS ═══════════ */}
        <div className="space-y-4">
          {SECTIONS.map((section, idx) => {
            const Icon = section.icon;
            return (
              <motion.section
                key={section.id}
                id={section.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 + idx * 0.03 }}
                className="glass-panel rounded-xl p-5 sm:p-6 scroll-mt-20"
              >
                <div className="flex items-start gap-3 mb-4">
                  <div className={`w-9 h-9 rounded-lg ${section.bg} flex items-center justify-center shrink-0`}>
                    <Icon size={16} className={section.color} />
                  </div>
                  <h2 className="text-base sm:text-lg font-bold text-foreground pt-1">
                    {section.title}
                  </h2>
                </div>

                <div className="space-y-3 pl-0 sm:pl-12">
                  {section.content.map((para, i) => (
                    <p key={i} className="text-sm text-gray-400 leading-relaxed">
                      {para}
                    </p>
                  ))}

                  {section.list && (
                    <ul className="space-y-2.5 mt-3">
                      {section.list.map((item, i) => (
                        <li
                          key={i}
                          className="flex items-start gap-2.5 p-3 rounded-lg bg-white/[0.02] border border-[var(--border)]"
                        >
                          <div className="w-1 h-1 rounded-full bg-[var(--accent)] mt-2 shrink-0" />
                          <div className="flex-1">
                            <span className="text-xs font-semibold text-foreground">
                              {item.label}:
                            </span>{" "}
                            <span className="text-xs text-gray-400 leading-relaxed">
                              {item.text}
                            </span>
                          </div>
                        </li>
                      ))}
                    </ul>
                  )}

                  {section.contactInfo && (
                    <div className="mt-4 p-4 rounded-xl bg-[var(--accent)]/[0.05] border border-[var(--accent)]/15">
                      <div className="flex items-center gap-2 mb-2">
                        <Mail size={14} className="text-[var(--accent)]" />
                        <span className="text-xs font-semibold text-foreground">
                          Legal Inquiries
                        </span>
                      </div>
                      <a
                        href={`mailto:${PLATFORM_CONFIG.SUPPORT_EMAIL}`}
                        className="text-sm text-[var(--accent)] hover:underline font-mono"
                      >
                        {PLATFORM_CONFIG.SUPPORT_EMAIL}
                      </a>
                      <p className="text-[11px] text-gray-500 mt-2">
                        For general support, use the in-app{" "}
                        <Link href="/chat" className="text-[var(--accent)] hover:underline">
                          Live Chat
                        </Link>{" "}
                        feature.
                      </p>
                    </div>
                  )}
                </div>
              </motion.section>
            );
          })}
        </div>

        {/* ═══════════ ACCEPTANCE FOOTER ═══════════ */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="relative overflow-hidden rounded-2xl border border-[var(--accent)]/20 bg-gradient-to-br from-[var(--accent)]/10 via-purple-500/5 to-transparent p-5 sm:p-6"
        >
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-[var(--accent)]/15 flex items-center justify-center shrink-0">
              <Gavel size={18} className="text-[var(--accent)]" />
            </div>
            <div className="flex-1">
              <p className="text-sm font-semibold text-foreground mb-1">
                Agreement Acknowledgment
              </p>
              <p className="text-xs text-gray-400 leading-relaxed">
                By using {PLATFORM_CONFIG.name}, you confirm that you have read, understood, and agreed to be bound by these Terms of Service. Also see our{" "}
                <Link href="/privacy" className="text-[var(--accent)] hover:underline">
                  Privacy Policy
                </Link>
                .
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}