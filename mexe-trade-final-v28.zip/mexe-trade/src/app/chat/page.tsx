// src/app/chat/page.tsx
"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  MessageCircle,
  HelpCircle,
  Send,
  X,
  Loader2,
  ChevronDown,
  ChevronRight,
  Shield,
  Zap,
  CreditCard,
  UserCheck,
  Clock,
  CheckCircle2,
  AlertCircle,
  Headphones,
  Bot,
  Paperclip,
  Inbox,
  MoreVertical,
  Trash2,
} from "lucide-react";
import { useAuthStore } from "@/store/authStore";
import { chatAPI } from "@/lib/api";
import Link from "next/link";

// ============================================================
// TYPES
// ============================================================

interface ChatMessageType {
  id: string;
  message: string;
  imageUrl?: string | null;
  sender: "USER" | "ADMIN";
  isRead: boolean;
  createdAt: string;
  deletedForEveryone?: boolean;
  isEdited?: boolean;   // true when admin edited this message for the user
}

type ChatTab = "faq" | "chat";

// ============================================================
// FAQ DATA
// ============================================================

interface FAQItem {
  question: string;
  answer: string;
}

interface FAQCategory {
  id: string;
  title: string;
  icon: React.ElementType;
  iconColor: string;
  iconBg: string;
  faqs: FAQItem[];
}

const FAQ_CATEGORIES: FAQCategory[] = [
  {
    id: "deposit",
    title: "Deposits",
    icon: CreditCard,
    iconColor: "text-green-400",
    iconBg: "bg-green-500/10",
    faqs: [
      {
        question: "How do I deposit USDT?",
        answer:
          "Go to Funds → Deposit tab. Copy the TRC20 wallet address, send USDT from your external wallet (Binance, Trust Wallet, etc.), then submit the deposit form with your transaction hash and payment screenshot.",
      },
      {
        question: "What is the minimum deposit?",
        answer:
          "The minimum deposit is $10 USDT via TRC20 network. There is a $1 processing fee per deposit.",
      },
      {
        question: "How long does a deposit take?",
        answer:
          "TRC20 deposits typically confirm within 1-3 minutes on the blockchain. After that, our team reviews and approves deposits within 1-3 business days.",
      },
      {
        question: "Which networks are supported?",
        answer:
          "Currently we only support USDT deposits via the TRC20 (TRON) network. Please do NOT send tokens via other networks (ERC20, BEP20) as funds may be permanently lost.",
      },
    ],
  },
  {
    id: "withdrawal",
    title: "Withdrawals",
    icon: Zap,
    iconColor: "text-amber-400",
    iconBg: "bg-amber-500/10",
    faqs: [
      {
        question: "How do I withdraw funds?",
        answer:
          "Go to Funds → Withdraw tab. Enter your TRC20 wallet address, the amount, and your withdrawal password. Withdrawals require KYC verification to be completed first.",
      },
      {
        question: "Why is my withdrawal blocked?",
        answer:
          "Withdrawals require approved KYC verification. Go to KYC Verification page to submit your identity documents. Once approved, withdrawals will be enabled.",
      },
      {
        question: "What are the withdrawal limits?",
        answer:
          "Minimum withdrawal: $20 USDT. Maximum per transaction: $50,000 USDT. Daily limit: $10,000 USDT.",
      },
      {
        question: "How long do withdrawals take?",
        answer:
          "Withdrawals are processed within 1-3 business days after submission. You will receive the USDT to your provided TRC20 wallet address.",
      },
    ],
  },
  {
    id: "security",
    title: "Account & Security",
    icon: Shield,
    iconColor: "text-blue-400",
    iconBg: "bg-blue-500/10",
    faqs: [
      {
        question: "How do I reset my password?",
        answer:
          "Go to Security Center to change your account password. You need to know your current password to set a new one. If you forgot your password, contact support via live chat.",
      },
      {
        question: "What is a withdrawal password?",
        answer:
          "A withdrawal password is a separate password required when making withdrawals. It adds an extra layer of security. You can set it from the Security Center page.",
      },
      {
        question: "Is my data safe?",
        answer:
          "Yes. All passwords are hashed using industry-standard bcrypt encryption. Sessions are managed via secure httpOnly cookies. We never store plaintext passwords.",
      },
    ],
  },
  {
    id: "kyc",
    title: "KYC Verification",
    icon: UserCheck,
    iconColor: "text-purple-400",
    iconBg: "bg-purple-500/10",
    faqs: [
      {
        question: "Why do I need KYC?",
        answer:
          "KYC (Know Your Customer) verification is required to enable withdrawals and access higher transaction limits. It helps us comply with regulations and protect your account.",
      },
      {
        question: "What documents are accepted?",
        answer:
          "We accept National ID cards, Driving Licenses, and Passports. You'll need to upload the front and back of your document, plus a selfie for verification.",
      },
      {
        question: "How long does KYC review take?",
        answer:
          "KYC submissions are typically reviewed within 1-3 business days. You'll be notified of the result via the platform.",
      },
    ],
  },
];

// ============================================================
// MAIN COMPONENT
// ============================================================

export default function ChatPage() {
  const [tab, setTab] = useState<ChatTab>("faq");
  const { user } = useAuthStore();

  return (
    <div className="h-full mesh-bg flex flex-col">
      <div className="flex-1 flex flex-col max-w-3xl w-full mx-auto p-4 sm:p-6 lg:p-8 min-h-0">
        {/* ═══════════ HEADER (only visible in FAQ tab to save space in chat) ═══════════ */}
        <AnimatePresence>
          {tab === "faq" && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.2 }}
              className="overflow-hidden"
            >
              <div className="mb-5">
                <h1 className="text-2xl sm:text-3xl font-bold text-foreground mb-1.5">
                  Help Center
                </h1>
                <p className="text-sm text-gray-500">
                  Find answers or chat with our support team
                </p>
              </div>

              {/* Support Status Card — only in FAQ */}
              <div className="relative overflow-hidden rounded-2xl border border-[var(--border)] bg-gradient-to-br from-[var(--accent)]/10 via-purple-500/5 to-transparent p-5 sm:p-6 mb-5">
                <div className="absolute -top-10 -right-10 w-40 h-40 rounded-full bg-[var(--accent)]/10 blur-3xl pointer-events-none" />
                <div className="relative z-10 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl bg-[var(--accent)]/15 flex items-center justify-center">
                      <Headphones size={22} className="text-[var(--accent)]" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-foreground mb-0.5">
                        Customer Support
                      </div>
                      <div className="text-xs text-gray-500">
                        Available 24/7 • Typical response: &lt;2 hours
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-green-500/10 border border-green-500/20">
                    <span className="relative flex h-2 w-2">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75" />
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500" />
                    </span>
                    <span className="text-[10px] font-semibold text-green-400 uppercase tracking-wider">
                      Online
                    </span>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* ═══════════ COMPACT HEADER (only in Chat tab) ═══════════ */}
        {tab === "chat" && (
          <motion.div
            initial={{ opacity: 0, y: -5 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-4 flex items-center justify-between"
          >
            <div>
              <h1 className="text-xl font-bold text-foreground">Live Chat</h1>
              <p className="text-xs text-gray-500">Chat with our support team</p>
            </div>
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-green-500/10 border border-green-500/20">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500" />
              </span>
              <span className="text-[10px] font-semibold text-green-400 uppercase tracking-wider">
                Online
              </span>
            </div>
          </motion.div>
        )}

        {/* ═══════════ TAB SWITCHER ═══════════ */}
        <div className="relative flex p-1 rounded-xl bg-card border border-[var(--border)] mb-4 shrink-0">
          {([
            {
              id: "faq" as ChatTab,
              label: "FAQ",
              icon: HelpCircle,
              color: "text-blue-400",
            },
            {
              id: "chat" as ChatTab,
              label: "Live Chat",
              icon: MessageCircle,
              color: "text-green-400",
            },
          ]).map((t) => {
            const Icon = t.icon;
            return (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`relative flex-1 flex items-center justify-center gap-2 py-3 text-sm font-semibold rounded-lg transition-colors z-10 ${
                  tab === t.id
                    ? "text-foreground"
                    : "text-gray-500 hover:text-gray-300"
                }`}
              >
                {tab === t.id && (
                  <motion.div
                    layoutId="chatTabPill"
                    className="absolute inset-0 rounded-lg bg-white/[0.05] border border-[var(--border)]"
                    transition={{ type: "spring", stiffness: 300, damping: 30 }}
                  />
                )}
                <Icon
                  size={16}
                  className={`relative z-10 ${tab === t.id ? t.color : ""}`}
                />
                <span className="relative z-10">{t.label}</span>
              </button>
            );
          })}
        </div>

        {/* ═══════════ TAB CONTENT ═══════════ */}
        {tab === "faq" ? (
          <div className="flex-1">
            <FAQPanel />
            {/* Footer info (only in FAQ tab) */}
            <div className="flex items-start gap-2.5 p-4 rounded-xl bg-white/[0.02] border border-[var(--border)] mt-5">
              <AlertCircle size={14} className="text-gray-500 shrink-0 mt-0.5" />
              <p className="text-xs text-gray-500 leading-relaxed">
                Need urgent help? Email us at{" "}
                <span className="text-[var(--accent)] font-medium">
                  support@premiumexchange.online
                </span>
                . For security-related issues, never share your password or
                withdrawal PIN with anyone, including support staff. Read our{" "}
                <Link href="/privacy" className="text-[var(--accent)] hover:underline">
                  Privacy Policy
                </Link>{" "}
                and{" "}
                <Link href="/terms" className="text-[var(--accent)] hover:underline">
                  Terms of Service
                </Link>
                .
              </p>
            </div>
          </div>
        ) : (
          <div className="flex-1 flex flex-col min-h-0">
            <LiveChatPanel userName={user?.username || user?.email?.split("@")[0] || "User"} />
          </div>
        )}
      </div>
    </div>
  );
}

// ============================================================
// FAQ PANEL
// ============================================================

function FAQPanel() {
  const [openCategory, setOpenCategory] = useState<string | null>("deposit");
  const [openQuestion, setOpenQuestion] = useState<string | null>(null);

  return (
    <div className="space-y-3">
      {FAQ_CATEGORIES.map((category) => {
        const Icon = category.icon;
        const isOpen = openCategory === category.id;

        return (
          <motion.div
            key={category.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="glass-panel rounded-xl overflow-hidden"
          >
            <button
              onClick={() => setOpenCategory(isOpen ? null : category.id)}
              className="w-full flex items-center gap-3 p-4 hover:bg-white/[0.02] transition-colors"
            >
              <div className={`w-9 h-9 rounded-lg ${category.iconBg} flex items-center justify-center`}>
                <Icon size={16} className={category.iconColor} />
              </div>
              <span className="flex-1 text-sm font-semibold text-foreground text-left">
                {category.title}
              </span>
              <span className="text-[10px] text-gray-500 mr-2">
                {category.faqs.length} articles
              </span>
              <motion.div animate={{ rotate: isOpen ? 180 : 0 }} transition={{ duration: 0.2 }}>
                <ChevronDown size={16} className="text-gray-500" />
              </motion.div>
            </button>

            <AnimatePresence>
              {isOpen && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.25, ease: "easeInOut" }}
                  className="overflow-hidden"
                >
                  <div className="px-4 pb-3 space-y-1">
                    {category.faqs.map((faq, idx) => {
                      const qKey = `${category.id}-${idx}`;
                      const isQOpen = openQuestion === qKey;

                      return (
                        <div key={qKey} className="rounded-lg overflow-hidden">
                          <button
                            onClick={() => setOpenQuestion(isQOpen ? null : qKey)}
                            className="w-full flex items-start gap-2.5 p-3 text-left hover:bg-white/[0.03] rounded-lg transition-colors"
                          >
                            <ChevronRight
                              size={14}
                              className={`mt-0.5 text-gray-500 shrink-0 transition-transform duration-200 ${
                                isQOpen ? "rotate-90 text-[var(--accent)]" : ""
                              }`}
                            />
                            <span
                              className={`text-sm transition-colors ${
                                isQOpen
                                  ? "text-[var(--accent)] font-semibold"
                                  : "text-gray-300 font-medium"
                              }`}
                            >
                              {faq.question}
                            </span>
                          </button>

                          <AnimatePresence>
                            {isQOpen && (
                              <motion.div
                                initial={{ height: 0, opacity: 0 }}
                                animate={{ height: "auto", opacity: 1 }}
                                exit={{ height: 0, opacity: 0 }}
                                transition={{ duration: 0.2 }}
                                className="overflow-hidden"
                              >
                                <div className="px-3 pb-3 pl-8">
                                  <p className="text-xs text-gray-400 leading-relaxed bg-white/[0.02] rounded-lg p-3 border border-[var(--border)]">
                                    {faq.answer}
                                  </p>
                                </div>
                              </motion.div>
                            )}
                          </AnimatePresence>
                        </div>
                      );
                    })}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        );
      })}

      <div className="grid grid-cols-2 gap-3 pt-2">
        <Link href="/funds">
          <div className="group glass-panel rounded-xl p-4 hover:border-[var(--accent)]/20 transition-all cursor-pointer">
            <CreditCard size={18} className="text-green-400 mb-2" />
            <div className="text-xs font-semibold text-foreground mb-0.5">Deposit Funds</div>
            <div className="text-[10px] text-gray-500">Add USDT to your account</div>
          </div>
        </Link>
        <Link href="/kyc">
          <div className="group glass-panel rounded-xl p-4 hover:border-[var(--accent)]/20 transition-all cursor-pointer">
            <UserCheck size={18} className="text-purple-400 mb-2" />
            <div className="text-xs font-semibold text-foreground mb-0.5">KYC Verification</div>
            <div className="text-[10px] text-gray-500">Verify your identity</div>
          </div>
        </Link>
      </div>
    </div>
  );
}

// ============================================================
// LIVE CHAT PANEL
// ============================================================

function LiveChatPanel({ userName }: { userName: string }) {
  const [messages, setMessages] = useState<ChatMessageType[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [image, setImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [sending, setSending] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const messagesContainerRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const pollingRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // ─── Scroll INSIDE messages container only (not whole page) ───
  const scrollToBottom = useCallback(() => {
    const container = messagesContainerRef.current;
    if (container) {
      container.scrollTop = container.scrollHeight;
    }
  }, []);

  const fetchMessages = useCallback(async (isInitial = false) => {
    try {
      const result = await chatAPI.getMessages();
      if (result.messages) {
        setMessages(result.messages as ChatMessageType[]);
        if (isInitial) {
          setTimeout(() => scrollToBottom(), 50);
        }
      }
    } catch {
      console.error("Failed to fetch messages");
    } finally {
      if (isInitial) setLoading(false);
    }
  }, [scrollToBottom]);

  useEffect(() => {
    fetchMessages(true);
    pollingRef.current = setInterval(() => {
      fetchMessages(false);
    }, 3000);

    return () => {
      if (pollingRef.current) {
        clearInterval(pollingRef.current);
      }
    };
  }, [fetchMessages]);

  useEffect(() => {
    scrollToBottom();
  }, [messages.length, scrollToBottom]);

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      setError("Image must be less than 5MB");
      return;
    }

    if (!file.type.startsWith("image/")) {
      setError("Only image files are allowed");
      return;
    }

    setError("");
    setImage(file);

    const reader = new FileReader();
    reader.onloadend = () => setImagePreview(reader.result as string);
    reader.readAsDataURL(file);
  };

  const removeImage = () => {
    setImage(null);
    setImagePreview(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const handleSend = async (e?: React.FormEvent) => {
    e?.preventDefault();

    const trimmedMessage = newMessage.trim();
    if (!trimmedMessage && !image) return;

    setSending(true);
    setError("");

    try {
      let result;

      if (image) {
        const formData = new FormData();
        formData.append("message", trimmedMessage);
        formData.append("image", image);
        result = await chatAPI.sendMessageWithImage(formData);
      } else {
        result = await chatAPI.sendMessage({ message: trimmedMessage });
      }

      if (result.error) {
        setError(result.error);
        return;
      }

      setNewMessage("");
      removeImage();
      await fetchMessages(false);
      setTimeout(() => scrollToBottom(), 100);
    } catch {
      setError("Failed to send message");
    } finally {
      setSending(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleDeleteMessage = async (
    messageId: string,
    type: "forMe" | "forEveryone"
  ) => {
    try {
      await chatAPI.deleteMessage(messageId, type);
      // Refresh messages silently after deletion
      await fetchMessages(false);
    } catch (err) {
      console.error("Failed to delete message:", err);
    }
  };

  if (loading) {
    return (
      <div className="glass-panel rounded-2xl flex items-center justify-center" style={{ minHeight: "400px" }}>
        <Loader2 className="w-6 h-6 text-[var(--accent)] animate-spin" />
      </div>
    );
  }

  return (
    <div className="glass-panel rounded-2xl overflow-hidden flex flex-col flex-1 min-h-0">
      {/* ─── Chat Header ─── */}
      <div className="flex items-center gap-3 p-4 border-b border-[var(--border)] bg-white/[0.02] shrink-0">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[var(--accent)] to-purple-500 flex items-center justify-center">
          <Bot size={18} className="text-white" />
        </div>
        <div className="flex-1">
          <div className="text-sm font-semibold text-foreground">Support Team</div>
          <div className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-green-400" />
            <span className="text-[10px] text-gray-500">
              Online • Typically replies within 2 hours
            </span>
          </div>
        </div>
        <div className="flex items-center gap-1.5 px-2 py-1 rounded-md bg-white/[0.03] border border-[var(--border)]">
          <Clock size={10} className="text-gray-500" />
          <span className="text-[10px] text-gray-500">24/7</span>
        </div>
      </div>

      {/* ─── Messages Area (own scroll container) ─── */}
      <div
        ref={messagesContainerRef}
        className="flex-1 overflow-y-auto p-4 space-y-3 scrollbar-thin min-h-0"
      >
        {messages.length === 0 ? (
          <ChatEmptyState />
        ) : (
          <>
            <div className="flex justify-center mb-4">
              <div className="px-3 py-1.5 rounded-full bg-white/[0.03] border border-[var(--border)]">
                <span className="text-[10px] text-gray-500">
                  Chat started • Messages are encrypted
                </span>
              </div>
            </div>
            {messages.map((msg) => (
              <ChatBubble
                key={msg.id}
                message={msg}
                userName={userName}
                onDelete={handleDeleteMessage}
              />
            ))}
          </>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* ─── Error Banner ─── */}
      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="px-4 overflow-hidden shrink-0"
          >
            <div className="flex items-center gap-2 p-2.5 rounded-lg bg-red-500/10 border border-red-500/20 mb-2">
              <AlertCircle size={12} className="text-red-400 shrink-0" />
              <p className="text-[11px] text-red-400">{error}</p>
              <button onClick={() => setError("")} className="ml-auto text-red-400 hover:text-red-300">
                <X size={12} />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ─── Image Preview ─── */}
      <AnimatePresence>
        {imagePreview && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="px-4 overflow-hidden shrink-0"
          >
            <div className="relative inline-block mb-2">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={imagePreview}
                alt="Attachment preview"
                className="w-20 h-20 object-cover rounded-lg border border-[var(--border)]"
              />
              <button
                onClick={removeImage}
                className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full bg-red-500 flex items-center justify-center text-white hover:bg-red-400 transition-colors"
              >
                <X size={10} />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ─── Composer ─── */}
      <form onSubmit={handleSend} className="p-3 border-t border-[var(--border)] bg-white/[0.02] shrink-0">
        <div className="flex items-end gap-2">
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="shrink-0 w-9 h-9 rounded-lg bg-white/[0.03] border border-[var(--border)] flex items-center justify-center text-gray-500 hover:text-[var(--accent)] hover:border-[var(--accent)]/30 transition-all"
          >
            <Paperclip size={16} />
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleImageSelect}
            className="sr-only"
          />

          <div className="flex-1 relative">
            <textarea
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Type your message..."
              rows={1}
              className="w-full px-4 py-2.5 bg-white/[0.03] border border-[var(--border)] rounded-xl text-sm text-foreground placeholder:text-gray-600 focus:outline-none focus:border-[var(--accent)]/50 focus:bg-white/[0.05] transition-all resize-none"
              style={{ minHeight: "40px", maxHeight: "120px" }}
              onInput={(e) => {
                const target = e.target as HTMLTextAreaElement;
                target.style.height = "40px";
                target.style.height = `${Math.min(target.scrollHeight, 120)}px`;
              }}
            />
          </div>

          <button
            type="submit"
            disabled={sending || (!newMessage.trim() && !image)}
            className="shrink-0 w-9 h-9 rounded-lg bg-[var(--accent)] flex items-center justify-center text-white hover:opacity-90 transition-all active:scale-95 disabled:opacity-30 disabled:cursor-not-allowed disabled:active:scale-100"
          >
            {sending ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}
          </button>
        </div>

        <div className="flex items-center justify-between mt-2 px-1">
          <span className="text-[10px] text-gray-600">
            Press Enter to send • Shift+Enter for new line
          </span>
          <span className="text-[10px] text-gray-600">{newMessage.length}/2000</span>
        </div>
      </form>
    </div>
  );
}

// ============================================================
// CHAT BUBBLE
// ============================================================

function ChatBubble({
  message,
  userName,
  onDelete,
}: {
  message: ChatMessageType;
  userName: string;
  onDelete: (messageId: string, type: "forMe" | "forEveryone") => void;
}) {
  const isUser = message.sender === "USER";
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  const time = new Date(message.createdAt).toLocaleTimeString("en-US", {
    hour: "2-digit",
    minute: "2-digit",
  });

  // Close menu on outside click
  useEffect(() => {
    if (!menuOpen) return;
    const handler = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setMenuOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [menuOpen]);

  // Deleted-for-everyone tombstone
  if (message.deletedForEveryone) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        className={`flex gap-2.5 ${isUser ? "flex-row-reverse" : "flex-row"}`}
      >
        <div className="w-8 h-8 rounded-full bg-gray-700/50 flex items-center justify-center shrink-0">
          <Trash2 size={12} className="text-gray-500" />
        </div>
        <div className="max-w-[75%]">
          <div className="rounded-2xl px-4 py-2.5 bg-white/[0.02] border border-dashed border-white/10 text-gray-500 text-sm italic">
            🗑 This message was deleted
          </div>
          <div className={`flex mt-1 ${isUser ? "justify-end" : "justify-start"}`}>
            <span className="text-[10px] text-gray-700">{time}</span>
          </div>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className={`flex gap-2.5 group ${isUser ? "flex-row-reverse" : "flex-row"}`}
    >
      <div
        className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold shrink-0 ${
          isUser
            ? "bg-gradient-to-br from-[var(--accent)] to-purple-500 text-white"
            : "bg-gradient-to-br from-emerald-500 to-teal-500 text-white"
        }`}
      >
        {isUser ? userName.charAt(0).toUpperCase() : "S"}
      </div>

      <div className={`max-w-[75%] flex flex-col ${isUser ? "items-end" : "items-start"}`}>
        <div
          className={`text-[10px] font-medium mb-1 ${
            isUser ? "text-right text-gray-500" : "text-left text-emerald-400"
          }`}
        >
          {isUser ? "You" : "Support Team"}
        </div>

        {/* Row: ⋮ button + bubble */}
        <div className={`flex items-end gap-1.5 ${isUser ? "flex-row" : "flex-row-reverse"}`}>
          {/* ⋮ delete trigger — shown on hover */}
          <div className="relative shrink-0" ref={menuRef}>
            <button
              onClick={() => setMenuOpen((o) => !o)}
              className={`
                w-6 h-6 rounded-full bg-white/[0.05] border border-[var(--border)]
                flex items-center justify-center text-gray-500
                hover:text-gray-300 hover:bg-white/[0.08] transition-all
                opacity-0 group-hover:opacity-100 focus:opacity-100
              `}
            >
              <MoreVertical size={13} />
            </button>

            <AnimatePresence>
              {menuOpen && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.92, y: -4 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.92, y: -4 }}
                  transition={{ duration: 0.1 }}
                  className={`
                    absolute z-50 bottom-8 min-w-[175px]
                    bg-[var(--background)] border border-[var(--border)]
                    rounded-xl shadow-xl overflow-hidden
                    ${isUser ? "right-0" : "left-0"}
                  `}
                >
                  <button
                    onClick={() => {
                      setMenuOpen(false);
                      onDelete(message.id, "forMe");
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2.5 text-xs text-gray-300 hover:bg-white/[0.05] hover:text-white transition-all"
                  >
                    <Trash2 size={13} className="text-gray-500" />
                    <span>Delete for me</span>
                  </button>
                  {/* "Delete for everyone" only for user's own messages */}
                  {isUser && (
                    <>
                      <div className="h-px bg-[var(--border)]" />
                      <button
                        onClick={() => {
                          setMenuOpen(false);
                          onDelete(message.id, "forEveryone");
                        }}
                        className="w-full flex items-center gap-2.5 px-3 py-2.5 text-xs text-red-400 hover:bg-red-500/[0.06] transition-all"
                      >
                        <Trash2 size={13} />
                        <span>Delete for everyone</span>
                      </button>
                    </>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Bubble */}
          <div
            className={`rounded-2xl px-4 py-2.5 ${
              isUser
                ? "bg-[var(--accent)] text-white rounded-br-md"
                : "bg-white/[0.05] border border-[var(--border)] text-foreground rounded-bl-md"
            }`}
          >
            {message.imageUrl && (
              <a
                href={message.imageUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="block mb-2"
              >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={message.imageUrl}
                  alt="Attachment"
                  className="max-w-full max-h-48 rounded-lg object-contain"
                />
              </a>
            )}

            {message.message && (
              <p className="text-sm leading-relaxed whitespace-pre-wrap break-words">
                {message.message}
              </p>
            )}
          </div>
        </div>

        <div className={`flex items-center gap-1.5 mt-1 ${isUser ? "justify-end" : "justify-start"}`}>
          <span className="text-[10px] text-gray-600">{time}</span>
          {isUser && (
            <CheckCircle2
              size={10}
              className={message.isRead ? "text-[var(--accent)]" : "text-gray-600"}
            />
          )}
        </div>
      </div>
    </motion.div>
  );
}

// ============================================================
// EMPTY STATE
// ============================================================

function ChatEmptyState() {
  return (
    <div className="h-full flex flex-col items-center justify-center py-12 px-4">
      <div className="w-16 h-16 rounded-2xl bg-[var(--accent)]/10 border border-[var(--accent)]/20 flex items-center justify-center mb-4">
        <Inbox size={28} className="text-[var(--accent)]" />
      </div>
      <h3 className="text-base font-semibold text-foreground mb-1">
        Start a Conversation
      </h3>
      <p className="text-xs text-gray-500 text-center max-w-xs mb-4">
        Send a message below and our support team will respond as soon as
        possible. We&apos;re here to help 24/7.
      </p>
      <div className="flex flex-wrap justify-center gap-2">
        {["I need help with deposit", "Withdrawal issue", "KYC question"].map((suggestion) => (
          <span
            key={suggestion}
            className="px-3 py-1.5 rounded-full bg-white/[0.03] border border-[var(--border)] text-[11px] text-gray-400 cursor-default"
          >
            {suggestion}
          </span>
        ))}
      </div>
    </div>
  );
}