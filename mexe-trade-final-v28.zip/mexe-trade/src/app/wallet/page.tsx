// src/app/wallet/page.tsx
"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  Wallet,
  ArrowDownLeft,
  ArrowUpRight,
  TrendingUp,
  TrendingDown,
  Eye,
  EyeOff,
  Plus,
  ChevronRight,
  Activity,
  Zap,
} from "lucide-react";
import { useAuthStore } from "@/store/authStore";
import { tradesAPI, depositsAPI, withdrawalsAPI } from "@/lib/api";

const ASSETS = [
  { symbol: "USDT", name: "Tether USD", icon: "💵", color: "from-green-500 to-emerald-500" },
  { symbol: "BTC", name: "Bitcoin", icon: "₿", color: "from-orange-500 to-amber-500" },
  { symbol: "ETH", name: "Ethereum", icon: "Ξ", color: "from-blue-500 to-indigo-500" },
];

interface WalletStats {
  totalDeposits: number;
  totalWithdrawals: number;
  totalRealizedPnL: number;
  totalMarginInPositions: number;
  openPositions: number;
}

export default function WalletPage() {
  const { user } = useAuthStore();
  const [showBalance, setShowBalance] = useState(true);
  const [mounted, setMounted] = useState(false);
  const [stats, setStats] = useState<WalletStats>({
    totalDeposits: 0,
    totalWithdrawals: 0,
    totalRealizedPnL: 0,
    totalMarginInPositions: 0,
    openPositions: 0,
  });
  const [loadingStats, setLoadingStats] = useState(true);

  useEffect(() => {
    setMounted(true);
  }, []);

  // ─── Fetch wallet stats ───
  useEffect(() => {
    const fetchStats = async () => {
      const [depResult, wdResult, tradesResult] = await Promise.all([
        depositsAPI.list(),
        withdrawalsAPI.list(),
        tradesAPI.list(),
      ]);

      // Calculate deposit total (only approved)
      const deposits = (depResult.deposits as Array<{ amount: number; status: string }>) || [];
      const totalDeposits = deposits
        .filter((d) => d.status === "APPROVED")
        .reduce((sum, d) => sum + d.amount, 0);

      // Calculate withdrawal total (all — pending are already deducted)
      const withdrawals = (wdResult.withdrawals as Array<{ amount: number; status: string }>) || [];
      const totalWithdrawals = withdrawals.reduce((sum, w) => sum + w.amount, 0);

      // Trade stats
      const tradeStats = tradesResult.stats as {
        openCount?: number;
        totalMarginInPositions?: number;
        totalRealizedPnL?: number;
      } | undefined;

      setStats({
        totalDeposits,
        totalWithdrawals,
        totalRealizedPnL: tradeStats?.totalRealizedPnL ?? 0,
        totalMarginInPositions: tradeStats?.totalMarginInPositions ?? 0,
        openPositions: tradeStats?.openCount ?? 0,
      });
      setLoadingStats(false);
    };

    fetchStats();
  }, []);

  const availableBalance = user?.balance ?? 0;
  const totalEquity = availableBalance + stats.totalMarginInPositions;

  const displayBalance = showBalance ? `$${availableBalance.toFixed(2)}` : "••••••";
  const displayEquity = showBalance ? `$${totalEquity.toFixed(2)}` : "••••••";

  return (
    <div className="min-h-full mesh-bg">
      <div className="max-w-4xl mx-auto p-4 sm:p-6 lg:p-8 space-y-5">
        {/* ═══════════ HEADER ═══════════ */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <h1 className="text-2xl sm:text-3xl font-bold text-foreground mb-1.5">
            My Wallet
          </h1>
          <p className="text-sm text-gray-500">
            Manage your assets, view balances and trading positions
          </p>
        </motion.div>

        {/* ═══════════ MAIN EQUITY CARD ═══════════ */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="relative overflow-hidden rounded-2xl border border-[var(--border)] bg-gradient-to-br from-[var(--accent)]/15 via-purple-500/10 to-transparent p-6 sm:p-8"
        >
          <div className="absolute -top-20 -right-20 w-64 h-64 rounded-full bg-[var(--accent)]/15 blur-3xl pointer-events-none" />
          <div className="absolute -bottom-20 -left-20 w-64 h-64 rounded-full bg-purple-500/10 blur-3xl pointer-events-none" />

          <div className="relative z-10">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-lg bg-[var(--accent)]/15 flex items-center justify-center">
                  <Wallet size={16} className="text-[var(--accent)]" />
                </div>
                <span className="text-xs uppercase tracking-wider font-semibold text-gray-400">
                  Total Equity
                </span>
              </div>
              <button
                onClick={() => setShowBalance(!showBalance)}
                className="p-2 rounded-lg hover:bg-white/5 text-gray-400 hover:text-foreground transition-colors"
              >
                {showBalance ? <Eye size={16} /> : <EyeOff size={16} />}
              </button>
            </div>

            <div className="text-4xl sm:text-5xl font-bold text-foreground mb-2 font-mono tracking-tight">
              {mounted ? displayEquity : "••••••"}
            </div>
            <div className="text-sm text-gray-500 mb-5">
              USDT · Available + In Positions
            </div>

            {/* Balance Breakdown */}
            <div className="grid grid-cols-2 gap-3 mb-6">
              <div className="p-3 rounded-xl bg-white/[0.05] border border-[var(--border)]">
                <div className="text-[10px] text-gray-400 uppercase tracking-wider font-semibold mb-1">
                  Available
                </div>
                <div className="text-lg font-bold text-foreground font-mono">
                  {mounted ? displayBalance : "••••"}
                </div>
                <div className="text-[10px] text-gray-500 mt-0.5">Ready to trade</div>
              </div>
              <div className="p-3 rounded-xl bg-[var(--accent)]/[0.08] border border-[var(--accent)]/20">
                <div className="text-[10px] text-[var(--accent)] uppercase tracking-wider font-semibold mb-1 flex items-center gap-1">
                  <Activity size={10} />
                  In Positions
                </div>
                <div className="text-lg font-bold text-[var(--accent)] font-mono">
                  {mounted && showBalance
                    ? `$${stats.totalMarginInPositions.toFixed(2)}`
                    : "••••"}
                </div>
                <div className="text-[10px] text-gray-500 mt-0.5">
                  {stats.openPositions} open {stats.openPositions === 1 ? "trade" : "trades"}
                </div>
              </div>
            </div>

            {/* Quick action buttons */}
            <div className="grid grid-cols-3 gap-2 sm:gap-3">
              <Link href="/funds">
                <button className="w-full flex items-center justify-center gap-1.5 py-3 rounded-xl bg-gradient-to-r from-green-500 to-emerald-500 text-white font-semibold text-xs sm:text-sm hover:opacity-95 transition-all active:scale-95 shadow-lg shadow-green-500/20">
                  <ArrowDownLeft size={14} />
                  <span className="hidden sm:inline">Deposit</span>
                  <span className="sm:hidden">Add</span>
                </button>
              </Link>
              <Link href="/funds">
                <button className="w-full flex items-center justify-center gap-1.5 py-3 rounded-xl bg-white/[0.05] border border-[var(--border)] text-foreground font-semibold text-xs sm:text-sm hover:bg-white/[0.08] transition-all active:scale-95">
                  <ArrowUpRight size={14} />
                  <span className="hidden sm:inline">Withdraw</span>
                  <span className="sm:hidden">Send</span>
                </button>
              </Link>
              <Link href="/trade">
                <button className="w-full flex items-center justify-center gap-1.5 py-3 rounded-xl bg-gradient-to-r from-[var(--accent)] to-purple-500 text-white font-semibold text-xs sm:text-sm hover:opacity-95 transition-all active:scale-95 shadow-lg shadow-[var(--accent)]/20">
                  <Zap size={14} />
                  Trade
                </button>
              </Link>
            </div>
          </div>
        </motion.div>

        {/* ═══════════ ASSET BREAKDOWN ═══════════ */}
        <motion.section
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-base font-bold text-foreground">My Assets</h2>
            <Link
              href="/records"
              className="flex items-center gap-1 text-xs font-medium text-[var(--accent)] hover:gap-2 transition-all"
            >
              View History
              <ChevronRight size={14} />
            </Link>
          </div>

          <div className="glass-panel rounded-2xl overflow-hidden">
            {ASSETS.map((asset, idx) => {
              const assetBalance = asset.symbol === "USDT" ? availableBalance : 0;
              return (
                <div
                  key={asset.symbol}
                  className={`flex items-center justify-between p-4 hover:bg-white/[0.02] transition-colors ${
                    idx !== ASSETS.length - 1 ? "border-b border-[var(--border)]" : ""
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-full bg-gradient-to-br ${asset.color} flex items-center justify-center text-white font-bold text-base shadow-lg`}>
                      {asset.icon}
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-foreground">
                        {asset.symbol}
                      </div>
                      <div className="text-[11px] text-gray-500">
                        {asset.name}
                      </div>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="text-sm font-semibold text-foreground font-mono">
                      {showBalance ? assetBalance.toFixed(2) : "•••"}
                    </div>
                    <div className="text-[11px] text-gray-500 font-mono">
                      {showBalance ? `≈ $${assetBalance.toFixed(2)}` : "•••"}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </motion.section>

        {/* ═══════════ QUICK STATS ═══════════ */}
        <motion.section
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <StatCard
              label="Total Deposits"
              value={
                loadingStats
                  ? "..."
                  : showBalance
                  ? `$${stats.totalDeposits.toFixed(2)}`
                  : "••••"
              }
              icon={ArrowDownLeft}
              color="text-green-400"
              bg="bg-green-500/10"
            />
            <StatCard
              label="Withdrawals"
              value={
                loadingStats
                  ? "..."
                  : showBalance
                  ? `$${stats.totalWithdrawals.toFixed(2)}`
                  : "••••"
              }
              icon={ArrowUpRight}
              color="text-red-400"
              bg="bg-red-500/10"
            />
            <StatCard
              label="Realized P&L"
              value={
                loadingStats
                  ? "..."
                  : showBalance
                  ? `${stats.totalRealizedPnL >= 0 ? "+" : ""}$${stats.totalRealizedPnL.toFixed(2)}`
                  : "••••"
              }
              icon={stats.totalRealizedPnL >= 0 ? TrendingUp : TrendingDown}
              color={stats.totalRealizedPnL >= 0 ? "text-green-400" : "text-red-400"}
              bg={stats.totalRealizedPnL >= 0 ? "bg-green-500/10" : "bg-red-500/10"}
            />
            <StatCard
              label="Open Positions"
              value={loadingStats ? "..." : stats.openPositions.toString()}
              icon={Activity}
              color="text-[var(--accent)]"
              bg="bg-[var(--accent)]/10"
            />
          </div>
        </motion.section>

        {/* ═══════════ ADD ASSETS PROMPT ═══════════ */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
        >
          <Link href="/funds">
            <div className="group flex items-center justify-between p-4 rounded-2xl border border-dashed border-[var(--border)] hover:border-[var(--accent)]/40 hover:bg-white/[0.02] transition-all cursor-pointer">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[var(--accent)]/10 flex items-center justify-center group-hover:bg-[var(--accent)]/20 transition-colors">
                  <Plus size={18} className="text-[var(--accent)]" />
                </div>
                <div>
                  <div className="text-sm font-semibold text-foreground">
                    Add Funds
                  </div>
                  <div className="text-[11px] text-gray-500">
                    Deposit crypto or use bank transfer
                  </div>
                </div>
              </div>
              <ChevronRight size={18} className="text-gray-500 group-hover:text-[var(--accent)] group-hover:translate-x-0.5 transition-all" />
            </div>
          </Link>
        </motion.div>
      </div>
    </div>
  );
}

// ─── Stat Card Component ───
function StatCard({
  label,
  value,
  icon: Icon,
  color,
  bg,
}: {
  label: string;
  value: string;
  icon: React.ElementType;
  color: string;
  bg: string;
}) {
  return (
    <div className="glass-panel rounded-xl p-3 sm:p-4">
      <div className={`w-7 h-7 rounded-lg ${bg} flex items-center justify-center mb-2`}>
        <Icon size={14} className={color} />
      </div>
      <div className="text-[10px] text-gray-500 uppercase tracking-wider font-semibold mb-0.5">
        {label}
      </div>
      <div className={`text-sm sm:text-base font-bold font-mono ${color}`}>
        {value}
      </div>
    </div>
  );
}