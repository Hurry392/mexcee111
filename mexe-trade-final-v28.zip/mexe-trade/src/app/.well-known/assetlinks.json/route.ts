// src/app/.well-known/assetlinks.json/route.ts
//
// Digital Asset Links — served at /.well-known/assetlinks.json.
// This is what lets the Trusted Web Activity (TWA) Android app open this
// domain FULLSCREEN with no browser address bar. Without a valid file
// here matching the app's signing certificate, Android shows a URL bar
// at the top (the #1 reason wrapped-website apps look "broken").
//
// The app's SHA-256 signing fingerprint isn't known until the .apk is
// generated, so we read it from an environment variable. After you build
// the app and get its fingerprint, set ANDROID_CERT_FINGERPRINT in Vercel
// (Project → Settings → Environment Variables) and redeploy — no code
// change needed. You can set multiple fingerprints comma-separated (e.g.
// your upload key + Play's re-signing key), and it handles both.

import { NextResponse } from "next/server";

const PACKAGE_NAME = process.env.ANDROID_PACKAGE_NAME || "app.vercel.mexe_trade_main_1.twa";

export function GET() {
  const raw = process.env.ANDROID_CERT_FINGERPRINT || "";
  const fingerprints = raw
    .split(",")
    .map((f) => f.trim())
    .filter(Boolean);

  const body = [
    {
      relation: ["delegate_permission/common.handle_all_urls"],
      target: {
        namespace: "android_app",
        package_name: PACKAGE_NAME,
        sha256_cert_fingerprints: fingerprints,
      },
    },
  ];

  return NextResponse.json(body, {
    headers: {
      // Cache lightly so a fingerprint change propagates reasonably fast.
      "Cache-Control": "public, max-age=300",
    },
  });
}
