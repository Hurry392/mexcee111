// src/app/layout.tsx
import type { Metadata, Viewport } from "next";
import { Inter } from "next/font/google";
import "@/app/globals.css";
import ClientLayout from "@/components/ClientLayout";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});

// ✅ Server-side metadata — SEO, title, description, PWA
export const metadata: Metadata = {
  title: "MEXC Trade — Global Crypto Exchange",
  description:
    "Trade cryptocurrencies with confidence. MEXC Trade offers secure deposits, real-time markets, multi-method withdrawals, and professional trading tools.",
  keywords: ["mexc", "crypto", "trading", "exchange", "bitcoin", "ethereum", "usdt", "withdrawal"],
  manifest: "/manifest.webmanifest",
  applicationName: "MEXC Trade",
  appleWebApp: {
    // iOS "Add to Home Screen": launch fullscreen with a dark status bar.
    capable: true,
    title: "MEXC Trade",
    statusBarStyle: "black-translucent",
  },
  icons: {
    icon: "/favicon.ico",
    shortcut: "/favicon.ico",
    apple: "/apple-icon.png",
  },
};

// Next.js 16: theme color and viewport behavior live in the viewport export.
export const viewport: Viewport = {
  themeColor: "#030712",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1, // prevent the zoom-on-input-focus jump on mobile
  viewportFit: "cover", // draw under the notch/home indicator for a native feel
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" suppressHydrationWarning data-scroll-behavior="smooth">
      <body
        className={`${inter.variable} font-sans antialiased`}
        suppressHydrationWarning
      >
        <ClientLayout>{children}</ClientLayout>
      </body>
    </html>
  );
}