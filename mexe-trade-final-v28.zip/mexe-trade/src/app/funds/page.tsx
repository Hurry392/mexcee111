// src/app/funds/page.tsx
"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  ArrowDownLeft,
  ArrowUpRight,
  AlertCircle,
  ShieldCheck,
} from "lucide-react";
import Link from "next/link";
import { useAuthStore } from "@/store/authStore";
import DepositPanel from "@/components/funds/DepositPanel";
import WithdrawPanel from "@/components/funds/WithdrawPanel";

type FundsTab = "deposit" | "withdraw";

export default function FundsPage() {
  const [tab, setTab] = useState<FundsTab>("deposit");
  const { user } = useAuthStore();

  const kycPending = user?.kycStatus !== "APPROVED";

  return (
    <div className="min-h-full mesh-bg">
      <div className="max-w-3xl mx-auto p-4 sm:p-6 lg:p-8 space-y-5">
        {/* ═══════════ HEADER ═══════════ */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
        >
          <h1 className="text-2xl sm:text-3xl font-bold text-foreground mb-1.5">
            Funds Management
          </h1>
          <p className="text-sm text-gray-500">
            Deposit or withdraw your assets securely
          </p>
        </motion.div>

        {/* ═══════════ KYC ALERT (if not approved) ═══════════ */}
        {kycPending && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-start gap-3 p-4 rounded-xl bg-amber-500/[0.07] border border-amber-500/20"
          >
            <div className="w-8 h-8 rounded-lg bg-amber-500/15 flex items-center justify-center shrink-0">
              <ShieldCheck size={16} className="text-amber-400" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-amber-300 mb-0.5">
                KYC Verification Required
              </p>
              <p className="text-xs text-amber-200/70 mb-2">
                Complete identity verification to enable withdrawals and unlock higher limits.
              </p>
              <Link href="/kyc">
                <button className="text-xs font-semibold text-amber-400 hover:text-amber-300 underline underline-offset-2">
                  Complete KYC →
                </button>
              </Link>
            </div>
          </motion.div>
        )}

        {/* ═══════════ BALANCE CARD ═══════════ */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="relative overflow-hidden rounded-2xl border border-[var(--border)] bg-gradient-to-br from-[var(--accent)]/10 via-purple-500/5 to-transparent p-5 sm:p-6"
        >
          <div className="absolute -top-10 -right-10 w-40 h-40 rounded-full bg-[var(--accent)]/10 blur-3xl pointer-events-none" />

          <div className="relative z-10 flex items-center justify-between">
            <div>
              <div className="text-[10px] uppercase tracking-wider text-gray-500 font-semibold mb-1">
                Available Balance
              </div>
              <div className="text-3xl sm:text-4xl font-bold text-foreground">
                ${user?.balance?.toFixed(2) ?? "0.00"}
              </div>
              <div className="text-xs text-gray-500 mt-1">USDT</div>
            </div>
            <div className="flex flex-col items-end gap-1">
              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-green-500/10 border border-green-500/20">
                <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
                <span className="text-[10px] font-semibold text-green-400 uppercase tracking-wider">
                  Active
                </span>
              </div>
            </div>
          </div>
        </motion.div>

        {/* ═══════════ DEPOSIT/WITHDRAW TAB SWITCHER ═══════════ */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="relative flex p-1 rounded-xl bg-card border border-[var(--border)]"
        >
          {([
            { id: "deposit" as FundsTab, label: "Deposit", icon: ArrowDownLeft, color: "text-green-400" },
            { id: "withdraw" as FundsTab, label: "Withdraw", icon: ArrowUpRight, color: "text-red-400" },
          ]).map((t) => {
            const Icon = t.icon;
            return (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`relative flex-1 flex items-center justify-center gap-2 py-3 text-sm font-semibold rounded-lg transition-colors z-10 ${
                  tab === t.id ? "text-foreground" : "text-gray-500 hover:text-gray-300"
                }`}
              >
                {tab === t.id && (
                  <motion.div
                    layoutId="fundsTabPill"
                    className="absolute inset-0 rounded-lg bg-white/[0.05] border border-[var(--border)]"
                    transition={{ type: "spring", stiffness: 300, damping: 30 }}
                  />
                )}
                <Icon size={16} className={`relative z-10 ${tab === t.id ? t.color : ""}`} />
                <span className="relative z-10">{t.label}</span>
              </button>
            );
          })}
        </motion.div>

        {/* ═══════════ PANEL CONTENT ═══════════ */}
        <AnimatePresence mode="wait">
          {tab === "deposit" ? (
            <motion.div
              key="deposit"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 10 }}
              transition={{ duration: 0.2 }}
            >
              <DepositPanel />
            </motion.div>
          ) : (
            <motion.div
              key="withdraw"
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -10 }}
              transition={{ duration: 0.2 }}
            >
              <WithdrawPanel />
            </motion.div>
          )}
        </AnimatePresence>

        {/* ═══════════ INFO FOOTER ═══════════ */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="flex items-start gap-2.5 p-4 rounded-xl bg-white/[0.02] border border-[var(--border)]"
        >
          <AlertCircle size={14} className="text-gray-500 shrink-0 mt-0.5" />
          <p className="text-xs text-gray-500 leading-relaxed">
            All transactions are reviewed manually by our team. Processing time typically takes <span className="text-foreground font-medium">1-3 business days</span>. For urgent inquiries, contact{" "}
            <Link href="/chat" className="text-[var(--accent)] hover:underline">
              support
            </Link>.
          </p>
        </motion.div>
      </div>
    </div>
  );
}