// src/app/admin/users/[id]/page.tsx
"use client";

import { useEffect, useState, useCallback, use } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import {
  ArrowLeft,
  Mail,
  Phone,
  Globe,
  Calendar,
  Shield,
  DollarSign,
  Plus,
  Minus,
  Ban,
  CheckCircle,
  UserPlus,
  UserMinus,
  Trash2,
  Wallet,
  ArrowDownToLine,
  ArrowUpFromLine,
  TrendingUp,
  Copy,
  Check,
  Clock,
  KeyRound,
  Loader2,
  Snowflake,
  Unlock,
} from "lucide-react";
import { adminAPI } from "@/lib/api";
import BalanceModal from "@/components/admin/BalanceModal";
import UserActionsModal from "@/components/admin/UserActionsModal";

interface UserDetail {
  id: string;
  uid: number;
  email: string;
  username: string | null;
  phone: string | null;
  country: string | null;
  balance: number;
  role: string;
  isActive: boolean;
  isVerified: boolean;
  kycStatus: string;
  withdrawalsFrozen: boolean;
  withdrawalFreezeReason: string | null;
  withdrawalFrozenAt: string | null;
  referralCode: string;
  referredBy: string | null;
  createdAt: string;
  lastLoginAt: string | null;
  deposits: Array<{
    id: string;
    amount: number;
    currency: string;
    status: string;
    createdAt: string;
  }>;
  withdrawals: Array<{
    id: string;
    amount: number;
    currency: string;
    status: string;
    createdAt: string;
  }>;
  trades: Array<{
    id: string;
    coinSymbol: string;
    side: string;
    marginAmount: number;
    pnl: number;
    status: string;
    openedAt: string;
  }>;
  _count: {
    deposits: number;
    withdrawals: number;
    trades: number;
    chatMessages: number;
    sessions: number;
  };
}

interface UserStats {
  totalDeposited: number;
  totalWithdrawn: number;
  openTrades: number;
}

type ModalAction = "SUSPEND" | "ACTIVATE" | "PROMOTE" | "DEMOTE" | "DELETE" | "FREEZE_WITHDRAWALS" | "UNFREEZE_WITHDRAWALS" | null;

export default function AdminUserDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = use(params);
  const router = useRouter();

  const [user, setUser] = useState<UserDetail | null>(null);
  const [stats, setStats] = useState<UserStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [balanceModalOpen, setBalanceModalOpen] = useState(false);
  const [actionModal, setActionModal] = useState<ModalAction>(null);
  const [copied, setCopied] = useState(false);

  // ─── Password reset state ───
  const [pwModalOpen, setPwModalOpen] = useState(false);
  const [pwInput, setPwInput] = useState("");
  const [pwNote, setPwNote] = useState("");
  const [pwBusy, setPwBusy] = useState(false);
  const [pwError, setPwError] = useState("");
  const [pwResult, setPwResult] = useState<string | null>(null);
  const [pwCopied, setPwCopied] = useState(false);

  // Withdrawal-password reset modal
  const [wpModalOpen, setWpModalOpen] = useState(false);
  const [wpInput, setWpInput] = useState("");
  const [wpNote, setWpNote] = useState("");
  const [wpBusy, setWpBusy] = useState(false);
  const [wpError, setWpError] = useState("");
  const [wpResult, setWpResult] = useState<string | null>(null);
  const [wpCleared, setWpCleared] = useState(false);
  const [wpCopied, setWpCopied] = useState(false);

  const fetchUser = useCallback(async () => {
    setLoading(true);
    try {
      const response = await fetch(`/api/admin/users/${id}`, {
        credentials: "include",
      });
      const data = await response.json();

      if (data.success) {
        setUser(data.user);
        setStats(data.stats);
      } else if (data.error) {
        // User not found or unauthorized
        router.push("/admin/users");
      }
    } catch (err) {
      console.error("Failed to fetch user:", err);
    } finally {
      setLoading(false);
    }
  }, [id, router]);

  useEffect(() => {
    fetchUser();
  }, [fetchUser]);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleActionSuccess = () => {
    if (actionModal === "DELETE") {
      router.push("/admin/users");
    } else {
      fetchUser();
    }
  };

  const openPwModal = () => {
    setPwInput("");
    setPwNote("");
    setPwError("");
    setPwResult(null);
    setPwCopied(false);
    setPwModalOpen(true);
  };

  const submitPwReset = async () => {
    setPwBusy(true);
    setPwError("");
    try {
      const payload: { newPassword?: string; note?: string } = {};
      if (pwInput.trim()) payload.newPassword = pwInput.trim();
      if (pwNote.trim()) payload.note = pwNote.trim();
      const res = (await adminAPI.resetPassword(id, payload)) as {
        error?: string;
        newPassword?: string;
      };
      if (res.error) {
        setPwError(res.error);
      } else {
        setPwResult(res.newPassword ?? "");
        fetchUser(); // sessions were cleared; refresh view
      }
    } catch {
      setPwError("Failed to reset password. Please try again.");
    } finally {
      setPwBusy(false);
    }
  };

  const copyNewPassword = async () => {
    if (!pwResult) return;
    try {
      await navigator.clipboard.writeText(pwResult);
      setPwCopied(true);
      setTimeout(() => setPwCopied(false), 1500);
    } catch {
      // ignore
    }
  };

  const openWpModal = () => {
    setWpInput("");
    setWpNote("");
    setWpError("");
    setWpResult(null);
    setWpCleared(false);
    setWpCopied(false);
    setWpModalOpen(true);
  };

  const submitWpReset = async (clear: boolean) => {
    setWpBusy(true);
    setWpError("");
    try {
      const payload: { newPassword?: string; clear?: boolean; note?: string } = {};
      if (clear) {
        payload.clear = true;
      } else if (wpInput.trim()) {
        payload.newPassword = wpInput.trim();
      }
      if (wpNote.trim()) payload.note = wpNote.trim();
      const res = (await adminAPI.resetWithdrawalPassword(id, payload)) as {
        error?: string;
        newPassword?: string;
        cleared?: boolean;
      };
      if (res.error) {
        setWpError(res.error);
      } else if (res.cleared) {
        setWpCleared(true);
      } else {
        setWpResult(res.newPassword ?? "");
      }
    } catch {
      setWpError("Failed to reset withdrawal password. Please try again.");
    } finally {
      setWpBusy(false);
    }
  };

  const copyNewWithdrawalPassword = async () => {
    if (!wpResult) return;
    try {
      await navigator.clipboard.writeText(wpResult);
      setWpCopied(true);
      setTimeout(() => setWpCopied(false), 1500);
    } catch {
      // ignore
    }
  };

  if (loading) {
    return (
      <div className="p-4 lg:p-8 max-w-6xl mx-auto">
        <div className="skeleton h-8 w-48 mb-6 rounded" />
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="skeleton h-64 rounded-2xl" />
          <div className="skeleton h-64 rounded-2xl" />
          <div className="skeleton h-64 rounded-2xl" />
        </div>
      </div>
    );
  }

  if (!user) return null;

  return (
    <div className="p-4 lg:p-8 max-w-6xl mx-auto">
      {/* ═══ Back Button ═══ */}
      <Link href="/admin/users">
        <button className="flex items-center gap-2 text-xs text-gray-400 hover:text-[var(--accent)] mb-4 transition-all">
          <ArrowLeft size={14} />
          <span>Back to Users</span>
        </button>
      </Link>

      {/* ═══ Header Card ═══ */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="premium-card rounded-2xl p-5 lg:p-6 mb-4"
      >
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center text-white text-2xl font-bold shadow-lg">
            {user.email.charAt(0).toUpperCase()}
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <h1 className="text-xl lg:text-2xl font-bold text-foreground truncate">
                {user.username || user.email.split("@")[0]}
              </h1>
              <span className="inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-bold font-mono bg-[var(--accent)]/10 border border-[var(--accent)]/20 text-[var(--accent)]">
                UID {user.uid}
              </span>
              {user.role === "ADMIN" && (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-blue-500/10 border border-blue-500/20 text-blue-400">
                  <Shield size={10} />
                  ADMIN
                </span>
              )}
              {user.isActive ? (
                <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-green-400">
                  <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
                  Active
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-red-400">
                  <span className="w-1.5 h-1.5 rounded-full bg-red-400" />
                  Suspended
                </span>
              )}
              {user.withdrawalsFrozen && (
                <span
                  className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-cyan-500/10 border border-cyan-500/20 text-cyan-400"
                  title={user.withdrawalFreezeReason || undefined}
                >
                  <Snowflake size={10} />
                  WITHDRAWALS FROZEN
                </span>
              )}
            </div>

            <div className="flex flex-wrap gap-3 text-xs text-gray-500">
              <span className="flex items-center gap-1">
                <Mail size={11} />
                {user.email}
              </span>
              {user.phone && (
                <span className="flex items-center gap-1">
                  <Phone size={11} />
                  {user.phone}
                </span>
              )}
              {user.country && (
                <span className="flex items-center gap-1">
                  <Globe size={11} />
                  {user.country}
                </span>
              )}
              <span className="flex items-center gap-1">
                <Calendar size={11} />
                Joined {new Date(user.createdAt).toLocaleDateString()}
              </span>
            </div>
          </div>

          <button
            onClick={() => copyToClipboard(user.id)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/5 border border-[var(--border)] text-[10px] text-gray-400 hover:text-white transition-all"
          >
            {copied ? <Check size={12} className="text-green-400" /> : <Copy size={12} />}
            <span className="font-mono">{copied ? "Copied!" : user.id.slice(0, 12) + "..."}</span>
          </button>
        </div>
      </motion.div>

      {/* ═══ Quick Stats ═══ */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
        <StatBox
          label="Current Balance"
          value={`$${user.balance.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}
          icon={Wallet}
          color="accent"
        />
        <StatBox
          label="Total Deposited"
          value={`$${(stats?.totalDeposited || 0).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}
          icon={ArrowDownToLine}
          color="green"
        />
        <StatBox
          label="Total Withdrawn"
          value={`$${(stats?.totalWithdrawn || 0).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}
          icon={ArrowUpFromLine}
          color="red"
        />
        <StatBox
          label="Open Trades"
          value={stats?.openTrades || 0}
          icon={TrendingUp}
          color="purple"
        />
      </div>

      {/* ═══ Main Grid ═══ */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left: Balance & Actions */}
        <div className="lg:col-span-1 space-y-4">
          {/* Balance Card */}
          <div className="premium-card rounded-2xl p-5">
            <h3 className="text-xs font-bold uppercase tracking-wider text-gray-500 mb-3">Balance Management</h3>

            <div className="p-4 rounded-xl bg-gradient-to-br from-[var(--accent)]/10 to-purple-500/10 border border-[var(--accent)]/20 mb-4">
              <p className="text-[10px] uppercase tracking-wider text-gray-500 font-semibold mb-1">
                Current Balance
              </p>
              <p className="text-2xl font-bold gradient-text">
                ${user.balance.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </p>
            </div>

            <button
              onClick={() => setBalanceModalOpen(true)}
              className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-gradient-to-r from-[var(--accent)] to-purple-500 text-white font-bold text-sm shadow-lg shadow-blue-500/20 hover:shadow-blue-500/40 transition-all"
            >
              <DollarSign size={16} />
              <span>Manage Balance</span>
            </button>
          </div>

          {/* Account Actions */}
          <div className="premium-card rounded-2xl p-5">
            <h3 className="text-xs font-bold uppercase tracking-wider text-gray-500 mb-3">Account Actions</h3>

            <div className="space-y-2">
              {/* Suspend/Activate */}
              {user.isActive ? (
                <button
                  onClick={() => setActionModal("SUSPEND")}
                  className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 hover:bg-amber-500/20 transition-all text-sm font-semibold"
                >
                  <Ban size={16} />
                  <span>Suspend User</span>
                </button>
              ) : (
                <button
                  onClick={() => setActionModal("ACTIVATE")}
                  className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl bg-green-500/10 border border-green-500/20 text-green-400 hover:bg-green-500/20 transition-all text-sm font-semibold"
                >
                  <CheckCircle size={16} />
                  <span>Activate User</span>
                </button>
              )}

              {/* Freeze/Unfreeze Withdrawals */}
              {user.withdrawalsFrozen && user.withdrawalFreezeReason && (
                <div className="p-3 rounded-xl bg-cyan-500/[0.05] border border-cyan-500/20">
                  <p className="text-[9px] uppercase tracking-wider text-cyan-400/80 font-semibold mb-1">
                    Freeze reason (visible to user)
                  </p>
                  <p className="text-[11px] text-gray-300 leading-relaxed">
                    {user.withdrawalFreezeReason}
                  </p>
                  {user.withdrawalFrozenAt && (
                    <p className="text-[9px] text-gray-500 mt-1">
                      Frozen on {new Date(user.withdrawalFrozenAt).toLocaleString()}
                    </p>
                  )}
                </div>
              )}
              {user.withdrawalsFrozen ? (
                <button
                  onClick={() => setActionModal("UNFREEZE_WITHDRAWALS")}
                  className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl bg-green-500/10 border border-green-500/20 text-green-400 hover:bg-green-500/20 transition-all text-sm font-semibold"
                >
                  <Unlock size={16} />
                  <span>Re-enable Withdrawals</span>
                </button>
              ) : (
                <button
                  onClick={() => setActionModal("FREEZE_WITHDRAWALS")}
                  className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 hover:bg-cyan-500/20 transition-all text-sm font-semibold"
                >
                  <Snowflake size={16} />
                  <span>Freeze Withdrawals</span>
                </button>
              )}

              {/* Promote/Demote */}
              {user.role === "ADMIN" ? (
                <button
                  onClick={() => setActionModal("DEMOTE")}
                  className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl bg-white/5 border border-[var(--border)] text-gray-300 hover:bg-white/10 transition-all text-sm font-semibold"
                >
                  <UserMinus size={16} />
                  <span>Demote to User</span>
                </button>
              ) : (
                <button
                  onClick={() => setActionModal("PROMOTE")}
                  className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl bg-blue-500/10 border border-blue-500/20 text-blue-400 hover:bg-blue-500/20 transition-all text-sm font-semibold"
                >
                  <UserPlus size={16} />
                  <span>Promote to Admin</span>
                </button>
              )}

              {/* Reset Password */}
              <button
                onClick={openPwModal}
                className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 hover:bg-indigo-500/20 transition-all text-sm font-semibold"
              >
                <KeyRound size={16} />
                <span>Reset Password</span>
              </button>

              {/* Reset Withdrawal Password */}
              <button
                onClick={openWpModal}
                className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl bg-teal-500/10 border border-teal-500/20 text-teal-400 hover:bg-teal-500/20 transition-all text-sm font-semibold"
              >
                <KeyRound size={16} />
                <span>Reset Withdrawal Password</span>
              </button>

              {/* Delete */}
              <button
                onClick={() => setActionModal("DELETE")}
                className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 hover:bg-red-500/20 transition-all text-sm font-semibold"
              >
                <Trash2 size={16} />
                <span>Delete User</span>
              </button>
            </div>
          </div>

          {/* Info Card */}
          <div className="premium-card rounded-2xl p-5">
            <h3 className="text-xs font-bold uppercase tracking-wider text-gray-500 mb-3">Account Info</h3>
            <div className="space-y-3">
              <InfoRow label="UID" value={String(user.uid)} mono />
              <InfoRow label="User ID" value={user.id} mono />
              <InfoRow label="Referral Code" value={user.referralCode} mono />
              {user.referredBy && <InfoRow label="Referred By" value={user.referredBy} mono />}
              <InfoRow label="KYC Status" value={user.kycStatus} badge={user.kycStatus} />
              <InfoRow label="Email Verified" value={user.isVerified ? "Yes" : "No"} />
              {user.lastLoginAt && (
                <InfoRow label="Last Login" value={new Date(user.lastLoginAt).toLocaleString()} />
              )}
            </div>
          </div>
        </div>

        {/* Right: Recent Activity */}
        <div className="lg:col-span-2 space-y-4">
          {/* Recent Deposits */}
          <div className="premium-card rounded-2xl p-5">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <ArrowDownToLine className="w-4 h-4 text-green-400" />
                <h3 className="text-sm font-bold text-foreground">
                  Recent Deposits ({user._count.deposits})
                </h3>
              </div>
            </div>

            {user.deposits.length === 0 ? (
              <p className="text-xs text-gray-500 text-center py-6">No deposits yet</p>
            ) : (
              <div className="space-y-2">
                {user.deposits.slice(0, 5).map((deposit) => (
                  <ActivityRow
                    key={deposit.id}
                    amount={deposit.amount}
                    currency={deposit.currency}
                    status={deposit.status}
                    date={deposit.createdAt}
                    type="deposit"
                  />
                ))}
              </div>
            )}
          </div>

          {/* Recent Withdrawals */}
          <div className="premium-card rounded-2xl p-5">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <ArrowUpFromLine className="w-4 h-4 text-red-400" />
                <h3 className="text-sm font-bold text-foreground">
                  Recent Withdrawals ({user._count.withdrawals})
                </h3>
              </div>
            </div>

            {user.withdrawals.length === 0 ? (
              <p className="text-xs text-gray-500 text-center py-6">No withdrawals yet</p>
            ) : (
              <div className="space-y-2">
                {user.withdrawals.slice(0, 5).map((withdrawal) => (
                  <ActivityRow
                    key={withdrawal.id}
                    amount={withdrawal.amount}
                    currency={withdrawal.currency}
                    status={withdrawal.status}
                    date={withdrawal.createdAt}
                    type="withdrawal"
                  />
                ))}
              </div>
            )}
          </div>

          {/* Recent Trades */}
          <div className="premium-card rounded-2xl p-5">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-[var(--accent)]" />
                <h3 className="text-sm font-bold text-foreground">
                  Recent Trades ({user._count.trades})
                </h3>
              </div>
            </div>

            {user.trades.length === 0 ? (
              <p className="text-xs text-gray-500 text-center py-6">No trades yet</p>
            ) : (
              <div className="space-y-2">
                {user.trades.slice(0, 5).map((trade) => (
                  <div key={trade.id} className="flex items-center justify-between p-3 rounded-lg bg-white/[0.02] border border-[var(--border)]">
                    <div className="flex items-center gap-3">
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-[10px] font-bold ${
                        trade.side === "BUY" ? "bg-green-500/10 text-green-400" : "bg-red-500/10 text-red-400"
                      }`}>
                        {trade.side === "BUY" ? "L" : "S"}
                      </div>
                      <div>
                        <p className="text-xs font-semibold text-foreground">{trade.coinSymbol}/USDT</p>
                        <p className="text-[10px] text-gray-500 flex items-center gap-1">
                          <Clock size={9} />
                          {new Date(trade.openedAt).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-xs font-bold text-foreground">${trade.marginAmount.toFixed(2)}</p>
                      <p className={`text-[10px] font-semibold ${
                        trade.status === "OPEN" ? "text-blue-400" :
                        trade.pnl >= 0 ? "text-green-400" : "text-red-400"
                      }`}>
                        {trade.status === "OPEN" ? "OPEN" : `${trade.pnl >= 0 ? "+" : "-"}$${Math.abs(trade.pnl).toFixed(2)}`}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* ═══ Modals ═══ */}
      <BalanceModal
        isOpen={balanceModalOpen}
        onClose={() => setBalanceModalOpen(false)}
        user={user}
        onSuccess={fetchUser}
      />

      {actionModal && (
        <UserActionsModal
          isOpen={!!actionModal}
          onClose={() => setActionModal(null)}
          user={user}
          action={actionModal}
          onSuccess={handleActionSuccess}
        />
      )}

      {/* ═══ Reset Password Modal ═══ */}
      {pwModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="w-full max-w-md premium-card rounded-2xl p-5 border border-[var(--border)]">
            <div className="flex items-center gap-2 mb-1">
              <KeyRound size={18} className="text-indigo-400" />
              <h3 className="text-base font-bold text-foreground">Reset Password</h3>
            </div>
            <p className="text-[11px] text-gray-500 mb-4">
              For <span className="text-gray-300">{user.email}</span> (UID {user.uid}).
              This sets a new password — the old one can never be recovered.
              All active sessions will be logged out.
            </p>

            {!pwResult ? (
              <>
                <label className="block text-[11px] font-semibold text-gray-400 mb-1">
                  New password
                </label>
                <input
                  type="text"
                  value={pwInput}
                  onChange={(e) => setPwInput(e.target.value)}
                  placeholder="Leave blank to auto-generate a strong one"
                  className="w-full px-3 py-2.5 rounded-xl bg-white/5 border border-white/10 text-foreground text-sm placeholder:text-gray-600 focus:border-indigo-500/50 outline-none transition-all mb-1"
                />
                <p className="text-[10px] text-gray-600 mb-3">
                  Min 8 chars, with an uppercase, a lowercase, and a number.
                </p>

                <label className="block text-[11px] font-semibold text-gray-400 mb-1">
                  Note (optional, for the audit log)
                </label>
                <input
                  type="text"
                  value={pwNote}
                  onChange={(e) => setPwNote(e.target.value)}
                  placeholder="e.g. User requested reset via support chat"
                  className="w-full px-3 py-2.5 rounded-xl bg-white/5 border border-white/10 text-foreground text-sm placeholder:text-gray-600 focus:border-indigo-500/50 outline-none transition-all mb-3"
                />

                {pwError && (
                  <p className="text-xs text-red-400 mb-3">{pwError}</p>
                )}

                <div className="flex gap-2">
                  <button
                    onClick={() => setPwModalOpen(false)}
                    disabled={pwBusy}
                    className="flex-1 px-3 py-2.5 rounded-xl bg-white/5 border border-[var(--border)] text-gray-300 hover:bg-white/10 transition-all text-sm font-semibold disabled:opacity-50"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={submitPwReset}
                    disabled={pwBusy}
                    className="flex-1 flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl bg-indigo-500/15 border border-indigo-500/30 text-indigo-300 hover:bg-indigo-500/25 transition-all text-sm font-semibold disabled:opacity-50"
                  >
                    {pwBusy ? (
                      <>
                        <Loader2 size={14} className="animate-spin" />
                        Resetting...
                      </>
                    ) : (
                      "Reset Password"
                    )}
                  </button>
                </div>
              </>
            ) : (
              <>
                <div className="p-3 rounded-xl bg-green-500/10 border border-green-500/20 mb-3">
                  <p className="text-[11px] text-green-400 font-semibold mb-2">
                    Password reset. Copy it now — it won&apos;t be shown again.
                  </p>
                  <div className="flex items-center gap-2">
                    <code className="flex-1 px-2 py-2 rounded-lg bg-black/30 border border-[var(--border)] text-sm font-mono text-foreground break-all">
                      {pwResult}
                    </code>
                    <button
                      onClick={copyNewPassword}
                      className="shrink-0 p-2 rounded-lg bg-white/5 border border-[var(--border)] text-gray-300 hover:bg-white/10 transition-all"
                      title="Copy password"
                    >
                      {pwCopied ? <Check size={16} className="text-green-400" /> : <Copy size={16} />}
                    </button>
                  </div>
                </div>
                <p className="text-[10px] text-gray-500 mb-3">
                  Share this with the user through a secure channel. They should change
                  it after logging in.
                </p>
                <button
                  onClick={() => setPwModalOpen(false)}
                  className="w-full px-3 py-2.5 rounded-xl bg-white/5 border border-[var(--border)] text-gray-300 hover:bg-white/10 transition-all text-sm font-semibold"
                >
                  Done
                </button>
              </>
            )}
          </div>
        </div>
      )}

      {/* ═══ Reset Withdrawal Password Modal ═══ */}
      {wpModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="w-full max-w-md premium-card rounded-2xl p-5 border border-[var(--border)]">
            <div className="flex items-center gap-2 mb-1">
              <KeyRound size={18} className="text-teal-400" />
              <h3 className="text-base font-bold text-foreground">Reset Withdrawal Password</h3>
            </div>
            <p className="text-[11px] text-gray-500 mb-4">
              For <span className="text-gray-300">{user.email}</span> (UID {user.uid}).
              This is the password required to make withdrawals — separate from the
              login password. The old one can never be recovered.
            </p>

            {!wpResult && !wpCleared ? (
              <>
                <label className="block text-[11px] font-semibold text-gray-400 mb-1">
                  New withdrawal password
                </label>
                <input
                  type="text"
                  value={wpInput}
                  onChange={(e) => setWpInput(e.target.value)}
                  placeholder="Leave blank to auto-generate a strong one"
                  className="w-full px-3 py-2.5 rounded-xl bg-white/5 border border-white/10 text-foreground text-sm placeholder:text-gray-600 focus:border-teal-500/50 outline-none transition-all mb-1"
                />
                <p className="text-[10px] text-gray-600 mb-3">
                  Min 8 chars, with an uppercase, a lowercase, and a number.
                </p>

                <label className="block text-[11px] font-semibold text-gray-400 mb-1">
                  Note (optional, for the audit log)
                </label>
                <input
                  type="text"
                  value={wpNote}
                  onChange={(e) => setWpNote(e.target.value)}
                  placeholder="e.g. User forgot withdrawal password, requested via support"
                  className="w-full px-3 py-2.5 rounded-xl bg-white/5 border border-white/10 text-foreground text-sm placeholder:text-gray-600 focus:border-teal-500/50 outline-none transition-all mb-3"
                />

                {wpError && <p className="text-xs text-red-400 mb-3">{wpError}</p>}

                <div className="flex gap-2 mb-2">
                  <button
                    onClick={() => setWpModalOpen(false)}
                    disabled={wpBusy}
                    className="flex-1 px-3 py-2.5 rounded-xl bg-white/5 border border-[var(--border)] text-gray-300 hover:bg-white/10 transition-all text-sm font-semibold disabled:opacity-50"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => submitWpReset(false)}
                    disabled={wpBusy}
                    className="flex-1 flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl bg-teal-500/15 border border-teal-500/30 text-teal-300 hover:bg-teal-500/25 transition-all text-sm font-semibold disabled:opacity-50"
                  >
                    {wpBusy ? (
                      <>
                        <Loader2 size={14} className="animate-spin" />
                        Resetting...
                      </>
                    ) : (
                      "Reset Password"
                    )}
                  </button>
                </div>

                {/* Clear option — lets the user set a fresh one themselves */}
                <button
                  onClick={() => submitWpReset(true)}
                  disabled={wpBusy}
                  className="w-full px-3 py-2 rounded-xl bg-white/[0.02] border border-[var(--border)] text-gray-400 hover:bg-white/5 hover:text-gray-300 transition-all text-[11px] font-medium disabled:opacity-50"
                  title="Remove the withdrawal password so the user sets a new one themselves"
                >
                  Or just clear it (user sets a new one themselves)
                </button>
              </>
            ) : wpCleared ? (
              <>
                <div className="p-3 rounded-xl bg-green-500/10 border border-green-500/20 mb-3">
                  <p className="text-[11px] text-green-400 font-semibold">
                    Withdrawal password cleared. The user will be prompted to set a new
                    one in Security before their next withdrawal.
                  </p>
                </div>
                <button
                  onClick={() => setWpModalOpen(false)}
                  className="w-full px-3 py-2.5 rounded-xl bg-white/5 border border-[var(--border)] text-gray-300 hover:bg-white/10 transition-all text-sm font-semibold"
                >
                  Done
                </button>
              </>
            ) : (
              <>
                <div className="p-3 rounded-xl bg-green-500/10 border border-green-500/20 mb-3">
                  <p className="text-[11px] text-green-400 font-semibold mb-2">
                    Withdrawal password reset. Copy it now — it won&apos;t be shown again.
                  </p>
                  <div className="flex items-center gap-2">
                    <code className="flex-1 px-2 py-2 rounded-lg bg-black/30 border border-[var(--border)] text-sm font-mono text-foreground break-all">
                      {wpResult}
                    </code>
                    <button
                      onClick={copyNewWithdrawalPassword}
                      className="shrink-0 p-2 rounded-lg bg-white/5 border border-[var(--border)] text-gray-300 hover:bg-white/10 transition-all"
                      title="Copy password"
                    >
                      {wpCopied ? <Check size={16} className="text-green-400" /> : <Copy size={16} />}
                    </button>
                  </div>
                </div>
                <p className="text-[10px] text-gray-500 mb-3">
                  Share this with the user through a secure channel. They can change it
                  anytime in Security → Withdrawal Password.
                </p>
                <button
                  onClick={() => setWpModalOpen(false)}
                  className="w-full px-3 py-2.5 rounded-xl bg-white/5 border border-[var(--border)] text-gray-300 hover:bg-white/10 transition-all text-sm font-semibold"
                >
                  Done
                </button>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Stat Box ───
function StatBox({
  label,
  value,
  icon: Icon,
  color,
}: {
  label: string;
  value: string | number;
  icon: React.ElementType;
  color: "accent" | "green" | "red" | "purple";
}) {
  const colorMap = {
    accent: "text-[var(--accent)] bg-[var(--accent)]/10 border-[var(--accent)]/20",
    green: "text-green-400 bg-green-500/10 border-green-500/20",
    red: "text-red-400 bg-red-500/10 border-red-500/20",
    purple: "text-purple-400 bg-purple-500/10 border-purple-500/20",
  };

  return (
    <div className="premium-card rounded-2xl p-4">
      <div className={`w-8 h-8 rounded-lg border flex items-center justify-center mb-3 ${colorMap[color]}`}>
        <Icon className="w-4 h-4" />
      </div>
      <p className="text-[10px] uppercase tracking-wider text-gray-500 font-semibold mb-1">{label}</p>
      <p className="text-base lg:text-lg font-bold text-foreground truncate">{value}</p>
    </div>
  );
}

// ─── Info Row ───
function InfoRow({
  label,
  value,
  mono,
  badge,
}: {
  label: string;
  value: string;
  mono?: boolean;
  badge?: string;
}) {
  const badgeColors: Record<string, string> = {
    NONE: "bg-gray-500/10 text-gray-400 border-gray-500/20",
    PENDING: "bg-amber-500/10 text-amber-400 border-amber-500/20",
    APPROVED: "bg-green-500/10 text-green-400 border-green-500/20",
    REJECTED: "bg-red-500/10 text-red-400 border-red-500/20",
  };

  return (
    <div className="flex items-start justify-between gap-2">
      <span className="text-[11px] text-gray-500">{label}</span>
      {badge ? (
        <span className={`text-[10px] px-2 py-0.5 rounded font-semibold border ${badgeColors[badge] || badgeColors.NONE}`}>
          {value === "NONE" ? "No KYC" : value}
        </span>
      ) : (
        <span className={`text-[11px] text-foreground text-right break-all ${mono ? "font-mono" : ""}`}>
          {value}
        </span>
      )}
    </div>
  );
}

// ─── Activity Row (Deposits/Withdrawals) ───
function ActivityRow({
  amount,
  currency,
  status,
  date,
  type,
}: {
  amount: number;
  currency: string;
  status: string;
  date: string;
  type: "deposit" | "withdrawal";
}) {
  const statusColors: Record<string, string> = {
    PENDING: "text-amber-400 bg-amber-500/10 border-amber-500/20",
    APPROVED: "text-green-400 bg-green-500/10 border-green-500/20",
    COMPLETED: "text-green-400 bg-green-500/10 border-green-500/20",
    REJECTED: "text-red-400 bg-red-500/10 border-red-500/20",
  };

  return (
    <div className="flex items-center justify-between p-3 rounded-lg bg-white/[0.02] border border-[var(--border)]">
      <div className="flex items-center gap-3">
        <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
          type === "deposit" ? "bg-green-500/10 text-green-400" : "bg-red-500/10 text-red-400"
        }`}>
          {type === "deposit" ? <Plus size={14} /> : <Minus size={14} />}
        </div>
        <div>
          <p className="text-xs font-semibold text-foreground">
            {type === "deposit" ? "+" : "-"}${amount.toFixed(2)} {currency}
          </p>
          <p className="text-[10px] text-gray-500 flex items-center gap-1">
            <Clock size={9} />
            {new Date(date).toLocaleDateString()}
          </p>
        </div>
      </div>
      <span className={`text-[10px] px-2 py-0.5 rounded font-semibold border ${statusColors[status] || statusColors.PENDING}`}>
        {status}
      </span>
    </div>
  );
}