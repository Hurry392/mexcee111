// src/app/admin/users/page.tsx
"use client";

import { useEffect, useState, useCallback } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  Users,
  Search,
  Filter,
  ChevronLeft,
  ChevronRight,
  Shield,
  Mail,
  Calendar,
  ArrowRight,
  X,
} from "lucide-react";
import { adminAPI } from "@/lib/api";

interface UserItem {
  id: string;
  uid: number;
  email: string;
  username: string | null;
  phone: string | null;
  country: string | null;
  balance: number;
  role: string;
  isActive: boolean;
  isVerified: boolean;
  kycStatus: string;
  referralCode: string;
  createdAt: string;
  lastLoginAt: string | null;
  _count: {
    deposits: number;
    withdrawals: number;
    trades: number;
    kycSubmissions: number;
  };
}

const KYC_COLORS: Record<string, string> = {
  NONE: "text-gray-500 bg-gray-500/10 border-gray-500/20",
  PENDING: "text-amber-400 bg-amber-500/10 border-amber-500/20",
  APPROVED: "text-green-400 bg-green-500/10 border-green-500/20",
  REJECTED: "text-red-400 bg-red-500/10 border-red-500/20",
};

export default function AdminUsersPage() {
  const [users, setUsers] = useState<UserItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchInput, setSearchInput] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [kycFilter, setKycFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [roleFilter, setRoleFilter] = useState("");
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [total, setTotal] = useState(0);

  const fetchUsers = useCallback(async () => {
    setLoading(true);
    try {
      const result = await adminAPI.listUsers({
        search: searchQuery,
        kyc: kycFilter,
        status: statusFilter,
        role: roleFilter,
        page,
        limit: 20,
      });

      if (result.users) {
        setUsers(result.users as UserItem[]);
        if (result.pagination) {
          setTotalPages(result.pagination.totalPages);
          setTotal(result.pagination.total);
        }
      }
    } catch (err) {
      console.error("Failed to fetch users:", err);
    } finally {
      setLoading(false);
    }
  }, [searchQuery, kycFilter, statusFilter, roleFilter, page]);

  useEffect(() => {
    fetchUsers();
  }, [fetchUsers]);

  // Debounced search
  useEffect(() => {
    const timer = setTimeout(() => {
      setSearchQuery(searchInput);
      setPage(1); // Reset to page 1 on new search
    }, 400);
    return () => clearTimeout(timer);
  }, [searchInput]);

  const clearFilters = () => {
    setSearchInput("");
    setSearchQuery("");
    setKycFilter("");
    setStatusFilter("");
    setRoleFilter("");
    setPage(1);
  };

  const hasActiveFilters = searchQuery || kycFilter || statusFilter || roleFilter;

  return (
    <div className="p-4 lg:p-8 max-w-7xl mx-auto">
      {/* ═══ Header ═══ */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6"
      >
        <div className="flex items-center gap-2 mb-2">
          <Users className="w-5 h-5 text-[var(--accent)]" />
          <span className="text-xs font-semibold uppercase tracking-wider text-[var(--accent)]">
            Management
          </span>
        </div>
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
          <div>
            <h1 className="text-2xl lg:text-3xl font-bold text-foreground mb-1">Users</h1>
            <p className="text-sm text-gray-500">
              {loading ? "Loading..." : `${total} total ${total === 1 ? "user" : "users"}`}
            </p>
          </div>
        </div>
      </motion.div>

      {/* ═══ Filters ═══ */}
      <div className="premium-card rounded-2xl p-4 mb-4">
        <div className="flex flex-col lg:flex-row gap-3">
          {/* Search */}
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
            <input
              type="text"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              placeholder="Search by UID, email, username, or referral code..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white/5 border border-white/10 text-foreground text-sm placeholder:text-gray-600 focus:border-[var(--accent)]/50 focus:bg-white/[0.07] outline-none transition-all"
            />
            {searchInput && (
              <button
                onClick={() => setSearchInput("")}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300"
              >
                <X size={16} />
              </button>
            )}
          </div>

          {/* Filter Selects */}
          <div className="grid grid-cols-3 lg:flex gap-2">
            <FilterSelect
              value={kycFilter}
              onChange={(v) => {
                setKycFilter(v);
                setPage(1);
              }}
              placeholder="KYC"
              options={[
                { value: "", label: "All KYC" },
                { value: "NONE", label: "No KYC" },
                { value: "PENDING", label: "Pending" },
                { value: "APPROVED", label: "Approved" },
                { value: "REJECTED", label: "Rejected" },
              ]}
            />
            <FilterSelect
              value={statusFilter}
              onChange={(v) => {
                setStatusFilter(v);
                setPage(1);
              }}
              placeholder="Status"
              options={[
                { value: "", label: "All Status" },
                { value: "active", label: "Active" },
                { value: "suspended", label: "Suspended" },
              ]}
            />
            <FilterSelect
              value={roleFilter}
              onChange={(v) => {
                setRoleFilter(v);
                setPage(1);
              }}
              placeholder="Role"
              options={[
                { value: "", label: "All Roles" },
                { value: "USER", label: "User" },
                { value: "ADMIN", label: "Admin" },
              ]}
            />
          </div>

          {hasActiveFilters && (
            <button
              onClick={clearFilters}
              className="flex items-center gap-1.5 px-3 py-2.5 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-xs font-semibold hover:bg-red-500/20 transition-all"
            >
              <X size={14} />
              <span>Clear</span>
            </button>
          )}
        </div>
      </div>

      {/* ═══ Users Table ═══ */}
      <div className="premium-card rounded-2xl overflow-hidden">
        {loading ? (
          <div className="p-4 space-y-2">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="skeleton h-16 rounded-xl" />
            ))}
          </div>
        ) : users.length === 0 ? (
          <div className="p-12 text-center">
            <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-white/[0.03] border border-[var(--border)] flex items-center justify-center">
              <Users className="w-8 h-8 text-gray-600" />
            </div>
            <p className="text-sm text-gray-400 font-medium">No users found</p>
            <p className="text-xs text-gray-500 mt-1">Try adjusting your filters</p>
          </div>
        ) : (
          <>
            {/* Desktop Table */}
            <div className="hidden lg:block overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-[var(--border)] bg-white/[0.02]">
                    <th className="text-left px-4 py-3 text-[10px] font-semibold text-gray-500 uppercase tracking-wider">User</th>
                    <th className="text-left px-4 py-3 text-[10px] font-semibold text-gray-500 uppercase tracking-wider">Balance</th>
                    <th className="text-left px-4 py-3 text-[10px] font-semibold text-gray-500 uppercase tracking-wider">KYC</th>
                    <th className="text-left px-4 py-3 text-[10px] font-semibold text-gray-500 uppercase tracking-wider">Role</th>
                    <th className="text-left px-4 py-3 text-[10px] font-semibold text-gray-500 uppercase tracking-wider">Status</th>
                    <th className="text-left px-4 py-3 text-[10px] font-semibold text-gray-500 uppercase tracking-wider">Activity</th>
                    <th className="text-left px-4 py-3 text-[10px] font-semibold text-gray-500 uppercase tracking-wider">Joined</th>
                    <th className="text-right px-4 py-3 text-[10px] font-semibold text-gray-500 uppercase tracking-wider"></th>
                  </tr>
                </thead>
                <tbody>
                  {users.map((user, idx) => (
                    <motion.tr
                      key={user.id}
                      initial={{ opacity: 0, y: 5 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: idx * 0.02 }}
                      className="border-b border-[var(--border)] hover:bg-white/[0.02] transition-all"
                    >
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center text-white text-xs font-bold shrink-0">
                            {user.email.charAt(0).toUpperCase()}
                          </div>
                          <div className="min-w-0">
                            <p className="text-xs font-semibold text-foreground truncate max-w-[180px]">
                              {user.username || user.email.split("@")[0]}
                            </p>
                            <p className="text-[10px] text-gray-500 truncate max-w-[180px]">{user.email}</p>
                            <p className="text-[10px] font-mono text-[var(--accent)]">UID: {user.uid}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <p className="text-sm font-bold text-foreground">
                          ${user.balance.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </p>
                      </td>
                      <td className="px-4 py-3">
                        <span className={`inline-flex px-2 py-1 rounded-md text-[10px] font-semibold border ${KYC_COLORS[user.kycStatus] || KYC_COLORS.NONE}`}>
                          {user.kycStatus === "NONE" ? "No KYC" : user.kycStatus}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        {user.role === "ADMIN" ? (
                          <span className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-[10px] font-semibold bg-blue-500/10 border border-blue-500/20 text-blue-400">
                            <Shield size={10} />
                            ADMIN
                          </span>
                        ) : (
                          <span className="text-[10px] text-gray-500 font-medium">User</span>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        {user.isActive ? (
                          <span className="inline-flex items-center gap-1.5 text-[10px] font-semibold text-green-400">
                            <span className="w-1.5 h-1.5 rounded-full bg-green-400" />
                            Active
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1.5 text-[10px] font-semibold text-red-400">
                            <span className="w-1.5 h-1.5 rounded-full bg-red-400" />
                            Suspended
                          </span>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex gap-1.5 text-[10px] text-gray-500">
                          <span title="Deposits">D:{user._count.deposits}</span>
                          <span>·</span>
                          <span title="Withdrawals">W:{user._count.withdrawals}</span>
                          <span>·</span>
                          <span title="Trades">T:{user._count.trades}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <p className="text-[10px] text-gray-500">
                          {new Date(user.createdAt).toLocaleDateString()}
                        </p>
                      </td>
                      <td className="px-4 py-3 text-right">
                        <Link href={`/admin/users/${user.id}`}>
                          <button className="p-1.5 rounded-lg bg-white/5 hover:bg-[var(--accent)]/10 text-gray-400 hover:text-[var(--accent)] transition-all">
                            <ArrowRight size={14} />
                          </button>
                        </Link>
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Mobile Cards */}
            <div className="lg:hidden divide-y divide-[var(--border)]">
              {users.map((user, idx) => (
                <motion.div
                  key={user.id}
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.02 }}
                >
                  <Link href={`/admin/users/${user.id}`}>
                    <div className="p-4 hover:bg-white/[0.02] transition-all">
                      <div className="flex items-start gap-3 mb-3">
                        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center text-white text-sm font-bold shrink-0">
                          {user.email.charAt(0).toUpperCase()}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <p className="text-sm font-semibold text-foreground truncate">
                              {user.username || user.email.split("@")[0]}
                            </p>
                            {user.role === "ADMIN" && (
                              <Shield className="w-3 h-3 text-blue-400 shrink-0" />
                            )}
                          </div>
                          <p className="text-[10px] text-gray-500 truncate flex items-center gap-1">
                            <Mail className="w-2.5 h-2.5" />
                            {user.email}
                          </p>
                          <p className="text-[10px] font-mono text-[var(--accent)]">UID: {user.uid}</p>
                        </div>
                        <div className="text-right shrink-0">
                          <p className="text-sm font-bold text-foreground">
                            ${user.balance.toFixed(2)}
                          </p>
                          <p className={`text-[10px] font-semibold ${user.isActive ? "text-green-400" : "text-red-400"}`}>
                            {user.isActive ? "Active" : "Suspended"}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center justify-between">
                        <span className={`inline-flex px-2 py-0.5 rounded text-[10px] font-semibold border ${KYC_COLORS[user.kycStatus] || KYC_COLORS.NONE}`}>
                          {user.kycStatus === "NONE" ? "No KYC" : user.kycStatus}
                        </span>
                        <div className="flex items-center gap-1 text-[10px] text-gray-500">
                          <Calendar className="w-2.5 h-2.5" />
                          {new Date(user.createdAt).toLocaleDateString()}
                        </div>
                      </div>
                    </div>
                  </Link>
                </motion.div>
              ))}
            </div>
          </>
        )}
      </div>

      {/* ═══ Pagination ═══ */}
      {!loading && totalPages > 1 && (
        <div className="flex items-center justify-between mt-4">
          <p className="text-xs text-gray-500">
            Page {page} of {totalPages}
          </p>
          <div className="flex gap-2">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page === 1}
              className="p-2 rounded-lg border border-[var(--border)] text-gray-400 hover:bg-white/5 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
            >
              <ChevronLeft size={16} />
            </button>
            <button
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page === totalPages}
              className="p-2 rounded-lg border border-[var(--border)] text-gray-400 hover:bg-white/5 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
            >
              <ChevronRight size={16} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Filter Select Component ───
function FilterSelect({
  value,
  onChange,
  placeholder,
  options,
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder: string;
  options: { value: string; label: string }[];
}) {
  return (
    <div className="relative">
      <Filter className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-500 pointer-events-none" />
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="pl-8 pr-8 py-2.5 rounded-xl bg-white/5 border border-white/10 text-foreground text-xs font-medium focus:border-[var(--accent)]/50 outline-none transition-all cursor-pointer appearance-none w-full lg:w-auto"
      >
        {options.map((opt) => (
          <option key={opt.value} value={opt.value} className="bg-[var(--background)]">
            {opt.label || placeholder}
          </option>
        ))}
      </select>
    </div>
  );
}