// src/app/admin/layout.tsx
"use client";

import { useState, useEffect } from "react";
import { usePathname } from "next/navigation";
import { useAdminThemeStore } from "@/store/themeStore"; // ✅ Admin theme store
import { useUIStore } from "@/store/uiStore";
import { useAdminAuth } from "@/hooks/useAdminAuth";
import AdminSidebar from "@/components/admin/AdminSidebar";
import AdminTopbar from "@/components/admin/AdminTopbar";

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const [mounted, setMounted] = useState(false);
  const pathname = usePathname();
  const { theme } = useAdminThemeStore(); // ✅ Admin theme only
  const { sidebarOpen } = useUIStore();

  const isLoginPage = pathname === "/admin/login";

  useAdminAuth();

  useEffect(() => {
    setMounted(true);
    document.documentElement.setAttribute("data-theme", theme);
  }, [theme]);

  useEffect(() => {
    if (sidebarOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [sidebarOpen]);

  if (!mounted) {
    return (
      <div className="flex items-center justify-center h-screen bg-[#030712]">
        <div className="flex flex-col items-center gap-4">
          <div className="relative w-12 h-12">
            <div className="absolute inset-0 rounded-full border-2 border-transparent border-t-blue-500 animate-spin" />
            <div
              className="absolute inset-1 rounded-full border-2 border-transparent border-b-purple-500 animate-spin"
              style={{ animationDirection: "reverse", animationDuration: "1.5s" }}
            />
          </div>
          <span className="text-sm text-gray-500 font-medium tracking-wider">LOADING ADMIN</span>
        </div>
      </div>
    );
  }

  if (isLoginPage) {
    return (
      <div className="min-h-screen bg-background text-foreground transition-colors duration-300">
        {children}
      </div>
    );
  }

  return (
    <div className="flex h-screen overflow-hidden bg-background text-foreground transition-colors duration-300">
      <AdminSidebar />
      <div className="flex-1 flex flex-col h-screen overflow-hidden relative">
        <AdminTopbar />
        <main className="flex-1 overflow-y-auto scrollbar-thin">{children}</main>
      </div>
    </div>
  );
}