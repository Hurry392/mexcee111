// src/app/admin/kyc/page.tsx
"use client";

import { useEffect, useState, useCallback } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  ShieldCheck,
  Search,
  ChevronLeft,
  ChevronRight,
  X,
  Eye,
  CheckCircle2,
  XCircle,
  Clock,
  Filter,
  Mail,
  IdCard,
  Car,
  BookUser,
  Globe,
} from "lucide-react";
import { adminAPI } from "@/lib/api";
import KYCReviewModal from "@/components/admin/KYCReviewModal";

interface KYCItem {
  id: string;
  documentType: string;
  documentFrontUrl: string;
  documentBackUrl: string | null;
  selfieUrl: string | null;
  fullName: string;
  dateOfBirth: string | null;
  documentNumber: string | null;
  status: string;
  rejectionReason: string | null;
  createdAt: string;
  reviewedAt: string | null;
  user: {
    id: string;
    email: string;
    username: string | null;
    country: string | null;
    kycStatus: string;
    balance: number;
    createdAt: string;
  };
}

const STATUS_COLORS: Record<string, string> = {
  PENDING: "text-amber-400 bg-amber-500/10 border-amber-500/20",
  APPROVED: "text-green-400 bg-green-500/10 border-green-500/20",
  REJECTED: "text-red-400 bg-red-500/10 border-red-500/20",
};

const DOC_META: Record<string, { label: string; icon: typeof IdCard; color: string }> = {
  NATIONAL_ID: { label: "National ID", icon: IdCard, color: "text-blue-400" },
  DRIVING_LICENSE: { label: "Driving License", icon: Car, color: "text-green-400" },
  PASSPORT: { label: "Passport", icon: BookUser, color: "text-purple-400" },
};

export default function AdminKYCPage() {
  const [submissions, setSubmissions] = useState<KYCItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchInput, setSearchInput] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("PENDING");
  const [docTypeFilter, setDocTypeFilter] = useState("");
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [total, setTotal] = useState(0);
  const [pendingCount, setPendingCount] = useState(0);

  // Modal state
  const [reviewOpen, setReviewOpen] = useState(false);
  const [selectedSubmission, setSelectedSubmission] = useState<KYCItem | null>(null);

  const fetchSubmissions = useCallback(async () => {
    setLoading(true);
    try {
      const result = await adminAPI.listKyc({
        status: statusFilter,
        documentType: docTypeFilter,
        search: searchQuery,
        page,
        limit: 20,
      });

      if (result.submissions) {
        setSubmissions(result.submissions as KYCItem[]);
        if (result.pagination) {
          setTotalPages(result.pagination.totalPages);
          setTotal(result.pagination.total);
        }
        if (typeof result.pendingCount === "number") {
          setPendingCount(result.pendingCount);
        }
      }
    } catch (err) {
      console.error("Failed to fetch KYC submissions:", err);
    } finally {
      setLoading(false);
    }
  }, [statusFilter, docTypeFilter, searchQuery, page]);

  useEffect(() => {
    fetchSubmissions();
  }, [fetchSubmissions]);

  useEffect(() => {
    const timer = setTimeout(() => {
      setSearchQuery(searchInput);
      setPage(1);
    }, 400);
    return () => clearTimeout(timer);
  }, [searchInput]);

  const openReview = (submission: KYCItem) => {
    setSelectedSubmission(submission);
    setReviewOpen(true);
  };

  const handleReviewSuccess = () => {
    fetchSubmissions();
  };

  const hasFilters = searchQuery || statusFilter !== "PENDING" || docTypeFilter;

  return (
    <div className="p-4 lg:p-8 max-w-7xl mx-auto">
      {/* ═══ Header ═══ */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6"
      >
        <div className="flex items-center gap-2 mb-2">
          <ShieldCheck className="w-5 h-5 text-[var(--accent)]" />
          <span className="text-xs font-semibold uppercase tracking-wider text-[var(--accent)]">
            Management
          </span>
        </div>
        <div>
          <h1 className="text-2xl lg:text-3xl font-bold text-foreground mb-1">KYC Review</h1>
          <p className="text-sm text-gray-500">
            {loading ? "Loading..." : `${total} ${statusFilter.toLowerCase() || "all"} submissions`}
            {pendingCount > 0 && (
              <span className="ml-2 inline-flex items-center gap-1 text-amber-400 font-semibold">
                • <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" /> {pendingCount} pending review
              </span>
            )}
          </p>
        </div>
      </motion.div>

      {/* ═══ Filters ═══ */}
      <div className="premium-card rounded-2xl p-4 mb-4">
        <div className="flex flex-col lg:flex-row gap-3">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
            <input
              type="text"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              placeholder="Search by name, email, or document number..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white/5 border border-white/10 text-foreground text-sm placeholder:text-gray-600 focus:border-[var(--accent)]/50 focus:bg-white/[0.07] outline-none transition-all"
            />
            {searchInput && (
              <button
                onClick={() => setSearchInput("")}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300"
              >
                <X size={16} />
              </button>
            )}
          </div>

          <div className="grid grid-cols-2 lg:flex gap-2">
            <FilterSelect
              value={statusFilter}
              onChange={(v) => {
                setStatusFilter(v);
                setPage(1);
              }}
              options={[
                { value: "", label: "All Status" },
                { value: "PENDING", label: "Pending" },
                { value: "APPROVED", label: "Approved" },
                { value: "REJECTED", label: "Rejected" },
              ]}
            />
            <FilterSelect
              value={docTypeFilter}
              onChange={(v) => {
                setDocTypeFilter(v);
                setPage(1);
              }}
              options={[
                { value: "", label: "All Documents" },
                { value: "NATIONAL_ID", label: "National ID" },
                { value: "DRIVING_LICENSE", label: "Driving License" },
                { value: "PASSPORT", label: "Passport" },
              ]}
            />
          </div>

          {hasFilters && (
            <button
              onClick={() => {
                setSearchInput("");
                setStatusFilter("PENDING");
                setDocTypeFilter("");
                setPage(1);
              }}
              className="flex items-center gap-1.5 px-3 py-2.5 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-xs font-semibold hover:bg-red-500/20 transition-all"
            >
              <X size={14} />
              <span>Reset</span>
            </button>
          )}
        </div>
      </div>

      {/* ═══ Submissions Grid ═══ */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="skeleton h-48 rounded-2xl" />
          ))}
        </div>
      ) : submissions.length === 0 ? (
        <div className="premium-card rounded-2xl p-12 text-center">
          <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-white/[0.03] border border-[var(--border)] flex items-center justify-center">
            <ShieldCheck className="w-8 h-8 text-gray-600" />
          </div>
          <p className="text-sm text-gray-400 font-medium">No KYC submissions found</p>
          <p className="text-xs text-gray-500 mt-1">
            {statusFilter === "PENDING" ? "All caught up! No pending KYCs." : "Try adjusting filters"}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {submissions.map((submission, idx) => {
            const docMeta = DOC_META[submission.documentType] || DOC_META.NATIONAL_ID;
            const DocIcon = docMeta.icon;

            return (
              <motion.div
                key={submission.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.03 }}
                className="premium-card rounded-2xl overflow-hidden"
              >
                {/* Preview thumbnail */}
                <div className="relative h-32 bg-black/40 overflow-hidden">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={submission.documentFrontUrl}
                    alt="Document preview"
                    className="w-full h-full object-cover"
                    style={{ filter: "blur(4px)" }}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
                  <div className="absolute top-2 right-2">
                    <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-md text-[10px] font-semibold border backdrop-blur-sm ${STATUS_COLORS[submission.status]}`}>
                      {submission.status === "PENDING" && <Clock size={10} />}
                      {submission.status === "APPROVED" && <CheckCircle2 size={10} />}
                      {submission.status === "REJECTED" && <XCircle size={10} />}
                      {submission.status}
                    </span>
                  </div>
                  <div className="absolute top-2 left-2">
                    <div className="w-8 h-8 rounded-lg bg-black/60 backdrop-blur-sm border border-white/10 flex items-center justify-center">
                      <DocIcon className={`w-4 h-4 ${docMeta.color}`} />
                    </div>
                  </div>
                </div>

                {/* Content */}
                <div className="p-4">
                  {/* Name + Doc type */}
                  <div className="mb-3">
                    <p className="text-sm font-bold text-foreground truncate">
                      {submission.fullName}
                    </p>
                    <p className="text-[10px] text-gray-500">
                      {docMeta.label}
                    </p>
                  </div>

                  {/* User info */}
                  <div className="space-y-1.5 mb-4">
                    <Link
                      href={`/admin/users/${submission.user.id}`}
                      className="flex items-center gap-1.5 text-[11px] text-gray-400 hover:text-[var(--accent)] transition-colors truncate"
                    >
                      <Mail className="w-2.5 h-2.5 shrink-0" />
                      <span className="truncate">{submission.user.email}</span>
                    </Link>
                    {submission.user.country && (
                      <div className="flex items-center gap-1.5 text-[11px] text-gray-500">
                        <Globe className="w-2.5 h-2.5 shrink-0" />
                        <span>{submission.user.country}</span>
                      </div>
                    )}
                    <div className="flex items-center gap-1.5 text-[11px] text-gray-500">
                      <Clock className="w-2.5 h-2.5 shrink-0" />
                      <span>{new Date(submission.createdAt).toLocaleDateString()}</span>
                    </div>
                  </div>

                  {/* Action button */}
                  <button
                    onClick={() => openReview(submission)}
                    className={`w-full flex items-center justify-center gap-2 py-2.5 rounded-xl font-semibold text-xs transition-all ${
                      submission.status === "PENDING"
                        ? "bg-gradient-to-r from-[var(--accent)] to-purple-500 text-white shadow-lg shadow-[var(--accent)]/20 hover:shadow-[var(--accent)]/40"
                        : "bg-white/5 border border-[var(--border)] text-gray-400 hover:bg-white/10"
                    }`}
                  >
                    <Eye size={14} />
                    <span>
                      {submission.status === "PENDING" ? "Review Submission" : "View Details"}
                    </span>
                  </button>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}

      {/* ═══ Pagination ═══ */}
      {!loading && totalPages > 1 && (
        <div className="flex items-center justify-between mt-6">
          <p className="text-xs text-gray-500">
            Page {page} of {totalPages}
          </p>
          <div className="flex gap-2">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page === 1}
              className="p-2 rounded-lg border border-[var(--border)] text-gray-400 hover:bg-white/5 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
            >
              <ChevronLeft size={16} />
            </button>
            <button
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page === totalPages}
              className="p-2 rounded-lg border border-[var(--border)] text-gray-400 hover:bg-white/5 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
            >
              <ChevronRight size={16} />
            </button>
          </div>
        </div>
      )}

      {/* ═══ Review Modal ═══ */}
      {selectedSubmission && (
        <KYCReviewModal
          isOpen={reviewOpen}
          onClose={() => {
            setReviewOpen(false);
            setSelectedSubmission(null);
          }}
          submission={selectedSubmission}
          onSuccess={handleReviewSuccess}
        />
      )}
    </div>
  );
}

// ─── Filter Select ───
function FilterSelect({
  value,
  onChange,
  options,
}: {
  value: string;
  onChange: (v: string) => void;
  options: { value: string; label: string }[];
}) {
  return (
    <div className="relative">
      <Filter className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-500 pointer-events-none" />
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="pl-8 pr-8 py-2.5 rounded-xl bg-white/5 border border-white/10 text-foreground text-xs font-medium focus:border-[var(--accent)]/50 outline-none cursor-pointer appearance-none w-full lg:w-auto"
      >
        {options.map((opt) => (
          <option key={opt.value} value={opt.value} className="bg-[var(--background)]">
            {opt.label}
          </option>
        ))}
      </select>
    </div>
  );
}