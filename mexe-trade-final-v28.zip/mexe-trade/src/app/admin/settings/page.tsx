// src/app/admin/settings/page.tsx
"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import {
  Settings as SettingsIcon,
  Wallet,
  ArrowDownToLine,
  ArrowUpFromLine,
  Users,
  Save,
  AlertCircle,
  CheckCircle2,
  Info,
  Lock,
  Eye,
  EyeOff,
} from "lucide-react";

interface SettingsState {
  trc20WalletAddress: string;
  minDeposit: string;
  maxDeposit: string;
  minWithdrawal: string;
  maxWithdrawal: string;
  dailyWithdrawalLimit: string;
  referralBonusPercent: string;
  referralBonusEnabled: string;
}

const DEFAULTS: SettingsState = {
  trc20WalletAddress: "",
  minDeposit: "10",
  maxDeposit: "100000",
  minWithdrawal: "0",
  maxWithdrawal: "50000",
  dailyWithdrawalLimit: "10000",
  referralBonusPercent: "5",
  referralBonusEnabled: "true",
};

export default function AdminSettingsPage() {
  const [settings, setSettings] = useState<SettingsState>(DEFAULTS);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  // ─── Password change state ───
  const [pwForm, setPwForm] = useState({ current: "", next: "", confirm: "" });
  const [pwChanging, setPwChanging] = useState(false);
  const [pwError, setPwError] = useState("");
  const [pwSuccess, setPwSuccess] = useState("");
  const [showPw, setShowPw] = useState({ current: false, next: false, confirm: false });

  const fetchSettings = async () => {
    setLoading(true);
    try {
      const response = await fetch("/api/admin/settings", {
        credentials: "include",
      });
      const data = await response.json();

      if (data.settings) {
        setSettings({
          trc20WalletAddress: data.settings.trc20WalletAddress || "",
          minDeposit: data.settings.minDeposit || DEFAULTS.minDeposit,
          maxDeposit: data.settings.maxDeposit || DEFAULTS.maxDeposit,
          minWithdrawal: data.settings.minWithdrawal || DEFAULTS.minWithdrawal,
          maxWithdrawal: data.settings.maxWithdrawal || DEFAULTS.maxWithdrawal,
          dailyWithdrawalLimit: data.settings.dailyWithdrawalLimit || DEFAULTS.dailyWithdrawalLimit,
          referralBonusPercent: data.settings.referralBonusPercent || DEFAULTS.referralBonusPercent,
          referralBonusEnabled: data.settings.referralBonusEnabled || DEFAULTS.referralBonusEnabled,
        });
      }
    } catch (err) {
      console.error("Failed to load settings:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSettings();
  }, []);

  const handleSave = async () => {
    setError("");
    setSuccess("");

    // Basic validation
    if (!settings.trc20WalletAddress.trim()) {
      setError("TRC20 wallet address is required");
      return;
    }

    setSaving(true);

    try {
      const response = await fetch("/api/admin/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ settings }),
      });

      const data = await response.json();

      if (!response.ok) {
        setError(data.error || "Failed to save settings");
        setSaving(false);
        return;
      }

      setSuccess("Settings updated successfully!");
      setSaving(false);
      setTimeout(() => setSuccess(""), 3000);
    } catch (err) {
      console.error(err);
      setError("Network error");
      setSaving(false);
    }
  };

  const updateField = (key: keyof SettingsState, value: string) => {
    setSettings((prev) => ({ ...prev, [key]: value }));
  };

  const handleChangePassword = async () => {
    setPwError("");
    setPwSuccess("");

    if (!pwForm.current || !pwForm.next || !pwForm.confirm) {
      setPwError("All three password fields are required.");
      return;
    }
    if (pwForm.next !== pwForm.confirm) {
      setPwError("New password and confirm password do not match.");
      return;
    }
    if (pwForm.current === pwForm.next) {
      setPwError("New password must be different from your current password.");
      return;
    }

    setPwChanging(true);
    try {
      const res = await fetch("/api/admin/change-password", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          currentPassword: pwForm.current,
          newPassword: pwForm.next,
          confirmPassword: pwForm.confirm,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setPwError(data.error || "Failed to change password.");
      } else {
        setPwSuccess("Password changed successfully!");
        setPwForm({ current: "", next: "", confirm: "" });
        setTimeout(() => setPwSuccess(""), 4000);
      }
    } catch {
      setPwError("Network error. Please try again.");
    } finally {
      setPwChanging(false);
    }
  };

  if (loading) {
    return (
      <div className="p-4 lg:p-8 max-w-4xl mx-auto">
        <div className="skeleton h-8 w-64 mb-6 rounded" />
        <div className="space-y-4">
          <div className="skeleton h-64 rounded-2xl" />
          <div className="skeleton h-64 rounded-2xl" />
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-8 max-w-4xl mx-auto">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6"
      >
        <div className="flex items-center gap-2 mb-2">
          <SettingsIcon className="w-5 h-5 text-[var(--accent)]" />
          <span className="text-xs font-semibold uppercase tracking-wider text-[var(--accent)]">
            Configuration
          </span>
        </div>
        <h1 className="text-2xl lg:text-3xl font-bold text-foreground mb-1">
          Platform Settings
        </h1>
        <p className="text-sm text-gray-500">
          Configure deposit addresses, limits, and referral bonuses
        </p>
      </motion.div>

      {/* Info Banner */}
      <div className="p-4 rounded-xl bg-blue-500/10 border border-blue-500/20 mb-6 flex items-start gap-3">
        <Info className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
        <div>
          <p className="text-xs font-semibold text-blue-400 mb-1">
            Changes apply immediately
          </p>
          <p className="text-[11px] text-blue-300/70 leading-relaxed">
            Users will see the new settings on their next page load. Deposit address changes only affect NEW deposits.
          </p>
        </div>
      </div>

      {/* Wallet Address Section */}
      <div className="premium-card rounded-2xl p-5 mb-4">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center">
            <Wallet className="w-5 h-5 text-blue-400" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-foreground">Deposit Wallet</h3>
            <p className="text-[11px] text-gray-500">TRC20 (USDT) address for user deposits</p>
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-gray-400 mb-2 uppercase tracking-wider">
            TRC20 Wallet Address <span className="text-red-400 normal-case">*</span>
          </label>
          <input
            type="text"
            value={settings.trc20WalletAddress}
            onChange={(e) => updateField("trc20WalletAddress", e.target.value)}
            placeholder="TXxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
            className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-foreground text-sm font-mono placeholder:text-gray-600 focus:border-[var(--accent)]/50 outline-none transition-all"
          />
          <p className="text-[10px] text-gray-500 mt-2">
            This address is shown to users on the deposit page. Make sure it&apos;s a valid TRC20 (TRON) address.
          </p>
        </div>
      </div>

      {/* Deposit Limits */}
      <div className="premium-card rounded-2xl p-5 mb-4">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-green-500/10 border border-green-500/20 flex items-center justify-center">
            <ArrowDownToLine className="w-5 h-5 text-green-400" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-foreground">Deposit Limits</h3>
            <p className="text-[11px] text-gray-500">Minimum and maximum deposit amounts (USD)</p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <NumberField
            label="Min Deposit"
            value={settings.minDeposit}
            onChange={(v) => updateField("minDeposit", v)}
          />
          <NumberField
            label="Max Deposit"
            value={settings.maxDeposit}
            onChange={(v) => updateField("maxDeposit", v)}
          />
        </div>
      </div>

      {/* Withdrawal Limits */}
      <div className="premium-card rounded-2xl p-5 mb-4">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-red-500/10 border border-red-500/20 flex items-center justify-center">
            <ArrowUpFromLine className="w-5 h-5 text-red-400" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-foreground">Withdrawal Limits</h3>
            <p className="text-[11px] text-gray-500">Per-transaction and daily withdrawal caps (USD)</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <NumberField
            label="Min Withdrawal"
            value={settings.minWithdrawal}
            onChange={(v) => updateField("minWithdrawal", v)}
          />
          <NumberField
            label="Max Withdrawal"
            value={settings.maxWithdrawal}
            onChange={(v) => updateField("maxWithdrawal", v)}
          />
          <NumberField
            label="Daily Limit"
            value={settings.dailyWithdrawalLimit}
            onChange={(v) => updateField("dailyWithdrawalLimit", v)}
          />
        </div>
      </div>

      {/* Referral Bonus */}
      <div className="premium-card rounded-2xl p-5 mb-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center">
            <Users className="w-5 h-5 text-purple-400" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-foreground">Referral Program</h3>
            <p className="text-[11px] text-gray-500">Bonus percentage on referred users&apos; deposits</p>
          </div>
        </div>

        <div className="space-y-4">
          {/* Enable toggle */}
          <div className="flex items-center justify-between p-3 rounded-lg bg-white/[0.02] border border-[var(--border)]">
            <div>
              <p className="text-sm font-semibold text-foreground">Enable Referral Bonus</p>
              <p className="text-[11px] text-gray-500 mt-0.5">Users earn bonus when their referrals deposit</p>
            </div>
            <button
              onClick={() => updateField("referralBonusEnabled", settings.referralBonusEnabled === "true" ? "false" : "true")}
              className={`relative w-12 h-6 rounded-full transition-colors ${
                settings.referralBonusEnabled === "true" ? "bg-[var(--accent)]" : "bg-white/10"
              }`}
            >
              <div
                className={`absolute top-0.5 w-5 h-5 rounded-full bg-white transition-transform ${
                  settings.referralBonusEnabled === "true" ? "translate-x-6" : "translate-x-0.5"
                }`}
              />
            </button>
          </div>

          <NumberField
            label="Bonus Percentage (%)"
            value={settings.referralBonusPercent}
            onChange={(v) => updateField("referralBonusPercent", v)}
            suffix="%"
            disabled={settings.referralBonusEnabled !== "true"}
          />
        </div>
      </div>

      {/* Security — Change Password */}
      <div className="premium-card rounded-2xl p-5 mb-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-orange-500/10 border border-orange-500/20 flex items-center justify-center">
            <Lock className="w-5 h-5 text-orange-400" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-foreground">Admin Password</h3>
            <p className="text-[11px] text-gray-500">Change the password for this admin account</p>
          </div>
        </div>

        <div className="space-y-3">
          <PasswordField
            label="Current Password"
            value={pwForm.current}
            show={showPw.current}
            onChange={(v) => setPwForm((f) => ({ ...f, current: v }))}
            onToggleShow={() => setShowPw((s) => ({ ...s, current: !s.current }))}
          />
          <PasswordField
            label="New Password"
            value={pwForm.next}
            show={showPw.next}
            onChange={(v) => setPwForm((f) => ({ ...f, next: v }))}
            onToggleShow={() => setShowPw((s) => ({ ...s, next: !s.next }))}
            hint="8+ characters with uppercase, lowercase, and a number"
          />
          <PasswordField
            label="Confirm New Password"
            value={pwForm.confirm}
            show={showPw.confirm}
            onChange={(v) => setPwForm((f) => ({ ...f, confirm: v }))}
            onToggleShow={() => setShowPw((s) => ({ ...s, confirm: !s.confirm }))}
          />
        </div>

        {pwError && (
          <motion.div
            initial={{ opacity: 0, y: -5 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-start gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/20 mt-4"
          >
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
            <p className="text-xs text-red-400">{pwError}</p>
          </motion.div>
        )}

        {pwSuccess && (
          <motion.div
            initial={{ opacity: 0, y: -5 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-start gap-2 p-3 rounded-lg bg-green-500/10 border border-green-500/20 mt-4"
          >
            <CheckCircle2 className="w-4 h-4 text-green-400 shrink-0 mt-0.5" />
            <p className="text-xs text-green-400">{pwSuccess}</p>
          </motion.div>
        )}

        <button
          onClick={handleChangePassword}
          disabled={pwChanging}
          className="mt-4 w-full py-3 rounded-xl bg-orange-500/10 border border-orange-500/20 text-orange-400 font-semibold text-sm hover:bg-orange-500/20 disabled:opacity-50 transition-all flex items-center justify-center gap-2"
        >
          {pwChanging ? (
            <>
              <div className="w-4 h-4 border-2 border-orange-400/30 border-t-orange-400 rounded-full animate-spin" />
              <span>Changing Password…</span>
            </>
          ) : (
            <>
              <Lock size={16} />
              <span>Change Password</span>
            </>
          )}
        </button>
      </div>

      {/* Error/Success */}
      {error && (
        <motion.div
          initial={{ opacity: 0, y: -5 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-start gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/20 mb-4"
        >
          <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
          <p className="text-xs text-red-400">{error}</p>
        </motion.div>
      )}

      {success && (
        <motion.div
          initial={{ opacity: 0, y: -5 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-start gap-2 p-3 rounded-lg bg-green-500/10 border border-green-500/20 mb-4"
        >
          <CheckCircle2 className="w-4 h-4 text-green-400 shrink-0 mt-0.5" />
          <p className="text-xs text-green-400">{success}</p>
        </motion.div>
      )}

      {/* Save button */}
      <div className="sticky bottom-4">
        <button
          onClick={handleSave}
          disabled={saving}
          className="w-full py-3 rounded-xl bg-gradient-to-r from-[var(--accent)] to-purple-500 text-white font-bold text-sm shadow-lg shadow-[var(--accent)]/20 disabled:opacity-50 transition-all flex items-center justify-center gap-2"
        >
          {saving ? (
            <>
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              <span>Saving...</span>
            </>
          ) : (
            <>
              <Save size={16} />
              <span>Save All Settings</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
}

// Password Field
function PasswordField({
  label,
  value,
  show,
  onChange,
  onToggleShow,
  hint,
}: {
  label: string;
  value: string;
  show: boolean;
  onChange: (v: string) => void;
  onToggleShow: () => void;
  hint?: string;
}) {
  return (
    <div>
      <label className="block text-xs font-semibold text-gray-400 mb-2 uppercase tracking-wider">
        {label}
      </label>
      <div className="relative">
        <input
          type={show ? "text" : "password"}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          autoComplete="new-password"
          className="w-full pl-4 pr-10 py-3 rounded-xl bg-white/5 border border-white/10 text-foreground text-sm focus:border-[var(--accent)]/50 outline-none transition-all"
        />
        <button
          type="button"
          onClick={onToggleShow}
          tabIndex={-1}
          className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300 transition-colors"
        >
          {show ? <EyeOff size={16} /> : <Eye size={16} />}
        </button>
      </div>
      {hint && (
        <p className="text-[10px] text-gray-500 mt-1.5">{hint}</p>
      )}
    </div>
  );
}

// Number Field
function NumberField({
  label,
  value,
  onChange,
  suffix,
  disabled,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  suffix?: string;
  disabled?: boolean;
}) {
  return (
    <div>
      <label className="block text-xs font-semibold text-gray-400 mb-2 uppercase tracking-wider">
        {label}
      </label>
      <div className="relative">
        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm">
          {suffix ? "" : "$"}
        </span>
        <input
          type="number"
          step="any"
          min="0"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          disabled={disabled}
          className={`w-full ${suffix ? "pl-4 pr-8" : "pl-8 pr-4"} py-3 rounded-xl bg-white/5 border border-white/10 text-foreground text-sm font-mono focus:border-[var(--accent)]/50 outline-none transition-all disabled:opacity-50`}
        />
        {suffix && (
          <span className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm">
            {suffix}
          </span>
        )}
      </div>
    </div>
  );
}