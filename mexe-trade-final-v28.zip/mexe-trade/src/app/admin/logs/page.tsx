// src/app/admin/logs/page.tsx
"use client";

import { useEffect, useState, useCallback } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  ScrollText,
  Search,
  ChevronLeft,
  ChevronRight,
  X,
  Filter,
  Clock,
  User as UserIcon,
  DollarSign,
  ArrowDownToLine,
  ArrowUpFromLine,
  ShieldCheck,
  MessageSquare,
  Settings as SettingsIcon,
  Activity,
  ChevronDown,
  ChevronUp,
} from "lucide-react";

interface AuditLog {
  id: string;
  adminId: string;
  adminEmail: string;
  action: string;
  category: string;
  targetUserId: string | null;
  targetId: string | null;
  note: string | null;
  amount: number | null;
  metadata: string | null;
  parsedMetadata: Record<string, unknown> | null;
  createdAt: string;
  targetUser: {
    id: string;
    email: string;
    username: string | null;
  } | null;
}

const CATEGORY_META: Record<string, { icon: React.ElementType; color: string; label: string }> = {
  DEPOSIT: { icon: ArrowDownToLine, color: "text-green-400 bg-green-500/10 border-green-500/20", label: "Deposit" },
  WITHDRAWAL: { icon: ArrowUpFromLine, color: "text-red-400 bg-red-500/10 border-red-500/20", label: "Withdrawal" },
  KYC: { icon: ShieldCheck, color: "text-purple-400 bg-purple-500/10 border-purple-500/20", label: "KYC" },
  BALANCE: { icon: DollarSign, color: "text-[var(--accent)] bg-[var(--accent)]/10 border-[var(--accent)]/20", label: "Balance" },
  USER: { icon: UserIcon, color: "text-blue-400 bg-blue-500/10 border-blue-500/20", label: "User" },
  CHAT: { icon: MessageSquare, color: "text-cyan-400 bg-cyan-500/10 border-cyan-500/20", label: "Chat" },
  SETTINGS: { icon: SettingsIcon, color: "text-amber-400 bg-amber-500/10 border-amber-500/20", label: "Settings" },
  GENERAL: { icon: Activity, color: "text-gray-400 bg-gray-500/10 border-gray-500/20", label: "General" },
};

const ACTION_LABELS: Record<string, string> = {
  APPROVE_DEPOSIT: "Approved Deposit",
  REJECT_DEPOSIT: "Rejected Deposit",
  APPROVE_WITHDRAWAL: "Approved Withdrawal",
  REJECT_WITHDRAWAL: "Rejected Withdrawal",
  COMPLETE_WITHDRAWAL: "Completed Withdrawal",
  APPROVE_KYC: "Approved KYC",
  REJECT_KYC: "Rejected KYC",
  ADD_BALANCE: "Added Balance",
  DEDUCT_BALANCE: "Deducted Balance",
  SUSPEND_USER: "Suspended User",
  ACTIVATE_USER: "Activated User",
  PROMOTE_TO_ADMIN: "Promoted to Admin",
  DEMOTE_ADMIN: "Demoted Admin",
  DELETE_USER: "Deleted User",
  CHAT_REPLY: "Sent Chat Reply",
  UPDATE_SETTINGS: "Updated Settings",
  FORCE_CLOSE_TRADE: "Force Closed Trade",
};

export default function AdminLogsPage() {
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchInput, setSearchInput] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("");
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [total, setTotal] = useState(0);
  const [categoryCounts, setCategoryCounts] = useState<Record<string, number>>({});
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const fetchLogs = useCallback(async () => {
    setLoading(true);
    try {
      const query = new URLSearchParams();
      if (categoryFilter) query.set("category", categoryFilter);
      if (searchQuery) query.set("search", searchQuery);
      query.set("page", String(page));
      query.set("limit", "30");

      const response = await fetch(`/api/admin/logs?${query}`, {
        credentials: "include",
      });
      const data = await response.json();

      if (data.logs) {
        setLogs(data.logs);
        if (data.pagination) {
          setTotalPages(data.pagination.totalPages);
          setTotal(data.pagination.total);
        }
        if (data.categoryCounts) {
          setCategoryCounts(data.categoryCounts);
        }
      }
    } catch (err) {
      console.error("Failed to fetch logs:", err);
    } finally {
      setLoading(false);
    }
  }, [categoryFilter, searchQuery, page]);

  useEffect(() => {
    fetchLogs();
  }, [fetchLogs]);

  useEffect(() => {
    const timer = setTimeout(() => {
      setSearchQuery(searchInput);
      setPage(1);
    }, 400);
    return () => clearTimeout(timer);
  }, [searchInput]);

  const hasFilters = searchQuery || categoryFilter;
  const totalActions = Object.values(categoryCounts).reduce((sum, c) => sum + c, 0);

  return (
    <div className="p-4 lg:p-8 max-w-7xl mx-auto">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6"
      >
        <div className="flex items-center gap-2 mb-2">
          <ScrollText className="w-5 h-5 text-[var(--accent)]" />
          <span className="text-xs font-semibold uppercase tracking-wider text-[var(--accent)]">
            Compliance
          </span>
        </div>
        <div>
          <h1 className="text-2xl lg:text-3xl font-bold text-foreground mb-1">Audit Logs</h1>
          <p className="text-sm text-gray-500">
            {loading ? "Loading..." : `${total} of ${totalActions} total admin actions logged`}
          </p>
        </div>
      </motion.div>

      {/* Category Stats */}
      {totalActions > 0 && (
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2 mb-4">
          {Object.entries(CATEGORY_META).map(([key, meta]) => {
            const count = categoryCounts[key] || 0;
            const Icon = meta.icon;
            const isActive = categoryFilter === key;

            return (
              <button
                key={key}
                onClick={() => {
                  setCategoryFilter(isActive ? "" : key);
                  setPage(1);
                }}
                className={`premium-card rounded-xl p-3 transition-all ${
                  isActive ? "ring-2 ring-[var(--accent)]" : ""
                }`}
              >
                <div className={`w-7 h-7 rounded-lg border flex items-center justify-center mb-2 ${meta.color}`}>
                  <Icon className="w-3.5 h-3.5" />
                </div>
                <p className="text-[10px] text-gray-500 font-semibold uppercase tracking-wider text-left">
                  {meta.label}
                </p>
                <p className="text-sm font-bold text-foreground text-left">{count}</p>
              </button>
            );
          })}
        </div>
      )}

      {/* Filters */}
      <div className="premium-card rounded-2xl p-4 mb-4">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
            <input
              type="text"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              placeholder="Search by action, admin email, or note..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white/5 border border-white/10 text-foreground text-sm placeholder:text-gray-600 focus:border-[var(--accent)]/50 outline-none transition-all"
            />
            {searchInput && (
              <button
                onClick={() => setSearchInput("")}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300"
              >
                <X size={16} />
              </button>
            )}
          </div>

          <div className="relative">
            <Filter className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-500 pointer-events-none" />
            <select
              value={categoryFilter}
              onChange={(e) => {
                setCategoryFilter(e.target.value);
                setPage(1);
              }}
              className="pl-8 pr-8 py-2.5 rounded-xl bg-white/5 border border-white/10 text-foreground text-xs font-medium focus:border-[var(--accent)]/50 outline-none cursor-pointer appearance-none w-full sm:w-auto"
            >
              <option value="" className="bg-[var(--background)]">All Categories</option>
              {Object.entries(CATEGORY_META).map(([key, meta]) => (
                <option key={key} value={key} className="bg-[var(--background)]">
                  {meta.label}
                </option>
              ))}
            </select>
          </div>

          {hasFilters && (
            <button
              onClick={() => {
                setSearchInput("");
                setCategoryFilter("");
                setPage(1);
              }}
              className="flex items-center gap-1.5 px-3 py-2.5 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-xs font-semibold hover:bg-red-500/20 transition-all"
            >
              <X size={14} />
              <span>Reset</span>
            </button>
          )}
        </div>
      </div>

      {/* Logs List */}
      <div className="premium-card rounded-2xl overflow-hidden">
        {loading ? (
          <div className="p-4 space-y-2">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="skeleton h-16 rounded-xl" />
            ))}
          </div>
        ) : logs.length === 0 ? (
          <div className="p-12 text-center">
            <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-white/[0.03] border border-[var(--border)] flex items-center justify-center">
              <ScrollText className="w-8 h-8 text-gray-600" />
            </div>
            <p className="text-sm text-gray-400 font-medium">No audit logs found</p>
            <p className="text-xs text-gray-500 mt-1">
              {hasFilters ? "Try adjusting filters" : "Admin actions will appear here"}
            </p>
          </div>
        ) : (
          <div className="divide-y divide-[var(--border)]">
            {logs.map((log, idx) => {
              const meta = CATEGORY_META[log.category] || CATEGORY_META.GENERAL;
              const Icon = meta.icon;
              const isExpanded = expandedId === log.id;
              const actionLabel = ACTION_LABELS[log.action] || log.action;

              return (
                <motion.div
                  key={log.id}
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.02 }}
                  className="hover:bg-white/[0.02] transition-all"
                >
                  <button
                    onClick={() => setExpandedId(isExpanded ? null : log.id)}
                    className="w-full flex items-start gap-3 p-4 text-left"
                  >
                    <div className={`w-9 h-9 rounded-lg border flex items-center justify-center shrink-0 ${meta.color}`}>
                      <Icon className="w-4 h-4" />
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2 mb-1">
                        <span className="text-sm font-bold text-foreground">
                          {actionLabel}
                        </span>
                        {log.amount !== null && log.amount !== 0 && (
                          <span className={`text-xs font-bold ${
                            log.amount > 0 ? "text-green-400" : "text-red-400"
                          }`}>
                            {log.amount > 0 ? "+" : ""}${Math.abs(log.amount).toFixed(2)}
                          </span>
                        )}
                        <span className={`text-[10px] px-1.5 py-0.5 rounded font-semibold ${meta.color}`}>
                          {meta.label}
                        </span>
                      </div>

                      <div className="flex flex-wrap gap-3 text-[11px] text-gray-500">
                        <span className="flex items-center gap-1">
                          <UserIcon size={10} />
                          {log.adminEmail}
                        </span>
                        {log.targetUser && (
                          <>
                            <span>→</span>
                            <Link
                              href={`/admin/users/${log.targetUser.id}`}
                              onClick={(e) => e.stopPropagation()}
                              className="text-[var(--accent)] hover:underline flex items-center gap-1"
                            >
                              <UserIcon size={10} />
                              {log.targetUser.email}
                            </Link>
                          </>
                        )}
                        <span className="flex items-center gap-1">
                          <Clock size={10} />
                          {formatDateTime(log.createdAt)}
                        </span>
                      </div>

                      {log.note && !isExpanded && (
                        <p className="text-[11px] text-gray-400 mt-1.5 truncate italic">
                          &quot;{log.note}&quot;
                        </p>
                      )}
                    </div>

                    <div className="shrink-0">
                      {isExpanded ? (
                        <ChevronUp size={16} className="text-gray-500" />
                      ) : (
                        <ChevronDown size={16} className="text-gray-500" />
                      )}
                    </div>
                  </button>

                  {/* Expanded Details */}
                  {isExpanded && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      className="overflow-hidden"
                    >
                      <div className="px-4 pb-4 pl-16 space-y-3 border-t border-[var(--border)] pt-3">
                        {log.note && (
                          <div>
                            <p className="text-[10px] uppercase tracking-wider text-gray-500 font-semibold mb-1">
                              Note
                            </p>
                            <p className="text-xs text-foreground p-2.5 rounded-lg bg-white/[0.02] border border-[var(--border)]">
                              {log.note}
                            </p>
                          </div>
                        )}

                        {log.parsedMetadata && Object.keys(log.parsedMetadata).length > 0 && (
                          <div>
                            <p className="text-[10px] uppercase tracking-wider text-gray-500 font-semibold mb-1">
                              Metadata
                            </p>
                            <div className="p-2.5 rounded-lg bg-white/[0.02] border border-[var(--border)] space-y-1">
                              {Object.entries(log.parsedMetadata).map(([key, value]) => (
                                <div key={key} className="flex items-start justify-between gap-2 text-[11px]">
                                  <span className="text-gray-500 capitalize">{formatKey(key)}:</span>
                                  <span className="text-foreground font-mono text-right break-all max-w-[60%]">
                                    {formatValue(value)}
                                  </span>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        <div className="grid grid-cols-2 gap-2 text-[10px] text-gray-500">
                          <div>
                            <span className="uppercase font-semibold">Log ID:</span>{" "}
                            <span className="font-mono">{log.id.slice(0, 12)}...</span>
                          </div>
                          <div>
                            <span className="uppercase font-semibold">Admin ID:</span>{" "}
                            <span className="font-mono">{log.adminId.slice(0, 12)}...</span>
                          </div>
                          {log.targetId && (
                            <div className="col-span-2">
                              <span className="uppercase font-semibold">Target ID:</span>{" "}
                              <span className="font-mono">{log.targetId}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </motion.div>
                  )}
                </motion.div>
              );
            })}
          </div>
        )}
      </div>

      {/* Pagination */}
      {!loading && totalPages > 1 && (
        <div className="flex items-center justify-between mt-4">
          <p className="text-xs text-gray-500">Page {page} of {totalPages}</p>
          <div className="flex gap-2">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page === 1}
              className="p-2 rounded-lg border border-[var(--border)] text-gray-400 hover:bg-white/5 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
            >
              <ChevronLeft size={16} />
            </button>
            <button
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page === totalPages}
              className="p-2 rounded-lg border border-[var(--border)] text-gray-400 hover:bg-white/5 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
            >
              <ChevronRight size={16} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// Helpers
function formatDateTime(dateStr: string): string {
  const date = new Date(dateStr);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);

  if (diffMins < 1) return "just now";
  if (diffMins < 60) return `${diffMins}m ago`;
  if (diffHours < 24) return `${diffHours}h ago`;
  if (diffDays < 7) return `${diffDays}d ago`;
  return date.toLocaleString();
}

function formatKey(key: string): string {
  return key.replace(/([A-Z])/g, " $1").replace(/^./, (str) => str.toUpperCase());
}

function formatValue(value: unknown): string {
  if (value === null || value === undefined) return "-";
  if (typeof value === "number") return value.toString();
  if (typeof value === "boolean") return value ? "Yes" : "No";
  if (typeof value === "string") {
    return value.length > 50 ? value.slice(0, 50) + "..." : value;
  }
  return JSON.stringify(value);
}