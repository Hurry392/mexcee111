// src/app/admin/withdrawals/page.tsx
"use client";

import { useEffect, useState, useCallback } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  ArrowUpFromLine,
  Search,
  ChevronLeft,
  ChevronRight,
  X,
  CheckCircle2,
  XCircle,
  Clock,
  Filter,
  Mail,
  Send,
} from "lucide-react";
import { adminAPI } from "@/lib/api";
import ApprovalModal, { ApprovalAction } from "@/components/admin/ApprovalModal";
import WithdrawalDetailsCard from "@/components/admin/WithdrawalDetailsCard";

interface WithdrawalItem {
  id: string;
  amount: number;
  currency: string;
  network: string;
  method: string;
  walletAddress: string | null;
  bankAccountId: string | null;
  status: string;
  adminNote: string | null;
  txId: string | null;
  createdAt: string;
  processedAt: string | null;
  user: {
    id: string;
    email: string;
    username: string | null;
    balance: number;
    kycStatus: string;
    country: string | null;
  };
}

const STATUS_COLORS: Record<string, string> = {
  PENDING: "text-amber-400 bg-amber-500/10 border-amber-500/20",
  APPROVED: "text-blue-400 bg-blue-500/10 border-blue-500/20",
  COMPLETED: "text-green-400 bg-green-500/10 border-green-500/20",
  REJECTED: "text-red-400 bg-red-500/10 border-red-500/20",
};

export default function AdminWithdrawalsPage() {
  const [withdrawals, setWithdrawals] = useState<WithdrawalItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchInput, setSearchInput] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("PENDING");
  const [methodFilter, setMethodFilter] = useState("");
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [total, setTotal] = useState(0);
  const [pendingCount, setPendingCount] = useState(0);

  // Modal state
  const [approvalOpen, setApprovalOpen] = useState(false);
  const [approvalAction, setApprovalAction] = useState<ApprovalAction>("APPROVE");
  const [selectedWithdrawal, setSelectedWithdrawal] = useState<WithdrawalItem | null>(null);
  const [modalLoading, setModalLoading] = useState(false);
  const [modalError, setModalError] = useState("");

  const fetchWithdrawals = useCallback(async () => {
    setLoading(true);
    try {
      const result = await adminAPI.listWithdrawals({
        status: statusFilter,
        method: methodFilter,
        search: searchQuery,
        page,
        limit: 20,
      });

      if (result.withdrawals) {
        setWithdrawals(result.withdrawals as WithdrawalItem[]);
        if (result.pagination) {
          setTotalPages(result.pagination.totalPages);
          setTotal(result.pagination.total);
        }
        if (typeof result.pendingCount === "number") {
          setPendingCount(result.pendingCount);
        }
      }
    } catch (err) {
      console.error("Failed to fetch withdrawals:", err);
    } finally {
      setLoading(false);
    }
  }, [statusFilter, methodFilter, searchQuery, page]);

  useEffect(() => {
    fetchWithdrawals();
  }, [fetchWithdrawals]);

  useEffect(() => {
    const timer = setTimeout(() => {
      setSearchQuery(searchInput);
      setPage(1);
    }, 400);
    return () => clearTimeout(timer);
  }, [searchInput]);

  const openApproval = (withdrawal: WithdrawalItem, action: ApprovalAction) => {
    setSelectedWithdrawal(withdrawal);
    setApprovalAction(action);
    setModalError("");
    setApprovalOpen(true);
  };

  const handleApprovalConfirm = async ({ note, txId }: { note: string; txId?: string }) => {
    if (!selectedWithdrawal) return;

    setModalLoading(true);
    setModalError("");

    try {
      const result = await adminAPI.processWithdrawal(selectedWithdrawal.id, {
        action: approvalAction,
        note,
        txId,
      });

      if (result.error) {
        setModalError(result.error);
        setModalLoading(false);
        return;
      }

      setApprovalOpen(false);
      setSelectedWithdrawal(null);
      setModalLoading(false);
      fetchWithdrawals();
    } catch (err) {
      console.error(err);
      setModalError("Network error. Please try again.");
      setModalLoading(false);
    }
  };

  const hasFilters = searchQuery || statusFilter !== "PENDING" || methodFilter;

  return (
    <div className="p-4 lg:p-8 max-w-7xl mx-auto">
      {/* ═══ Header ═══ */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6"
      >
        <div className="flex items-center gap-2 mb-2">
          <ArrowUpFromLine className="w-5 h-5 text-[var(--accent)]" />
          <span className="text-xs font-semibold uppercase tracking-wider text-[var(--accent)]">
            Management
          </span>
        </div>
        <div>
          <h1 className="text-2xl lg:text-3xl font-bold text-foreground mb-1">Withdrawals</h1>
          <p className="text-sm text-gray-500">
            {loading ? "Loading..." : `${total} ${statusFilter.toLowerCase() || "all"} withdrawals`}
            {pendingCount > 0 && (
              <span className="ml-2 inline-flex items-center gap-1 text-amber-400 font-semibold">
                • <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" /> {pendingCount} pending
              </span>
            )}
          </p>
        </div>
      </motion.div>

      {/* ═══ Filters ═══ */}
      <div className="premium-card rounded-2xl p-4 mb-4">
        <div className="flex flex-col lg:flex-row gap-3">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
            <input
              type="text"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              placeholder="Search by email or username..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white/5 border border-white/10 text-foreground text-sm placeholder:text-gray-600 focus:border-[var(--accent)]/50 focus:bg-white/[0.07] outline-none transition-all"
            />
            {searchInput && (
              <button
                onClick={() => setSearchInput("")}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300"
              >
                <X size={16} />
              </button>
            )}
          </div>

          <div className="grid grid-cols-2 lg:flex gap-2">
            <FilterSelect
              value={statusFilter}
              onChange={(v) => {
                setStatusFilter(v);
                setPage(1);
              }}
              options={[
                { value: "", label: "All Status" },
                { value: "PENDING", label: "Pending" },
                { value: "APPROVED", label: "Approved" },
                { value: "COMPLETED", label: "Completed" },
                { value: "REJECTED", label: "Rejected" },
              ]}
            />
            <FilterSelect
              value={methodFilter}
              onChange={(v) => {
                setMethodFilter(v);
                setPage(1);
              }}
              options={[
                { value: "", label: "All Methods" },
                { value: "CRYPTO", label: "Crypto" },
                { value: "BANK", label: "Bank" },
                { value: "UPI", label: "UPI" },
                { value: "PAYPAL", label: "PayPal" },
              ]}
            />
          </div>

          {hasFilters && (
            <button
              onClick={() => {
                setSearchInput("");
                setStatusFilter("PENDING");
                setMethodFilter("");
                setPage(1);
              }}
              className="flex items-center gap-1.5 px-3 py-2.5 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-xs font-semibold hover:bg-red-500/20 transition-all"
            >
              <X size={14} />
              <span>Reset</span>
            </button>
          )}
        </div>
      </div>

      {/* ═══ Withdrawals List ═══ */}
      <div className="premium-card rounded-2xl overflow-hidden">
        {loading ? (
          <div className="p-4 space-y-2">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="skeleton h-32 rounded-xl" />
            ))}
          </div>
        ) : withdrawals.length === 0 ? (
          <div className="p-12 text-center">
            <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-white/[0.03] border border-[var(--border)] flex items-center justify-center">
              <ArrowUpFromLine className="w-8 h-8 text-gray-600" />
            </div>
            <p className="text-sm text-gray-400 font-medium">No withdrawals found</p>
            <p className="text-xs text-gray-500 mt-1">
              {statusFilter === "PENDING" ? "All caught up! No pending withdrawals." : "Try adjusting filters"}
            </p>
          </div>
        ) : (
          <div className="divide-y divide-[var(--border)]">
            {withdrawals.map((withdrawal, idx) => (
              <motion.div
                key={withdrawal.id}
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.03 }}
                className="p-4 hover:bg-white/[0.02] transition-all"
              >
                {/* Top Row: User + Amount + Status + Actions */}
                <div className="flex flex-col lg:flex-row lg:items-center gap-4 mb-3">
                  <div className="flex items-center gap-3 flex-1 min-w-0">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-red-500 to-rose-500 flex items-center justify-center text-white text-xs font-bold shrink-0">
                      {withdrawal.user.email.charAt(0).toUpperCase()}
                    </div>
                    <div className="flex-1 min-w-0">
                      <Link
                        href={`/admin/users/${withdrawal.user.id}`}
                        className="text-sm font-semibold text-foreground hover:text-[var(--accent)] transition-colors truncate block"
                      >
                        {withdrawal.user.username || withdrawal.user.email.split("@")[0]}
                      </Link>
                      <p className="text-[11px] text-gray-500 flex items-center gap-1 truncate">
                        <Mail className="w-2.5 h-2.5 shrink-0" />
                        {withdrawal.user.email}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    <div>
                      <p className="text-[10px] uppercase tracking-wider text-gray-500 font-semibold">Amount</p>
                      <p className="text-lg font-bold text-red-400">
                        -${withdrawal.amount.toFixed(2)}
                      </p>
                    </div>
                    <div>
                      <p className="text-[10px] uppercase tracking-wider text-gray-500 font-semibold">Balance</p>
                      <p className="text-xs font-bold text-foreground">
                        ${withdrawal.user.balance.toFixed(2)}
                      </p>
                    </div>
                  </div>

                  <div>
                    <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-md text-[10px] font-semibold border ${STATUS_COLORS[withdrawal.status]}`}>
                      {withdrawal.status === "PENDING" && <Clock size={10} />}
                      {withdrawal.status === "APPROVED" && <CheckCircle2 size={10} />}
                      {withdrawal.status === "COMPLETED" && <CheckCircle2 size={10} />}
                      {withdrawal.status === "REJECTED" && <XCircle size={10} />}
                      {withdrawal.status}
                    </span>
                    <p className="text-[10px] text-gray-500 mt-1">
                      {new Date(withdrawal.createdAt).toLocaleDateString()}
                    </p>
                  </div>

                  {/* Actions */}
                  <div className="flex flex-wrap items-center gap-2">
                    {withdrawal.status === "PENDING" && (
                      <>
                        <button
                          onClick={() => openApproval(withdrawal, "APPROVE")}
                          className="px-3 py-2 rounded-lg bg-green-500/10 border border-green-500/20 text-green-400 hover:bg-green-500/20 text-xs font-semibold flex items-center gap-1.5 transition-all"
                        >
                          <CheckCircle2 size={12} />
                          <span className="hidden sm:inline">Approve</span>
                        </button>
                        <button
                          onClick={() => openApproval(withdrawal, "REJECT")}
                          className="px-3 py-2 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 hover:bg-red-500/20 text-xs font-semibold flex items-center gap-1.5 transition-all"
                        >
                          <XCircle size={12} />
                          <span className="hidden sm:inline">Reject</span>
                        </button>
                      </>
                    )}

                    {withdrawal.status === "APPROVED" && (
                      <>
                        <button
                          onClick={() => openApproval(withdrawal, "COMPLETE")}
                          className="px-3 py-2 rounded-lg bg-blue-500/10 border border-blue-500/20 text-blue-400 hover:bg-blue-500/20 text-xs font-semibold flex items-center gap-1.5 transition-all"
                        >
                          <Send size={12} />
                          <span className="hidden sm:inline">Mark Complete</span>
                        </button>
                        <button
                          onClick={() => openApproval(withdrawal, "REJECT")}
                          className="px-3 py-2 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 hover:bg-red-500/20 text-xs font-semibold flex items-center gap-1.5 transition-all"
                        >
                          <XCircle size={12} />
                          <span className="hidden sm:inline">Reject</span>
                        </button>
                      </>
                    )}
                  </div>
                </div>

                {/* Withdrawal Details Card */}
                <WithdrawalDetailsCard
                  method={withdrawal.method}
                  network={withdrawal.network}
                  walletAddress={withdrawal.walletAddress}
                />

                {/* Admin Note + TxID */}
                {(withdrawal.adminNote || withdrawal.txId) && (
                  <div className="mt-3 flex flex-col gap-2">
                    {withdrawal.txId && (
                      <div className="flex items-center gap-2 p-2 rounded-lg bg-white/[0.02] border border-[var(--border)]">
                        <span className="text-[10px] uppercase tracking-wider text-gray-500 font-semibold shrink-0">
                          TxID:
                        </span>
                        <span className="text-[11px] font-mono text-gray-300 break-all">
                          {withdrawal.txId}
                        </span>
                      </div>
                    )}
                    {withdrawal.adminNote && (
                      <div className="p-2 rounded-lg bg-white/[0.02] border border-[var(--border)]">
                        <p className="text-[10px] uppercase tracking-wider text-gray-500 font-semibold mb-0.5">
                          Admin Note
                        </p>
                        <p className="text-[11px] text-gray-300">{withdrawal.adminNote}</p>
                      </div>
                    )}
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        )}
      </div>

      {/* ═══ Pagination ═══ */}
      {!loading && totalPages > 1 && (
        <div className="flex items-center justify-between mt-4">
          <p className="text-xs text-gray-500">
            Page {page} of {totalPages}
          </p>
          <div className="flex gap-2">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page === 1}
              className="p-2 rounded-lg border border-[var(--border)] text-gray-400 hover:bg-white/5 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
            >
              <ChevronLeft size={16} />
            </button>
            <button
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page === totalPages}
              className="p-2 rounded-lg border border-[var(--border)] text-gray-400 hover:bg-white/5 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
            >
              <ChevronRight size={16} />
            </button>
          </div>
        </div>
      )}

      {/* ═══ Approval Modal ═══ */}
      {selectedWithdrawal && (
        <ApprovalModal
          isOpen={approvalOpen}
          onClose={() => {
            setApprovalOpen(false);
            setSelectedWithdrawal(null);
          }}
          action={approvalAction}
          type="withdrawal"
          amount={selectedWithdrawal.amount}
          currency={selectedWithdrawal.currency}
          userEmail={selectedWithdrawal.user.email}
          loading={modalLoading}
          error={modalError}
          onConfirm={handleApprovalConfirm}
        />
      )}
    </div>
  );
}

// ─── Filter Select ───
function FilterSelect({
  value,
  onChange,
  options,
}: {
  value: string;
  onChange: (v: string) => void;
  options: { value: string; label: string }[];
}) {
  return (
    <div className="relative">
      <Filter className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-500 pointer-events-none" />
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="pl-8 pr-8 py-2.5 rounded-xl bg-white/5 border border-white/10 text-foreground text-xs font-medium focus:border-[var(--accent)]/50 outline-none cursor-pointer appearance-none w-full lg:w-auto"
      >
        {options.map((opt) => (
          <option key={opt.value} value={opt.value} className="bg-[var(--background)]">
            {opt.label}
          </option>
        ))}
      </select>
    </div>
  );
}