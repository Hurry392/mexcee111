// src/app/admin/dashboard/page.tsx
"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  Users,
  ArrowDownToLine,
  ArrowUpFromLine,
  ShieldCheck,
  MessageSquare,
  TrendingUp,
  DollarSign,
  Wallet,
  UserCheck,
  Activity,
  ArrowRight,
  Clock,
  Mail,
} from "lucide-react";

interface DashboardStats {
  users: { total: number; active: number; verified: number };
  pending: { kyc: number; deposits: number; withdrawals: number; messages: number };
  financial: { totalDeposits: number; totalWithdrawals: number; totalBalance: number };
  trades: { open: number; total: number };
}

interface RecentUser {
  id: string;
  email: string;
  username: string | null;
  kycStatus: string;
  balance: number;
  createdAt: string;
}

interface RecentDeposit {
  id: string;
  amount: number;
  currency: string;
  createdAt: string;
  user: { email: string; username: string | null };
}

export default function AdminDashboardPage() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [recentUsers, setRecentUsers] = useState<RecentUser[]>([]);
  const [recentDeposits, setRecentDeposits] = useState<RecentDeposit[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const response = await fetch("/api/admin/stats", {
          credentials: "include",
        });
        const data = await response.json();

        if (data.success) {
          setStats(data.stats);
          setRecentUsers(data.recentUsers || []);
          setRecentDeposits(data.recentDeposits || []);
        }
      } catch (err) {
        console.error("Failed to fetch stats:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
    // Auto-refresh every 30 seconds
    const interval = setInterval(fetchStats, 30000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="p-4 lg:p-8 max-w-7xl mx-auto">
      {/* ═══ Header ═══ */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <div className="flex items-center gap-2 mb-2">
          <Activity className="w-5 h-5 text-[var(--accent)]" />
          <span className="text-xs font-semibold uppercase tracking-wider text-[var(--accent)]">
            Overview
          </span>
        </div>
        <h1 className="text-2xl lg:text-3xl font-bold text-foreground mb-1">
          Admin Dashboard
        </h1>
        <p className="text-sm text-gray-500">
          Real-time overview of platform activity and pending actions
        </p>
      </motion.div>

      {/* ═══ Alert Cards (Pending Items) ═══ */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4 mb-6">
        <AlertCard
          title="Pending KYC"
          count={stats?.pending.kyc || 0}
          icon={ShieldCheck}
          color="amber"
          href="/admin/kyc"
          loading={loading}
        />
        <AlertCard
          title="Pending Deposits"
          count={stats?.pending.deposits || 0}
          icon={ArrowDownToLine}
          color="blue"
          href="/admin/deposits"
          loading={loading}
        />
        <AlertCard
          title="Pending Withdrawals"
          count={stats?.pending.withdrawals || 0}
          icon={ArrowUpFromLine}
          color="purple"
          href="/admin/withdrawals"
          loading={loading}
        />
        <AlertCard
          title="Unread Messages"
          count={stats?.pending.messages || 0}
          icon={MessageSquare}
          color="green"
          href="/admin/chat"
          loading={loading}
        />
      </div>

      {/* ═══ Main Stats Grid ═══ */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
        {/* Users Card */}
        <StatCard
          title="Users"
          icon={Users}
          loading={loading}
          items={[
            { label: "Total Users", value: stats?.users.total || 0, color: "text-white" },
            { label: "Active", value: stats?.users.active || 0, color: "text-green-400" },
            { label: "KYC Verified", value: stats?.users.verified || 0, color: "text-blue-400" },
          ]}
        />

        {/* Financial Card */}
        <StatCard
          title="Financial (Virtual)"
          icon={DollarSign}
          loading={loading}
          items={[
            {
              label: "Total Balance",
              value: `$${(stats?.financial.totalBalance || 0).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
              color: "text-[var(--accent)]",
            },
            {
              label: "Total Deposits",
              value: `$${(stats?.financial.totalDeposits || 0).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
              color: "text-green-400",
            },
            {
              label: "Total Withdrawals",
              value: `$${(stats?.financial.totalWithdrawals || 0).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
              color: "text-red-400",
            },
          ]}
        />

        {/* Trades Card */}
        <StatCard
          title="Trading Activity"
          icon={TrendingUp}
          loading={loading}
          items={[
            { label: "Open Positions", value: stats?.trades.open || 0, color: "text-green-400" },
            { label: "Total Trades", value: stats?.trades.total || 0, color: "text-white" },
            { label: "Closed Trades", value: (stats?.trades.total || 0) - (stats?.trades.open || 0), color: "text-gray-400" },
          ]}
        />
      </div>

      {/* ═══ Recent Activity ═══ */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Recent Users */}
        <div className="premium-card rounded-2xl p-5">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <UserCheck className="w-4 h-4 text-[var(--accent)]" />
              <h3 className="text-sm font-bold text-foreground">Recent Users</h3>
            </div>
            <Link href="/admin/users" className="text-xs text-[var(--accent)] hover:underline flex items-center gap-1">
              View All <ArrowRight className="w-3 h-3" />
            </Link>
          </div>

          {loading ? (
            <div className="space-y-2">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="skeleton h-14 rounded-lg" />
              ))}
            </div>
          ) : recentUsers.length === 0 ? (
            <p className="text-xs text-gray-500 text-center py-8">No users yet</p>
          ) : (
            <div className="space-y-2">
              {recentUsers.map((user) => (
                <Link key={user.id} href={`/admin/users`}>
                  <div className="flex items-center gap-3 p-2.5 rounded-lg hover:bg-white/[0.03] transition-all cursor-pointer">
                    <div className="w-9 h-9 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center text-white text-xs font-bold shrink-0">
                      {user.email.charAt(0).toUpperCase()}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium text-foreground truncate">
                        {user.username || user.email.split("@")[0]}
                      </p>
                      <p className="text-[10px] text-gray-500 truncate">{user.email}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-xs font-bold text-foreground">${user.balance.toFixed(2)}</p>
                      <p className={`text-[10px] font-medium ${
                        user.kycStatus === "APPROVED" ? "text-green-400" :
                        user.kycStatus === "PENDING" ? "text-amber-400" :
                        user.kycStatus === "REJECTED" ? "text-red-400" :
                        "text-gray-500"
                      }`}>
                        {user.kycStatus === "NONE" ? "No KYC" : user.kycStatus}
                      </p>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>

        {/* Recent Pending Deposits */}
        <div className="premium-card rounded-2xl p-5">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-amber-400" />
              <h3 className="text-sm font-bold text-foreground">Pending Deposits</h3>
            </div>
            <Link href="/admin/deposits" className="text-xs text-[var(--accent)] hover:underline flex items-center gap-1">
              Review All <ArrowRight className="w-3 h-3" />
            </Link>
          </div>

          {loading ? (
            <div className="space-y-2">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="skeleton h-14 rounded-lg" />
              ))}
            </div>
          ) : recentDeposits.length === 0 ? (
            <div className="text-center py-8">
              <ArrowDownToLine className="w-8 h-8 text-gray-600 mx-auto mb-2" />
              <p className="text-xs text-gray-500">No pending deposits</p>
            </div>
          ) : (
            <div className="space-y-2">
              {recentDeposits.map((deposit) => (
                <Link key={deposit.id} href="/admin/deposits">
                  <div className="flex items-center gap-3 p-2.5 rounded-lg hover:bg-white/[0.03] transition-all cursor-pointer">
                    <div className="w-9 h-9 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center shrink-0">
                      <ArrowDownToLine className="w-4 h-4 text-amber-400" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium text-foreground truncate">
                        {deposit.user.username || deposit.user.email.split("@")[0]}
                      </p>
                      <p className="text-[10px] text-gray-500 truncate flex items-center gap-1">
                        <Mail className="w-2.5 h-2.5" />
                        {deposit.user.email}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-xs font-bold text-green-400">
                        +${deposit.amount.toFixed(2)}
                      </p>
                      <p className="text-[10px] text-gray-500">{deposit.currency}</p>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── Alert Card Component ───
function AlertCard({
  title,
  count,
  icon: Icon,
  color,
  href,
  loading,
}: {
  title: string;
  count: number;
  icon: React.ElementType;
  color: "amber" | "blue" | "purple" | "green";
  href: string;
  loading: boolean;
}) {
  const colorMap = {
    amber: "text-amber-400 bg-amber-500/10 border-amber-500/20",
    blue: "text-blue-400 bg-blue-500/10 border-blue-500/20",
    purple: "text-purple-400 bg-purple-500/10 border-purple-500/20",
    green: "text-green-400 bg-green-500/10 border-green-500/20",
  };

  return (
    <Link href={href}>
      <motion.div
        whileHover={{ y: -2 }}
        className="premium-card rounded-2xl p-4 cursor-pointer group"
      >
        <div className="flex items-center justify-between mb-3">
          <div className={`w-10 h-10 rounded-xl flex items-center justify-center border ${colorMap[color]}`}>
            <Icon className="w-5 h-5" />
          </div>
          {count > 0 && !loading && (
            <span className="w-6 h-6 rounded-full bg-red-500 text-white text-[10px] font-bold flex items-center justify-center animate-pulse">
              {count > 9 ? "9+" : count}
            </span>
          )}
        </div>
        <p className="text-[11px] text-gray-500 uppercase tracking-wider font-semibold mb-1">
          {title}
        </p>
        {loading ? (
          <div className="skeleton h-6 w-12 rounded" />
        ) : (
          <p className="text-xl lg:text-2xl font-bold text-foreground">{count}</p>
        )}
      </motion.div>
    </Link>
  );
}

// ─── Stat Card Component ───
function StatCard({
  title,
  icon: Icon,
  items,
  loading,
}: {
  title: string;
  icon: React.ElementType;
  items: { label: string; value: string | number; color: string }[];
  loading: boolean;
}) {
  return (
    <div className="premium-card rounded-2xl p-5">
      <div className="flex items-center gap-2 mb-4">
        <Icon className="w-4 h-4 text-[var(--accent)]" />
        <h3 className="text-sm font-bold text-foreground">{title}</h3>
      </div>

      <div className="space-y-3">
        {items.map((item, i) => (
          <div key={i} className="flex items-center justify-between">
            <span className="text-xs text-gray-500">{item.label}</span>
            {loading ? (
              <div className="skeleton h-4 w-16 rounded" />
            ) : (
              <span className={`text-sm font-bold ${item.color}`}>{item.value}</span>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}