// src/app/admin/deposits/page.tsx
"use client";

import { useEffect, useState, useCallback } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  ArrowDownToLine,
  Search,
  ChevronLeft,
  ChevronRight,
  X,
  Eye,
  CheckCircle2,
  XCircle,
  Clock,
  Filter,
  Mail,
  Hash,
  Image as ImageIcon,
} from "lucide-react";
import { adminAPI } from "@/lib/api";
import ScreenshotViewer from "@/components/admin/ScreenshotViewer";
import ApprovalModal, { ApprovalAction } from "@/components/admin/ApprovalModal";

interface DepositItem {
  id: string;
  amount: number;
  currency: string;
  network: string;
  method: string;
  txId: string | null;
  screenshotUrl: string | null;
  status: string;
  adminNote: string | null;
  createdAt: string;
  processedAt: string | null;
  user: {
    id: string;
    email: string;
    username: string | null;
    balance: number;
    kycStatus: string;
    country: string | null;
  };
}

const STATUS_COLORS: Record<string, string> = {
  PENDING: "text-amber-400 bg-amber-500/10 border-amber-500/20",
  APPROVED: "text-green-400 bg-green-500/10 border-green-500/20",
  REJECTED: "text-red-400 bg-red-500/10 border-red-500/20",
};

export default function AdminDepositsPage() {
  const [deposits, setDeposits] = useState<DepositItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchInput, setSearchInput] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("PENDING"); // Default to pending
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [total, setTotal] = useState(0);
  const [pendingCount, setPendingCount] = useState(0);

  // Modal states
  const [screenshotOpen, setScreenshotOpen] = useState(false);
  const [currentScreenshot, setCurrentScreenshot] = useState("");
  const [approvalOpen, setApprovalOpen] = useState(false);
  const [approvalAction, setApprovalAction] = useState<ApprovalAction>("APPROVE");
  const [selectedDeposit, setSelectedDeposit] = useState<DepositItem | null>(null);
  const [modalLoading, setModalLoading] = useState(false);
  const [modalError, setModalError] = useState("");

  const fetchDeposits = useCallback(async () => {
    setLoading(true);
    try {
      const result = await adminAPI.listDeposits({
        status: statusFilter,
        search: searchQuery,
        page,
        limit: 20,
      });

      if (result.deposits) {
        setDeposits(result.deposits as DepositItem[]);
        if (result.pagination) {
          setTotalPages(result.pagination.totalPages);
          setTotal(result.pagination.total);
        }
        if (typeof result.pendingCount === "number") {
          setPendingCount(result.pendingCount);
        }
      }
    } catch (err) {
      console.error("Failed to fetch deposits:", err);
    } finally {
      setLoading(false);
    }
  }, [statusFilter, searchQuery, page]);

  useEffect(() => {
    fetchDeposits();
  }, [fetchDeposits]);

  // Debounced search
  useEffect(() => {
    const timer = setTimeout(() => {
      setSearchQuery(searchInput);
      setPage(1);
    }, 400);
    return () => clearTimeout(timer);
  }, [searchInput]);

  const openScreenshot = (url: string) => {
    setCurrentScreenshot(url);
    setScreenshotOpen(true);
  };

  const openApproval = (deposit: DepositItem, action: ApprovalAction) => {
    setSelectedDeposit(deposit);
    setApprovalAction(action);
    setModalError("");
    setApprovalOpen(true);
  };

  const handleApprovalConfirm = async ({ note }: { note: string }) => {
    if (!selectedDeposit) return;

    setModalLoading(true);
    setModalError("");

    try {
      const result = await adminAPI.processDeposit(selectedDeposit.id, {
        action: approvalAction as "APPROVE" | "REJECT",
        note,
      });

      if (result.error) {
        setModalError(result.error);
        setModalLoading(false);
        return;
      }

      // Success — close modal, refresh list
      setApprovalOpen(false);
      setSelectedDeposit(null);
      setModalLoading(false);
      fetchDeposits();
    } catch (err) {
      console.error(err);
      setModalError("Network error. Please try again.");
      setModalLoading(false);
    }
  };

  const hasFilters = searchQuery || statusFilter !== "PENDING";

  return (
    <div className="p-4 lg:p-8 max-w-7xl mx-auto">
      {/* ═══ Header ═══ */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6"
      >
        <div className="flex items-center gap-2 mb-2">
          <ArrowDownToLine className="w-5 h-5 text-[var(--accent)]" />
          <span className="text-xs font-semibold uppercase tracking-wider text-[var(--accent)]">
            Management
          </span>
        </div>
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
          <div>
            <h1 className="text-2xl lg:text-3xl font-bold text-foreground mb-1">Deposits</h1>
            <p className="text-sm text-gray-500">
              {loading ? "Loading..." : `${total} ${statusFilter.toLowerCase() || "all"} deposits`}
              {pendingCount > 0 && (
                <span className="ml-2 inline-flex items-center gap-1 text-amber-400 font-semibold">
                  • <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" /> {pendingCount} pending
                </span>
              )}
            </p>
          </div>
        </div>
      </motion.div>

      {/* ═══ Filters ═══ */}
      <div className="premium-card rounded-2xl p-4 mb-4">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
            <input
              type="text"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              placeholder="Search by email, username, or TxID..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white/5 border border-white/10 text-foreground text-sm placeholder:text-gray-600 focus:border-[var(--accent)]/50 focus:bg-white/[0.07] outline-none transition-all"
            />
            {searchInput && (
              <button
                onClick={() => setSearchInput("")}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300"
              >
                <X size={16} />
              </button>
            )}
          </div>

          <div className="flex gap-2">
            <div className="relative flex-1 sm:flex-none">
              <Filter className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-500 pointer-events-none" />
              <select
                value={statusFilter}
                onChange={(e) => {
                  setStatusFilter(e.target.value);
                  setPage(1);
                }}
                className="pl-8 pr-8 py-2.5 rounded-xl bg-white/5 border border-white/10 text-foreground text-xs font-medium focus:border-[var(--accent)]/50 outline-none cursor-pointer appearance-none w-full sm:w-auto"
              >
                <option value="" className="bg-[var(--background)]">All Status</option>
                <option value="PENDING" className="bg-[var(--background)]">Pending</option>
                <option value="APPROVED" className="bg-[var(--background)]">Approved</option>
                <option value="REJECTED" className="bg-[var(--background)]">Rejected</option>
              </select>
            </div>

            {hasFilters && (
              <button
                onClick={() => {
                  setSearchInput("");
                  setStatusFilter("PENDING");
                  setPage(1);
                }}
                className="flex items-center gap-1.5 px-3 py-2.5 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-xs font-semibold hover:bg-red-500/20 transition-all"
              >
                <X size={14} />
                <span>Reset</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* ═══ Deposits List ═══ */}
      <div className="premium-card rounded-2xl overflow-hidden">
        {loading ? (
          <div className="p-4 space-y-2">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="skeleton h-24 rounded-xl" />
            ))}
          </div>
        ) : deposits.length === 0 ? (
          <div className="p-12 text-center">
            <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-white/[0.03] border border-[var(--border)] flex items-center justify-center">
              <ArrowDownToLine className="w-8 h-8 text-gray-600" />
            </div>
            <p className="text-sm text-gray-400 font-medium">No deposits found</p>
            <p className="text-xs text-gray-500 mt-1">
              {statusFilter === "PENDING" ? "All caught up! No pending deposits." : "Try adjusting filters"}
            </p>
          </div>
        ) : (
          <div className="divide-y divide-[var(--border)]">
            {deposits.map((deposit, idx) => (
              <motion.div
                key={deposit.id}
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.03 }}
                className="p-4 hover:bg-white/[0.02] transition-all"
              >
                <div className="flex flex-col lg:flex-row lg:items-center gap-4">
                  {/* Left: User + Amount */}
                  <div className="flex items-center gap-3 flex-1 min-w-0">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-green-500 to-emerald-500 flex items-center justify-center text-white text-xs font-bold shrink-0">
                      {deposit.user.email.charAt(0).toUpperCase()}
                    </div>

                    <div className="flex-1 min-w-0">
                      <Link
                        href={`/admin/users/${deposit.user.id}`}
                        className="text-sm font-semibold text-foreground hover:text-[var(--accent)] transition-colors truncate block"
                      >
                        {deposit.user.username || deposit.user.email.split("@")[0]}
                      </Link>
                      <p className="text-[11px] text-gray-500 flex items-center gap-1 truncate">
                        <Mail className="w-2.5 h-2.5 shrink-0" />
                        {deposit.user.email}
                      </p>
                    </div>
                  </div>

                  {/* Middle: Amount + Currency */}
                  <div className="flex items-center gap-4">
                    <div>
                      <p className="text-[10px] uppercase tracking-wider text-gray-500 font-semibold">Amount</p>
                      <p className="text-lg font-bold text-green-400">
                        +${deposit.amount.toFixed(2)}
                      </p>
                    </div>

                    <div>
                      <p className="text-[10px] uppercase tracking-wider text-gray-500 font-semibold">Network</p>
                      <p className="text-xs font-bold text-foreground">
                        {deposit.currency} · {deposit.network}
                      </p>
                    </div>
                  </div>

                  {/* Status */}
                  <div>
                    <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-md text-[10px] font-semibold border ${STATUS_COLORS[deposit.status]}`}>
                      {deposit.status === "PENDING" && <Clock size={10} />}
                      {deposit.status === "APPROVED" && <CheckCircle2 size={10} />}
                      {deposit.status === "REJECTED" && <XCircle size={10} />}
                      {deposit.status}
                    </span>
                    <p className="text-[10px] text-gray-500 mt-1">
                      {new Date(deposit.createdAt).toLocaleDateString()}
                    </p>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2">
                    {/* View screenshot */}
                    {deposit.screenshotUrl && (
                      <button
                        onClick={() => openScreenshot(deposit.screenshotUrl!)}
                        className="p-2 rounded-lg bg-white/5 hover:bg-blue-500/10 text-gray-400 hover:text-blue-400 transition-all"
                        title="View Screenshot"
                      >
                        <Eye size={14} />
                      </button>
                    )}

                    {/* Approve/Reject (only for PENDING) */}
                    {deposit.status === "PENDING" && (
                      <>
                        <button
                          onClick={() => openApproval(deposit, "APPROVE")}
                          className="px-3 py-2 rounded-lg bg-green-500/10 border border-green-500/20 text-green-400 hover:bg-green-500/20 text-xs font-semibold flex items-center gap-1.5 transition-all"
                        >
                          <CheckCircle2 size={12} />
                          <span className="hidden sm:inline">Approve</span>
                        </button>
                        <button
                          onClick={() => openApproval(deposit, "REJECT")}
                          className="px-3 py-2 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 hover:bg-red-500/20 text-xs font-semibold flex items-center gap-1.5 transition-all"
                        >
                          <XCircle size={12} />
                          <span className="hidden sm:inline">Reject</span>
                        </button>
                      </>
                    )}
                  </div>
                </div>

                {/* TxID + Note (below main row) */}
                {(deposit.txId || deposit.adminNote || !deposit.screenshotUrl) && (
                  <div className="mt-3 pt-3 border-t border-[var(--border)] flex flex-wrap gap-3 text-[11px]">
                    {deposit.txId && (
                      <div className="flex items-center gap-1.5 text-gray-500">
                        <Hash size={10} />
                        <span className="font-mono truncate max-w-[200px]">{deposit.txId}</span>
                      </div>
                    )}
                    {!deposit.screenshotUrl && (
                      <div className="flex items-center gap-1.5 text-amber-400">
                        <ImageIcon size={10} />
                        <span>No screenshot</span>
                      </div>
                    )}
                    {deposit.adminNote && (
                      <div className="w-full mt-1 p-2 rounded bg-white/[0.02] border border-[var(--border)]">
                        <p className="text-[10px] uppercase tracking-wider text-gray-500 font-semibold mb-0.5">
                          Admin Note
                        </p>
                        <p className="text-[11px] text-gray-300">{deposit.adminNote}</p>
                      </div>
                    )}
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        )}
      </div>

      {/* ═══ Pagination ═══ */}
      {!loading && totalPages > 1 && (
        <div className="flex items-center justify-between mt-4">
          <p className="text-xs text-gray-500">
            Page {page} of {totalPages}
          </p>
          <div className="flex gap-2">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page === 1}
              className="p-2 rounded-lg border border-[var(--border)] text-gray-400 hover:bg-white/5 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
            >
              <ChevronLeft size={16} />
            </button>
            <button
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page === totalPages}
              className="p-2 rounded-lg border border-[var(--border)] text-gray-400 hover:bg-white/5 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
            >
              <ChevronRight size={16} />
            </button>
          </div>
        </div>
      )}

      {/* ═══ Modals ═══ */}
      <ScreenshotViewer
        isOpen={screenshotOpen}
        onClose={() => setScreenshotOpen(false)}
        imageUrl={currentScreenshot}
        title="Deposit Proof"
      />

      {selectedDeposit && (
        <ApprovalModal
          isOpen={approvalOpen}
          onClose={() => {
            setApprovalOpen(false);
            setSelectedDeposit(null);
          }}
          action={approvalAction}
          type="deposit"
          amount={selectedDeposit.amount}
          currency={selectedDeposit.currency}
          userEmail={selectedDeposit.user.email}
          loading={modalLoading}
          error={modalError}
          onConfirm={handleApprovalConfirm}
        />
      )}
    </div>
  );
}