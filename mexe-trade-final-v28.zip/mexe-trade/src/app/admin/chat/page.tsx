// src/app/admin/chat/page.tsx
"use client";

import { useEffect, useState, useCallback, useRef } from "react";
import Link from "next/link";
import { motion, AnimatePresence } from "framer-motion";
import {
  MessageSquare,
  Search,
  X,
  Send,
  Paperclip,
  Loader2,
  Bot,
  Inbox,
  ArrowLeft,
  Shield,
  Mail,
  Globe,
  Wallet,
  Clock,
  AlertCircle,
  CheckCircle2,
  User as UserIcon,
  Image as ImageIcon,
  Trash2,
  Pencil,
  Check,
} from "lucide-react";
import { adminAPI } from "@/lib/api";

interface ConversationUser {
  id: string;
  email: string;
  username: string | null;
  country: string | null;
  kycStatus: string;
  balance: number;
  isActive: boolean;
  role?: string;
  createdAt?: string;
}

interface LastMessage {
  id: string;
  message: string;
  imageUrl: string | null;
  sender: "USER" | "ADMIN";
  createdAt: string;
}

interface Conversation {
  user: ConversationUser;
  lastMessage: LastMessage | null;
  unreadCount: number;
}

interface ChatMessage {
  id: string;
  message: string;
  imageUrl: string | null;
  sender: "USER" | "ADMIN";
  isRead: boolean;
  createdAt: string;
  deletedForEveryone?: boolean;
  editedMessage?: string | null;
  editedAt?: string | null;
}

const KYC_BADGE: Record<string, string> = {
  NONE: "bg-gray-500/10 text-gray-400",
  PENDING: "bg-amber-500/10 text-amber-400",
  APPROVED: "bg-green-500/10 text-green-400",
  REJECTED: "bg-red-500/10 text-red-400",
};

export default function AdminChatPage() {
  // ─── Conversations list state ───
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [listLoading, setListLoading] = useState(true);
  const [searchInput, setSearchInput] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [totalUnread, setTotalUnread] = useState(0);

  // ─── Selected conversation state ───
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [selectedUser, setSelectedUser] = useState<ConversationUser | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [threadLoading, setThreadLoading] = useState(false);

  // ─── Reply composer state ───
  const [newMessage, setNewMessage] = useState("");
  const [image, setImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState("");

  // ─── Refs ───
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const messagesContainerRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const listPollingRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const threadPollingRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // ─── Mobile view state ───
  const [showThreadMobile, setShowThreadMobile] = useState(false);

  // ═══════════════════════════════════════════════════════════
  // Fetch conversations list
  // ═══════════════════════════════════════════════════════════
  const fetchConversations = useCallback(async (isInitial = false) => {
    if (isInitial) setListLoading(true);
    try {
      const result = await adminAPI.listConversations({
        search: searchQuery,
      });

      if (result.conversations) {
        setConversations(result.conversations as Conversation[]);
        if (typeof result.totalUnread === "number") {
          setTotalUnread(result.totalUnread);
        }
      }
    } catch (err) {
      console.error("Failed to fetch conversations:", err);
    } finally {
      if (isInitial) setListLoading(false);
    }
  }, [searchQuery]);

  // Initial load + polling every 5s
  useEffect(() => {
    fetchConversations(true);

    listPollingRef.current = setInterval(() => {
      fetchConversations(false);
    }, 5000);

    return () => {
      if (listPollingRef.current) clearInterval(listPollingRef.current);
    };
  }, [fetchConversations]);

  // Debounced search
  useEffect(() => {
    const timer = setTimeout(() => {
      setSearchQuery(searchInput);
    }, 400);
    return () => clearTimeout(timer);
  }, [searchInput]);

  // ═══════════════════════════════════════════════════════════
  // Fetch conversation thread
  // ═══════════════════════════════════════════════════════════
  const scrollToBottom = useCallback(() => {
    const container = messagesContainerRef.current;
    if (container) {
      container.scrollTop = container.scrollHeight;
    }
  }, []);

  const fetchThread = useCallback(
    async (userId: string, isInitial = false) => {
      if (isInitial) setThreadLoading(true);
      try {
        const result = await adminAPI.getConversation(userId);

        if (result.messages) {
          setMessages(result.messages as ChatMessage[]);
          if (result.user) {
            setSelectedUser(result.user as unknown as ConversationUser);  // ✅ FIXED
          }
          if (isInitial) {
            setTimeout(() => scrollToBottom(), 50);
          }
        }
      } catch (err) {
        console.error("Failed to fetch thread:", err);
      } finally {
        if (isInitial) setThreadLoading(false);
      }
    },
    [scrollToBottom]
  );

  // When user is selected, load thread + start polling
  useEffect(() => {
    if (!selectedUserId) return;

    fetchThread(selectedUserId, true);

    threadPollingRef.current = setInterval(() => {
      fetchThread(selectedUserId, false);
    }, 3000);

    return () => {
      if (threadPollingRef.current) clearInterval(threadPollingRef.current);
    };
  }, [selectedUserId, fetchThread]);

  // Auto-scroll on new messages
  useEffect(() => {
    scrollToBottom();
  }, [messages.length, scrollToBottom]);

  // ═══════════════════════════════════════════════════════════
  // Handlers
  // ═══════════════════════════════════════════════════════════

  const selectConversation = (userId: string) => {
    if (userId === selectedUserId) return;
    setSelectedUserId(userId);
    setMessages([]);
    setNewMessage("");
    setImage(null);
    setImagePreview(null);
    setError("");
    setShowThreadMobile(true);
    // Refresh list shortly after opening — thread fetch will auto-mark as read,
    // so the unread badge in the sidebar and conversation list should clear.
    setTimeout(() => fetchConversations(false), 1500);
  };

  const handleBackToList = () => {
    setShowThreadMobile(false);
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      setError("Image must be less than 5MB");
      return;
    }
    if (!file.type.startsWith("image/")) {
      setError("Only image files are allowed");
      return;
    }

    setError("");
    setImage(file);
    const reader = new FileReader();
    reader.onloadend = () => setImagePreview(reader.result as string);
    reader.readAsDataURL(file);
  };

  const removeImage = () => {
    setImage(null);
    setImagePreview(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const handleSend = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!selectedUserId) return;

    const trimmedMessage = newMessage.trim();
    if (!trimmedMessage && !image) return;

    setSending(true);
    setError("");

    try {
      let result;

      if (image) {
        const formData = new FormData();
        formData.append("message", trimmedMessage);
        formData.append("image", image);
        result = await adminAPI.sendChatReplyWithImage(selectedUserId, formData);
      } else {
        result = await adminAPI.sendChatReply(selectedUserId, {
          message: trimmedMessage,
        });
      }

      if (result.error) {
        setError(result.error);
        return;
      }

      setNewMessage("");
      removeImage();
      await fetchThread(selectedUserId, false);
      await fetchConversations(false); // Refresh list to show new last message
      setTimeout(() => scrollToBottom(), 100);
    } catch (err) {
      console.error(err);
      setError("Failed to send message");
    } finally {
      setSending(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleDeleteMessage = async (
    messageId: string,
    action: "DELETE_FOR_ME" | "DELETE_FOR_EVERYONE"
  ) => {
    if (!selectedUserId) return;
    try {
      await adminAPI.deleteChatMessage(selectedUserId, messageId, action);
      await fetchThread(selectedUserId, false);
      await fetchConversations(false);
    } catch (err) {
      console.error("Failed to delete message:", err);
    }
  };

  const handleEditMessage = async (messageId: string, newMessage: string) => {
    if (!selectedUserId) return;
    try {
      await adminAPI.editChatMessage(selectedUserId, messageId, newMessage);
      await fetchThread(selectedUserId, false);
    } catch (err) {
      console.error("Failed to edit message:", err);
    }
  };

  // ═══════════════════════════════════════════════════════════
  // Render
  // ═══════════════════════════════════════════════════════════

  return (
    <div className="h-full flex flex-col">
      {/* ═══ Page Header ═══ */}
      <div className="px-4 lg:px-8 pt-4 lg:pt-8 pb-4 border-b border-[var(--border)]">
        <div className="flex items-center gap-2 mb-1">
          <MessageSquare className="w-5 h-5 text-[var(--accent)]" />
          <span className="text-xs font-semibold uppercase tracking-wider text-[var(--accent)]">
            Support
          </span>
        </div>
        <div className="flex items-center justify-between gap-2">
          <div>
            <h1 className="text-xl lg:text-2xl font-bold text-foreground">Chat Support</h1>
            <p className="text-xs text-gray-500">
              {conversations.length} conversation{conversations.length !== 1 ? "s" : ""}
              {totalUnread > 0 && (
                <span className="ml-2 inline-flex items-center gap-1 text-red-400 font-semibold">
                  • <span className="w-1.5 h-1.5 rounded-full bg-red-400 animate-pulse" /> {totalUnread} unread
                </span>
              )}
            </p>
          </div>
        </div>
      </div>

      {/* ═══ Split View ═══ */}
      <div className="flex-1 flex overflow-hidden">
        {/* ─── LEFT: Conversations Sidebar ─── */}
        <div
          className={`${
            showThreadMobile ? "hidden lg:flex" : "flex"
          } w-full lg:w-[340px] lg:shrink-0 flex-col border-r border-[var(--border)]`}
        >
          {/* Search */}
          <div className="p-3 border-b border-[var(--border)]">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <input
                type="text"
                value={searchInput}
                onChange={(e) => setSearchInput(e.target.value)}
                placeholder="Search users..."
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white/5 border border-white/10 text-foreground text-sm placeholder:text-gray-600 focus:border-[var(--accent)]/50 focus:bg-white/[0.07] outline-none transition-all"
              />
              {searchInput && (
                <button
                  onClick={() => setSearchInput("")}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300"
                >
                  <X size={16} />
                </button>
              )}
            </div>
          </div>

          {/* Conversations list */}
          <div className="flex-1 overflow-y-auto scrollbar-thin">
            {listLoading ? (
              <div className="p-3 space-y-2">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="skeleton h-16 rounded-xl" />
                ))}
              </div>
            ) : conversations.length === 0 ? (
              <div className="p-8 text-center">
                <div className="w-12 h-12 mx-auto mb-3 rounded-xl bg-white/[0.03] border border-[var(--border)] flex items-center justify-center">
                  <Inbox className="w-6 h-6 text-gray-600" />
                </div>
                <p className="text-xs text-gray-400 font-medium">No conversations yet</p>
                <p className="text-[10px] text-gray-500 mt-1">
                  {searchQuery ? "No results for your search" : "Users' messages will appear here"}
                </p>
              </div>
            ) : (
              <div className="divide-y divide-[var(--border)]">
                {conversations.map((conv) => (
                  <ConversationItem
                    key={conv.user.id}
                    conversation={conv}
                    isSelected={selectedUserId === conv.user.id}
                    onClick={() => selectConversation(conv.user.id)}
                  />
                ))}
              </div>
            )}
          </div>
        </div>

        {/* ─── RIGHT: Message Thread ─── */}
        <div
          className={`${
            showThreadMobile ? "flex" : "hidden lg:flex"
          } flex-1 flex-col min-w-0`}
        >
          {!selectedUserId ? (
            /* Empty state */
            <div className="flex-1 flex flex-col items-center justify-center p-8 text-center">
              <div className="w-20 h-20 rounded-2xl bg-[var(--accent)]/10 border border-[var(--accent)]/20 flex items-center justify-center mb-4">
                <MessageSquare className="w-10 h-10 text-[var(--accent)]" />
              </div>
              <h3 className="text-base font-bold text-foreground mb-1">
                Select a Conversation
              </h3>
              <p className="text-xs text-gray-500 max-w-xs">
                Choose a user from the sidebar to view their messages and reply as support.
              </p>
            </div>
          ) : (
            <>
              {/* Thread header */}
              {selectedUser && (
                <div className="flex items-center gap-3 p-4 border-b border-[var(--border)] bg-white/[0.02] shrink-0">
                  {/* Mobile back button */}
                  <button
                    onClick={handleBackToList}
                    className="lg:hidden p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-white/5 transition-all"
                  >
                    <ArrowLeft size={18} />
                  </button>

                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center text-white text-sm font-bold shrink-0">
                    {selectedUser.email.charAt(0).toUpperCase()}
                  </div>

                  <div className="flex-1 min-w-0">
                    <Link
                      href={`/admin/users/${selectedUser.id}`}
                      className="text-sm font-bold text-foreground hover:text-[var(--accent)] transition-colors truncate block"
                    >
                      {selectedUser.username || selectedUser.email.split("@")[0]}
                    </Link>
                    <div className="flex items-center gap-3 text-[10px] text-gray-500">
                      <span className="flex items-center gap-1 truncate">
                        <Mail size={9} />
                        {selectedUser.email}
                      </span>
                      {selectedUser.country && (
                        <span className="flex items-center gap-1 shrink-0">
                          <Globe size={9} />
                          {selectedUser.country}
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="hidden sm:flex items-center gap-2 shrink-0">
                    <div className="flex items-center gap-1 px-2 py-1 rounded-md bg-white/[0.03] border border-[var(--border)]">
                      <Wallet size={10} className="text-[var(--accent)]" />
                      <span className="text-[10px] font-bold text-foreground">
                        ${selectedUser.balance.toFixed(2)}
                      </span>
                    </div>
                    <span
                      className={`text-[10px] px-2 py-1 rounded font-semibold ${
                        KYC_BADGE[selectedUser.kycStatus] || KYC_BADGE.NONE
                      }`}
                    >
                      {selectedUser.kycStatus === "NONE" ? "No KYC" : selectedUser.kycStatus}
                    </span>
                    {!selectedUser.isActive && (
                      <span className="text-[10px] px-2 py-1 rounded font-semibold bg-red-500/10 text-red-400">
                        SUSPENDED
                      </span>
                    )}
                  </div>
                </div>
              )}

              {/* Messages area */}
              <div
                ref={messagesContainerRef}
                className="flex-1 overflow-y-auto p-4 space-y-3 scrollbar-thin min-h-0"
              >
                {threadLoading ? (
                  <div className="flex items-center justify-center h-full">
                    <Loader2 className="w-6 h-6 text-[var(--accent)] animate-spin" />
                  </div>
                ) : messages.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center">
                    <div className="w-14 h-14 rounded-2xl bg-white/[0.03] border border-[var(--border)] flex items-center justify-center mb-3">
                      <MessageSquare className="w-6 h-6 text-gray-600" />
                    </div>
                    <p className="text-xs text-gray-400">No messages yet</p>
                    <p className="text-[10px] text-gray-500 mt-1">Start the conversation below</p>
                  </div>
                ) : (
                  <>
                    <div className="flex justify-center mb-4">
                      <div className="px-3 py-1.5 rounded-full bg-white/[0.03] border border-[var(--border)]">
                        <span className="text-[10px] text-gray-500">
                          {messages.length} message{messages.length !== 1 ? "s" : ""} • Encrypted
                        </span>
                      </div>
                    </div>
                    {messages.map((msg) => (
                      <ChatBubble
                        key={msg.id}
                        message={msg}
                        userName={selectedUser?.email.charAt(0).toUpperCase() || "U"}
                        onDelete={handleDeleteMessage}
                        onEdit={handleEditMessage}
                      />
                    ))}
                  </>
                )}
                <div ref={messagesEndRef} />
              </div>

              {/* Error banner */}
              <AnimatePresence>
                {error && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="px-4 overflow-hidden shrink-0"
                  >
                    <div className="flex items-center gap-2 p-2.5 rounded-lg bg-red-500/10 border border-red-500/20 mb-2">
                      <AlertCircle size={12} className="text-red-400 shrink-0" />
                      <p className="text-[11px] text-red-400 flex-1">{error}</p>
                      <button
                        onClick={() => setError("")}
                        className="text-red-400 hover:text-red-300"
                      >
                        <X size={12} />
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Image preview */}
              <AnimatePresence>
                {imagePreview && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="px-4 overflow-hidden shrink-0"
                  >
                    <div className="relative inline-block mb-2">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={imagePreview}
                        alt="Preview"
                        className="w-20 h-20 object-cover rounded-lg border border-[var(--border)]"
                      />
                      <button
                        onClick={removeImage}
                        className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full bg-red-500 flex items-center justify-center text-white hover:bg-red-400 transition-colors"
                      >
                        <X size={10} />
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Composer */}
              <form
                onSubmit={handleSend}
                className="p-3 border-t border-[var(--border)] bg-white/[0.02] shrink-0"
              >
                <div className="flex items-end gap-2">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="shrink-0 w-9 h-9 rounded-lg bg-white/[0.03] border border-[var(--border)] flex items-center justify-center text-gray-500 hover:text-[var(--accent)] hover:border-[var(--accent)]/30 transition-all"
                  >
                    <Paperclip size={16} />
                  </button>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleImageSelect}
                    className="sr-only"
                  />

                  <div className="flex-1 relative">
                    <textarea
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      onKeyDown={handleKeyDown}
                      placeholder="Reply as support..."
                      rows={1}
                      disabled={sending}
                      className="w-full px-4 py-2.5 bg-white/[0.03] border border-[var(--border)] rounded-xl text-sm text-foreground placeholder:text-gray-600 focus:outline-none focus:border-[var(--accent)]/50 focus:bg-white/[0.05] transition-all resize-none disabled:opacity-50"
                      style={{ minHeight: "40px", maxHeight: "120px" }}
                      onInput={(e) => {
                        const target = e.target as HTMLTextAreaElement;
                        target.style.height = "40px";
                        target.style.height = `${Math.min(target.scrollHeight, 120)}px`;
                      }}
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={sending || (!newMessage.trim() && !image)}
                    className="shrink-0 w-9 h-9 rounded-lg bg-gradient-to-r from-[var(--accent)] to-purple-500 flex items-center justify-center text-white hover:opacity-90 transition-all active:scale-95 disabled:opacity-30 disabled:cursor-not-allowed disabled:active:scale-100 shadow-lg shadow-[var(--accent)]/20"
                  >
                    {sending ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}
                  </button>
                </div>

                <div className="flex items-center justify-between mt-2 px-1">
                  <span className="text-[10px] text-gray-600">
                    Press Enter to send • Shift+Enter for new line
                  </span>
                  <span className="text-[10px] text-gray-600">{newMessage.length}/2000</span>
                </div>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════
// CONVERSATION ITEM (Left sidebar)
// ═══════════════════════════════════════════════════════════

function ConversationItem({
  conversation,
  isSelected,
  onClick,
}: {
  conversation: Conversation;
  isSelected: boolean;
  onClick: () => void;
}) {
  const { user, lastMessage, unreadCount } = conversation;
  const hasUnread = unreadCount > 0;

  return (
    <button
      onClick={onClick}
      className={`w-full flex items-start gap-3 p-3 text-left transition-all ${
        isSelected
          ? "bg-[var(--accent)]/[0.08] border-l-2 border-l-[var(--accent)]"
          : "hover:bg-white/[0.02] border-l-2 border-l-transparent"
      }`}
    >
      {/* Avatar */}
      <div className="relative shrink-0">
        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center text-white text-sm font-bold">
          {user.email.charAt(0).toUpperCase()}
        </div>
        {hasUnread && (
          <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-full bg-red-500 border-2 border-[var(--background)] text-[9px] font-bold text-white flex items-center justify-center animate-pulse">
            {unreadCount > 9 ? "9+" : unreadCount}
          </span>
        )}
      </div>

      {/* Content */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between gap-2 mb-0.5">
          <div className="flex items-center gap-1 min-w-0">
            <p className={`text-xs font-bold truncate ${
              hasUnread ? "text-foreground" : "text-gray-300"
            }`}>
              {user.username || user.email.split("@")[0]}
            </p>
            {user.role === "ADMIN" && (
              <Shield size={9} className="text-blue-400 shrink-0" />
            )}
          </div>
          {lastMessage && (
            <span className="text-[10px] text-gray-500 shrink-0">
              {formatRelativeTime(lastMessage.createdAt)}
            </span>
          )}
        </div>

        {lastMessage ? (
          <p className={`text-[11px] truncate ${
            hasUnread ? "text-gray-300 font-medium" : "text-gray-500"
          }`}>
            {lastMessage.sender === "ADMIN" && (
              <span className="text-[var(--accent)] mr-1">You:</span>
            )}
            {lastMessage.imageUrl && !lastMessage.message && (
              <span className="inline-flex items-center gap-1">
                <ImageIcon size={9} />
                Image
              </span>
            )}
            {lastMessage.message || (lastMessage.imageUrl ? "" : "No message")}
          </p>
        ) : (
          <p className="text-[11px] text-gray-500 italic">No messages</p>
        )}
      </div>
    </button>
  );
}

// ═══════════════════════════════════════════════════════════
// CHAT BUBBLE
// ═══════════════════════════════════════════════════════════

function ChatBubble({
  message,
  userName,
  onDelete,
  onEdit,
}: {
  message: ChatMessage;
  userName: string;
  onDelete: (messageId: string, action: "DELETE_FOR_ME" | "DELETE_FOR_EVERYONE") => void;
  onEdit: (messageId: string, newMessage: string) => void;
}) {
  const isAdmin = message.sender === "ADMIN";
  const [menuOpen, setMenuOpen] = useState(false);
  const [editing, setEditing] = useState(false);
  const [editText, setEditText] = useState("");
  const [saving, setSaving] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const editRef = useRef<HTMLTextAreaElement>(null);

  const time = new Date(message.createdAt).toLocaleTimeString("en-US", {
    hour: "2-digit",
    minute: "2-digit",
  });

  // Close menu on outside click
  useEffect(() => {
    if (!menuOpen) return;
    const handler = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setMenuOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [menuOpen]);

  // Focus textarea when entering edit mode
  useEffect(() => {
    if (editing && editRef.current) {
      editRef.current.focus();
      editRef.current.setSelectionRange(editRef.current.value.length, editRef.current.value.length);
    }
  }, [editing]);

  const startEditing = () => {
    // Pre-fill with editedMessage if it exists, otherwise original
    setEditText(message.editedMessage ?? message.message);
    setEditing(true);
    setMenuOpen(false);
  };

  const cancelEdit = () => {
    setEditing(false);
    setEditText("");
  };

  const saveEdit = async () => {
    const trimmed = editText.trim();
    // Cancel if nothing changed from what the user is currently seeing
    const currentStored = message.editedMessage ?? message.message;
    if (!trimmed || trimmed === currentStored) {
      cancelEdit();
      return;
    }
    setSaving(true);
    try {
      await onEdit(message.id, trimmed);
    } finally {
      setSaving(false);
      setEditing(false);
      setEditText("");
    }
  };

  const handleEditKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      saveEdit();
    }
    if (e.key === "Escape") {
      cancelEdit();
    }
  };

  // Deleted-for-everyone tombstone
  if (message.deletedForEveryone) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        className={`flex gap-2.5 ${isAdmin ? "flex-row-reverse" : "flex-row"}`}
      >
        <div className="w-8 h-8 rounded-full bg-gray-700/50 flex items-center justify-center shrink-0">
          <Trash2 size={12} className="text-gray-500" />
        </div>
        <div className="max-w-[75%]">
          <div className="rounded-2xl px-4 py-2.5 bg-white/[0.02] border border-dashed border-white/10 text-gray-500 text-sm italic">
            🗑 This message was deleted
          </div>
          <div className={`flex mt-1 ${isAdmin ? "justify-end" : "justify-start"}`}>
            <span className="text-[10px] text-gray-700">{time}</span>
          </div>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className={`flex gap-2.5 ${isAdmin ? "flex-row-reverse" : "flex-row"}`}
    >
      {/* Avatar — click to open hidden management menu */}
      <div className="relative shrink-0" ref={menuRef}>
        <div
          onClick={() => setMenuOpen((o) => !o)}
          className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold cursor-pointer select-none ${
            isAdmin
              ? "bg-gradient-to-br from-[var(--accent)] to-purple-500 text-white"
              : "bg-gradient-to-br from-blue-500 to-cyan-500 text-white"
          }`}
        >
          {isAdmin ? <Bot size={14} /> : userName}
        </div>

        {/* Hidden dropdown — triggered by clicking the avatar */}
        <AnimatePresence>
          {menuOpen && !editing && (
            <motion.div
              initial={{ opacity: 0, scale: 0.92, y: -4 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.92, y: -4 }}
              transition={{ duration: 0.1 }}
              className={`
                absolute z-50 top-9 min-w-[185px]
                bg-[var(--background)] border border-[var(--border)]
                rounded-xl shadow-xl overflow-hidden
                ${isAdmin ? "right-0" : "left-0"}
              `}
            >
              {/* Edit — only for admin-sent messages */}
              {isAdmin && (
                <>
                  <button
                    onClick={startEditing}
                    className="w-full flex items-center gap-2.5 px-3 py-2.5 text-xs text-blue-300 hover:bg-blue-500/[0.06] transition-all"
                  >
                    <Pencil size={13} className="text-blue-400" />
                    <span>Edit message</span>
                  </button>
                  <div className="h-px bg-[var(--border)]" />
                </>
              )}
              <button
                onClick={() => {
                  setMenuOpen(false);
                  onDelete(message.id, "DELETE_FOR_ME");
                }}
                className="w-full flex items-center gap-2.5 px-3 py-2.5 text-xs text-gray-300 hover:bg-white/[0.05] hover:text-white transition-all"
              >
                <Trash2 size={13} className="text-gray-500" />
                <span>Delete for me</span>
              </button>
              <div className="h-px bg-[var(--border)]" />
              <button
                onClick={() => {
                  setMenuOpen(false);
                  onDelete(message.id, "DELETE_FOR_EVERYONE");
                }}
                className="w-full flex items-center gap-2.5 px-3 py-2.5 text-xs text-red-400 hover:bg-red-500/[0.06] transition-all"
              >
                <Trash2 size={13} />
                <span>Delete for everyone</span>
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Bubble + menu wrapper */}
      <div className={`max-w-[75%] flex flex-col ${isAdmin ? "items-end" : "items-start"}`}>
        <div
          className={`text-[10px] font-medium mb-1 ${
            isAdmin ? "text-right text-[var(--accent)]" : "text-left text-gray-500"
          }`}
        >
          {isAdmin ? "You (Support)" : "User"}
        </div>

        {/* Bubble row — no visible trigger, menu is on the avatar */}
        <div className={`flex items-end gap-1.5 ${isAdmin ? "flex-row" : "flex-row-reverse"}`}>
          {/* Bubble / Inline editor */}
          {editing ? (
            <div className="flex flex-col gap-1.5 min-w-[220px] max-w-full">
              <textarea
                ref={editRef}
                value={editText}
                onChange={(e) => setEditText(e.target.value)}
                onKeyDown={handleEditKeyDown}
                disabled={saving}
                rows={2}
                className="w-full px-3 py-2 rounded-xl bg-white/[0.07] border border-[var(--accent)]/40 text-sm text-foreground placeholder:text-gray-500 focus:outline-none focus:border-[var(--accent)]/70 resize-none transition-all disabled:opacity-50"
                style={{ minHeight: "52px", maxHeight: "120px" }}
                onInput={(e) => {
                  const t = e.target as HTMLTextAreaElement;
                  t.style.height = "52px";
                  t.style.height = `${Math.min(t.scrollHeight, 120)}px`;
                }}
              />
              <div className="flex items-center gap-1.5 justify-end">
                <button
                  onClick={cancelEdit}
                  disabled={saving}
                  className="px-2.5 py-1 rounded-lg text-[11px] text-gray-400 hover:text-gray-200 hover:bg-white/[0.05] transition-all disabled:opacity-40"
                >
                  Cancel
                </button>
                <button
                  onClick={saveEdit}
                  disabled={saving || !editText.trim()}
                  className="flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] bg-[var(--accent)]/80 hover:bg-[var(--accent)] text-white transition-all disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  {saving ? (
                    <Loader2 size={10} className="animate-spin" />
                  ) : (
                    <Check size={10} />
                  )}
                  Save
                </button>
              </div>
            </div>
          ) : (
            <div
              className={`rounded-2xl px-4 py-2.5 ${
                isAdmin
                  ? "bg-[var(--accent)] text-white rounded-br-md"
                  : "bg-white/[0.05] border border-[var(--border)] text-foreground rounded-bl-md"
              }`}
            >
              {message.imageUrl && (
                <a
                  href={message.imageUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block mb-2"
                >
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={message.imageUrl}
                    alt="Attachment"
                    className="max-w-full max-h-48 rounded-lg object-contain"
                  />
                </a>
              )}
              {message.message && (
                <p className="text-sm leading-relaxed whitespace-pre-wrap break-words">
                  {message.message}
                </p>
              )}
            </div>
          )}
        </div>

        <div className={`flex items-center gap-1.5 mt-1 ${isAdmin ? "justify-end" : "justify-start"}`}>
          <span className="text-[10px] text-gray-600">{time}</span>
          {isAdmin && (
            <CheckCircle2
              size={10}
              className={message.isRead ? "text-[var(--accent)]" : "text-gray-600"}
            />
          )}
        </div>
      </div>
    </motion.div>
  );
}

// ═══════════════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════════════

function formatRelativeTime(dateStr: string): string {
  const date = new Date(dateStr);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);

  if (diffMins < 1) return "just now";
  if (diffMins < 60) return `${diffMins}m ago`;
  if (diffHours < 24) return `${diffHours}h ago`;
  if (diffDays === 1) return "yesterday";
  if (diffDays < 7) return `${diffDays}d ago`;
  return date.toLocaleDateString();
}