// src/app/admin/trades/page.tsx
"use client";

import { useEffect, useState, useCallback } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  TrendingUp,
  TrendingDown,
  Search,
  ChevronLeft,
  ChevronRight,
  X,
  Filter,
  Mail,
  DollarSign,
  Activity,
  Zap,
  Eye,
  Percent,
} from "lucide-react";

interface TradeItem {
  id: string;
  coinId: string;
  coinSymbol: string;
  binanceSymbol: string;
  side: "BUY" | "SELL";
  orderType: string;
  leverage: number;
  marginAmount: number;
  positionSize: number;
  quantity: number;
  entryPrice: number;
  exitPrice: number | null;
  fee: number;
  pnl: number;
  pnlPercent: number;
  status: string;
  closeReason: string | null;
  adminSetProfitPercent: number | null;
  openedAt: string;
  closedAt: string | null;
  user: {
    id: string;
    email: string;
    username: string | null;
  };
}

interface TradeStats {
  openCount: number;
  totalMargin: number;
  totalPnL: number;
  totalFees: number;
}

const STATUS_COLORS: Record<string, string> = {
  OPEN: "text-blue-400 bg-blue-500/10 border-blue-500/20",
  CLOSED: "text-gray-400 bg-gray-500/10 border-gray-500/20",
  LIQUIDATED: "text-red-400 bg-red-500/10 border-red-500/20",
};

const SUPPORTED_COINS = ["BTC", "ETH", "USDT", "BNB", "SOL", "XRP", "ADA", "DOGE", "AVAX", "TRX", "DOT", "LINK"];

export default function AdminTradesPage() {
  const [trades, setTrades] = useState<TradeItem[]>([]);
  const [stats, setStats] = useState<TradeStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [searchInput, setSearchInput] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [sideFilter, setSideFilter] = useState("");
  const [coinFilter, setCoinFilter] = useState("");
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [total, setTotal] = useState(0);

  // Set trade result modal state
  const [closeModalOpen, setCloseModalOpen] = useState(false);
  const [selectedTrade, setSelectedTrade] = useState<TradeItem | null>(null);
  const [exitPrice, setExitPrice] = useState("");
  const [closeNote, setCloseNote] = useState("");
  const [closingLoading, setClosingLoading] = useState(false);
  const [closeError, setCloseError] = useState("");

  // View details modal
  const [viewTrade, setViewTrade] = useState<TradeItem | null>(null);

  const fetchTrades = useCallback(async () => {
    setLoading(true);
    try {
      const query = new URLSearchParams();
      if (statusFilter) query.set("status", statusFilter);
      if (sideFilter) query.set("side", sideFilter);
      if (coinFilter) query.set("coin", coinFilter);
      if (searchQuery) query.set("search", searchQuery);
      query.set("page", String(page));
      query.set("limit", "20");

      const response = await fetch(`/api/admin/trades?${query}`, {
        credentials: "include",
      });
      const result = await response.json();

      if (result.trades) {
        setTrades(result.trades as TradeItem[]);
        if (result.pagination) {
          setTotalPages(result.pagination.totalPages);
          setTotal(result.pagination.total);
        }
        if (result.stats) {
          setStats(result.stats as TradeStats);
        }
      }
    } catch (err) {
      console.error("Failed to fetch trades:", err);
    } finally {
      setLoading(false);
    }
  }, [statusFilter, sideFilter, coinFilter, searchQuery, page]);

  useEffect(() => {
    fetchTrades();
  }, [fetchTrades]);

  useEffect(() => {
    const timer = setTimeout(() => {
      setSearchQuery(searchInput);
      setPage(1);
    }, 400);
    return () => clearTimeout(timer);
  }, [searchInput]);

  const [closeMode, setCloseMode] = useState<"percent" | "price">("percent");
  const [profitPercent, setProfitPercent] = useState("");

  const openCloseModal = (trade: TradeItem) => {
    setSelectedTrade(trade);
    setExitPrice(trade.entryPrice.toString());
    // Pre-fill with the currently pending value, if one is already set
    setProfitPercent(
      trade.adminSetProfitPercent !== null ? String(trade.adminSetProfitPercent) : ""
    );
    setCloseMode("percent");
    setCloseNote("");
    setCloseError("");
    setCloseModalOpen(true);
  };

  const handleSetResult = async () => {
    if (!selectedTrade) return;

    const body: { exitPrice?: number; profitPercent?: number; note?: string } = {
      note: closeNote.trim() || undefined,
    };

    if (closeMode === "percent") {
      const parsedPercent = parseFloat(profitPercent);
      if (isNaN(parsedPercent)) {
        setCloseError("Please enter a valid profit percentage (e.g. 20 or -10)");
        return;
      }
      body.profitPercent = parsedPercent;
    } else {
      const parsedPrice = parseFloat(exitPrice);
      if (isNaN(parsedPrice) || parsedPrice <= 0) {
        setCloseError("Please enter a valid exit price");
        return;
      }
      body.exitPrice = parsedPrice;
    }

    setClosingLoading(true);
    setCloseError("");

    try {
      const response = await fetch(`/api/admin/trades/${selectedTrade.id}/set-result`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(body),
      });
      const result = await response.json();

      if (!response.ok) {
        setCloseError(result.error || "Failed to set trade result");
        setClosingLoading(false);
        return;
      }

      setCloseModalOpen(false);
      setSelectedTrade(null);
      setClosingLoading(false);
      fetchTrades();
    } catch (err) {
      console.error(err);
      setCloseError("Network error");
      setClosingLoading(false);
    }
  };

  const handleClearResult = async () => {
    if (!selectedTrade) return;

    setClosingLoading(true);
    setCloseError("");

    try {
      const response = await fetch(`/api/admin/trades/${selectedTrade.id}/set-result`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ clear: true }),
      });
      const result = await response.json();

      if (!response.ok) {
        setCloseError(result.error || "Failed to clear pending result");
        setClosingLoading(false);
        return;
      }

      setCloseModalOpen(false);
      setSelectedTrade(null);
      setClosingLoading(false);
      fetchTrades();
    } catch (err) {
      console.error(err);
      setCloseError("Network error");
      setClosingLoading(false);
    }
  };

  const hasFilters = searchQuery || statusFilter || sideFilter || coinFilter;

  return (
    <div className="p-4 lg:p-8 max-w-7xl mx-auto">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6"
      >
        <div className="flex items-center gap-2 mb-2">
          <Activity className="w-5 h-5 text-[var(--accent)]" />
          <span className="text-xs font-semibold uppercase tracking-wider text-[var(--accent)]">
            Management
          </span>
        </div>
        <div>
          <h1 className="text-2xl lg:text-3xl font-bold text-foreground mb-1">Trades Monitor</h1>
          <p className="text-sm text-gray-500">
            {loading ? "Loading..." : `${total} total trades`}
            {stats && stats.openCount > 0 && (
              <span className="ml-2 inline-flex items-center gap-1 text-blue-400 font-semibold">
                • <span className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-pulse" /> {stats.openCount} open positions
              </span>
            )}
          </p>
        </div>
      </motion.div>

      {/* Stats */}
      {stats && (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
          <StatBox
            label="Open Positions"
            value={stats.openCount}
            icon={Activity}
            color="text-blue-400 bg-blue-500/10 border-blue-500/20"
          />
          <StatBox
            label="Total Margin"
            value={`$${stats.totalMargin.toLocaleString("en-US", { maximumFractionDigits: 0 })}`}
            icon={DollarSign}
            color="text-[var(--accent)] bg-[var(--accent)]/10 border-[var(--accent)]/20"
          />
          <StatBox
            label="Realized P&L"
            value={`${stats.totalPnL >= 0 ? "+" : ""}$${stats.totalPnL.toLocaleString("en-US", { maximumFractionDigits: 2 })}`}
            icon={stats.totalPnL >= 0 ? TrendingUp : TrendingDown}
            color={
              stats.totalPnL >= 0
                ? "text-green-400 bg-green-500/10 border-green-500/20"
                : "text-red-400 bg-red-500/10 border-red-500/20"
            }
          />
          <StatBox
            label="Total Fees"
            value={`$${stats.totalFees.toLocaleString("en-US", { maximumFractionDigits: 2 })}`}
            icon={Zap}
            color="text-amber-400 bg-amber-500/10 border-amber-500/20"
          />
        </div>
      )}

      {/* Filters */}
      <div className="premium-card rounded-2xl p-4 mb-4">
        <div className="flex flex-col lg:flex-row gap-3">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
            <input
              type="text"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              placeholder="Search by user email..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white/5 border border-white/10 text-foreground text-sm placeholder:text-gray-600 focus:border-[var(--accent)]/50 focus:bg-white/[0.07] outline-none transition-all"
            />
            {searchInput && (
              <button
                onClick={() => setSearchInput("")}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300"
              >
                <X size={16} />
              </button>
            )}
          </div>

          <div className="grid grid-cols-3 lg:flex gap-2">
            <FilterSelect
              value={statusFilter}
              onChange={(v) => { setStatusFilter(v); setPage(1); }}
              options={[
                { value: "", label: "All Status" },
                { value: "OPEN", label: "Open" },
                { value: "CLOSED", label: "Closed" },
                { value: "LIQUIDATED", label: "Liquidated" },
              ]}
            />
            <FilterSelect
              value={sideFilter}
              onChange={(v) => { setSideFilter(v); setPage(1); }}
              options={[
                { value: "", label: "All Sides" },
                { value: "BUY", label: "Long" },
                { value: "SELL", label: "Short" },
              ]}
            />
            <FilterSelect
              value={coinFilter}
              onChange={(v) => { setCoinFilter(v); setPage(1); }}
              options={[
                { value: "", label: "All Coins" },
                ...SUPPORTED_COINS.map((c) => ({ value: c, label: c })),
              ]}
            />
          </div>

          {hasFilters && (
            <button
              onClick={() => {
                setSearchInput("");
                setStatusFilter("");
                setSideFilter("");
                setCoinFilter("");
                setPage(1);
              }}
              className="flex items-center gap-1.5 px-3 py-2.5 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-xs font-semibold hover:bg-red-500/20 transition-all"
            >
              <X size={14} />
              <span>Reset</span>
            </button>
          )}
        </div>
      </div>

      {/* Trades List */}
      <div className="premium-card rounded-2xl overflow-hidden">
        {loading ? (
          <div className="p-4 space-y-2">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="skeleton h-24 rounded-xl" />
            ))}
          </div>
        ) : trades.length === 0 ? (
          <div className="p-12 text-center">
            <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-white/[0.03] border border-[var(--border)] flex items-center justify-center">
              <TrendingUp className="w-8 h-8 text-gray-600" />
            </div>
            <p className="text-sm text-gray-400 font-medium">No trades found</p>
            <p className="text-xs text-gray-500 mt-1">Try adjusting your filters</p>
          </div>
        ) : (
          <div className="divide-y divide-[var(--border)]">
            {trades.map((trade, idx) => {
              const isLong = trade.side === "BUY";
              const isProfitable = trade.pnl >= 0;

              return (
                <motion.div
                  key={trade.id}
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.03 }}
                  className="p-4 hover:bg-white/[0.02] transition-all"
                >
                  <div className="flex flex-col lg:flex-row lg:items-center gap-4">
                    {/* User + Coin */}
                    <div className="flex items-center gap-3 flex-1 min-w-0">
                      <div className={`w-10 h-10 rounded-lg flex items-center justify-center text-xs font-bold shrink-0 ${
                        isLong
                          ? "bg-green-500/10 text-green-400 border border-green-500/20"
                          : "bg-red-500/10 text-red-400 border border-red-500/20"
                      }`}>
                        {isLong ? "L" : "S"}
                      </div>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-0.5">
                          <p className="text-sm font-bold text-foreground">
                            {trade.coinSymbol}/USDT
                          </p>
                          <span className={`text-[10px] font-semibold ${
                            isLong ? "text-green-400" : "text-red-400"
                          }`}>
                            {isLong ? "LONG" : "SHORT"} {trade.leverage}x
                          </span>
                        </div>
                        <Link
                          href={`/admin/users/${trade.user.id}`}
                          className="text-[11px] text-gray-500 hover:text-[var(--accent)] transition-colors flex items-center gap-1 truncate"
                        >
                          <Mail className="w-2.5 h-2.5 shrink-0" />
                          <span className="truncate">{trade.user.email}</span>
                        </Link>
                      </div>
                    </div>

                    {/* Prices */}
                    <div className="hidden sm:flex items-center gap-4 text-right">
                      <div>
                        <p className="text-[10px] uppercase tracking-wider text-gray-500 font-semibold">Entry</p>
                        <p className="text-xs font-bold text-foreground font-mono">
                          ${trade.entryPrice.toFixed(trade.entryPrice > 10 ? 2 : 6)}
                        </p>
                      </div>
                      {trade.exitPrice && (
                        <div>
                          <p className="text-[10px] uppercase tracking-wider text-gray-500 font-semibold">Exit</p>
                          <p className="text-xs font-bold text-foreground font-mono">
                            ${trade.exitPrice.toFixed(trade.exitPrice > 10 ? 2 : 6)}
                          </p>
                        </div>
                      )}
                    </div>

                    {/* Margin + P&L */}
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <p className="text-[10px] uppercase tracking-wider text-gray-500 font-semibold">Margin</p>
                        <p className="text-xs font-bold text-foreground">
                          ${trade.marginAmount.toFixed(2)}
                        </p>
                      </div>

                      {trade.status !== "OPEN" && (
                        <div className="text-right">
                          <p className="text-[10px] uppercase tracking-wider text-gray-500 font-semibold">P&L</p>
                          <p className={`text-xs font-bold ${isProfitable ? "text-green-400" : "text-red-400"}`}>
                            {isProfitable ? "+" : ""}${trade.pnl.toFixed(2)}
                          </p>
                          <p className={`text-[9px] ${isProfitable ? "text-green-400/70" : "text-red-400/70"}`}>
                            {trade.pnlPercent >= 0 ? "+" : ""}{trade.pnlPercent.toFixed(2)}%
                          </p>
                        </div>
                      )}
                    </div>

                    {/* Status + Action */}
                    <div className="flex items-center gap-2">
                      <div className="text-right">
                        <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-md text-[10px] font-semibold border ${STATUS_COLORS[trade.status]}`}>
                          {trade.status}
                        </span>
                        <p className="text-[10px] text-gray-500 mt-1">
                          {new Date(trade.openedAt).toLocaleDateString()}
                        </p>
                      </div>

                      <button
                        onClick={() => setViewTrade(trade)}
                        className="p-2 rounded-lg bg-white/[0.03] border border-[var(--border)] text-gray-400 hover:bg-white/[0.06] hover:text-foreground transition-all"
                        title="View trade details"
                      >
                        <Eye size={14} />
                      </button>

                      {trade.status === "OPEN" && (
                        <button
                          onClick={() => openCloseModal(trade)}
                          className="p-2 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 hover:bg-red-500/20 transition-all"
                          title="Set trade result"
                        >
                          <Percent size={14} />
                        </button>
                      )}
                    </div>
                  </div>

                  {trade.status === "OPEN" && trade.adminSetProfitPercent !== null && (
                    <div className="mt-2 flex items-center gap-1.5">
                      <span className="text-[10px] font-semibold text-amber-400 bg-amber-500/10 border border-amber-500/20 px-1.5 py-0.5 rounded-md">
                        Pending result: {trade.adminSetProfitPercent >= 0 ? "+" : ""}
                        {trade.adminSetProfitPercent.toFixed(2)}%
                      </span>
                    </div>
                  )}

                  {trade.closeReason && (
                    <div className="mt-2 flex items-center gap-1.5">
                      <span className="text-[10px] text-gray-500">Close reason:</span>
                      <span className="text-[10px] text-gray-400 font-semibold">{trade.closeReason}</span>
                    </div>
                  )}
                </motion.div>
              );
            })}
          </div>
        )}
      </div>

      {/* Pagination */}
      {!loading && totalPages > 1 && (
        <div className="flex items-center justify-between mt-4">
          <p className="text-xs text-gray-500">Page {page} of {totalPages}</p>
          <div className="flex gap-2">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page === 1}
              className="p-2 rounded-lg border border-[var(--border)] text-gray-400 hover:bg-white/5 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
            >
              <ChevronLeft size={16} />
            </button>
            <button
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page === totalPages}
              className="p-2 rounded-lg border border-[var(--border)] text-gray-400 hover:bg-white/5 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
            >
              <ChevronRight size={16} />
            </button>
          </div>
        </div>
      )}

      {/* Set Result Modal */}
      {closeModalOpen && selectedTrade && (
        <SetResultModal
          trade={selectedTrade}
          closeMode={closeMode}
          setCloseMode={setCloseMode}
          exitPrice={exitPrice}
          setExitPrice={setExitPrice}
          profitPercent={profitPercent}
          setProfitPercent={setProfitPercent}
          note={closeNote}
          setNote={setCloseNote}
          error={closeError}
          loading={closingLoading}
          onClose={() => setCloseModalOpen(false)}
          onConfirm={handleSetResult}
          onClear={handleClearResult}
        />
      )}

      {/* View Details Modal */}
      {viewTrade && (
        <ViewTradeModal trade={viewTrade} onClose={() => setViewTrade(null)} />
      )}
    </div>
  );
}

// Stat Box
function StatBox({
  label,
  value,
  icon: Icon,
  color,
}: {
  label: string;
  value: string | number;
  icon: React.ElementType;
  color: string;
}) {
  return (
    <div className="premium-card rounded-2xl p-4">
      <div className={`w-8 h-8 rounded-lg border flex items-center justify-center mb-3 ${color}`}>
        <Icon className="w-4 h-4" />
      </div>
      <p className="text-[10px] uppercase tracking-wider text-gray-500 font-semibold mb-1">{label}</p>
      <p className="text-base lg:text-lg font-bold text-foreground truncate">{value}</p>
    </div>
  );
}

// Filter Select
function FilterSelect({
  value,
  onChange,
  options,
}: {
  value: string;
  onChange: (v: string) => void;
  options: { value: string; label: string }[];
}) {
  return (
    <div className="relative">
      <Filter className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-500 pointer-events-none" />
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="pl-8 pr-8 py-2.5 rounded-xl bg-white/5 border border-white/10 text-foreground text-xs font-medium focus:border-[var(--accent)]/50 outline-none cursor-pointer appearance-none w-full lg:w-auto"
      >
        {options.map((opt) => (
          <option key={opt.value} value={opt.value} className="bg-[var(--background)]">
            {opt.label}
          </option>
        ))}
      </select>
    </div>
  );
}

// Set Result Modal
function SetResultModal({
  trade,
  closeMode,
  setCloseMode,
  exitPrice,
  setExitPrice,
  profitPercent,
  setProfitPercent,
  note,
  setNote,
  error,
  loading,
  onClose,
  onConfirm,
  onClear,
}: {
  trade: TradeItem;
  closeMode: "percent" | "price";
  setCloseMode: (v: "percent" | "price") => void;
  exitPrice: string;
  setExitPrice: (v: string) => void;
  profitPercent: string;
  setProfitPercent: (v: string) => void;
  note: string;
  setNote: (v: string) => void;
  error: string;
  loading: boolean;
  onClose: () => void;
  onConfirm: () => void;
  onClear: () => void;
}) {
  const isLong = trade.side === "BUY";
  const hasPendingResult = trade.adminSetProfitPercent !== null;

  const parsedPercent = parseFloat(profitPercent);
  const parsedPrice = parseFloat(exitPrice) || 0;

  let projectedPnL = 0;
  let hasProjection = false;

  if (closeMode === "percent" && !isNaN(parsedPercent)) {
    projectedPnL = (trade.marginAmount * parsedPercent) / 100;
    hasProjection = true;
  } else if (closeMode === "price" && parsedPrice > 0) {
    projectedPnL = isLong
      ? ((parsedPrice - trade.entryPrice) / trade.entryPrice) * trade.positionSize
      : ((trade.entryPrice - parsedPrice) / trade.entryPrice) * trade.positionSize;
    hasProjection = true;
  }

  // No fee — full margin + P&L is what the client will receive.
  const projectedPayout = Math.max(trade.marginAmount + projectedPnL, 0);
  const canConfirm = closeMode === "percent" ? !isNaN(parsedPercent) : parsedPrice > 0;

  return (
    <>
      <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50" onClick={onClose} />
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[95vw] max-w-md z-50"
      >
        <div className="glass-panel rounded-2xl overflow-hidden shadow-2xl border border-[var(--border)]">
          <div className="flex items-center justify-between p-5 border-b border-[var(--border)]">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-red-500/10 border border-red-500/20 flex items-center justify-center">
                <Percent className="w-5 h-5 text-red-400" />
              </div>
              <div>
                <h3 className="text-base font-bold text-foreground">Set Trade Result</h3>
                <p className="text-[11px] text-gray-500">{trade.coinSymbol}/USDT • {isLong ? "LONG" : "SHORT"} {trade.leverage}x • {trade.user.email}</p>
              </div>
            </div>
            <button onClick={onClose} disabled={loading} className="p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-white/5">
              <X size={18} />
            </button>
          </div>

          <div className="p-5 space-y-4">
            <div className="p-3 rounded-lg bg-blue-500/10 border border-blue-500/20">
              <p className="text-xs text-blue-400">
                This <strong>does not close the trade</strong>. It sets the result the client will get whenever they close it themselves — nothing changes for them until then, and they are never notified of this.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 rounded-lg bg-white/[0.03] border border-[var(--border)]">
                <p className="text-[10px] uppercase text-gray-500 font-semibold">Entry Price</p>
                <p className="text-sm font-bold text-foreground font-mono">
                  ${trade.entryPrice.toFixed(trade.entryPrice > 10 ? 2 : 6)}
                </p>
              </div>
              <div className="p-3 rounded-lg bg-white/[0.03] border border-[var(--border)]">
                <p className="text-[10px] uppercase text-gray-500 font-semibold">Margin</p>
                <p className="text-sm font-bold text-foreground">${trade.marginAmount.toFixed(2)}</p>
              </div>
            </div>

            {/* Mode toggle */}
            <div className="flex gap-1.5 p-1 rounded-xl bg-white/[0.03] border border-[var(--border)]">
              <button
                onClick={() => setCloseMode("percent")}
                className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-semibold transition-all ${
                  closeMode === "percent" ? "bg-[var(--accent)] text-white" : "text-gray-400 hover:text-foreground"
                }`}
              >
                <Percent size={12} /> Set Profit %
              </button>
              <button
                onClick={() => setCloseMode("price")}
                className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-semibold transition-all ${
                  closeMode === "price" ? "bg-[var(--accent)] text-white" : "text-gray-400 hover:text-foreground"
                }`}
              >
                <DollarSign size={12} /> Set Exit Price
              </button>
            </div>

            {closeMode === "percent" ? (
              <div>
                <label className="block text-xs font-semibold text-gray-400 mb-2 uppercase tracking-wider">
                  Profit / Loss % of Margin <span className="text-red-400 normal-case">*</span>
                </label>
                <div className="relative">
                  <input
                    type="number"
                    step="any"
                    value={profitPercent}
                    onChange={(e) => setProfitPercent(e.target.value)}
                    placeholder="e.g. 20 for +20%, -10 for -10%"
                    disabled={loading}
                    className="w-full pl-4 pr-8 py-3 rounded-xl bg-white/5 border border-white/10 text-foreground text-base font-mono focus:border-[var(--accent)]/50 outline-none transition-all"
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500">%</span>
                </div>
                <p className="text-[10px] text-gray-500 mt-1.5">
                  Applies directly to the ${trade.marginAmount.toFixed(2)} margin — e.g. 20% pays out ${(trade.marginAmount * 1.2).toFixed(2)} total when they close.
                </p>
              </div>
            ) : (
              <div>
                <label className="block text-xs font-semibold text-gray-400 mb-2 uppercase tracking-wider">
                  Exit Price (USD) <span className="text-red-400 normal-case">*</span>
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500">$</span>
                  <input
                    type="number"
                    step="any"
                    value={exitPrice}
                    onChange={(e) => setExitPrice(e.target.value)}
                    disabled={loading}
                    className="w-full pl-8 pr-4 py-3 rounded-xl bg-white/5 border border-white/10 text-foreground text-base font-mono focus:border-[var(--accent)]/50 outline-none transition-all"
                  />
                </div>
                <p className="text-[10px] text-gray-500 mt-1.5">
                  Converted to an equivalent profit % on save — leverage multiplies price moves, so a small change can mean a large return.
                </p>
              </div>
            )}

            {hasProjection && (
              <div className="p-3 rounded-lg bg-white/[0.02] border border-[var(--border)] space-y-1.5">
                <div className="flex justify-between text-[11px]">
                  <span className="text-gray-500">Projected P&L</span>
                  <span className={`font-bold ${projectedPnL >= 0 ? "text-green-400" : "text-red-400"}`}>
                    {projectedPnL >= 0 ? "+" : ""}${projectedPnL.toFixed(2)}
                  </span>
                </div>
                <div className="border-t border-[var(--border)] pt-1.5 flex justify-between text-xs">
                  <span className="text-gray-400 font-semibold">Payout When Client Closes</span>
                  <span className="text-green-400 font-bold font-mono">${projectedPayout.toFixed(2)}</span>
                </div>
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-gray-400 mb-2 uppercase tracking-wider">
                Note <span className="text-gray-600 normal-case font-normal">(internal only, optional)</span>
              </label>
              <textarea
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="Internal note for the admin log"
                rows={2}
                disabled={loading}
                className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-foreground text-sm focus:border-[var(--accent)]/50 outline-none transition-all resize-none"
              />
            </div>

            {error && (
              <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/20">
                <p className="text-xs text-red-400">{error}</p>
              </div>
            )}

            <div className="flex gap-2">
              <button
                onClick={onClose}
                disabled={loading}
                className="flex-1 py-3 rounded-xl border border-[var(--border)] text-gray-400 font-semibold text-sm hover:bg-white/5 transition-all disabled:opacity-50"
              >
                Cancel
              </button>
              {hasPendingResult && (
                <button
                  onClick={onClear}
                  disabled={loading}
                  className="py-3 px-4 rounded-xl border border-[var(--border)] text-gray-400 font-semibold text-sm hover:bg-white/5 hover:text-red-400 transition-all disabled:opacity-50"
                  title="Remove the pending result — trade falls back to live market price when closed"
                >
                  Clear
                </button>
              )}
              <button
                onClick={onConfirm}
                disabled={loading || !canConfirm}
                className="flex-1 py-3 rounded-xl font-bold text-sm text-white shadow-lg disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-2 bg-gradient-to-r from-red-600 to-rose-600 shadow-red-500/20"
              >
                {loading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    <span>Saving...</span>
                  </>
                ) : (
                  <>
                    <Percent size={16} />
                    <span>Set Result</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </motion.div>
    </>
  );
}

// Small label/value row used inside ViewTradeModal
function DetailRow({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between py-2 border-b border-[var(--border)] last:border-0">
      <span className="text-xs text-gray-500">{label}</span>
      <span className="text-xs font-semibold text-foreground font-mono">{value}</span>
    </div>
  );
}

// View Trade Details Modal
function ViewTradeModal({ trade, onClose }: { trade: TradeItem; onClose: () => void }) {
  const isLong = trade.side === "BUY";
  const isProfitable = trade.pnl >= 0;

  return (
    <>
      <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50" onClick={onClose} />
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[95vw] max-w-md z-50"
      >
        <div className="glass-panel rounded-2xl overflow-hidden shadow-2xl border border-[var(--border)]">
          <div className="flex items-center justify-between p-5 border-b border-[var(--border)]">
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center border ${
                isLong ? "bg-green-500/10 border-green-500/20 text-green-400" : "bg-red-500/10 border-red-500/20 text-red-400"
              }`}>
                {isLong ? <TrendingUp className="w-5 h-5" /> : <TrendingDown className="w-5 h-5" />}
              </div>
              <div>
                <h3 className="text-base font-bold text-foreground">
                  {trade.coinSymbol}/USDT • {isLong ? "LONG" : "SHORT"} {trade.leverage}x
                </h3>
                <p className="text-[11px] text-gray-500">{trade.user.email}</p>
              </div>
            </div>
            <button onClick={onClose} className="p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-white/5">
              <X size={18} />
            </button>
          </div>

          <div className="p-5">
            <div className="mb-3">
              <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-md text-[10px] font-semibold border ${STATUS_COLORS[trade.status]}`}>
                {trade.status}
              </span>
              {trade.closeReason && (
                <span className="ml-2 text-[10px] text-gray-500">{trade.closeReason}</span>
              )}
            </div>

            <DetailRow label="Trade ID" value={trade.id} />
            <DetailRow label="Order Type" value={trade.orderType} />
            <DetailRow label="Leverage" value={`${trade.leverage}x`} />
            <DetailRow label="Margin" value={`$${trade.marginAmount.toFixed(2)}`} />
            <DetailRow label="Position Size" value={`$${trade.positionSize.toFixed(2)}`} />
            <DetailRow label="Quantity" value={trade.quantity.toFixed(6)} />
            <DetailRow label="Entry Price" value={`$${trade.entryPrice.toFixed(trade.entryPrice > 10 ? 2 : 6)}`} />
            {trade.exitPrice != null && (
              <DetailRow label="Exit Price" value={`$${trade.exitPrice.toFixed(trade.exitPrice > 10 ? 2 : 6)}`} />
            )}
            <DetailRow label="Fee" value={`$${trade.fee.toFixed(2)}`} />
            {trade.adminSetProfitPercent !== null && (
              <DetailRow
                label="Pending Set Result"
                value={
                  <span className="text-amber-400">
                    {trade.adminSetProfitPercent >= 0 ? "+" : ""}
                    {trade.adminSetProfitPercent.toFixed(2)}% of margin
                  </span>
                }
              />
            )}
            {trade.status !== "OPEN" && (
              <>
                <DetailRow
                  label="P&L"
                  value={
                    <span className={isProfitable ? "text-green-400" : "text-red-400"}>
                      {isProfitable ? "+" : ""}${trade.pnl.toFixed(2)} ({trade.pnlPercent >= 0 ? "+" : ""}{trade.pnlPercent.toFixed(2)}%)
                    </span>
                  }
                />
              </>
            )}
            <DetailRow label="Opened" value={new Date(trade.openedAt).toLocaleString()} />
            {trade.closedAt && <DetailRow label="Closed" value={new Date(trade.closedAt).toLocaleString()} />}

            <Link
              href={`/admin/users/${trade.user.id}`}
              className="mt-4 flex items-center justify-center gap-1.5 py-2.5 rounded-xl border border-[var(--border)] text-gray-400 hover:bg-white/5 hover:text-foreground text-xs font-semibold transition-all"
            >
              <Mail size={12} /> View {trade.user.email}&apos;s Account
            </Link>
          </div>
        </div>
      </motion.div>
    </>
  );
}

