// src/app/privacy/page.tsx
"use client";

import { motion } from "framer-motion";
import Link from "next/link";
import {
  Shield,
  Lock,
  Eye,
  Database,
  UserCheck,
  Globe,
  Mail,
  FileText,
  ChevronRight,
  ArrowLeft,
} from "lucide-react";
import { PLATFORM_CONFIG } from "@/config/constants";

const LAST_UPDATED = "January 2026";

const SECTIONS = [
  {
    id: "introduction",
    title: "1. Introduction",
    icon: FileText,
    color: "text-blue-400",
    bg: "bg-blue-500/10",
    content: [
      `Welcome to ${PLATFORM_CONFIG.name}. We respect your privacy and are committed to protecting your personal data. This Privacy Policy explains how we collect, use, store, and safeguard your information when you use our platform.`,
      "By accessing or using our services, you agree to the practices described in this policy. Please read it carefully.",
    ],
  },
  {
    id: "information-collected",
    title: "2. Information We Collect",
    icon: Database,
    color: "text-purple-400",
    bg: "bg-purple-500/10",
    content: [
      "We collect the following categories of information to provide and improve our services:",
    ],
    list: [
      {
        label: "Account Information",
        text: "Email address, phone number, username, and password (encrypted using bcrypt).",
      },
      {
        label: "Identity Verification (KYC)",
        text: "Full name, date of birth, government-issued ID documents, and selfie images for compliance.",
      },
      {
        label: "Financial Data",
        text: "Deposit history, withdrawal records, wallet addresses, transaction hashes, and payment screenshots.",
      },
      {
        label: "Technical Data",
        text: "IP address, browser type, device information, session tokens, and access logs.",
      },
      {
        label: "Communication Data",
        text: "Support chat messages, attachments, and email correspondence.",
      },
    ],
  },
  {
    id: "how-we-use",
    title: "3. How We Use Your Information",
    icon: Eye,
    color: "text-green-400",
    bg: "bg-green-500/10",
    content: ["We use the collected information for the following purposes:"],
    list: [
      { label: "Service Delivery", text: "Process deposits, withdrawals, and trading operations." },
      { label: "Identity Verification", text: "Comply with KYC and anti-money laundering regulations." },
      { label: "Security", text: "Detect and prevent fraud, unauthorized access, and suspicious activity." },
      { label: "Customer Support", text: "Respond to your queries and resolve issues." },
      { label: "Platform Improvement", text: "Analyze usage patterns to enhance features and performance." },
      { label: "Legal Compliance", text: "Meet regulatory and legal obligations in applicable jurisdictions." },
    ],
  },
  {
    id: "data-security",
    title: "4. Data Security",
    icon: Lock,
    color: "text-amber-400",
    bg: "bg-amber-500/10",
    content: [
      "We implement industry-standard security measures to protect your data:",
    ],
    list: [
      { label: "Password Hashing", text: "All passwords are hashed using bcrypt with 12 salt rounds. We never store passwords in plaintext." },
      { label: "Secure Sessions", text: "Authentication uses JWT tokens stored in httpOnly cookies, protected from XSS attacks." },
      { label: "Encrypted Connections", text: "All data transmission is secured via HTTPS in production." },
      { label: "Database Protection", text: "Our database is access-controlled with strict permissions." },
      { label: "Regular Audits", text: "We continuously monitor systems for vulnerabilities and potential breaches." },
    ],
  },
  {
    id: "data-sharing",
    title: "5. Data Sharing & Third Parties",
    icon: Globe,
    color: "text-cyan-400",
    bg: "bg-cyan-500/10",
    content: [
      "We do NOT sell your personal data. We may share information only in these limited circumstances:",
    ],
    list: [
      { label: "Service Providers", text: "Trusted third parties (e.g., blockchain APIs, cloud hosting) who help us operate the platform." },
      { label: "Legal Requirements", text: "When required by law, court order, or government request." },
      { label: "Fraud Prevention", text: "With other financial institutions to prevent illegal activity." },
      { label: "Business Transfers", text: "In case of merger, acquisition, or sale of assets (with prior notification)." },
    ],
  },
  {
    id: "your-rights",
    title: "6. Your Rights",
    icon: UserCheck,
    color: "text-pink-400",
    bg: "bg-pink-500/10",
    content: ["You have the following rights regarding your personal data:"],
    list: [
      { label: "Right to Access", text: "Request a copy of the personal data we hold about you." },
      { label: "Right to Correction", text: "Update or correct inaccurate information in your account." },
      { label: "Right to Deletion", text: "Request deletion of your account and associated data (subject to legal retention requirements)." },
      { label: "Right to Withdraw Consent", text: "Opt out of non-essential data processing." },
      { label: "Right to Object", text: "Object to certain types of data processing." },
      { label: "Right to Portability", text: "Request your data in a portable format." },
    ],
  },
  {
    id: "data-retention",
    title: "7. Data Retention",
    icon: Database,
    color: "text-indigo-400",
    bg: "bg-indigo-500/10",
    content: [
      "We retain your personal data only as long as necessary to fulfill the purposes described in this policy or as required by law.",
      "Transaction records and KYC documents are retained for a minimum of 5 years to comply with financial regulations, even after account closure.",
      "Inactive accounts may be archived after 24 months of no activity. Users will be notified before any data deletion.",
    ],
  },
  {
    id: "cookies",
    title: "8. Cookies & Tracking",
    icon: Eye,
    color: "text-orange-400",
    bg: "bg-orange-500/10",
    content: [
      "We use essential cookies to keep you logged in and maintain your session. These cookies are necessary for the platform to function and cannot be disabled.",
      "We do not use third-party advertising or tracking cookies. Your browsing activity on our platform is not shared with external advertisers.",
    ],
  },
  {
    id: "international",
    title: "9. International Data Transfers",
    icon: Globe,
    color: "text-teal-400",
    bg: "bg-teal-500/10",
    content: [
      "Your data may be processed and stored in countries outside your jurisdiction. By using our platform, you consent to such transfers.",
      "We ensure that any international transfers comply with applicable data protection laws and implement appropriate safeguards.",
    ],
  },
  {
    id: "children",
    title: "10. Children's Privacy",
    icon: Shield,
    color: "text-red-400",
    bg: "bg-red-500/10",
    content: [
      `${PLATFORM_CONFIG.name} is not intended for users under the age of 18. We do not knowingly collect personal information from minors.`,
      "If we discover that a minor has provided us with personal data, we will delete such information immediately.",
    ],
  },
  {
    id: "changes",
    title: "11. Changes to This Policy",
    icon: FileText,
    color: "text-yellow-400",
    bg: "bg-yellow-500/10",
    content: [
      "We may update this Privacy Policy from time to time to reflect changes in our practices, technology, or legal requirements.",
      "Significant changes will be communicated via email or in-app notification. The 'Last Updated' date at the top of this page indicates when the policy was last revised.",
      "Continued use of the platform after changes constitutes acceptance of the updated policy.",
    ],
  },
  {
    id: "contact",
    title: "12. Contact Us",
    icon: Mail,
    color: "text-emerald-400",
    bg: "bg-emerald-500/10",
    content: [
      "If you have any questions, concerns, or requests regarding this Privacy Policy or your personal data, please contact us:",
    ],
    contactInfo: true,
  },
];

export default function PrivacyPolicyPage() {
  return (
    <div className="min-h-full mesh-bg">
      <div className="max-w-4xl mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
        {/* ═══════════ BACK LINK ═══════════ */}
        <motion.div
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 1, x: 0 }}
        >
          <Link href="/">
            <button className="inline-flex items-center gap-1.5 text-xs text-gray-500 hover:text-[var(--accent)] transition-colors">
              <ArrowLeft size={14} />
              Back to Home
            </button>
          </Link>
        </motion.div>

        {/* ═══════════ HEADER ═══════════ */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="relative overflow-hidden rounded-2xl border border-[var(--border)] bg-gradient-to-br from-[var(--accent)]/10 via-purple-500/5 to-transparent p-6 sm:p-8"
        >
          <div className="absolute -top-20 -right-20 w-64 h-64 rounded-full bg-[var(--accent)]/10 blur-3xl pointer-events-none" />

          <div className="relative z-10">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-xl bg-[var(--accent)]/15 flex items-center justify-center">
                <Shield size={22} className="text-[var(--accent)]" />
              </div>
              <div>
                <h1 className="text-2xl sm:text-3xl font-bold text-foreground">
                  Privacy Policy
                </h1>
                <p className="text-xs text-gray-500 mt-0.5">
                  Last Updated: {LAST_UPDATED}
                </p>
              </div>
            </div>

            <p className="text-sm text-gray-400 leading-relaxed max-w-2xl">
              At {PLATFORM_CONFIG.name}, your privacy is our priority. This policy outlines how we handle your personal data with transparency, security, and respect.
            </p>
          </div>
        </motion.div>

        {/* ═══════════ TABLE OF CONTENTS ═══════════ */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="glass-panel rounded-xl p-5"
        >
          <div className="text-[10px] uppercase tracking-wider text-gray-500 font-semibold mb-3">
            Table of Contents
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
            {SECTIONS.map((section) => (
              <a
                key={section.id}
                href={`#${section.id}`}
                className="flex items-center gap-2 px-2 py-1.5 rounded-lg text-xs text-gray-400 hover:text-[var(--accent)] hover:bg-white/[0.03] transition-colors"
              >
                <ChevronRight size={12} className="opacity-50" />
                <span>{section.title}</span>
              </a>
            ))}
          </div>
        </motion.div>

        {/* ═══════════ SECTIONS ═══════════ */}
        <div className="space-y-4">
          {SECTIONS.map((section, idx) => {
            const Icon = section.icon;
            return (
              <motion.section
                key={section.id}
                id={section.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 + idx * 0.03 }}
                className="glass-panel rounded-xl p-5 sm:p-6 scroll-mt-20"
              >
                <div className="flex items-start gap-3 mb-4">
                  <div className={`w-9 h-9 rounded-lg ${section.bg} flex items-center justify-center shrink-0`}>
                    <Icon size={16} className={section.color} />
                  </div>
                  <h2 className="text-base sm:text-lg font-bold text-foreground pt-1">
                    {section.title}
                  </h2>
                </div>

                <div className="space-y-3 pl-0 sm:pl-12">
                  {section.content.map((para, i) => (
                    <p key={i} className="text-sm text-gray-400 leading-relaxed">
                      {para}
                    </p>
                  ))}

                  {section.list && (
                    <ul className="space-y-2.5 mt-3">
                      {section.list.map((item, i) => (
                        <li
                          key={i}
                          className="flex items-start gap-2.5 p-3 rounded-lg bg-white/[0.02] border border-[var(--border)]"
                        >
                          <div className="w-1 h-1 rounded-full bg-[var(--accent)] mt-2 shrink-0" />
                          <div className="flex-1">
                            <span className="text-xs font-semibold text-foreground">
                              {item.label}:
                            </span>{" "}
                            <span className="text-xs text-gray-400 leading-relaxed">
                              {item.text}
                            </span>
                          </div>
                        </li>
                      ))}
                    </ul>
                  )}

                  {section.contactInfo && (
                    <div className="mt-4 p-4 rounded-xl bg-[var(--accent)]/[0.05] border border-[var(--accent)]/15">
                      <div className="flex items-center gap-2 mb-2">
                        <Mail size={14} className="text-[var(--accent)]" />
                        <span className="text-xs font-semibold text-foreground">
                          Email Support
                        </span>
                      </div>
                      <a
                        href={`mailto:${PLATFORM_CONFIG.SUPPORT_EMAIL}`}
                        className="text-sm text-[var(--accent)] hover:underline font-mono"
                      >
                        {PLATFORM_CONFIG.SUPPORT_EMAIL}
                      </a>
                      <p className="text-[11px] text-gray-500 mt-2">
                        You can also reach us via the in-app{" "}
                        <Link href="/chat" className="text-[var(--accent)] hover:underline">
                          Live Chat
                        </Link>{" "}
                        feature.
                      </p>
                    </div>
                  )}
                </div>
              </motion.section>
            );
          })}
        </div>

        {/* ═══════════ FOOTER ═══════════ */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="flex items-start gap-2.5 p-4 rounded-xl bg-white/[0.02] border border-[var(--border)]"
        >
          <Shield size={14} className="text-gray-500 shrink-0 mt-0.5" />
          <p className="text-xs text-gray-500 leading-relaxed">
            This document was last updated on {LAST_UPDATED}. By continuing to use {PLATFORM_CONFIG.name}, you acknowledge that you have read and agree to this Privacy Policy. Also see our{" "}
            <Link href="/terms" className="text-[var(--accent)] hover:underline">
              Terms of Service
            </Link>
            .
          </p>
        </motion.div>
      </div>
    </div>
  );
}