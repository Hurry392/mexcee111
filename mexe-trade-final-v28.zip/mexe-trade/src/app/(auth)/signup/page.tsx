// src/app/(auth)/signup/page.tsx
"use client";

import { useSearchParams } from "next/navigation";
import { authAPI } from "@/lib/api";
import { useAuthStore } from "@/store/authStore";
import { useState, useEffect, Suspense } from "react";
import Link from "next/link";
import { motion, AnimatePresence } from "framer-motion";
import {
  Mail,
  Phone,
  Lock,
  Eye,
  EyeOff,
  Gift,
  AlertCircle,
  CheckCircle2,
  Loader2,
  ArrowRight,
  Sparkles,
} from "lucide-react";

type AuthMethod = "email" | "phone";

// ─── Wrap in Suspense because useSearchParams requires it ───
export default function SignupPage() {
  return (
    <Suspense fallback={<SignupSkeleton />}>
      <SignupForm />
    </Suspense>
  );
}

function SignupSkeleton() {
  return (
    <div className="flex items-center justify-center py-20">
      <Loader2 className="w-6 h-6 text-[var(--accent)] animate-spin" />
    </div>
  );
}

function SignupForm() {
  const [method, setMethod] = useState<AuthMethod>("email");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [agreed, setAgreed] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const searchParams = useSearchParams();
  const { setAuth } = useAuthStore();

  // ─── Track if referral code came from URL (for visual indicator) ───
  const [referredFromLink, setReferredFromLink] = useState(false);

  // Form state
  const [formData, setFormData] = useState({
    email: "",
    phone: "",
    password: "",
    confirmPassword: "",
    referralCode: "",
  });

  // ─── Auto-fill referral code from URL on mount ───
  useEffect(() => {
    const refFromUrl = searchParams.get("ref");
    if (refFromUrl) {
      const cleanCode = refFromUrl.trim().toUpperCase();
      setFormData((prev) => ({ ...prev, referralCode: cleanCode }));
      setReferredFromLink(true);
    }
  }, [searchParams]);

  const handleChange = (field: keyof typeof formData, value: string) => {
    setFormData({ ...formData, [field]: value });
    if (error) setError("");
    // If user manually edits referral code, remove "from link" indicator
    if (field === "referralCode") {
      setReferredFromLink(false);
    }
  };

  // Password strength check
  const getPasswordStrength = () => {
    const pw = formData.password;
    if (!pw) return { score: 0, label: "", color: "" };
    let score = 0;
    if (pw.length >= 8) score++;
    if (/[A-Z]/.test(pw)) score++;
    if (/[a-z]/.test(pw)) score++;
    if (/[0-9]/.test(pw)) score++;
    if (/[^A-Za-z0-9]/.test(pw)) score++;

    if (score <= 2) return { score, label: "Weak", color: "bg-red-500" };
    if (score <= 3) return { score, label: "Fair", color: "bg-yellow-500" };
    if (score <= 4) return { score, label: "Good", color: "bg-blue-500" };
    return { score, label: "Strong", color: "bg-green-500" };
  };

  const strength = getPasswordStrength();
  const passwordsMatch =
    formData.password && formData.confirmPassword && formData.password === formData.confirmPassword;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!agreed) {
      setError("You must agree to the User Agreement and Privacy Policy");
      return;
    }

    if (formData.password !== formData.confirmPassword) {
      setError("Passwords do not match");
      return;
    }

    if (formData.password.length < 8) {
      setError("Password must be at least 8 characters");
      return;
    }

    setLoading(true);

    const result = await authAPI.register({
      method,
      email: method === "email" ? formData.email : undefined,
      phone: method === "phone" ? formData.phone : undefined,
      password: formData.password,
      referralCode: formData.referralCode || undefined,
    });

    setLoading(false);

    if (result.error) {
      setError(result.error);
      return;
    }

   if (result.user && result.token) {
      setAuth(result.user, result.token);
      // Small delay to ensure cookie propagates, then hard navigate
      // (Vercel serverless can have cookie race conditions with router.push)
      setTimeout(() => {
        window.location.href = "/";
      }, 150);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
    >
      {/* Header */}
      <div className="mb-6">
        <h2 className="text-2xl sm:text-3xl font-bold text-foreground mb-2">
          Create your account
        </h2>
        <p className="text-sm text-gray-500">
          Get started with Premium Exchange in seconds
        </p>
      </div>

      {/* ═══════════ REFERRAL FROM LINK BANNER ═══════════ */}
      <AnimatePresence>
        {referredFromLink && (
          <motion.div
            initial={{ opacity: 0, y: -10, height: 0 }}
            animate={{ opacity: 1, y: 0, height: "auto" }}
            exit={{ opacity: 0, y: -10, height: 0 }}
            className="mb-5 flex items-start gap-3 p-3.5 rounded-xl bg-gradient-to-r from-[var(--accent)]/10 to-purple-500/10 border border-[var(--accent)]/25"
          >
            <div className="w-8 h-8 rounded-lg bg-[var(--accent)]/15 flex items-center justify-center shrink-0">
              <Sparkles size={14} className="text-[var(--accent)]" />
            </div>
            <div className="flex-1">
              <p className="text-sm font-semibold text-foreground mb-0.5">
                You&apos;ve been invited!
              </p>
              <p className="text-xs text-gray-400">
                Referral code{" "}
                <span className="font-mono font-bold text-[var(--accent)]">
                  {formData.referralCode}
                </span>{" "}
                applied automatically
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Method Switcher (Email / Phone) */}
      <div className="relative flex p-1 mb-6 rounded-xl bg-white/[0.03] border border-[var(--border)]">
        {(["email", "phone"] as AuthMethod[]).map((m) => (
          <button
            key={m}
            type="button"
            onClick={() => setMethod(m)}
            className={`relative flex-1 flex items-center justify-center gap-2 py-2.5 text-sm font-medium rounded-lg transition-colors z-10 ${
              method === m ? "text-white" : "text-gray-500 hover:text-gray-300"
            }`}
          >
            {method === m && (
              <motion.div
                layoutId="authMethodPill"
                className="absolute inset-0 rounded-lg bg-gradient-to-r from-[var(--accent)] to-purple-500"
                transition={{ type: "spring", stiffness: 300, damping: 30 }}
              />
            )}
            {m === "email" ? <Mail size={15} className="relative z-10" /> : <Phone size={15} className="relative z-10" />}
            <span className="relative z-10 capitalize">{m}</span>
          </button>
        ))}
      </div>

      {/* Error Message */}
      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="mb-4 flex items-start gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/20"
          >
            <AlertCircle size={16} className="text-red-400 shrink-0 mt-0.5" />
            <p className="text-xs text-red-400">{error}</p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Form */}
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Email or Phone Field */}
        <AnimatePresence mode="wait">
          {method === "email" ? (
            <motion.div
              key="email"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 10 }}
              transition={{ duration: 0.2 }}
            >
              <label className="block text-xs font-medium text-gray-400 mb-2">
                Email Address
              </label>
              <div className="relative">
                <Mail
                  size={16}
                  className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-500"
                />
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleChange("email", e.target.value)}
                  placeholder="you@example.com"
                  required
                  className="w-full pl-10 pr-4 py-3 bg-white/[0.03] border border-[var(--border)] rounded-xl text-sm text-foreground placeholder:text-gray-600 focus:outline-none focus:border-[var(--accent)]/50 focus:bg-white/[0.05] transition-all"
                />
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="phone"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 10 }}
              transition={{ duration: 0.2 }}
            >
              <label className="block text-xs font-medium text-gray-400 mb-2">
                Phone Number
              </label>
              <div className="relative">
                <Phone
                  size={16}
                  className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-500"
                />
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => handleChange("phone", e.target.value)}
                  placeholder="+1 (555) 000-0000"
                  required
                  className="w-full pl-10 pr-4 py-3 bg-white/[0.03] border border-[var(--border)] rounded-xl text-sm text-foreground placeholder:text-gray-600 focus:outline-none focus:border-[var(--accent)]/50 focus:bg-white/[0.05] transition-all"
                />
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Password */}
        <div>
          <label className="block text-xs font-medium text-gray-400 mb-2">
            Password
          </label>
          <div className="relative">
            <Lock
              size={16}
              className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-500"
            />
            <input
              type={showPassword ? "text" : "password"}
              value={formData.password}
              onChange={(e) => handleChange("password", e.target.value)}
              placeholder="Create a strong password"
              required
              className="w-full pl-10 pr-11 py-3 bg-white/[0.03] border border-[var(--border)] rounded-xl text-sm text-foreground placeholder:text-gray-600 focus:outline-none focus:border-[var(--accent)]/50 focus:bg-white/[0.05] transition-all"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300 transition-colors"
            >
              {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          </div>

          {/* Password strength meter */}
          {formData.password && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              className="mt-2 flex items-center gap-2"
            >
              <div className="flex-1 grid grid-cols-5 gap-1">
                {[1, 2, 3, 4, 5].map((bar) => (
                  <div
                    key={bar}
                    className={`h-1 rounded-full transition-colors ${
                      bar <= strength.score ? strength.color : "bg-white/10"
                    }`}
                  />
                ))}
              </div>
              <span
                className={`text-[10px] font-semibold ${
                  strength.score <= 2
                    ? "text-red-400"
                    : strength.score <= 3
                    ? "text-yellow-400"
                    : strength.score <= 4
                    ? "text-blue-400"
                    : "text-green-400"
                }`}
              >
                {strength.label}
              </span>
            </motion.div>
          )}
        </div>

        {/* Confirm Password */}
        <div>
          <label className="block text-xs font-medium text-gray-400 mb-2">
            Confirm Password
          </label>
          <div className="relative">
            <Lock
              size={16}
              className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-500"
            />
            <input
              type={showConfirmPassword ? "text" : "password"}
              value={formData.confirmPassword}
              onChange={(e) => handleChange("confirmPassword", e.target.value)}
              placeholder="Re-enter your password"
              required
              className="w-full pl-10 pr-11 py-3 bg-white/[0.03] border border-[var(--border)] rounded-xl text-sm text-foreground placeholder:text-gray-600 focus:outline-none focus:border-[var(--accent)]/50 focus:bg-white/[0.05] transition-all"
            />
            <button
              type="button"
              onClick={() => setShowConfirmPassword(!showConfirmPassword)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300 transition-colors"
            >
              {showConfirmPassword ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          </div>
          {passwordsMatch && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="mt-2 flex items-center gap-1.5 text-[11px] text-green-400"
            >
              <CheckCircle2 size={12} />
              <span>Passwords match</span>
            </motion.div>
          )}
        </div>

        {/* Referral Code (Optional) */}
        <div>
          <label className="block text-xs font-medium text-gray-400 mb-2 flex items-center justify-between">
            <span>
              Referral Code{" "}
              {!referredFromLink && <span className="text-gray-600">(Optional)</span>}
            </span>
            {referredFromLink && (
              <span className="text-[10px] text-[var(--accent)] font-semibold flex items-center gap-1">
                <Sparkles size={10} />
                From invite link
              </span>
            )}
          </label>
          <div className="relative">
            <Gift
              size={16}
              className={`absolute left-3.5 top-1/2 -translate-y-1/2 ${
                referredFromLink ? "text-[var(--accent)]" : "text-gray-500"
              }`}
            />
            <input
              type="text"
              value={formData.referralCode}
              onChange={(e) =>
                handleChange("referralCode", e.target.value.toUpperCase())
              }
              placeholder="Enter referral code"
              maxLength={12}
              className={`w-full pl-10 pr-4 py-3 bg-white/[0.03] border rounded-xl text-sm text-foreground placeholder:text-gray-600 focus:outline-none focus:bg-white/[0.05] transition-all uppercase tracking-wider ${
                referredFromLink
                  ? "border-[var(--accent)]/40 focus:border-[var(--accent)]/60"
                  : "border-[var(--border)] focus:border-[var(--accent)]/50"
              }`}
            />
          </div>
        </div>

        {/* Agreement Checkbox */}
        <div className="flex items-start gap-3">
          <button
            type="button"
            role="checkbox"
            aria-checked={agreed}
            onClick={() => {
              setAgreed(!agreed);
              if (error) setError("");
            }}
            style={{ touchAction: "manipulation" }}
            className="relative shrink-0 mt-0.5 w-6 h-6 -m-1 p-1 flex items-center justify-center"
          >
            <span
              className={`w-4 h-4 rounded border transition-all flex items-center justify-center ${
                agreed
                  ? "bg-[var(--accent)] border-[var(--accent)]"
                  : "border-[var(--border)] bg-white/[0.03]"
              }`}
            >
              {agreed && (
                <motion.span
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ duration: 0.15 }}
                  className="flex"
                >
                  <CheckCircle2 size={11} className="text-white" />
                </motion.span>
              )}
            </span>
          </button>
          <span className="text-xs text-gray-400 leading-relaxed">
            I agree to the{" "}
            <Link
              href="/terms"
              className="text-[var(--accent)] hover:underline font-medium"
            >
              User Agreement
            </Link>{" "}
            and{" "}
            <Link
              href="/privacy"
              className="text-[var(--accent)] hover:underline font-medium"
            >
              Privacy Policy
            </Link>
          </span>
        </div>

        {/* Submit Button — kept tappable even when unchecked so users get
            a clear error message instead of a mysteriously dead button */}
        <button
          type="submit"
          disabled={loading}
          style={{ touchAction: "manipulation" }}
          className={`w-full flex items-center justify-center gap-2 py-3 mt-2 rounded-xl bg-gradient-to-r from-[var(--accent)] to-purple-500 text-white font-semibold text-sm hover:opacity-95 transition-all active:scale-[0.98] shadow-lg shadow-[var(--accent)]/20 disabled:opacity-50 disabled:cursor-not-allowed disabled:active:scale-100 ${
            !agreed && !loading ? "opacity-60" : ""
          }`}
        >
          {loading ? (
            <>
              <Loader2 size={16} className="animate-spin" />
              Creating Account...
            </>
          ) : (
            <>
              Create Account
              <ArrowRight size={16} />
            </>
          )}
        </button>
      </form>

      {/* Divider */}
      <div className="flex items-center gap-3 my-6">
        <div className="flex-1 h-px bg-[var(--border)]" />
        <span className="text-[10px] uppercase tracking-wider text-gray-500 font-medium">
          Already have an account
        </span>
        <div className="flex-1 h-px bg-[var(--border)]" />
      </div>

      {/* Login Link */}
      <Link href="/login">
        <button
          type="button"
          className="w-full py-3 rounded-xl border border-[var(--border)] text-sm font-semibold text-foreground hover:bg-white/[0.03] hover:border-[var(--accent)]/30 transition-all active:scale-[0.98]"
        >
          Log In Instead
        </button>
      </Link>
    </motion.div>
  );
}
