// src/app/(auth)/forgot-password/page.tsx
"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Link from "next/link";
import {
  Mail,
  ArrowLeft,
  Loader2,
  CheckCircle2,
  AlertCircle,
  MessageCircle,
  Shield,
} from "lucide-react";

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!email.trim()) {
      setError("Please enter your email address");
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      setError("Please enter a valid email address");
      return;
    }

    setLoading(true);

    // Simulate processing (no actual email sent yet — Phase 7 admin handles this)
    await new Promise((resolve) => setTimeout(resolve, 1500));

    setLoading(false);
    setSubmitted(true);
  };

  // ─── Success State ───
  if (submitted) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
      >
        <div className="text-center">
          <div className="w-16 h-16 rounded-2xl bg-green-500/15 border border-green-500/30 flex items-center justify-center mx-auto mb-5">
            <CheckCircle2 size={32} className="text-green-400" />
          </div>

          <h2 className="text-2xl font-bold text-foreground mb-2">
            Request Submitted
          </h2>
          <p className="text-sm text-gray-400 leading-relaxed mb-6 max-w-sm mx-auto">
            If an account exists with <span className="font-semibold text-foreground">{email}</span>,
            our support team will contact you with password reset instructions within 24 hours.
          </p>

          {/* Contact Support Option */}
          <div className="p-4 rounded-xl bg-[var(--accent)]/[0.05] border border-[var(--accent)]/20 mb-6 text-left">
            <div className="flex items-start gap-3">
              <div className="w-9 h-9 rounded-lg bg-[var(--accent)]/15 flex items-center justify-center shrink-0">
                <MessageCircle size={16} className="text-[var(--accent)]" />
              </div>
              <div>
                <p className="text-sm font-semibold text-foreground mb-0.5">
                  Need Faster Help?
                </p>
                <p className="text-xs text-gray-400 mb-2">
                  Contact our live support team for immediate assistance with account recovery.
                </p>
                <Link href="/chat">
                  <button className="text-xs font-semibold text-[var(--accent)] hover:underline">
                    Open Live Chat →
                  </button>
                </Link>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <Link href="/login">
              <button className="w-full py-3 rounded-xl bg-gradient-to-r from-[var(--accent)] to-purple-500 text-white font-semibold text-sm hover:opacity-95 transition-all active:scale-[0.98]">
                Back to Login
              </button>
            </Link>
            <Link href="/signup">
              <button className="w-full py-3 rounded-xl border border-[var(--border)] text-foreground font-semibold text-sm hover:bg-white/[0.03] transition-all">
                Create New Account
              </button>
            </Link>
          </div>
        </div>
      </motion.div>
    );
  }

  // ─── Form State ───
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
    >
      {/* Back Link */}
      <Link
        href="/login"
        className="inline-flex items-center gap-1.5 text-xs text-gray-500 hover:text-[var(--accent)] transition-colors mb-6"
      >
        <ArrowLeft size={14} />
        Back to Login
      </Link>

      {/* Header */}
      <div className="mb-6">
        <div className="w-14 h-14 rounded-2xl bg-[var(--accent)]/15 border border-[var(--accent)]/30 flex items-center justify-center mb-4">
          <Shield size={24} className="text-[var(--accent)]" />
        </div>
        <h2 className="text-2xl sm:text-3xl font-bold text-foreground mb-2">
          Reset Password
        </h2>
        <p className="text-sm text-gray-500">
          Enter your registered email address and our support team will help you regain access to your account.
        </p>
      </div>

      {/* Error */}
      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="mb-4 flex items-start gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/20"
          >
            <AlertCircle size={16} className="text-red-400 shrink-0 mt-0.5" />
            <p className="text-xs text-red-400">{error}</p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Form */}
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-xs font-medium text-gray-400 mb-2">
            Email Address
          </label>
          <div className="relative">
            <Mail
              size={16}
              className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-500"
            />
            <input
              type="email"
              value={email}
              onChange={(e) => {
                setEmail(e.target.value);
                if (error) setError("");
              }}
              placeholder="you@example.com"
              required
              className="w-full pl-10 pr-4 py-3 bg-white/[0.03] border border-[var(--border)] rounded-xl text-sm text-foreground placeholder:text-gray-600 focus:outline-none focus:border-[var(--accent)]/50 focus:bg-white/[0.05] transition-all"
            />
          </div>
        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-gradient-to-r from-[var(--accent)] to-purple-500 text-white font-semibold text-sm hover:opacity-95 transition-all active:scale-[0.98] shadow-lg shadow-[var(--accent)]/20 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {loading ? (
            <>
              <Loader2 size={16} className="animate-spin" />
              Submitting Request...
            </>
          ) : (
            "Submit Reset Request"
          )}
        </button>
      </form>

      {/* Help Info */}
      <div className="mt-6 p-4 rounded-xl bg-white/[0.02] border border-[var(--border)]">
        <h4 className="text-xs font-semibold text-foreground mb-2">
          How Password Reset Works:
        </h4>
        <ol className="space-y-2">
          {[
            "Submit your registered email address",
            "Our support team verifies your identity",
            "You receive reset instructions via email or chat",
            "Set your new password and login",
          ].map((step, i) => (
            <li key={i} className="flex items-start gap-2 text-[11px] text-gray-400">
              <span className="w-4 h-4 rounded-full bg-[var(--accent)]/15 flex items-center justify-center shrink-0 text-[9px] font-bold text-[var(--accent)] mt-0.5">
                {i + 1}
              </span>
              <span>{step}</span>
            </li>
          ))}
        </ol>
      </div>

      {/* Divider */}
      <div className="flex items-center gap-3 my-6">
        <div className="flex-1 h-px bg-[var(--border)]" />
        <span className="text-[10px] uppercase tracking-wider text-gray-500 font-medium">
          Remember your password?
        </span>
        <div className="flex-1 h-px bg-[var(--border)]" />
      </div>

      {/* Login Link */}
      <Link href="/login">
        <button
          type="button"
          className="w-full py-3 rounded-xl border border-[var(--border)] text-sm font-semibold text-foreground hover:bg-white/[0.03] hover:border-[var(--accent)]/30 transition-all active:scale-[0.98]"
        >
          Back to Login
        </button>
      </Link>
    </motion.div>
  );
}