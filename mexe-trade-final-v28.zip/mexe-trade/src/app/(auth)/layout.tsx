// src/app/(auth)/layout.tsx
"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowLeft, Shield, Zap, TrendingUp } from "lucide-react";
import { PLATFORM_CONFIG } from "@/config/constants";

export default function AuthLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="min-h-screen flex flex-col lg:flex-row">
      {/* ═══════════ LEFT — Branding Panel (Desktop Only) ═══════════ */}
      <div className="hidden lg:flex lg:w-[45%] xl:w-[40%] relative overflow-hidden bg-gradient-to-br from-[var(--accent)]/10 via-purple-500/5 to-transparent border-r border-[var(--border)]">
        {/* Decorative gradient blobs */}
        <div className="absolute -top-20 -left-20 w-96 h-96 rounded-full bg-[var(--accent)]/15 blur-3xl pointer-events-none" />
        <div className="absolute -bottom-20 -right-20 w-96 h-96 rounded-full bg-purple-500/10 blur-3xl pointer-events-none" />

        {/* Animated grid pattern */}
        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage:
              "linear-gradient(rgba(255,255,255,0.5) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.5) 1px, transparent 1px)",
            backgroundSize: "40px 40px",
          }}
        />

        <div className="relative z-10 flex flex-col justify-between p-10 xl:p-14 w-full">
          {/* Top — Brand */}
          <Link href="/" className="inline-flex items-center gap-2.5 group w-fit">
            <div className="flex items-center justify-center w-10 h-10 rounded-xl overflow-hidden group-hover:opacity-90 transition-all">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src="/logo.png" alt="Logo" className="w-full h-full object-cover" />
            </div>
            <div className="flex flex-col">
              <span className="font-bold text-base gradient-text leading-tight">
                {PLATFORM_CONFIG.name}
              </span>
              <span className="text-[10px] text-gray-500 leading-tight">
                Trading Platform
              </span>
            </div>
          </Link>

          {/* Middle — Hero */}
          <div className="space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h1 className="text-3xl xl:text-4xl font-bold text-foreground leading-tight mb-3">
                Welcome to the future of <span className="gradient-text">trading</span>
              </h1>
              <p className="text-sm xl:text-base text-gray-400 max-w-md leading-relaxed">
                Join thousands of traders accessing real-time markets, secure deposits, and professional-grade tools — all in one place.
              </p>
            </motion.div>

            {/* Feature Highlights */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.15 }}
              className="space-y-3 max-w-md"
            >
              {[
                {
                  icon: Shield,
                  title: "Bank-Grade Security",
                  desc: "Multi-layer protection for your assets",
                  color: "text-blue-400",
                  bg: "bg-blue-500/10",
                },
                {
                  icon: Zap,
                  title: "Lightning Fast Execution",
                  desc: "Trade in milliseconds, every time",
                  color: "text-yellow-400",
                  bg: "bg-yellow-500/10",
                },
                {
                  icon: TrendingUp,
                  title: "Real-Time Markets",
                  desc: "Live data from global exchanges",
                  color: "text-green-400",
                  bg: "bg-green-500/10",
                },
              ].map((item) => {
                const Icon = item.icon;
                return (
                  <div
                    key={item.title}
                    className="flex items-start gap-3 p-3 rounded-xl bg-white/[0.02] border border-[var(--border)]"
                  >
                    <div className={`w-9 h-9 rounded-lg ${item.bg} flex items-center justify-center shrink-0`}>
                      <Icon size={18} className={item.color} />
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-foreground">
                        {item.title}
                      </div>
                      <div className="text-xs text-gray-500 mt-0.5">
                        {item.desc}
                      </div>
                    </div>
                  </div>
                );
              })}
            </motion.div>
          </div>

          {/* Bottom — Stats */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="grid grid-cols-3 gap-4 pt-6 border-t border-[var(--border)]"
          >
            {[
              { value: "100+", label: "Crypto Pairs" },
              { value: "24/7", label: "Live Markets" },
              { value: "$0", label: "Trading Fees" },
            ].map((stat) => (
              <div key={stat.label}>
                <div className="text-lg xl:text-xl font-bold gradient-text">
                  {stat.value}
                </div>
                <div className="text-[10px] text-gray-500 uppercase tracking-wider mt-0.5">
                  {stat.label}
                </div>
              </div>
            ))}
          </motion.div>
        </div>
      </div>

      {/* ═══════════ RIGHT — Form Panel ═══════════ */}
      <div className="flex-1 flex flex-col">
        {/* Mobile Header */}
        <div className="lg:hidden flex items-center justify-between p-4 border-b border-[var(--border)]">
          <Link href="/" className="flex items-center gap-2">
            <div className="flex items-center justify-center w-8 h-8 rounded-lg overflow-hidden">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src="/logo.png" alt="Logo" className="w-full h-full object-cover" />
            </div>
            <span className="font-bold text-sm gradient-text">
              {PLATFORM_CONFIG.name}
            </span>
          </Link>
          <Link
            href="/"
            className="flex items-center gap-1.5 text-xs text-gray-500 hover:text-[var(--accent)] transition-colors"
          >
            <ArrowLeft size={14} />
            Back
          </Link>
        </div>

        {/* Form Container */}
        <div className="flex-1 flex items-center justify-center p-4 sm:p-6 lg:p-10">
          <div className="w-full max-w-md">{children}</div>
        </div>
      </div>
    </div>
  );
}