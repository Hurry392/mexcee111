// src/app/(auth)/login/page.tsx
"use client";

import { useRouter } from "next/navigation";
import { authAPI } from "@/lib/api";
import { useAuthStore } from "@/store/authStore";
import { useState } from "react";
import Link from "next/link";
import { motion, AnimatePresence } from "framer-motion";
import {
  Mail,
  Phone,
  Lock,
  Eye,
  EyeOff,
  AlertCircle,
  Loader2,
  ArrowRight,
} from "lucide-react";

type AuthMethod = "email" | "phone";

export default function LoginPage() {
  const [method, setMethod] = useState<AuthMethod>("email");
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const router = useRouter();
  const { setAuth } = useAuthStore();

  const [formData, setFormData] = useState({
    email: "",
    phone: "",
    password: "",
  });

  const handleChange = (field: keyof typeof formData, value: string) => {
    setFormData({ ...formData, [field]: value });
    if (error) setError("");
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    const result = await authAPI.login({
      method,
      email: method === "email" ? formData.email : undefined,
      phone: method === "phone" ? formData.phone : undefined,
      password: formData.password,
    });

    setLoading(false);

    if (result.error) {
      setError(result.error);
      return;
    }

    if (result.user && result.token) {
      setAuth(result.user, result.token);
      // Small delay to ensure cookie propagates, then hard navigate
      // (Vercel serverless can have cookie race conditions with router.push)
      setTimeout(() => {
        window.location.href = "/";
      }, 150);
    }
  };

  return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
      >
      {/* Header */}
      <div className="mb-6">
        <h2 className="text-2xl sm:text-3xl font-bold text-foreground mb-2">
          Welcome back
        </h2>
        <p className="text-sm text-gray-500">
          Log in to access your trading dashboard
        </p>
      </div>

      {/* Method Switcher */}
      <div className="relative flex p-1 mb-6 rounded-xl bg-white/[0.03] border border-[var(--border)]">
        {(["email", "phone"] as AuthMethod[]).map((m) => (
          <button
            key={m}
            type="button"
            onClick={() => setMethod(m)}
            className={`relative flex-1 flex items-center justify-center gap-2 py-2.5 text-sm font-medium rounded-lg transition-colors z-10 ${
              method === m ? "text-white" : "text-gray-500 hover:text-gray-300"
            }`}
          >
            {method === m && (
              <motion.div
                layoutId="authMethodPillLogin"
                className="absolute inset-0 rounded-lg bg-gradient-to-r from-[var(--accent)] to-purple-500"
                transition={{ type: "spring", stiffness: 300, damping: 30 }}
              />
            )}
            {m === "email" ? <Mail size={15} className="relative z-10" /> : <Phone size={15} className="relative z-10" />}
            <span className="relative z-10 capitalize">{m}</span>
          </button>
        ))}
      </div>

      {/* Error */}
      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="mb-4 flex items-start gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/20"
          >
            <AlertCircle size={16} className="text-red-400 shrink-0 mt-0.5" />
            <p className="text-xs text-red-400">{error}</p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Form */}
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Email or Phone */}
        <AnimatePresence mode="wait">
          {method === "email" ? (
            <motion.div
              key="email"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 10 }}
              transition={{ duration: 0.2 }}
            >
              <label className="block text-xs font-medium text-gray-400 mb-2">
                Email Address
              </label>
              <div className="relative">
                <Mail
                  size={16}
                  className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-500"
                />
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleChange("email", e.target.value)}
                  placeholder="you@example.com"
                  required
                  autoComplete="email"
                  className="w-full pl-10 pr-4 py-3 bg-white/[0.03] border border-[var(--border)] rounded-xl text-sm text-foreground placeholder:text-gray-600 focus:outline-none focus:border-[var(--accent)]/50 focus:bg-white/[0.05] transition-all"
                />
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="phone"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 10 }}
              transition={{ duration: 0.2 }}
            >
              <label className="block text-xs font-medium text-gray-400 mb-2">
                Phone Number
              </label>
              <div className="relative">
                <Phone
                  size={16}
                  className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-500"
                />
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => handleChange("phone", e.target.value)}
                  placeholder="+1 (555) 000-0000"
                  required
                  className="w-full pl-10 pr-4 py-3 bg-white/[0.03] border border-[var(--border)] rounded-xl text-sm text-foreground placeholder:text-gray-600 focus:outline-none focus:border-[var(--accent)]/50 focus:bg-white/[0.05] transition-all"
                />
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Password */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="block text-xs font-medium text-gray-400">
              Password
            </label>
            <Link
              href="/forgot-password"
              className="text-xs text-[var(--accent)] hover:underline font-medium"
            >
              Forgot password?
            </Link>
          </div>
          <div className="relative">
            <Lock
              size={16}
              className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-500"
            />
            <input
              type={showPassword ? "text" : "password"}
              value={formData.password}
              onChange={(e) => handleChange("password", e.target.value)}
              placeholder="Enter your password"
              required
              autoComplete="current-password"
              className="w-full pl-10 pr-11 py-3 bg-white/[0.03] border border-[var(--border)] rounded-xl text-sm text-foreground placeholder:text-gray-600 focus:outline-none focus:border-[var(--accent)]/50 focus:bg-white/[0.05] transition-all"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300 transition-colors"
            >
              {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          </div>
        </div>

        {/* Remember Me */}
        <label className="flex items-center gap-2.5 cursor-pointer group w-fit">
          <div className="relative">
            <input
              type="checkbox"
              checked={rememberMe}
              onChange={(e) => setRememberMe(e.target.checked)}
              className="peer sr-only"
            />
            <div className="w-4 h-4 rounded border border-[var(--border)] bg-white/[0.03] peer-checked:bg-[var(--accent)] peer-checked:border-[var(--accent)] transition-all flex items-center justify-center">
              {rememberMe && (
                <motion.svg
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  width="10"
                  height="10"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="white"
                  strokeWidth="3"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <polyline points="20 6 9 17 4 12"></polyline>
                </motion.svg>
              )}
            </div>
          </div>
          <span className="text-xs text-gray-400 group-hover:text-gray-300 transition-colors">
            Keep me logged in
          </span>
        </label>

        {/* Submit */}
        <button
          type="submit"
          disabled={loading}
          className="w-full flex items-center justify-center gap-2 py-3 mt-2 rounded-xl bg-gradient-to-r from-[var(--accent)] to-purple-500 text-white font-semibold text-sm hover:opacity-95 transition-all active:scale-[0.98] shadow-lg shadow-[var(--accent)]/20 disabled:opacity-50 disabled:cursor-not-allowed disabled:active:scale-100"
        >
          {loading ? (
            <>
              <Loader2 size={16} className="animate-spin" />
              Logging In...
            </>
          ) : (
            <>
              Log In
              <ArrowRight size={16} />
            </>
          )}
        </button>
      </form>

      {/* Divider */}
      <div className="flex items-center gap-3 my-6">
        <div className="flex-1 h-px bg-[var(--border)]" />
        <span className="text-[10px] uppercase tracking-wider text-gray-500 font-medium">
          New to MEXC Trade
        </span>
        <div className="flex-1 h-px bg-[var(--border)]" />
      </div>

      {/* Signup Link */}
      <Link href="/signup">
        <button
          type="button"
          className="w-full py-3 rounded-xl border border-[var(--border)] text-sm font-semibold text-foreground hover:bg-white/[0.03] hover:border-[var(--accent)]/30 transition-all active:scale-[0.98]"
        >
          Create New Account
        </button>
      </Link>
    </motion.div>
  );
}
