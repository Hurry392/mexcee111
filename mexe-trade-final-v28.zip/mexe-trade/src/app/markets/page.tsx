// src/app/markets/page.tsx
"use client";

import AnimatedPrice from "@/components/markets/AnimatedPrice";
import { useState } from "react";
import { motion } from "framer-motion";
import {
  TrendingUp,
  TrendingDown,
  RefreshCw,
  Search,
  Star,
  ArrowUpDown,
  Loader2,
  AlertCircle,
} from "lucide-react";
import Link from "next/link";
import { useMarkets } from "@/hooks/useMarkets";
import {
  formatPrice,
  formatLargeNumber,
  formatPercent,
  MarketCoin,
} from "@/lib/markets";

type SortKey = "rank" | "price" | "change" | "volume" | "marketcap";
type SortDir = "asc" | "desc";

export default function MarketsPage() {
  const { markets, loading, error, refetch } = useMarkets(30000);
  const [search, setSearch] = useState("");
  const [sortKey, setSortKey] = useState<SortKey>("rank");
  const [sortDir, setSortDir] = useState<SortDir>("asc");
  const [refreshing, setRefreshing] = useState(false);

  const handleRefresh = async () => {
    setRefreshing(true);
    await refetch();
    setTimeout(() => setRefreshing(false), 500);
  };

  const handleSort = (key: SortKey) => {
    if (sortKey === key) {
      setSortDir(sortDir === "asc" ? "desc" : "asc");
    } else {
      setSortKey(key);
      setSortDir("desc");
    }
  };

  // Filter + sort markets
  const filteredMarkets = markets
    .filter(
      (m) =>
        m.name.toLowerCase().includes(search.toLowerCase()) ||
        m.symbol.toLowerCase().includes(search.toLowerCase())
    )
    .sort((a, b) => {
      let aVal: number, bVal: number;
      switch (sortKey) {
        case "rank":
          aVal = a.market_cap_rank;
          bVal = b.market_cap_rank;
          break;
        case "price":
          aVal = a.current_price;
          bVal = b.current_price;
          break;
        case "change":
          aVal = a.price_change_percentage_24h;
          bVal = b.price_change_percentage_24h;
          break;
        case "volume":
          aVal = a.total_volume;
          bVal = b.total_volume;
          break;
        case "marketcap":
          aVal = a.market_cap;
          bVal = b.market_cap;
          break;
      }
      return sortDir === "asc" ? aVal - bVal : bVal - aVal;
    });

  // Calculate market stats
  const totalMarketCap = markets.reduce((sum, m) => sum + m.market_cap, 0);
  const totalVolume = markets.reduce((sum, m) => sum + m.total_volume, 0);
  const gainers = markets.filter(m => m.price_change_percentage_24h > 0).length;
  const losers = markets.filter(m => m.price_change_percentage_24h < 0).length;

  return (
    <div className="min-h-full mesh-bg">
      <div className="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8 space-y-5">
        {/* ═══════════ HEADER ═══════════ */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3"
        >
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <h1 className="text-2xl sm:text-3xl font-bold text-foreground">
                Live Markets
              </h1>
              <div className="flex items-center gap-1.5 px-2 py-1 rounded-full bg-green-500/10 border border-green-500/20">
                <span className="relative flex h-1.5 w-1.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75" />
                  <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-green-500" />
                </span>
                <span className="text-[10px] uppercase tracking-wider font-bold text-green-400">
                  Live
                </span>
              </div>
            </div>
            <p className="text-sm text-gray-500">
              Real-time prices • Auto-refresh every 30s
            </p>
          </div>

          <button
            onClick={handleRefresh}
            disabled={refreshing}
            className="flex items-center gap-2 px-3 py-2 rounded-lg bg-white/[0.03] border border-[var(--border)] text-xs font-semibold text-foreground hover:bg-white/[0.06] transition-all disabled:opacity-50"
          >
            <RefreshCw
              size={14}
              className={refreshing ? "animate-spin" : ""}
            />
            Refresh
          </button>
        </motion.div>

        {/* ═══════════ GLOBAL STATS ═══════════ */}
        {!loading && markets.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="grid grid-cols-2 lg:grid-cols-4 gap-3"
          >
            {[
              { label: "Market Cap", value: `$${formatLargeNumber(totalMarketCap)}`, color: "text-blue-400" },
              { label: "24h Volume", value: `$${formatLargeNumber(totalVolume)}`, color: "text-purple-400" },
              { label: "Gainers", value: gainers.toString(), color: "text-green-400" },
              { label: "Losers", value: losers.toString(), color: "text-red-400" },
            ].map((stat) => (
              <div
                key={stat.label}
                className="glass-panel rounded-xl p-3 sm:p-4"
              >
                <div className="text-[10px] text-gray-500 uppercase tracking-wider font-semibold mb-1">
                  {stat.label}
                </div>
                <div className={`text-lg sm:text-xl font-bold ${stat.color} font-mono`}>
                  {stat.value}
                </div>
              </div>
            ))}
          </motion.div>
        )}

        {/* ═══════════ SEARCH BAR ═══════════ */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="relative"
        >
          <Search
            size={16}
            className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-500"
          />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by name or symbol..."
            className="w-full pl-10 pr-4 py-3 bg-white/[0.03] border border-[var(--border)] rounded-xl text-sm text-foreground placeholder:text-gray-600 focus:outline-none focus:border-[var(--accent)]/50 focus:bg-white/[0.05] transition-all"
          />
        </motion.div>

        {/* ═══════════ ERROR STATE ═══════════ */}
        {error && (
          <div className="flex items-center gap-2 p-4 rounded-xl bg-red-500/10 border border-red-500/20">
            <AlertCircle size={16} className="text-red-400" />
            <span className="text-sm text-red-400">{error}</span>
          </div>
        )}

        {/* ═══════════ MARKETS TABLE ═══════════ */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="glass-panel rounded-2xl overflow-hidden"
        >
          {/* Table Header (Desktop) */}
          <div className="hidden md:grid grid-cols-12 gap-4 px-5 py-3 border-b border-[var(--border)] text-[10px] uppercase tracking-wider font-semibold text-gray-500">
            <button
              onClick={() => handleSort("rank")}
              className="col-span-1 flex items-center gap-1 hover:text-foreground transition-colors"
            >
              # <ArrowUpDown size={10} />
            </button>
            <div className="col-span-4">Asset</div>
            <button
              onClick={() => handleSort("price")}
              className="col-span-2 flex items-center justify-end gap-1 hover:text-foreground transition-colors"
            >
              Price <ArrowUpDown size={10} />
            </button>
            <button
              onClick={() => handleSort("change")}
              className="col-span-2 flex items-center justify-end gap-1 hover:text-foreground transition-colors"
            >
              24h <ArrowUpDown size={10} />
            </button>
            <button
              onClick={() => handleSort("volume")}
              className="col-span-2 flex items-center justify-end gap-1 hover:text-foreground transition-colors"
            >
              Volume <ArrowUpDown size={10} />
            </button>
            <div className="col-span-1 text-right">Action</div>
          </div>

          {/* Loading */}
          {loading && (
            <div className="flex flex-col items-center justify-center py-20">
              <Loader2 className="w-8 h-8 text-[var(--accent)] animate-spin mb-3" />
              <p className="text-sm text-gray-500">Loading live market data...</p>
            </div>
          )}

          {/* Empty */}
          {!loading && filteredMarkets.length === 0 && (
            <div className="flex flex-col items-center justify-center py-20">
              <Search size={32} className="text-gray-500 mb-3" />
              <p className="text-sm text-gray-500">No coins match your search</p>
            </div>
          )}

          {/* Rows */}
          {!loading && filteredMarkets.length > 0 && (
            <div className="divide-y divide-[var(--border)]">
              {filteredMarkets.map((coin, idx) => (
                <MarketRow key={coin.id} coin={coin} delay={idx * 0.02} />
              ))}
            </div>
          )}
        </motion.div>

        {/* ═══════════ FOOTER NOTE ═══════════ */}
        <div className="flex items-center justify-center gap-2 text-[10px] text-gray-500">
          <span>Powered by</span>
          <a
            href="https://www.coingecko.com"
            target="_blank"
            rel="noopener noreferrer"
            className="text-[var(--accent)] hover:underline font-semibold"
          >
            CoinGecko API
          </a>
        </div>
      </div>
    </div>
  );
}

// ─── Market Row Component ───
function MarketRow({ coin, delay }: { coin: MarketCoin; delay: number }) {
  const isUp = coin.price_change_percentage_24h >= 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 5 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.2 }}
      className="grid grid-cols-12 gap-2 md:gap-4 px-4 sm:px-5 py-3.5 hover:bg-white/[0.02] transition-colors items-center"
    >
      {/* Rank (Desktop only) */}
      <div className="hidden md:block col-span-1 text-xs text-gray-500 font-mono">
        {coin.market_cap_rank}
      </div>

      {/* Asset */}
      <div className="col-span-6 md:col-span-4 flex items-center gap-3">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={coin.image}
          alt={coin.name}
          className="w-8 h-8 rounded-full"
        />
        <div className="min-w-0">
          <div className="text-sm font-semibold text-foreground uppercase">
            {coin.symbol}
          </div>
          <div className="text-[11px] text-gray-500 truncate">
            {coin.name}
          </div>
        </div>
      </div>

      {/* Price */}
      <div className="col-span-3 md:col-span-2 text-right">
        <div className="text-sm font-semibold text-foreground font-mono">
          <AnimatedPrice price={coin.current_price} />
        </div>
        <div className="md:hidden text-[11px] mt-0.5">
          <span className={isUp ? "text-green-400" : "text-red-400"}>
            {formatPercent(coin.price_change_percentage_24h)}
          </span>
        </div>
      </div>

      {/* 24h Change (Desktop) */}
      <div className="hidden md:flex col-span-2 justify-end">
        <div
          className={`inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs font-semibold ${
            isUp
              ? "bg-green-500/10 text-green-400"
              : "bg-red-500/10 text-red-400"
          }`}
        >
          {isUp ? <TrendingUp size={11} /> : <TrendingDown size={11} />}
          {formatPercent(coin.price_change_percentage_24h)}
        </div>
      </div>

      {/* Volume (Desktop) */}
      <div className="hidden md:block col-span-2 text-right">
        <div className="text-xs font-medium text-foreground font-mono">
          ${formatLargeNumber(coin.total_volume)}
        </div>
        <div className="text-[10px] text-gray-500">
          MCap: ${formatLargeNumber(coin.market_cap)}
        </div>
      </div>

      {/* Trade Button */}
      <div className="col-span-3 md:col-span-1 flex justify-end">
        <Link href={`/trade?coin=${coin.id}`}>
          <button className="px-3 py-1.5 rounded-lg bg-[var(--accent)]/10 border border-[var(--accent)]/20 text-[var(--accent)] text-xs font-semibold hover:bg-[var(--accent)]/20 transition-all">
            Trade
          </button>
        </Link>
      </div>
    </motion.div>
  );
}