// src/components/InstallApp.tsx
"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Smartphone,
  Download,
  Globe,
  Apple,
  X,
  Share,
  Plus,
  CheckCircle2,
  ChevronRight,
} from "lucide-react";

// The APK download URL is read from a public env var so it can be filled in
// AFTER the .apk is generated and hosted (see ANDROID_APP_GUIDE.md). Until
// then the direct-APK button simply doesn't render.
const APK_URL = process.env.NEXT_PUBLIC_APK_URL || "";

// Minimal shape of the beforeinstallprompt event (not in TS DOM lib yet).
interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

type Platform = "android" | "ios" | "desktop" | "unknown";

function detectPlatform(): Platform {
  if (typeof navigator === "undefined") return "unknown";
  const ua = navigator.userAgent || "";
  if (/android/i.test(ua)) return "android";
  if (/iphone|ipad|ipod/i.test(ua)) return "ios";
  // iPadOS 13+ reports as Mac; catch it via touch support.
  if (/Macintosh/.test(ua) && typeof document !== "undefined" && "ontouchend" in document) {
    return "ios";
  }
  return "desktop";
}

export default function InstallApp() {
  const [platform, setPlatform] = useState<Platform>("unknown");
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isStandalone, setIsStandalone] = useState(false);
  const [showIosSheet, setShowIosSheet] = useState(false);
  const [showWebHelp, setShowWebHelp] = useState(false);

  useEffect(() => {
    // Defer browser-only detection to the next tick so it doesn't run
    // synchronously during the effect (avoids cascading-render warning and
    // keeps SSR/hydration clean).
    const raf = requestAnimationFrame(() => {
      setPlatform(detectPlatform());

      const standalone =
        window.matchMedia("(display-mode: standalone)").matches ||
        (window.navigator as unknown as { standalone?: boolean }).standalone === true;
      setIsStandalone(standalone);
    });

    // Capture the Android/Chrome install prompt so our own button can fire it.
    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };
    window.addEventListener("beforeinstallprompt", handler);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("beforeinstallprompt", handler);
    };
  }, []);

  // Don't show anything if the app is already installed.
  if (isStandalone) return null;

  // ── Fire the native PWA install prompt (Android/desktop Chrome) ──
  const handlePwaInstall = async () => {
    if (deferredPrompt) {
      await deferredPrompt.prompt();
      await deferredPrompt.userChoice;
      setDeferredPrompt(null);
    } else {
      // Prompt not available (e.g. iOS, or already dismissed) — show help.
      if (platform === "ios") setShowIosSheet(true);
      else setShowWebHelp(true);
    }
  };

  const showApkButton = platform !== "ios" && APK_URL !== "";

  return (
    <>
      <div className="relative overflow-hidden glass-panel rounded-2xl p-6 sm:p-8">
        {/* Ambient accent glow — same language as the rest of the site */}
        <div className="pointer-events-none absolute -top-24 -right-24 w-64 h-64 rounded-full bg-[var(--accent)]/10 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-24 -left-24 w-64 h-64 rounded-full bg-purple-500/10 blur-3xl" />

        <div className="relative flex flex-col lg:flex-row lg:items-center gap-6 lg:gap-10">
          {/* Left: copy */}
          <div className="flex-1">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[var(--accent)]/10 border border-[var(--accent)]/20 mb-4">
              <Smartphone size={13} className="text-[var(--accent)]" />
              <span className="text-[11px] font-semibold text-[var(--accent)] uppercase tracking-wider">
                Get the App
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-foreground mb-2">
              Trade anywhere, anytime
            </h2>
            <p className="text-sm text-gray-400 leading-relaxed max-w-md">
              Install MEXC Trade on your device for a faster, fullscreen experience
              with instant access from your home screen — no app store required.
            </p>

            {/* Trust row */}
            <div className="flex flex-wrap items-center gap-x-5 gap-y-2 mt-4">
              {["Free to install", "Fullscreen & fast", "Always up to date"].map((t) => (
                <div key={t} className="flex items-center gap-1.5">
                  <CheckCircle2 size={13} className="text-green-400" />
                  <span className="text-xs text-gray-500">{t}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Right: platform buttons */}
          <div className="w-full lg:w-auto lg:min-w-[300px] space-y-3">
            {/* iOS */}
            {platform === "ios" && (
              <button
                onClick={() => setShowIosSheet(true)}
                style={{ touchAction: "manipulation" }}
                className="w-full group flex items-center gap-3 p-4 rounded-xl bg-white/[0.03] border border-[var(--border)] hover:bg-white/[0.06] hover:border-[var(--accent)]/30 transition-all"
              >
                <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center shrink-0">
                  <Apple size={20} className="text-foreground" />
                </div>
                <div className="flex-1 text-left">
                  <div className="text-sm font-semibold text-foreground">Install on iPhone</div>
                  <div className="text-[11px] text-gray-500">Add to Home Screen via Safari</div>
                </div>
                <ChevronRight size={16} className="text-gray-500 group-hover:text-[var(--accent)] transition-colors" />
              </button>
            )}

            {/* Android + desktop */}
            {platform !== "ios" && (
              <>
                {/* Web / PWA install */}
                <button
                  onClick={handlePwaInstall}
                  style={{ touchAction: "manipulation" }}
                  className="w-full group flex items-center gap-3 p-4 rounded-xl bg-white/[0.03] border border-[var(--border)] hover:bg-white/[0.06] hover:border-[var(--accent)]/30 transition-all"
                >
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center shrink-0">
                    <Globe size={20} className="text-white" />
                  </div>
                  <div className="flex-1 text-left">
                    <div className="text-sm font-semibold text-foreground">Web App Install</div>
                    <div className="text-[11px] text-gray-500">Add to home screen from your browser</div>
                  </div>
                  <ChevronRight size={16} className="text-gray-500 group-hover:text-[var(--accent)] transition-colors" />
                </button>

                {/* Direct APK — only when a hosted APK URL is configured */}
                {showApkButton && (
                  <a
                    href={APK_URL}
                    className="w-full group flex items-center gap-3 p-4 rounded-xl bg-gradient-to-r from-[var(--accent)] to-purple-500 hover:opacity-95 transition-all shadow-lg shadow-[var(--accent)]/20"
                  >
                    <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center shrink-0">
                      <Download size={20} className="text-white" />
                    </div>
                    <div className="flex-1 text-left">
                      <div className="text-sm font-semibold text-white">Download Android App</div>
                      <div className="text-[11px] text-white/70">Install the .apk directly</div>
                    </div>
                    <ChevronRight size={16} className="text-white/80" />
                  </a>
                )}
              </>
            )}

            {/* Desktop-only helper line */}
            {platform === "desktop" && (
              <p className="text-[11px] text-gray-600 text-center px-2">
                On mobile? Open this page on your phone to install the app.
              </p>
            )}
          </div>
        </div>
      </div>

      {/* ── iOS "Add to Home Screen" instruction sheet ── */}
      <AnimatePresence>
        {showIosSheet && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowIosSheet(false)}
              className="fixed inset-0 bg-black/70 backdrop-blur-sm z-[9998]"
            />
            <motion.div
              initial={{ opacity: 0, y: 40, x: "-50%" }}
              animate={{ opacity: 1, y: 0, x: "-50%" }}
              exit={{ opacity: 0, y: 40, x: "-50%" }}
              className="fixed left-1/2 bottom-4 sm:bottom-auto sm:top-1/2 sm:-translate-y-1/2 w-[94vw] max-w-sm z-[9999]"
            >
              <div className="glass-panel rounded-2xl border border-[var(--border)] shadow-2xl overflow-hidden">
                <div className="flex items-center justify-between p-5 border-b border-[var(--border)]">
                  <div className="flex items-center gap-2.5">
                    <Apple size={18} className="text-foreground" />
                    <h3 className="text-sm font-bold text-foreground">Install on iPhone</h3>
                  </div>
                  <button onClick={() => setShowIosSheet(false)} className="p-1 text-gray-400 hover:text-white">
                    <X size={18} />
                  </button>
                </div>
                <div className="p-5 space-y-4">
                  <p className="text-xs text-gray-400">
                    iOS installs web apps through Safari&apos;s share menu. It only takes two taps:
                  </p>
                  <IosStep
                    n={1}
                    icon={<Share size={16} className="text-[var(--accent)]" />}
                    text="Tap the Share button in Safari's toolbar."
                  />
                  <IosStep
                    n={2}
                    icon={<Plus size={16} className="text-[var(--accent)]" />}
                    text="Choose 'Add to Home Screen', then tap Add."
                  />
                  <div className="p-3 rounded-lg bg-white/[0.03] border border-[var(--border)]">
                    <p className="text-[11px] text-gray-500">
                      Tip: this must be done in <span className="text-foreground font-medium">Safari</span> —
                      Chrome on iPhone can&apos;t install web apps (an Apple restriction).
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* ── Generic web-install help (Android/desktop when prompt unavailable) ── */}
      <AnimatePresence>
        {showWebHelp && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowWebHelp(false)}
              className="fixed inset-0 bg-black/70 backdrop-blur-sm z-[9998]"
            />
            <motion.div
              initial={{ opacity: 0, y: 40, x: "-50%" }}
              animate={{ opacity: 1, y: 0, x: "-50%" }}
              exit={{ opacity: 0, y: 40, x: "-50%" }}
              className="fixed left-1/2 bottom-4 sm:bottom-auto sm:top-1/2 sm:-translate-y-1/2 w-[94vw] max-w-sm z-[9999]"
            >
              <div className="glass-panel rounded-2xl border border-[var(--border)] shadow-2xl overflow-hidden">
                <div className="flex items-center justify-between p-5 border-b border-[var(--border)]">
                  <div className="flex items-center gap-2.5">
                    <Globe size={18} className="text-[var(--accent)]" />
                    <h3 className="text-sm font-bold text-foreground">Install the Web App</h3>
                  </div>
                  <button onClick={() => setShowWebHelp(false)} className="p-1 text-gray-400 hover:text-white">
                    <X size={18} />
                  </button>
                </div>
                <div className="p-5 space-y-4">
                  <p className="text-xs text-gray-400">
                    Your browser didn&apos;t offer an automatic prompt. You can still add it
                    manually in a couple of taps:
                  </p>
                  <IosStep
                    n={1}
                    icon={<span className="text-[var(--accent)] font-bold text-sm">⋮</span>}
                    text="Open your browser's menu (⋮ or ⋯)."
                  />
                  <IosStep
                    n={2}
                    icon={<Plus size={16} className="text-[var(--accent)]" />}
                    text="Tap 'Install app' or 'Add to Home screen'."
                  />
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}

function IosStep({ n, icon, text }: { n: number; icon: React.ReactNode; text: string }) {
  return (
    <div className="flex items-center gap-3">
      <div className="w-7 h-7 rounded-full bg-[var(--accent)]/10 border border-[var(--accent)]/20 flex items-center justify-center shrink-0 text-[11px] font-bold text-[var(--accent)]">
        {n}
      </div>
      <div className="flex items-center gap-2 flex-1">
        {icon}
        <span className="text-xs text-gray-300">{text}</span>
      </div>
    </div>
  );
}
