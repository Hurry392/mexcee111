// src/components/Footer.tsx
"use client";

import Link from "next/link";
import { Layers, Shield, Zap, Globe } from "lucide-react";
import { PLATFORM_CONFIG } from "@/config/constants";

export default function Footer() {
  const currentYear = new Date().getFullYear();

  const FOOTER_LINKS = {
    Platform: [
      { name: "Markets", href: "/markets" },
      { name: "Trade", href: "/trade" },
      { name: "Wallet", href: "/wallet" },
      { name: "Funds", href: "/funds" },
    ],
    Account: [
      { name: "Sign Up", href: "/signup" },
      { name: "Log In", href: "/login" },
      { name: "KYC Verification", href: "/kyc" },
      { name: "Security", href: "/security" },
    ],
    Support: [
      { name: "Help Center", href: "/chat" },
      { name: "Referrals", href: "/referrals" },
      { name: "Records", href: "/records" },
    ],
    Legal: [
      { name: "Privacy Policy", href: "/privacy" },
      { name: "Terms of Service", href: "/terms" },
    ],
  };

  return (
    <footer className="border-t border-[var(--border)] bg-card/30 backdrop-blur-xl mt-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        {/* Top Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-6 gap-8 mb-10">
          {/* Brand Column (spans 2) */}
          <div className="col-span-2">
            <div className="flex items-center gap-2.5 mb-4">
              <div className="flex items-center justify-center w-9 h-9 rounded-lg bg-[var(--accent)]/10 border border-[var(--accent)]/20">
                <Layers className="w-5 h-5 text-[var(--accent)]" />
              </div>
              <div className="flex flex-col">
                <span className="font-bold text-base gradient-text leading-tight">
                  {PLATFORM_CONFIG.name}
                </span>
                <span className="text-[10px] text-gray-500 leading-tight">
                  Trading Platform
                </span>
              </div>
            </div>
            <p className="text-xs text-gray-500 leading-relaxed max-w-xs mb-4">
              Premium cryptocurrency trading platform with real-time markets, secure deposits, and professional tools.
            </p>
            {/* Trust badges */}
            <div className="flex flex-wrap gap-2">
              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-white/[0.03] border border-[var(--border)]">
                <Shield size={11} className="text-blue-400" />
                <span className="text-[10px] font-medium text-gray-400">Secure</span>
              </div>
              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-white/[0.03] border border-[var(--border)]">
                <Zap size={11} className="text-yellow-400" />
                <span className="text-[10px] font-medium text-gray-400">Fast</span>
              </div>
              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-white/[0.03] border border-[var(--border)]">
                <Globe size={11} className="text-green-400" />
                <span className="text-[10px] font-medium text-gray-400">Global</span>
              </div>
            </div>
          </div>

          {/* Links Columns */}
          {Object.entries(FOOTER_LINKS).map(([category, links]) => (
            <div key={category}>
              <h3 className="text-xs font-bold uppercase tracking-wider text-gray-400 mb-3">
                {category}
              </h3>
              <ul className="space-y-2">
                {links.map((link) => (
                  <li key={link.name}>
                    <Link
                      href={link.href}
                      className="text-xs text-gray-500 hover:text-[var(--accent)] transition-colors"
                    >
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom Bar */}
        <div className="pt-6 border-t border-[var(--border)] flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-[11px] text-gray-500">
            © {currentYear} {PLATFORM_CONFIG.name}. All rights reserved.
          </p>
          <div className="flex items-center gap-4">
            <Link
              href="/privacy"
              className="text-[11px] text-gray-500 hover:text-[var(--accent)] transition-colors"
            >
              Privacy
            </Link>
            <Link
              href="/terms"
              className="text-[11px] text-gray-500 hover:text-[var(--accent)] transition-colors"
            >
              Terms
            </Link>
            <div className="flex items-center gap-1.5">
              <span className="relative flex h-1.5 w-1.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-green-500" />
              </span>
              <span className="text-[10px] uppercase tracking-wider font-semibold text-green-400">
                Operational
              </span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}