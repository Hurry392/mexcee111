// src/components/funds/DepositPanel.tsx
"use client";

import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Copy,
  Check,
  Upload,
  X,
  Image as ImageIcon,
  Loader2,
  AlertCircle,
  CheckCircle2,
  Info,
} from "lucide-react";
import { depositsAPI } from "@/lib/api";
import { useAuthStore } from "@/store/authStore";
import { usePlatformSettings } from "@/hooks/usePlatformSettings";

export default function DepositPanel() {
  const { user } = useAuthStore();
  const { settings, loading: settingsLoading } = usePlatformSettings();
  const [copied, setCopied] = useState(false);
  const [amount, setAmount] = useState("");
  const [txId, setTxId] = useState("");
  const [screenshot, setScreenshot] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleCopyAddress = () => {
    navigator.clipboard.writeText(settings.trc20WalletAddress);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      setError("Screenshot must be less than 5MB");
      return;
    }
    if (!file.type.startsWith("image/")) {
      setError("Only image files are allowed");
      return;
    }

    setError("");
    setScreenshot(file);
    const reader = new FileReader();
    reader.onloadend = () => setPreview(reader.result as string);
    reader.readAsDataURL(file);
  };

  const removeScreenshot = () => {
    setScreenshot(null);
    setPreview(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    const amountNum = parseFloat(amount);
    if (!amountNum || amountNum < settings.minDeposit) {
      setError(`Minimum deposit is $${settings.minDeposit}`);
      return;
    }
    if (amountNum > settings.maxDeposit) {
      setError(`Maximum deposit is $${settings.maxDeposit.toLocaleString()}`);
      return;
    }

    if (!txId.trim()) {
      setError("Transaction ID is required");
      return;
    }

    if (!screenshot) {
      setError("Payment screenshot is required");
      return;
    }

    setSubmitting(true);

    const formData = new FormData();
    formData.append("amount", amount);
    formData.append("txId", txId.trim());
    formData.append("network", "TRC20");
    formData.append("currency", "USDT");
    formData.append("screenshot", screenshot);

    const result = await depositsAPI.create(formData);
    setSubmitting(false);

    if (result.error) {
      setError(result.error);
      return;
    }

    setSuccess(true);
    setAmount("");
    setTxId("");
    removeScreenshot();
    setTimeout(() => setSuccess(false), 5000);
  };

  // Loading state while settings fetch
  if (settingsLoading) {
    return (
      <div className="space-y-4">
        <div className="skeleton h-32 rounded-2xl" />
        <div className="skeleton h-48 rounded-2xl" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* ── Success Banner ── */}
      <AnimatePresence>
        {success && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="flex items-start gap-3 p-4 rounded-xl bg-green-500/10 border border-green-500/30"
          >
            <CheckCircle2 size={18} className="text-green-400 shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-green-300 mb-0.5">
                Deposit Submitted Successfully
              </p>
              <p className="text-xs text-green-200/70">
                Your deposit is under review and will be credited within 1-3 business days.
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Error Banner ── */}
      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="flex items-start gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/20"
          >
            <AlertCircle size={14} className="text-red-400 shrink-0 mt-0.5" />
            <p className="text-xs text-red-400">{error}</p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ═══════════ NETWORK INFO CARD ═══════════ */}
      <div className="p-4 rounded-xl bg-gradient-to-br from-red-500/[0.05] to-red-500/[0.02] border border-red-500/20">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-11 h-11 rounded-xl bg-red-500/15 flex items-center justify-center text-xl">
            🔴
          </div>
          <div>
            <div className="text-sm font-bold text-foreground">USDT — TRC20</div>
            <div className="text-[11px] text-gray-500">TRON Network • Fastest & Cheapest</div>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-2">
          <div className="p-2 rounded-lg bg-white/[0.03] text-center">
            <div className="text-[9px] text-gray-500 uppercase tracking-wider mb-0.5">Min</div>
            <div className="text-xs font-bold text-foreground">${settings.minDeposit}</div>
          </div>
          <div className="p-2 rounded-lg bg-white/[0.03] text-center">
            <div className="text-[9px] text-gray-500 uppercase tracking-wider mb-0.5">Max</div>
            <div className="text-xs font-bold text-foreground">
              ${settings.maxDeposit >= 1000
                ? `${(settings.maxDeposit / 1000).toFixed(0)}K`
                : settings.maxDeposit}
            </div>
          </div>
          <div className="p-2 rounded-lg bg-white/[0.03] text-center">
            <div className="text-[9px] text-gray-500 uppercase tracking-wider mb-0.5">Time</div>
            <div className="text-xs font-bold text-foreground">1-3 min</div>
          </div>
        </div>
      </div>

      {/* ═══════════ DEPOSIT ADDRESS ═══════════ */}
      <div>
        <label className="block text-xs font-medium text-gray-400 mb-2">
          Send USDT to this address:
        </label>
        <div className="relative">
          <div className="flex items-center gap-2 p-3 rounded-xl bg-white/[0.03] border border-[var(--border)]">
            <code className="flex-1 text-xs text-foreground font-mono break-all">
              {settings.trc20WalletAddress}
            </code>
            <button
              type="button"
              onClick={handleCopyAddress}
              className={`shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                copied
                  ? "bg-green-500/20 text-green-400"
                  : "bg-[var(--accent)]/15 text-[var(--accent)] hover:bg-[var(--accent)]/25"
              }`}
            >
              {copied ? (
                <>
                  <Check size={12} />
                  Copied
                </>
              ) : (
                <>
                  <Copy size={12} />
                  Copy
                </>
              )}
            </button>
          </div>
        </div>
        <div className="flex items-start gap-1.5 mt-2 text-[10px] text-amber-400/80">
          <Info size={11} className="shrink-0 mt-0.5" />
          <span>
            Only send USDT via TRC20 (TRON) network. Other networks will result in permanent loss.
          </span>
        </div>
      </div>

      {/* ═══════════ FORM ═══════════ */}
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Amount */}
        <div>
          <label className="block text-xs font-medium text-gray-400 mb-2">
            Amount (USD) <span className="text-red-400">*</span>
          </label>
          <div className="relative">
            <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-sm font-semibold text-gray-500">
              $
            </span>
            <input
              type="number"
              step="0.01"
              min={settings.minDeposit}
              max={settings.maxDeposit}
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0.00"
              className="w-full pl-8 pr-4 py-3 bg-white/[0.03] border border-[var(--border)] rounded-xl text-sm text-foreground placeholder:text-gray-600 focus:outline-none focus:border-[var(--accent)]/50 focus:bg-white/[0.05] transition-all"
            />
          </div>
          <div className="flex items-center justify-between mt-1.5 text-[10px] text-gray-500">
            <span>Min: ${settings.minDeposit}</span>
            <span>Max: ${settings.maxDeposit.toLocaleString()}</span>
          </div>
        </div>

        {/* Transaction ID */}
        <div>
          <label className="block text-xs font-medium text-gray-400 mb-2">
            Transaction Hash (TxID) <span className="text-red-400">*</span>
          </label>
          <input
            type="text"
            value={txId}
            onChange={(e) => setTxId(e.target.value)}
            placeholder="Enter blockchain transaction hash"
            className="w-full px-4 py-3 bg-white/[0.03] border border-[var(--border)] rounded-xl text-sm text-foreground placeholder:text-gray-600 focus:outline-none focus:border-[var(--accent)]/50 focus:bg-white/[0.05] transition-all font-mono"
          />
          <div className="text-[10px] text-gray-500 mt-1.5">
            Copy this from your wallet after sending USDT
          </div>
        </div>

        {/* Screenshot */}
        <div>
          <label className="block text-xs font-medium text-gray-400 mb-2">
            Payment Screenshot <span className="text-red-400">*</span>
          </label>

          {!preview ? (
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="w-full flex flex-col items-center justify-center gap-2 py-8 px-4 rounded-xl border-2 border-dashed border-[var(--border)] hover:border-[var(--accent)]/40 hover:bg-white/[0.02] transition-all"
            >
              <div className="w-11 h-11 rounded-xl bg-[var(--accent)]/10 flex items-center justify-center">
                <Upload size={18} className="text-[var(--accent)]" />
              </div>
              <div className="text-center">
                <p className="text-sm font-medium text-foreground">Click to upload</p>
                <p className="text-[10px] text-gray-500 mt-0.5">PNG, JPG up to 5MB</p>
              </div>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileChange}
                className="sr-only"
              />
            </button>
          ) : (
            <div className="relative rounded-xl border border-[var(--border)] overflow-hidden">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={preview}
                alt="Screenshot preview"
                className="w-full max-h-64 object-contain bg-black/40"
              />
              <button
                type="button"
                onClick={removeScreenshot}
                className="absolute top-2 right-2 flex items-center justify-center w-7 h-7 rounded-lg bg-black/60 backdrop-blur-sm text-white hover:bg-red-500/80 transition-colors"
              >
                <X size={14} />
              </button>
              <div className="px-3 py-2 bg-black/60 backdrop-blur-sm text-[10px] text-gray-300 flex items-center gap-2">
                <ImageIcon size={10} />
                {screenshot?.name} ({((screenshot?.size ?? 0) / 1024).toFixed(1)} KB)
              </div>
            </div>
          )}
        </div>

        {/* Submit */}
        <button
          type="submit"
          disabled={submitting || !user}
          className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-gradient-to-r from-green-500 to-emerald-500 text-white font-semibold text-sm hover:opacity-95 transition-all active:scale-[0.98] shadow-lg shadow-green-500/20 disabled:opacity-50 disabled:cursor-not-allowed disabled:active:scale-100"
        >
          {submitting ? (
            <>
              <Loader2 size={16} className="animate-spin" />
              Submitting...
            </>
          ) : (
            <>
              <CheckCircle2 size={16} />
              Submit Deposit Request
            </>
          )}
        </button>

        {/* Info footer */}
        <div className="flex items-start gap-2 p-2.5 rounded-lg bg-white/[0.02] border border-[var(--border)]">
          <Info size={11} className="text-gray-500 shrink-0 mt-0.5" />
          <p className="text-[10px] text-gray-500 leading-relaxed">
            Deposits are reviewed manually within 1-3 business days. You&apos;ll receive a notification once approved.
          </p>
        </div>
      </form>
    </div>
  );
}