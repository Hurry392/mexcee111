// src/components/funds/WithdrawPanel.tsx
"use client";

import { useState, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Eye,
  EyeOff,
  Lock,
  Loader2,
  AlertCircle,
  CheckCircle2,
  ArrowUpRight,
  Info,
  ShieldCheck,
  Clock,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import Link from "next/link";
import { useAuthStore } from "@/store/authStore";
import {
  WITHDRAWAL_METHODS,
  WithdrawalMethod,
} from "@/config/constants";
import { withdrawalsAPI } from "@/lib/api";
import { usePlatformSettings } from "@/hooks/usePlatformSettings";

// ─── Category metadata ───
const CATEGORIES = [
  { id: "CRYPTO" as const, label: "Crypto", icon: "💎" },
  { id: "BANK" as const, label: "Bank", icon: "🏦" },
  { id: "UPI" as const, label: "UPI", icon: "📱" },
  { id: "PAYPAL" as const, label: "PayPal", icon: "💳" },
];

export default function WithdrawPanel() {
  const { user } = useAuthStore();
  const { settings, loading: settingsLoading } = usePlatformSettings();
  const userBalance = user?.balance ?? 0;
  const kycApproved = user?.kycStatus === "APPROVED";
  const kycPending = user?.kycStatus === "PENDING";
  const kycRejected = user?.kycStatus === "REJECTED";
  const withdrawalsFrozen = user?.withdrawalsFrozen === true;
  const freezeReason = user?.withdrawalFreezeReason || null;

  // ─── State ───
  const [selectedCategory, setSelectedCategory] = useState<typeof CATEGORIES[number]["id"]>("CRYPTO");
  const [selectedMethodId, setSelectedMethodId] = useState<string>(WITHDRAWAL_METHODS[0].id);
  const [methodPickerOpen, setMethodPickerOpen] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const [amount, setAmount] = useState("");
  const [withdrawalPassword, setWithdrawalPassword] = useState("");
  const [methodFields, setMethodFields] = useState<Record<string, string>>({});

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);

  // ─── Filter methods by category ───
  const methodsInCategory = useMemo(
    () => WITHDRAWAL_METHODS.filter((m) => m.category === selectedCategory),
    [selectedCategory]
  );

  const selectedMethod: WithdrawalMethod | undefined = useMemo(
    () => WITHDRAWAL_METHODS.find((m) => m.id === selectedMethodId),
    [selectedMethodId]
  );

  // ─── Apply admin-configured limits (override per-method limits) ───
  // NOTE: withdrawal minimum removed — any positive amount is accepted.
  const effectiveMax = useMemo(() => {
    if (!selectedMethod) return settings.maxWithdrawal;
    // Use the lower of admin's global max and method's specific max
    return Math.min(settings.maxWithdrawal, selectedMethod.maxWithdrawal);
  }, [selectedMethod, settings.maxWithdrawal]);

  // ─── Handle category switch ───
  const handleCategoryChange = (cat: typeof CATEGORIES[number]["id"]) => {
    setSelectedCategory(cat);
    const firstMethod = WITHDRAWAL_METHODS.find((m) => m.category === cat);
    if (firstMethod) {
      setSelectedMethodId(firstMethod.id);
      setMethodFields({});
    }
    setMethodPickerOpen(false);
    setError("");
  };

  const handleMethodChange = (id: string) => {
    setSelectedMethodId(id);
    setMethodFields({});
    setMethodPickerOpen(false);
    setError("");
  };

  const handleFieldChange = (fieldId: string, value: string) => {
    setMethodFields((prev) => ({ ...prev, [fieldId]: value }));
    setError("");
  };

  const handleMax = () => {
    const cappedMax = Math.min(userBalance, effectiveMax);
    setAmount(cappedMax.toString());
  };

  // ─── Submit ───
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (withdrawalsFrozen) {
      setError("Withdrawals are currently on hold for your account.");
      return;
    }

    if (!kycApproved) {
      setError("KYC verification is required for withdrawals");
      return;
    }

    if (!selectedMethod) {
      setError("Please select a withdrawal method");
      return;
    }

    const amountNum = parseFloat(amount);
    if (!amountNum || amountNum <= 0) {
      setError("Please enter a valid amount");
      return;
    }
    if (amountNum > userBalance) {
      setError("Insufficient balance");
      return;
    }
    if (amountNum > effectiveMax) {
      setError(`Maximum withdrawal is $${effectiveMax.toLocaleString()}`);
      return;
    }

    // Validate required fields
    for (const field of selectedMethod.fields) {
      if (field.required && !methodFields[field.id]?.trim()) {
        setError(`${field.label} is required`);
        return;
      }
    }

    if (!withdrawalPassword) {
      setError("Withdrawal password is required");
      return;
    }

    setSubmitting(true);

    const result = await withdrawalsAPI.create({
      amount: amountNum,
      methodId: selectedMethod.id,
      methodFields,
      withdrawalPassword,
    });

    setSubmitting(false);

    if (result.error) {
      setError(result.error);
      return;
    }

    if (user) {
      useAuthStore.getState().updateUser({
        balance: user.balance - amountNum,
      });
    }

    setSuccess(true);
    setAmount("");
    setWithdrawalPassword("");
    setMethodFields({});
    setTimeout(() => setSuccess(false), 4000);
  };

  // ─── Calculate net amount after fee ───
  const amountNum = parseFloat(amount) || 0;
  const feeAmount = selectedMethod
    ? selectedMethod.fee + (selectedMethod.feePercent ? (amountNum * selectedMethod.feePercent) / 100 : 0)
    : 0;
  const netAmount = Math.max(amountNum - feeAmount, 0);

  // ─── Loading state ───
  if (settingsLoading) {
    return (
      <div className="space-y-4">
        <div className="skeleton h-32 rounded-2xl" />
        <div className="skeleton h-48 rounded-2xl" />
      </div>
    );
  }

  // ═══════════════════════════════════════════════════════════
  // WITHDRAWALS FROZEN STATE (TOS enforcement — takes priority)
  // ═══════════════════════════════════════════════════════════
  if (withdrawalsFrozen) {
    return (
      <div className="space-y-4">
        <div className="relative overflow-hidden rounded-2xl border border-red-500/20 bg-red-500/[0.05] p-6 sm:p-8 text-center">
          <div className="absolute -top-20 -right-20 w-40 h-40 rounded-full bg-red-500/10 blur-3xl pointer-events-none" />

          <div className="relative z-10">
            <div className="w-14 h-14 rounded-2xl bg-red-500/15 border border-red-500/30 flex items-center justify-center mx-auto mb-4">
              <Lock size={26} className="text-red-400" />
            </div>

            <h3 className="text-base font-bold text-foreground mb-1.5">
              Withdrawals On Hold
            </h3>

            <p className="text-xs text-gray-400 leading-relaxed mb-4 max-w-sm mx-auto">
              Withdrawals have been temporarily suspended for your account
              due to a Terms of Service review.
            </p>

            {freezeReason && (
              <div className="max-w-sm mx-auto mb-5 p-3.5 rounded-xl bg-red-500/10 border border-red-500/20 text-left">
                <p className="text-[10px] uppercase tracking-wider text-red-400/80 font-semibold mb-1">
                  Reason for suspension
                </p>
                <p className="text-xs text-red-300 leading-relaxed">
                  {freezeReason}
                </p>
              </div>
            )}

            <Link href="/chat">
              <button className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-red-500 to-rose-500 text-white font-semibold text-sm hover:opacity-95 transition-all active:scale-[0.98] shadow-lg shadow-red-500/20">
                Contact Support →
              </button>
            </Link>
          </div>
        </div>

        <div className="flex items-start gap-2.5 p-4 rounded-xl bg-white/[0.02] border border-[var(--border)]">
          <Info size={14} className="text-gray-500 shrink-0 mt-0.5" />
          <p className="text-xs text-gray-500 leading-relaxed">
            Your funds remain safe in your account. Deposits and trading are
            not affected. If you believe this is a mistake, please reach out
            to our support team for a review.
          </p>
        </div>
      </div>
    );
  }

  // ═══════════════════════════════════════════════════════════
  // KYC BLOCKED STATE
  // ═══════════════════════════════════════════════════════════
  if (!kycApproved) {
    return (
      <div className="space-y-4">
        <div className="relative overflow-hidden rounded-2xl border border-amber-500/20 bg-amber-500/[0.05] p-6 sm:p-8 text-center">
          <div className="absolute -top-20 -right-20 w-40 h-40 rounded-full bg-amber-500/10 blur-3xl pointer-events-none" />

          <div className="relative z-10">
            <div className="w-14 h-14 rounded-2xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center mx-auto mb-4">
              {kycPending ? (
                <Clock size={26} className="text-amber-400" />
              ) : (
                <ShieldCheck size={26} className="text-amber-400" />
              )}
            </div>

            <h3 className="text-base font-bold text-foreground mb-1.5">
              {kycPending && "KYC Under Review"}
              {kycRejected && "KYC Was Rejected"}
              {!kycPending && !kycRejected && "Verification Required"}
            </h3>

            <p className="text-xs text-gray-400 leading-relaxed mb-5 max-w-sm mx-auto">
              {kycPending && "Your KYC submission is being reviewed. Withdrawals will be enabled once approved (1-3 business days)."}
              {kycRejected && "Your previous KYC submission was rejected. Please re-submit with clearer documents."}
              {!kycPending && !kycRejected && "Withdrawals require identity verification for security and compliance. Complete KYC to unlock withdrawals and higher limits."}
            </p>

            {!kycPending && (
              <Link href="/kyc">
                <button className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 text-white font-semibold text-sm hover:opacity-95 transition-all active:scale-[0.98] shadow-lg shadow-amber-500/20">
                  {kycRejected ? "Re-Submit KYC" : "Complete KYC →"}
                </button>
              </Link>
            )}

            {kycPending && (
              <Link href="/">
                <button className="px-5 py-2.5 rounded-xl border border-[var(--border)] text-foreground font-semibold text-sm hover:bg-white/[0.03] transition-all">
                  Back to Dashboard
                </button>
              </Link>
            )}
          </div>
        </div>

        <div className="flex items-start gap-2.5 p-4 rounded-xl bg-white/[0.02] border border-[var(--border)]">
          <Info size={14} className="text-gray-500 shrink-0 mt-0.5" />
          <p className="text-xs text-gray-500 leading-relaxed">
            KYC (Know Your Customer) verification is a regulatory requirement that helps prevent fraud and ensures secure withdrawals. Your data is encrypted and protected.
          </p>
        </div>
      </div>
    );
  }

  // ═══════════════════════════════════════════════════════════
  // MAIN WITHDRAW UI
  // ═══════════════════════════════════════════════════════════
  return (
    <div className="space-y-4">
      {/* ── Success Banner ── */}
      <AnimatePresence>
        {success && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="flex items-start gap-3 p-4 rounded-xl bg-green-500/10 border border-green-500/30"
          >
            <CheckCircle2 size={18} className="text-green-400 shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-green-300 mb-0.5">
                Withdrawal Request Submitted
              </p>
              <p className="text-xs text-green-200/70">
                Your withdrawal will be processed within {selectedMethod?.processingTime ?? "1-3 business days"}.
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Error Banner ── */}
      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="flex items-start gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/20"
          >
            <AlertCircle size={14} className="text-red-400 shrink-0 mt-0.5" />
            <p className="text-xs text-red-400">{error}</p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── KYC Verified Badge ── */}
      <div className="flex items-center gap-2 p-3 rounded-xl bg-green-500/[0.05] border border-green-500/15">
        <CheckCircle2 size={14} className="text-green-400 shrink-0" />
        <span className="text-xs text-green-300 font-medium">
          Identity verified — withdrawals enabled
        </span>
      </div>

      {/* ═══════════ CATEGORY TABS ═══════════ */}
      <div>
        <label className="block text-xs font-medium text-gray-400 mb-2">
          Withdrawal Type
        </label>
        <div className="grid grid-cols-4 gap-1.5 p-1 rounded-xl bg-card border border-[var(--border)]">
          {CATEGORIES.map((cat) => {
            const isActive = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => handleCategoryChange(cat.id)}
                className={`relative flex flex-col items-center justify-center gap-1 py-2.5 rounded-lg transition-colors ${
                  isActive ? "text-foreground" : "text-gray-500 hover:text-gray-300"
                }`}
              >
                {isActive && (
                  <motion.div
                    layoutId="withdrawCategoryPill"
                    className="absolute inset-0 rounded-lg bg-[var(--accent)]/15 border border-[var(--accent)]/30"
                    transition={{ type: "spring", stiffness: 300, damping: 30 }}
                  />
                )}
                <span className="relative z-10 text-base leading-none">{cat.icon}</span>
                <span className="relative z-10 text-[10px] font-semibold uppercase tracking-wider">
                  {cat.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* ═══════════ METHOD PICKER ═══════════ */}
      <div>
        <label className="block text-xs font-medium text-gray-400 mb-2">
          Select Method
        </label>

        <button
          type="button"
          onClick={() => setMethodPickerOpen(!methodPickerOpen)}
          className="w-full flex items-center gap-3 p-4 rounded-xl border border-[var(--border)] bg-white/[0.02] hover:bg-white/[0.04] transition-all text-left"
        >
          <div className="text-2xl">{selectedMethod?.icon}</div>
          <div className="flex-1 min-w-0">
            <div className="text-sm font-semibold text-foreground">
              {selectedMethod?.name}
            </div>
            <div className="text-[11px] text-gray-500 truncate">
              {selectedMethod?.description}
            </div>
          </div>
          <div className="text-right shrink-0">
            <div className="text-[10px] text-gray-500 uppercase">Fee</div>
            <div className="text-xs font-bold text-foreground">
              ${selectedMethod?.fee}
              {selectedMethod?.feePercent ? ` + ${selectedMethod.feePercent}%` : ""}
            </div>
          </div>
          {methodPickerOpen ? (
            <ChevronUp size={16} className="text-gray-500 shrink-0" />
          ) : (
            <ChevronDown size={16} className="text-gray-500 shrink-0" />
          )}
        </button>

        <AnimatePresence>
          {methodPickerOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="mt-2 space-y-1.5 overflow-hidden"
            >
              {methodsInCategory.map((m) => {
                const isSelected = m.id === selectedMethodId;
                return (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => handleMethodChange(m.id)}
                    className={`w-full flex items-center gap-3 p-3 rounded-xl border transition-all text-left ${
                      isSelected
                        ? "border-[var(--accent)]/40 bg-[var(--accent)]/[0.05]"
                        : "border-[var(--border)] bg-white/[0.02] hover:bg-white/[0.04]"
                    }`}
                  >
                    <div className="text-xl">{m.icon}</div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-semibold text-foreground">{m.name}</div>
                      <div className="text-[10px] text-gray-500">
                        {m.processingTime}
                      </div>
                    </div>
                    {isSelected && (
                      <CheckCircle2 size={16} className="text-[var(--accent)] shrink-0" />
                    )}
                  </button>
                );
              })}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* ═══════════ METHOD INFO BANNER (uses admin-configured limits) ═══════════ */}
      {selectedMethod && (
        <div className="grid grid-cols-3 gap-2">
          <div className="p-2.5 rounded-lg bg-white/[0.02] border border-[var(--border)] text-center">
            <div className="text-[9px] text-gray-500 uppercase tracking-wider mb-0.5">Fee</div>
            <div className="text-xs font-bold text-foreground">
              ${selectedMethod.fee}
              {selectedMethod.feePercent ? ` + ${selectedMethod.feePercent}%` : ""}
            </div>
          </div>
          <div className="p-2.5 rounded-lg bg-white/[0.02] border border-[var(--border)] text-center">
            <div className="text-[9px] text-gray-500 uppercase tracking-wider mb-0.5">Max</div>
            <div className="text-xs font-bold text-foreground">
              ${effectiveMax >= 1000
                ? `${(effectiveMax / 1000).toFixed(0)}K`
                : effectiveMax}
            </div>
          </div>
          <div className="p-2.5 rounded-lg bg-white/[0.02] border border-[var(--border)] text-center">
            <div className="text-[9px] text-gray-500 uppercase tracking-wider mb-0.5">Time</div>
            <div className="text-[11px] font-bold text-foreground">{selectedMethod.processingTime}</div>
          </div>
        </div>
      )}

      {/* ═══════════ FORM ═══════════ */}
      <form onSubmit={handleSubmit} className="space-y-4">
        {selectedMethod?.fields.map((field) => (
          <div key={field.id}>
            <label className="block text-xs font-medium text-gray-400 mb-2">
              {field.label}{" "}
              {field.required && <span className="text-red-400">*</span>}
            </label>
            <input
              type={field.type}
              value={methodFields[field.id] || ""}
              onChange={(e) => handleFieldChange(field.id, e.target.value)}
              placeholder={field.placeholder}
              className={`w-full px-4 py-3 bg-white/[0.03] border border-[var(--border)] rounded-xl text-sm text-foreground placeholder:text-gray-600 focus:outline-none focus:border-[var(--accent)]/50 focus:bg-white/[0.05] transition-all ${
                field.monospace ? "font-mono" : ""
              }`}
            />
            {field.helperText && (
              <div className="flex items-start gap-1.5 mt-2 text-[10px] text-amber-400/80">
                <Info size={11} className="shrink-0 mt-0.5" />
                <span>{field.helperText}</span>
              </div>
            )}
          </div>
        ))}

        {/* Amount */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="text-xs font-medium text-gray-400">
              Amount (USD) <span className="text-red-400">*</span>
            </label>
            <button
              type="button"
              onClick={handleMax}
              className="text-[10px] font-semibold text-[var(--accent)] hover:underline"
            >
              MAX
            </button>
          </div>
          <div className="relative">
            <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-sm font-semibold text-gray-500">
              $
            </span>
            <input
              type="number"
              step="0.01"
              min={0.01}
              max={Math.min(userBalance, effectiveMax)}
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0.00"
              className="w-full pl-8 pr-4 py-3 bg-white/[0.03] border border-[var(--border)] rounded-xl text-sm text-foreground placeholder:text-gray-600 focus:outline-none focus:border-[var(--accent)]/50 focus:bg-white/[0.05] transition-all"
            />
          </div>
          <div className="flex items-center justify-between mt-1.5 text-[10px] text-gray-500">
            <span>No minimum</span>
            <span>
              Available:{" "}
              <span className="text-foreground font-semibold">
                ${userBalance.toFixed(2)}
              </span>
            </span>
          </div>
        </div>

        {/* Fee Breakdown */}
        {amountNum > 0 && selectedMethod && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            className="space-y-1.5 p-3 rounded-lg bg-white/[0.02] border border-[var(--border)]"
          >
            <div className="flex items-center justify-between text-[11px]">
              <span className="text-gray-500">Withdrawal Amount</span>
              <span className="text-foreground font-mono">${amountNum.toFixed(2)}</span>
            </div>
            <div className="flex items-center justify-between text-[11px]">
              <span className="text-gray-500">
                Fee
                {selectedMethod.feePercent
                  ? ` (${selectedMethod.feePercent}% + $${selectedMethod.fee})`
                  : ""}
              </span>
              <span className="text-red-400 font-mono">- ${feeAmount.toFixed(2)}</span>
            </div>
            <div className="border-t border-[var(--border)] pt-1.5 flex items-center justify-between text-xs">
              <span className="text-gray-400 font-semibold">You will receive</span>
              <span className="text-green-400 font-mono font-bold">${netAmount.toFixed(2)}</span>
            </div>
          </motion.div>
        )}

        {/* Withdrawal Password */}
        <div>
          <label className="block text-xs font-medium text-gray-400 mb-2">
            Withdrawal Password <span className="text-red-400">*</span>
          </label>
          <div className="relative">
            <Lock
              size={14}
              className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-500"
            />
            <input
              type={showPassword ? "text" : "password"}
              value={withdrawalPassword}
              onChange={(e) => setWithdrawalPassword(e.target.value)}
              placeholder="Enter your withdrawal password"
              className="w-full pl-10 pr-11 py-3 bg-white/[0.03] border border-[var(--border)] rounded-xl text-sm text-foreground placeholder:text-gray-600 focus:outline-none focus:border-[var(--accent)]/50 focus:bg-white/[0.05] transition-all"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300 transition-colors"
            >
              {showPassword ? <EyeOff size={14} /> : <Eye size={14} />}
            </button>
          </div>
          <Link
            href="/security"
            className="inline-block mt-1.5 text-[10px] text-[var(--accent)] hover:underline"
          >
            Set or change withdrawal password →
          </Link>
        </div>

        {/* Submit Button */}
        <button
          type="submit"
          disabled={submitting}
          className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-gradient-to-r from-red-500 to-rose-500 text-white font-semibold text-sm hover:opacity-95 transition-all active:scale-[0.98] shadow-lg shadow-red-500/20 disabled:opacity-50 disabled:cursor-not-allowed disabled:active:scale-100"
        >
          {submitting ? (
            <>
              <Loader2 size={16} className="animate-spin" />
              Submitting...
            </>
          ) : (
            <>
              <ArrowUpRight size={16} />
              Submit Withdrawal Request
            </>
          )}
        </button>

        {/* Daily limit notice — uses admin-configured limit */}
        <div className="flex items-start gap-2 p-2.5 rounded-lg bg-white/[0.02] border border-[var(--border)]">
          <Info size={11} className="text-gray-500 shrink-0 mt-0.5" />
          <p className="text-[10px] text-gray-500 leading-relaxed">
            Daily withdrawal limit: <span className="text-foreground font-semibold">${settings.dailyWithdrawalLimit.toLocaleString()}</span>. Withdrawals are processed manually for security.
          </p>
        </div>
      </form>
    </div>
  );
}