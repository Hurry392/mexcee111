// src/components/trade/OrderBook.tsx
"use client";

import { useEffect, useState } from "react";
import { Radio } from "lucide-react";
import { formatPrice, COINGECKO_TO_BINANCE } from "@/lib/markets";

interface Props {
  currentPrice: number;
  symbol: string;
  coinId: string;
}

interface OrderRow {
  price: number;
  quantity: number;
  total: number;
}

interface BinanceDepth {
  bids: [string, string][];
  asks: [string, string][];
}

export default function OrderBook({ currentPrice, symbol, coinId }: Props) {
  const [asks, setAsks] = useState<OrderRow[]>([]);
  const [bids, setBids] = useState<OrderRow[]>([]);
  const [isLive, setIsLive] = useState(false);

  const binanceSymbol = COINGECKO_TO_BINANCE[coinId];

  useEffect(() => {
    if (!binanceSymbol) return;

    let isCancelled = false;

    const fetchOrderBook = async () => {
      try {
        const url = `https://api.binance.com/api/v3/depth?symbol=${binanceSymbol}&limit=10`;
        const response = await fetch(url);

        if (!response.ok) {
          setIsLive(false);
          return;
        }

        const data: BinanceDepth = await response.json();

        if (isCancelled) return;

        // Process asks (sell orders) — already sorted lowest to highest
        let askTotal = 0;
        const processedAsks = data.asks.slice(0, 8).map(([priceStr, qtyStr]) => {
          const price = parseFloat(priceStr);
          const quantity = parseFloat(qtyStr);
          askTotal += quantity;
          return { price, quantity, total: askTotal };
        });

        // Process bids (buy orders) — already sorted highest to lowest
        let bidTotal = 0;
        const processedBids = data.bids.slice(0, 8).map(([priceStr, qtyStr]) => {
          const price = parseFloat(priceStr);
          const quantity = parseFloat(qtyStr);
          bidTotal += quantity;
          return { price, quantity, total: bidTotal };
        });

        setAsks(processedAsks);
        setBids(processedBids);
        setIsLive(true);
      } catch (error) {
        console.error("Order book fetch error:", error);
        setIsLive(false);
      }
    };

    // Initial fetch
    fetchOrderBook();

    // Refresh every 2 seconds (Binance allows this)
    const interval = setInterval(fetchOrderBook, 2000);

    return () => {
      isCancelled = true;
      clearInterval(interval);
    };
  }, [binanceSymbol]);

  const maxTotal = Math.max(
    ...asks.map((a) => a.total),
    ...bids.map((b) => b.total),
    1
  );

  return (
    <div className="glass-panel rounded-2xl p-4 sm:p-5">
      {/* Header */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <h3 className="text-sm font-bold text-foreground">Order Book</h3>
          {isLive && (
            <div className="flex items-center gap-1 px-1.5 py-0.5 rounded bg-green-500/15 border border-green-500/25">
              <Radio size={8} className="text-green-400 animate-pulse" />
              <span className="text-[9px] uppercase font-bold text-green-400">
                Live
              </span>
            </div>
          )}
        </div>
        <span className="text-[10px] text-gray-500">{symbol}/USDT</span>
      </div>

      {/* Column Headers */}
      <div className="grid grid-cols-3 gap-2 px-2 pb-2 mb-2 border-b border-[var(--border)] text-[10px] uppercase tracking-wider font-semibold text-gray-500">
        <div>Price</div>
        <div className="text-right">Quantity</div>
        <div className="text-right">Total</div>
      </div>

      {/* Asks (reversed so closest is at bottom) */}
      <div className="space-y-0.5 mb-2 min-h-[180px]">
        {asks.slice().reverse().map((ask, idx) => (
          <OrderRowItem
            key={`ask-${ask.price}-${idx}`}
            row={ask}
            maxTotal={maxTotal}
            type="ask"
          />
        ))}
      </div>

      {/* Current Price */}
      <div className="flex items-center justify-center py-2 my-2 bg-[var(--accent)]/5 border-y border-[var(--accent)]/15">
        <span className="text-base font-bold text-[var(--accent)] font-mono">
          ${formatPrice(currentPrice)}
        </span>
      </div>

      {/* Bids */}
      <div className="space-y-0.5 min-h-[180px]">
        {bids.map((bid, idx) => (
          <OrderRowItem
            key={`bid-${bid.price}-${idx}`}
            row={bid}
            maxTotal={maxTotal}
            type="bid"
          />
        ))}
      </div>
    </div>
  );
}

function OrderRowItem({
  row,
  maxTotal,
  type,
}: {
  row: OrderRow;
  maxTotal: number;
  type: "ask" | "bid";
}) {
  const percent = (row.total / maxTotal) * 100;
  const isAsk = type === "ask";

  return (
    <div className="relative grid grid-cols-3 gap-2 px-2 py-1 text-[11px] font-mono hover:bg-white/[0.02] rounded transition-colors">
      <div
        className={`absolute inset-y-0 right-0 ${
          isAsk ? "bg-red-500/10" : "bg-green-500/10"
        }`}
        style={{ width: `${percent}%` }}
      />
      <div
        className={`relative z-10 ${
          isAsk ? "text-red-400" : "text-green-400"
        }`}
      >
        {formatPrice(row.price)}
      </div>
      <div className="relative z-10 text-right text-gray-300">
        {row.quantity.toFixed(row.quantity < 1 ? 4 : 2)}
      </div>
      <div className="relative z-10 text-right text-gray-500">
        {row.total.toFixed(2)}
      </div>
    </div>
  );
}