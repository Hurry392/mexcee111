// src/components/trade/TradingPanel.tsx
"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { TrendingUp, TrendingDown, Info, Loader2, AlertCircle, CheckCircle2, Zap } from "lucide-react";
import { useAuthStore } from "@/store/authStore";
import { tradesAPI } from "@/lib/api";
import { useBalance } from "@/hooks/useBalance";
import { triggerPositionsRefresh } from "./OpenPositions";

interface Props {
  coinId: string;
  coinSymbol: string;
  coinPrice: number;
}

type OrderSide = "BUY" | "SELL";
type OrderType = "MARKET" | "LIMIT";

const LEVERAGE_OPTIONS = [1, 5, 10, 25, 50, 100];

export default function TradingPanel({ coinId, coinSymbol, coinPrice }: Props) {
  const { user } = useAuthStore();
  const { refreshBalance } = useBalance();

  const [side, setSide] = useState<OrderSide>("BUY");
  const [orderType, setOrderType] = useState<OrderType>("MARKET");
  const [leverage, setLeverage] = useState(10);
  const [amount, setAmount] = useState("");
  const [limitPrice, setLimitPrice] = useState(coinPrice.toString());
  const [submitting, setSubmitting] = useState(false);
  const [message, setMessage] = useState<{ type: "success" | "error"; text: string } | null>(null);

  const balance = user?.balance ?? 0;
  const amountNum = parseFloat(amount) || 0;
  const priceUsed = orderType === "MARKET" ? coinPrice : parseFloat(limitPrice) || coinPrice;
  const positionSize = amountNum * leverage;
  const estimatedQuantity = priceUsed > 0 ? positionSize / priceUsed : 0;
  const totalCost = amountNum; // no trading fee

  const handlePercentage = (percent: number) => {
    const value = (balance * percent) / 100;
    setAmount(value.toFixed(2));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setMessage(null);

    if (!user) {
      setMessage({ type: "error", text: "Please log in to trade" });
      return;
    }

    if (amountNum <= 0) {
      setMessage({ type: "error", text: "Enter a valid margin amount" });
      return;
    }

    if (amountNum < 1) {
      setMessage({ type: "error", text: "Minimum margin is $1" });
      return;
    }

    if (totalCost > balance) {
      setMessage({
        type: "error",
        text: `Insufficient balance. Need $${totalCost.toFixed(2)}`,
      });
      return;
    }

    setSubmitting(true);

    // ─── REAL API CALL ───
    const result = await tradesAPI.open({
      coinId,
      coinSymbol,
      side,
      orderType,
      leverage,
      marginAmount: amountNum,
      entryPrice: priceUsed,
    });

    setSubmitting(false);

    if (result.error) {
      setMessage({ type: "error", text: result.error });
      setTimeout(() => setMessage(null), 5000);
      return;
    }

    // ─── SUCCESS ───
    setMessage({
      type: "success",
      text: `${side === "BUY" ? "Long" : "Short"} position opened: ${estimatedQuantity.toFixed(6)} ${coinSymbol} @ $${priceUsed.toFixed(2)}`,
    });

    // Refresh balance in Zustand store (instant UI update everywhere!)
    await refreshBalance();

    // Trigger OpenPositions to refetch
    triggerPositionsRefresh();

    // Clear form
    setAmount("");
    setTimeout(() => setMessage(null), 5000);
  };

  return (
    <div className="glass-panel rounded-2xl p-4 sm:p-5 space-y-4">
      {/* ── Side Tabs (Buy/Sell) ── */}
      <div className="relative flex p-1 rounded-xl bg-white/[0.03] border border-[var(--border)]">
        {([
          { id: "BUY" as OrderSide, label: "Buy Long", icon: TrendingUp },
          { id: "SELL" as OrderSide, label: "Sell Short", icon: TrendingDown },
        ]).map((s) => {
          const Icon = s.icon;
          const isActive = side === s.id;
          return (
            <button
              key={s.id}
              type="button"
              onClick={() => setSide(s.id)}
              className={`relative flex-1 flex items-center justify-center gap-2 py-2.5 text-sm font-bold rounded-lg transition-colors z-10 ${
                isActive ? "text-white" : "text-gray-500 hover:text-gray-300"
              }`}
            >
              {isActive && (
                <motion.div
                  layoutId="tradeSidePill"
                  className={`absolute inset-0 rounded-lg ${
                    s.id === "BUY"
                      ? "bg-gradient-to-r from-green-500 to-emerald-500"
                      : "bg-gradient-to-r from-red-500 to-rose-500"
                  }`}
                  transition={{ type: "spring", stiffness: 300, damping: 30 }}
                />
              )}
              <Icon size={15} className="relative z-10" />
              <span className="relative z-10">{s.label}</span>
            </button>
          );
        })}
      </div>

      {/* ── Order Type ── */}
      <div className="flex gap-2">
        {([
          { id: "MARKET" as OrderType, label: "Market" },
          { id: "LIMIT" as OrderType, label: "Limit" },
        ]).map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setOrderType(t.id)}
            className={`flex-1 py-1.5 text-xs font-semibold rounded-lg border transition-all ${
              orderType === t.id
                ? "bg-[var(--accent)]/15 border-[var(--accent)]/40 text-[var(--accent)]"
                : "border-[var(--border)] text-gray-500 hover:text-gray-300"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* ── Leverage Selector ── */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <label className="text-xs font-medium text-gray-400 flex items-center gap-1">
            <Zap size={12} />
            Leverage
          </label>
          <span className="text-sm font-bold text-[var(--accent)]">
            {leverage}x
          </span>
        </div>
        <div className="grid grid-cols-6 gap-1.5">
          {LEVERAGE_OPTIONS.map((lev) => (
            <button
              key={lev}
              type="button"
              onClick={() => setLeverage(lev)}
              className={`py-1.5 text-[11px] font-bold rounded-md transition-all ${
                leverage === lev
                  ? "bg-[var(--accent)] text-white"
                  : "bg-white/[0.03] text-gray-500 hover:bg-white/[0.08] hover:text-gray-300"
              }`}
            >
              {lev}x
            </button>
          ))}
        </div>
      </div>

      {/* ── Form ── */}
      <form onSubmit={handleSubmit} className="space-y-3">
        {/* Limit Price */}
        {orderType === "LIMIT" && (
          <div>
            <label className="block text-xs font-medium text-gray-400 mb-1.5">
              Limit Price (USD)
            </label>
            <input
              type="number"
              step="0.01"
              value={limitPrice}
              onChange={(e) => setLimitPrice(e.target.value)}
              className="w-full px-3 py-2.5 bg-white/[0.03] border border-[var(--border)] rounded-lg text-sm text-foreground focus:outline-none focus:border-[var(--accent)]/50 transition-all font-mono"
            />
          </div>
        )}

        {/* Amount (Margin) */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label className="text-xs font-medium text-gray-400">
              Margin (USD)
            </label>
            <span className="text-[10px] text-gray-500">
              Avail: <span className="text-foreground font-semibold">${balance.toFixed(2)}</span>
            </span>
          </div>
          <div className="relative">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-semibold text-gray-500">
              $
            </span>
            <input
              type="number"
              step="0.01"
              min="1"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0.00"
              className="w-full pl-7 pr-3 py-2.5 bg-white/[0.03] border border-[var(--border)] rounded-lg text-sm text-foreground focus:outline-none focus:border-[var(--accent)]/50 transition-all font-mono"
            />
          </div>

          {/* Percentage buttons */}
          <div className="grid grid-cols-4 gap-1.5 mt-2">
            {[25, 50, 75, 100].map((pct) => (
              <button
                key={pct}
                type="button"
                onClick={() => handlePercentage(pct)}
                className="py-1 text-[10px] font-semibold text-gray-500 hover:text-foreground bg-white/[0.02] hover:bg-white/[0.05] rounded transition-all"
              >
                {pct}%
              </button>
            ))}
          </div>
        </div>

        {/* Order Summary */}
        <div className="space-y-1.5 p-3 rounded-lg bg-white/[0.02] border border-[var(--border)]">
          <SummaryRow label="Position Size" value={`$${positionSize.toFixed(2)}`} />
          <SummaryRow label="Entry Price" value={`$${priceUsed.toFixed(2)}`} />
          <SummaryRow label="Quantity" value={`${estimatedQuantity.toFixed(6)} ${coinSymbol}`} />
          <SummaryRow label={`Fee`} value={`$0.00`} muted />
          <div className="border-t border-[var(--border)] pt-1.5">
            <SummaryRow
              label="Total Cost"
              value={`$${totalCost.toFixed(2)}`}
              highlight
            />
          </div>
        </div>

        {/* Message */}
        {message && (
          <motion.div
            initial={{ opacity: 0, y: -5 }}
            animate={{ opacity: 1, y: 0 }}
            className={`flex items-start gap-2 p-2.5 rounded-lg border text-xs ${
              message.type === "success"
                ? "bg-green-500/10 border-green-500/20 text-green-400"
                : "bg-red-500/10 border-red-500/20 text-red-400"
            }`}
          >
            {message.type === "success" ? (
              <CheckCircle2 size={13} className="shrink-0 mt-0.5" />
            ) : (
              <AlertCircle size={13} className="shrink-0 mt-0.5" />
            )}
            <span>{message.text}</span>
          </motion.div>
        )}

        {/* Submit Button */}
        <button
          type="submit"
          disabled={submitting}
          className={`w-full flex items-center justify-center gap-2 py-3 rounded-xl text-white font-bold text-sm transition-all active:scale-[0.98] shadow-lg disabled:opacity-50 disabled:cursor-not-allowed ${
            side === "BUY"
              ? "bg-gradient-to-r from-green-500 to-emerald-500 shadow-green-500/20"
              : "bg-gradient-to-r from-red-500 to-rose-500 shadow-red-500/20"
          }`}
        >
          {submitting ? (
            <>
              <Loader2 size={16} className="animate-spin" />
              Opening Position...
            </>
          ) : (
            <>
              {side === "BUY" ? <TrendingUp size={16} /> : <TrendingDown size={16} />}
              {side === "BUY" ? "Buy Long" : "Sell Short"} {coinSymbol}
            </>
          )}
        </button>

        {/* Info footer */}
        <div className="flex items-start gap-2 p-2 rounded-md bg-white/[0.02] border border-[var(--border)]">
          <Info size={10} className="text-gray-500 shrink-0 mt-0.5" />
          <p className="text-[10px] text-gray-500 leading-relaxed">
            Position closes with real profit/loss based on live market prices. No trading fees on open or close.
          </p>
        </div>
      </form>
    </div>
  );
}

function SummaryRow({
  label,
  value,
  muted = false,
  highlight = false,
}: {
  label: string;
  value: string;
  muted?: boolean;
  highlight?: boolean;
}) {
  return (
    <div className="flex items-center justify-between text-[11px]">
      <span className={highlight ? "text-foreground font-semibold" : "text-gray-500"}>
        {label}
      </span>
      <span
        className={`font-mono font-semibold ${
          muted
            ? "text-gray-400"
            : highlight
            ? "text-[var(--accent)] font-bold"
            : "text-foreground"
        }`}
      >
        {value}
      </span>
    </div>
  );
}