// src/components/trade/OpenPositions.tsx
"use client";

import { useEffect, useState, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  TrendingUp,
  TrendingDown,
  X,
  Loader2,
  Info,
  Zap,
  Clock,
  DollarSign,
  Activity,
} from "lucide-react";
import { tradesAPI } from "@/lib/api";
import { triggerHistoryRefresh } from "./TradeHistory";
import { useLivePrices } from "@/hooks/useLivePrices";
import { useBalance } from "@/hooks/useBalance";
import { formatPrice } from "@/lib/markets";

interface Trade {
  id: string;
  coinId: string;
  coinSymbol: string;
  binanceSymbol: string;
  side: "BUY" | "SELL";
  orderType: string;
  leverage: number;
  marginAmount: number;
  positionSize: number;
  quantity: number;
  entryPrice: number;
  exitPrice: number | null;
  fee: number;
  pnl: number;
  pnlPercent: number;
  status: string;
  openedAt: string;
}

// ─── Refresh signal (used by TradingPanel to trigger refetch) ───
let refreshCallback: (() => void) | null = null;

export function triggerPositionsRefresh() {
  if (refreshCallback) refreshCallback();
}

export default function OpenPositions() {
  const [trades, setTrades] = useState<Trade[]>([]);
  const [loading, setLoading] = useState(true);
  const [closingId, setClosingId] = useState<string | null>(null);
  const [message, setMessage] = useState<{
    type: "success" | "error";
    text: string;
  } | null>(null);

  const { prices } = useLivePrices();
  const { refreshBalance } = useBalance();

  // ─── Fetch open trades ───
  const fetchTrades = useCallback(async () => {
    const result = await tradesAPI.list("OPEN");
    if (result.trades) {
      setTrades(result.trades as Trade[]);
    }
    setLoading(false);
  }, []);

  // ─── Register global refresh callback ───
  useEffect(() => {
    refreshCallback = fetchTrades;
    fetchTrades();
    return () => {
      refreshCallback = null;
    };
  }, [fetchTrades]);

  // ─── Close position ───
  const handleClose = async (trade: Trade) => {
    const livePrice = prices[trade.coinId]?.price;
    if (!livePrice) {
      setMessage({ type: "error", text: "Live price unavailable. Try again." });
      return;
    }

    if (!confirm(`Close ${trade.side === "BUY" ? "Long" : "Short"} position on ${trade.coinSymbol}?`)) {
      return;
    }

    setClosingId(trade.id);

    const result = await tradesAPI.close({
      tradeId: trade.id,
      exitPrice: livePrice,
    });

    setClosingId(null);

    if (result.error) {
      setMessage({ type: "error", text: result.error });
      setTimeout(() => setMessage(null), 4000);
      return;
    }

    // Success — refresh trades + balance
    const pnl = result.pnl ?? 0;
    setMessage({
      type: "success",
      text:
        pnl >= 0
          ? `Position closed. Profit: +$${pnl.toFixed(2)}`
          : `Position closed. Loss: -$${Math.abs(pnl).toFixed(2)}`,
    });

    await fetchTrades();
    await refreshBalance(); // ← Balance updates instantly!
    triggerHistoryRefresh(); // ← Trade History list updates instantly too

    setTimeout(() => setMessage(null), 4000);
  };

  // ─── Calculate live P&L for each trade ───
  const calculateLivePnL = (trade: Trade): { pnl: number; pnlPercent: number } => {
    const livePrice = prices[trade.coinId]?.price;
    if (!livePrice) return { pnl: 0, pnlPercent: 0 };

    let priceChangePercent: number;
    if (trade.side === "BUY") {
      priceChangePercent = ((livePrice - trade.entryPrice) / trade.entryPrice) * 100;
    } else {
      priceChangePercent = ((trade.entryPrice - livePrice) / trade.entryPrice) * 100;
    }

    const pnl = (priceChangePercent * trade.positionSize) / 100;
    const pnlPercent = priceChangePercent * trade.leverage;

    return { pnl, pnlPercent };
  };

  if (loading) {
    return (
      <div className="glass-panel rounded-2xl p-5 flex items-center justify-center py-12">
        <Loader2 className="w-5 h-5 text-[var(--accent)] animate-spin" />
      </div>
    );
  }

  return (
    <div className="glass-panel rounded-2xl p-4 sm:p-5">
      {/* ═══════════ HEADER ═══════════ */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-[var(--accent)]/10 flex items-center justify-center">
            <Activity size={14} className="text-[var(--accent)]" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-foreground">Open Positions</h3>
            <p className="text-[10px] text-gray-500">
              {trades.length} {trades.length === 1 ? "position" : "positions"} live
            </p>
          </div>
        </div>
        {trades.length > 0 && (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-green-500/10 border border-green-500/20 text-[10px] font-bold text-green-400">
            <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
            LIVE
          </span>
        )}
      </div>

      {/* ═══════════ MESSAGE ═══════════ */}
      <AnimatePresence>
        {message && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className={`flex items-start gap-2 p-3 rounded-lg mb-3 border ${
              message.type === "success"
                ? "bg-green-500/10 border-green-500/20 text-green-400"
                : "bg-red-500/10 border-red-500/20 text-red-400"
            }`}
          >
            <Info size={13} className="shrink-0 mt-0.5" />
            <p className="text-xs">{message.text}</p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ═══════════ EMPTY STATE ═══════════ */}
      {trades.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-8 px-4 text-center">
          <div className="w-12 h-12 rounded-2xl bg-white/[0.03] border border-[var(--border)] flex items-center justify-center mb-3">
            <TrendingUp size={20} className="text-gray-500" />
          </div>
          <p className="text-sm font-semibold text-foreground mb-1">
            No open positions
          </p>
          <p className="text-xs text-gray-500">
            Open a trade to see it here with live P&L
          </p>
        </div>
      ) : (
        /* ═══════════ POSITIONS LIST ═══════════ */
        <div className="space-y-2">
          {trades.map((trade) => {
            const { pnl, pnlPercent } = calculateLivePnL(trade);
            const livePrice = prices[trade.coinId]?.price ?? trade.entryPrice;
            const isProfit = pnl >= 0;
            const isLong = trade.side === "BUY";

            return (
              <motion.div
                key={trade.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-3 sm:p-4 rounded-xl bg-white/[0.02] border border-[var(--border)] hover:border-[var(--accent)]/30 transition-all"
              >
                {/* Top Row: Symbol + Side + Leverage */}
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <div
                      className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                        isLong
                          ? "bg-green-500/15 text-green-400"
                          : "bg-red-500/15 text-red-400"
                      }`}
                    >
                      {isLong ? <TrendingUp size={14} /> : <TrendingDown size={14} />}
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-sm font-bold text-foreground">
                          {trade.coinSymbol}
                        </span>
                        <span
                          className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${
                            isLong
                              ? "bg-green-500/15 text-green-400"
                              : "bg-red-500/15 text-red-400"
                          }`}
                        >
                          {isLong ? "LONG" : "SHORT"}
                        </span>
                        <span className="inline-flex items-center gap-0.5 text-[9px] font-bold px-1.5 py-0.5 rounded bg-[var(--accent)]/15 text-[var(--accent)]">
                          <Zap size={8} />
                          {trade.leverage}x
                        </span>
                      </div>
                      <div className="text-[10px] text-gray-500 flex items-center gap-1 mt-0.5">
                        <Clock size={9} />
                        {new Date(trade.openedAt).toLocaleString("en-US", {
                          month: "short",
                          day: "numeric",
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </div>
                    </div>
                  </div>

                  {/* P&L Badge */}
                  <div className="text-right">
                    <div
                      className={`text-sm font-bold font-mono ${
                        isProfit ? "text-green-400" : "text-red-400"
                      }`}
                    >
                      {isProfit ? "+" : "-"}${Math.abs(pnl).toFixed(2)}
                    </div>
                    <div
                      className={`text-[10px] font-semibold ${
                        isProfit ? "text-green-400" : "text-red-400"
                      }`}
                    >
                      {isProfit ? "+" : "-"}
                      {Math.abs(pnlPercent).toFixed(2)}% ROI
                    </div>
                  </div>
                </div>

                {/* Details Grid */}
                <div className="grid grid-cols-4 gap-2 mb-3">
                  <MiniStat
                    label="Margin"
                    value={`$${trade.marginAmount.toFixed(2)}`}
                  />
                  <MiniStat
                    label="Size"
                    value={`$${trade.positionSize.toFixed(2)}`}
                  />
                  <MiniStat
                    label="Entry"
                    value={`$${formatPrice(trade.entryPrice)}`}
                  />
                  <MiniStat
                    label="Mark"
                    value={`$${formatPrice(livePrice)}`}
                    highlight
                  />
                </div>

                {/* Close Button */}
                <button
                  onClick={() => handleClose(trade)}
                  disabled={closingId === trade.id}
                  className="w-full flex items-center justify-center gap-2 py-2 rounded-lg bg-white/[0.03] border border-[var(--border)] hover:bg-red-500/10 hover:border-red-500/30 hover:text-red-400 text-foreground text-xs font-semibold transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {closingId === trade.id ? (
                    <>
                      <Loader2 size={12} className="animate-spin" />
                      Closing...
                    </>
                  ) : (
                    <>
                      <X size={12} />
                      Close Position
                    </>
                  )}
                </button>
              </motion.div>
            );
          })}
        </div>
      )}

      {/* ═══════════ FOOTER NOTICE ═══════════ */}
      {trades.length > 0 && (
        <div className="flex items-start gap-2 p-2.5 mt-3 rounded-lg bg-white/[0.02] border border-[var(--border)]">
          <DollarSign size={11} className="text-gray-500 shrink-0 mt-0.5" />
          <p className="text-[10px] text-gray-500 leading-relaxed">
            P&L updates in real-time based on live market prices. Close position anytime to realize profit/loss.
          </p>
        </div>
      )}
    </div>
  );
}

// ─── Mini Stat Component ───
function MiniStat({
  label,
  value,
  highlight = false,
}: {
  label: string;
  value: string;
  highlight?: boolean;
}) {
  return (
    <div className="p-2 rounded-md bg-white/[0.02] border border-[var(--border)]">
      <div className="text-[9px] text-gray-500 uppercase tracking-wider font-semibold mb-0.5">
        {label}
      </div>
      <div
        className={`text-[11px] font-bold font-mono truncate ${
          highlight ? "text-[var(--accent)]" : "text-foreground"
        }`}
      >
        {value}
      </div>
    </div>
  );
}