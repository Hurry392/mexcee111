// src/components/trade/CandlestickChart.tsx
"use client";

import { useEffect, useRef, useState } from "react";
import {
  createChart,
  IChartApi,
  ISeriesApi,
  CandlestickSeries,
  ColorType,
  UTCTimestamp,
} from "lightweight-charts";
import { Loader2, AlertCircle, Radio } from "lucide-react";
import { CandlestickData, COINGECKO_TO_BINANCE } from "@/lib/markets";
import { useLiveKline } from "@/hooks/useLiveKline";

interface Props {
  coinId: string;
  days?: number;
}

export default function CandlestickChart({ coinId, days = 1 }: Props) {
  const chartContainerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const seriesRef = useRef<ISeriesApi<"Candlestick"> | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const binanceSymbol = COINGECKO_TO_BINANCE[coinId] || null;
  const { liveCandle, isStreaming } = useLiveKline({ binanceSymbol, days });

  // ─── Initialize chart once ───
  useEffect(() => {
    if (!chartContainerRef.current) return;

    const chart = createChart(chartContainerRef.current, {
      width: chartContainerRef.current.clientWidth,
      height: 400,
      layout: {
        background: { type: ColorType.Solid, color: "transparent" },
        textColor: "#9ca3af",
        fontSize: 11,
      },
      grid: {
        vertLines: { color: "rgba(255,255,255,0.04)" },
        horzLines: { color: "rgba(255,255,255,0.04)" },
      },
      rightPriceScale: {
        borderColor: "rgba(255,255,255,0.08)",
      },
      timeScale: {
        borderColor: "rgba(255,255,255,0.08)",
        timeVisible: true,
        secondsVisible: false,
      },
      crosshair: {
        mode: 1,
        vertLine: {
          color: "rgba(59,130,246,0.5)",
          width: 1,
          style: 2,
        },
        horzLine: {
          color: "rgba(59,130,246,0.5)",
          width: 1,
          style: 2,
        },
      },
    });

    const candleSeries = chart.addSeries(CandlestickSeries, {
      upColor: "#22c55e",
      downColor: "#ef4444",
      borderUpColor: "#22c55e",
      borderDownColor: "#ef4444",
      wickUpColor: "#22c55e",
      wickDownColor: "#ef4444",
    });

    chartRef.current = chart;
    seriesRef.current = candleSeries;

    const handleResize = () => {
      if (chartContainerRef.current && chartRef.current) {
        chartRef.current.applyOptions({
          width: chartContainerRef.current.clientWidth,
        });
      }
    };
    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
      chart.remove();
      chartRef.current = null;
      seriesRef.current = null;
    };
  }, []);

  // ─── Fetch historical data when coin/timeframe changes ───
  useEffect(() => {
    if (!seriesRef.current) return;

    let isCancelled = false;

    const fetchData = async () => {
      setLoading(true);
      setError(null);

      // Clear existing chart data immediately
      seriesRef.current?.setData([]);

      try {
        const res = await fetch(`/api/markets/chart?coin=${coinId}&days=${days}`);
        const data = await res.json();

        if (isCancelled) return;

        if (!res.ok || !data.candles || data.candles.length === 0) {
          setError(data.error || "Chart data unavailable");
          return;
        }

        const candles: CandlestickData[] = data.candles;

        // Convert to lightweight-charts format with UTCTimestamp
        const chartData = candles.map((c) => ({
          time: c.time as UTCTimestamp,
          open: c.open,
          high: c.high,
          low: c.low,
          close: c.close,
        }));

        seriesRef.current?.setData(chartData);
        chartRef.current?.timeScale().fitContent();
      } catch (err) {
        if (!isCancelled) {
          console.error("Chart fetch error:", err);
          setError("Network error loading chart");
        }
      } finally {
        if (!isCancelled) {
          setLoading(false);
        }
      }
    };

    fetchData();

    return () => {
      isCancelled = true;
    };
  }, [coinId, days]);

  // ─── Real-time updates from WebSocket ───
  useEffect(() => {
    if (!seriesRef.current || !liveCandle || loading) return;

    try {
      // update() will either ADD a new candle (if time is newer)
      // or UPDATE the current forming candle (if time matches the last)
      seriesRef.current.update({
        time: liveCandle.time as UTCTimestamp,
        open: liveCandle.open,
        high: liveCandle.high,
        low: liveCandle.low,
        close: liveCandle.close,
      });
    } catch {
      // Ignore — sometimes the live candle time is older than existing
      // (happens during coin switch race conditions)
    }
  }, [liveCandle, loading]);

  return (
    <div className="relative">
      {/* Streaming Indicator */}
      {isStreaming && !loading && !error && (
        <div className="absolute top-2 right-2 z-20 flex items-center gap-1.5 px-2 py-1 rounded-md bg-green-500/15 border border-green-500/25 backdrop-blur-sm">
          <Radio size={10} className="text-green-400 animate-pulse" />
          <span className="text-[10px] uppercase tracking-wider font-bold text-green-400">
            Streaming
          </span>
        </div>
      )}

      {/* Loading Overlay */}
      {loading && (
        <div className="absolute inset-0 flex items-center justify-center bg-card/60 backdrop-blur-sm z-10 rounded-xl">
          <div className="flex flex-col items-center gap-2">
            <Loader2 className="w-6 h-6 text-[var(--accent)] animate-spin" />
            <span className="text-xs text-gray-500">Loading chart...</span>
          </div>
        </div>
      )}

      {/* Error Overlay */}
      {error && (
        <div className="absolute inset-0 flex items-center justify-center bg-card/60 backdrop-blur-sm z-10 rounded-xl">
          <div className="flex flex-col items-center gap-2 text-center px-4">
            <AlertCircle size={24} className="text-red-400" />
            <span className="text-sm font-medium text-red-400">{error}</span>
            <span className="text-[11px] text-gray-500">
              Try a different timeframe or coin
            </span>
          </div>
        </div>
      )}

      <div ref={chartContainerRef} className="w-full" />
    </div>
  );
}