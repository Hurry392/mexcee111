// src/components/trade/TradeHistory.tsx
"use client";

import { useEffect, useState, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { TrendingUp, TrendingDown, Loader2, History, Clock } from "lucide-react";
import { tradesAPI } from "@/lib/api";
import { formatPrice } from "@/lib/markets";

interface ClosedTrade {
  id: string;
  coinSymbol: string;
  side: "BUY" | "SELL";
  leverage: number;
  marginAmount: number;
  entryPrice: number;
  exitPrice: number | null;
  pnl: number;
  pnlPercent: number;
  status: string;
  closeReason?: string | null;
  openedAt: string;
  closedAt: string | null;
}

// ─── Refresh signal (triggered by OpenPositions after a self-close) ───
let refreshCallback: (() => void) | null = null;

export function triggerHistoryRefresh() {
  if (refreshCallback) refreshCallback();
}

export default function TradeHistory() {
  const [trades, setTrades] = useState<ClosedTrade[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchHistory = useCallback(async () => {
    const result = await tradesAPI.list("CLOSED");
    if (result.trades) {
      setTrades(result.trades as ClosedTrade[]);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    refreshCallback = fetchHistory;
    fetchHistory();
    return () => {
      refreshCallback = null;
    };
  }, [fetchHistory]);

  return (
    <div className="glass-panel rounded-2xl p-4 sm:p-5">
      <div className="flex items-center gap-2 mb-4">
        <History size={16} className="text-gray-400" />
        <h3 className="text-sm font-bold text-foreground">Trade History</h3>
        {trades.length > 0 && (
          <span className="text-[10px] text-gray-500 bg-white/5 px-1.5 py-0.5 rounded-md">
            {trades.length}
          </span>
        )}
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-10">
          <Loader2 className="w-5 h-5 text-[var(--accent)] animate-spin" />
        </div>
      ) : trades.length === 0 ? (
        <div className="text-center py-8">
          <Clock className="w-8 h-8 text-gray-600 mx-auto mb-2" />
          <p className="text-xs text-gray-500">No closed trades yet</p>
        </div>
      ) : (
        <div className="space-y-2 max-h-[420px] overflow-y-auto pr-1">
          <AnimatePresence>
            {trades.map((trade) => {
              const isLong = trade.side === "BUY";
              const isProfit = trade.pnl >= 0;
              const isLiquidated = trade.closeReason === "LIQUIDATED";

              return (
                <motion.div
                  key={trade.id}
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  className="p-3 rounded-xl bg-white/[0.02] border border-[var(--border)]"
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <div className="flex items-center gap-2">
                      <div
                        className={`w-6 h-6 rounded-md flex items-center justify-center ${
                          isLong ? "bg-green-500/10 text-green-400" : "bg-red-500/10 text-red-400"
                        }`}
                      >
                        {isLong ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
                      </div>
                      <span className="text-xs font-bold text-foreground">
                        {trade.coinSymbol}/USDT
                      </span>
                      <span className="text-[10px] text-gray-500">{trade.leverage}x</span>
                      {isLiquidated && (
                        <span className="text-[9px] font-semibold text-red-400 bg-red-500/10 px-1.5 py-0.5 rounded">
                          LIQUIDATED
                        </span>
                      )}
                    </div>
                    <span
                      className={`text-xs font-bold font-mono ${
                        isProfit ? "text-green-400" : "text-red-400"
                      }`}
                    >
                      {isProfit ? "+" : ""}${trade.pnl.toFixed(2)}
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-[10px] text-gray-500">
                    <span>
                      Entry ${formatPrice(trade.entryPrice)}
                      {trade.exitPrice != null && ` → Exit $${formatPrice(trade.exitPrice)}`}
                    </span>
                    <span className={isProfit ? "text-green-400/70" : "text-red-400/70"}>
                      {trade.pnlPercent >= 0 ? "+" : ""}
                      {trade.pnlPercent.toFixed(2)}%
                    </span>
                  </div>

                  {trade.closedAt && (
                    <div className="mt-1 text-[10px] text-gray-600">
                      Closed {new Date(trade.closedAt).toLocaleString()}
                    </div>
                  )}
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}
