// src/components/LiveTicker.tsx
"use client";

import { TrendingUp, TrendingDown } from "lucide-react";
import { useMarkets } from "@/hooks/useMarkets";
import { formatPrice, formatPercent } from "@/lib/markets";

export default function LiveTicker() {
  const { markets, loading, isLive } = useMarkets(30000);

  // Show skeleton while loading
  if (loading || markets.length === 0) {
    return (
      <div className="relative w-full h-9 bg-card border-y border-[var(--border)] overflow-hidden backdrop-blur-xl">
        <div className="absolute left-0 top-0 bottom-0 z-20 flex items-center gap-1.5 px-3 bg-gradient-to-r from-[var(--background)] via-[var(--background)]/95 to-transparent pr-6">
          <span className="relative flex h-1.5 w-1.5">
            <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${isLive ? "bg-green-400" : "bg-amber-400"}`} />
            <span className={`relative inline-flex rounded-full h-1.5 w-1.5 ${isLive ? "bg-green-500" : "bg-amber-500"}`} />
          </span>
          <span className={`text-[10px] uppercase tracking-wider font-bold ${isLive ? "text-green-400" : "text-amber-400"}`}>
            {isLive ? "Live" : "Connecting"}
          </span>
        </div>
        <div className="flex items-center justify-center h-full">
          <div className="text-[10px] text-gray-500 uppercase tracking-wider">
            Loading market data...
          </div>
        </div>
      </div>
    );
  }

  // Double the array for seamless infinite scroll
  const tickerItems = [...markets, ...markets];

  return (
    <div className="relative w-full h-9 bg-card border-y border-[var(--border)] overflow-hidden backdrop-blur-xl">
      {/* Live indicator (left side) */}
      <div className="absolute left-0 top-0 bottom-0 z-20 flex items-center gap-1.5 px-3 bg-gradient-to-r from-[var(--background)] via-[var(--background)]/95 to-transparent pr-6">
        <span className="relative flex h-1.5 w-1.5">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75" />
          <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-green-500" />
        </span>
        <span className="text-[10px] uppercase tracking-wider font-bold text-green-400">
          Live
        </span>
      </div>

      {/* Right fade gradient */}
      <div className="absolute right-0 top-0 bottom-0 w-12 z-20 bg-gradient-to-l from-[var(--background)] to-transparent pointer-events-none" />

      {/* Scrolling ticker */}
      <div
        className="flex items-center h-full animate-ticker"
        style={{ width: "max-content" }}
      >
        {tickerItems.map((coin, idx) => {
          const isUp = coin.price_change_percentage_24h >= 0;
          return (
            <div
              key={`${coin.id}-${idx}`}
              className="flex items-center gap-2 px-5 border-r border-[var(--border)] h-full"
            >
              <span className="text-xs font-bold text-foreground uppercase">
                {coin.symbol}
              </span>
              <span className="text-xs font-medium text-gray-400 font-mono">
                ${formatPrice(coin.current_price)}
              </span>
              <span
                className={`flex items-center gap-0.5 text-[11px] font-semibold ${
                  isUp ? "text-green-400" : "text-red-400"
                }`}
              >
                {isUp ? <TrendingUp size={10} /> : <TrendingDown size={10} />}
                {formatPercent(coin.price_change_percentage_24h)}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}