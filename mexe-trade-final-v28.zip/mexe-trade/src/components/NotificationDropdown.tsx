// src/components/NotificationDropdown.tsx
"use client";

import { useState, useRef, useEffect } from "react";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import {
  Bell,
  ArrowDownToLine,
  ArrowUpFromLine,
  ShieldCheck,
  MessageSquare,
  TrendingUp,
  Info,
  CheckCheck,
  Inbox,
} from "lucide-react";
import { useNotifications, UserNotification } from "@/hooks/useNotifications";

const TYPE_META: Record<string, { icon: typeof Bell; color: string; bg: string }> = {
  DEPOSIT: { icon: ArrowDownToLine, color: "text-green-400", bg: "bg-green-500/10" },
  WITHDRAWAL: { icon: ArrowUpFromLine, color: "text-red-400", bg: "bg-red-500/10" },
  KYC: { icon: ShieldCheck, color: "text-purple-400", bg: "bg-purple-500/10" },
  CHAT: { icon: MessageSquare, color: "text-blue-400", bg: "bg-blue-500/10" },
  TRADE: { icon: TrendingUp, color: "text-amber-400", bg: "bg-amber-500/10" },
  SYSTEM: { icon: Info, color: "text-gray-400", bg: "bg-gray-500/10" },
};

export default function NotificationDropdown() {
  const router = useRouter();
  const { notifications, unreadCount, markAsRead, markAllAsRead } = useNotifications();
  const [open, setOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleNotificationClick = async (notif: UserNotification) => {
    if (!notif.isRead) {
      await markAsRead(notif.id);
    }
    if (notif.actionUrl) {
      setOpen(false);
      router.push(notif.actionUrl);
    }
  };

  const handleMarkAllRead = async (e: React.MouseEvent) => {
    e.stopPropagation();
    await markAllAsRead();
  };

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center justify-center w-9 h-9 rounded-lg hover:bg-white/5 text-gray-400 hover:text-[var(--accent)] transition-all relative"
        aria-label="Notifications"
      >
        <Bell size={18} />
        {unreadCount > 0 && (
          <motion.span
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            className="absolute top-0.5 right-0.5 min-w-[16px] h-[16px] px-1 rounded-full bg-red-500 border-2 border-background text-[9px] font-bold text-white flex items-center justify-center animate-pulse"
          >
            {unreadCount > 9 ? "9+" : unreadCount}
          </motion.span>
        )}
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -8, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -8, scale: 0.95 }}
            transition={{ duration: 0.15 }}
            className="absolute right-0 mt-2 w-[360px] max-w-[calc(100vw-24px)] rounded-xl glass-panel shadow-2xl border border-[var(--border)] z-50 overflow-hidden"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b border-[var(--border)]">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-[var(--accent)]/10 border border-[var(--accent)]/20 flex items-center justify-center">
                  <Bell size={14} className="text-[var(--accent)]" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-foreground">Notifications</h3>
                  <p className="text-[10px] text-gray-500">
                    {unreadCount === 0
                      ? "You're all caught up"
                      : `${unreadCount} unread`}
                  </p>
                </div>
              </div>
              {unreadCount > 0 && (
                <button
                  onClick={handleMarkAllRead}
                  className="flex items-center gap-1 px-2 py-1 rounded-md bg-white/5 hover:bg-[var(--accent)]/10 text-[10px] text-gray-400 hover:text-[var(--accent)] font-semibold transition-all"
                >
                  <CheckCheck size={10} />
                  Mark all read
                </button>
              )}
            </div>

            {/* Notifications list */}
            <div className="max-h-[400px] overflow-y-auto scrollbar-thin">
              {notifications.length === 0 ? (
                <div className="p-8 text-center">
                  <div className="w-12 h-12 mx-auto mb-3 rounded-xl bg-white/[0.03] border border-[var(--border)] flex items-center justify-center">
                    <Inbox className="w-6 h-6 text-gray-600" />
                  </div>
                  <p className="text-xs text-gray-400 font-medium">No notifications yet</p>
                  <p className="text-[10px] text-gray-500 mt-1">
                    We&apos;ll notify you when something happens
                  </p>
                </div>
              ) : (
                <div className="divide-y divide-[var(--border)]">
                  {notifications.map((notif) => (
                    <NotificationItem
                      key={notif.id}
                      notification={notif}
                      onClick={() => handleNotificationClick(notif)}
                    />
                  ))}
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ─── Notification Item ───
function NotificationItem({
  notification,
  onClick,
}: {
  notification: UserNotification;
  onClick: () => void;
}) {
  const meta = TYPE_META[notification.type] || TYPE_META.SYSTEM;
  const Icon = meta.icon;

  return (
    <button
      onClick={onClick}
      className={`w-full flex items-start gap-3 p-3 text-left transition-all ${
        notification.isRead
          ? "hover:bg-white/[0.02]"
          : "bg-[var(--accent)]/[0.03] hover:bg-[var(--accent)]/[0.06]"
      }`}
    >
      <div
        className={`w-9 h-9 rounded-lg ${meta.bg} border border-current/20 flex items-center justify-center shrink-0 ${meta.color}`}
      >
        <Icon className="w-4 h-4" />
      </div>

      <div className="flex-1 min-w-0">
        <div className="flex items-start justify-between gap-2 mb-0.5">
          <p
            className={`text-xs truncate ${
              notification.isRead ? "text-gray-400" : "text-foreground font-bold"
            }`}
          >
            {notification.title}
          </p>
          {!notification.isRead && (
            <span className="w-2 h-2 rounded-full bg-[var(--accent)] shrink-0 mt-1.5" />
          )}
        </div>
        <p className="text-[11px] text-gray-500 line-clamp-2 leading-relaxed">
          {notification.message}
        </p>
        <p className="text-[10px] text-gray-600 mt-1">
          {formatRelativeTime(notification.createdAt)}
        </p>
      </div>
    </button>
  );
}

// ─── Helpers ───
function formatRelativeTime(dateStr: string): string {
  const date = new Date(dateStr);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);

  if (diffMins < 1) return "just now";
  if (diffMins < 60) return `${diffMins}m ago`;
  if (diffHours < 24) return `${diffHours}h ago`;
  if (diffDays === 1) return "yesterday";
  if (diffDays < 7) return `${diffDays}d ago`;
  return date.toLocaleDateString();
}