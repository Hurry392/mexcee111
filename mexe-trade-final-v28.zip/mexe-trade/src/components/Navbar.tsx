// src/components/Navbar.tsx
"use client";

import { authAPI } from "@/lib/api";
import { LogOut, Wallet, Lock } from "lucide-react";
import { useMarkets } from "@/hooks/useMarkets";
import { useAuthStore } from "@/store/authStore";
import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useThemeStore, Theme } from "@/store/themeStore";
import { useUIStore } from "@/store/uiStore";
import {

  Sun,
  Moon,
  Terminal,
  ChevronDown,
  Menu,
} from "lucide-react";
import { PLATFORM_CONFIG } from "@/config/constants";
import Link from "next/link";
import NotificationDropdown from "@/components/NotificationDropdown";

const THEMES: { id: Theme; label: string; Icon: React.ElementType; iconClass: string }[] = [
  { id: "deep-space", label: "Deep Space", Icon: Moon, iconClass: "text-blue-400" },
  { id: "cyberpunk", label: "Cyberpunk", Icon: Terminal, iconClass: "text-green-400" },
  { id: "light", label: "Light", Icon: Sun, iconClass: "text-amber-400" },
];

export default function Navbar() {
  const { theme, setTheme } = useThemeStore();
  const { setSidebarOpen } = useUIStore();
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setDropdownOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const ActiveTheme = THEMES.find((t) => t.id === theme) ?? THEMES[0];

  return (
    <nav className="sticky top-0 left-0 w-full h-14 lg:h-16 glass-panel z-40 px-3 lg:px-6 flex items-center justify-between border-b border-[var(--border)]">
      {/* ── Left: Hamburger + Brand ── */}
      <div className="flex items-center gap-3">
        <button
          onClick={() => setSidebarOpen(true)}
          className="lg:hidden p-1.5 rounded-lg text-gray-400 hover:text-[var(--accent)] hover:bg-white/5 transition-all active:scale-95"
          aria-label="Open menu"
        >
          <Menu size={22} />
        </button>

        <Link href="/" className="flex items-center gap-2 select-none group">
          <motion.div
            whileHover={{ rotate: 180 }}
            transition={{ duration: 0.5, ease: "easeInOut" }}
            className="flex items-center justify-center w-8 h-8 rounded-lg overflow-hidden"
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/logo.png" alt="Logo" className="w-full h-full object-cover" />
          </motion.div>
          <div className="hidden sm:flex flex-col">
            <span className="font-bold text-sm tracking-wide gradient-text leading-tight">
              {PLATFORM_CONFIG.name}
            </span>
            <span className="text-[10px] text-gray-500 leading-tight hidden md:block">
              Trading Platform
            </span>
          </div>
        </Link>
      </div>

      {/* ── Center: Live Status ── */}
      <LiveStatusBadge />

      {/* ── Right: Actions ── */}
      <div className="flex items-center gap-1.5 sm:gap-2 md:gap-3">
        {/* ✅ NOTIFICATION BELL (Real functionality!) */}
        <NotificationDropdown />

        {/* Theme Switcher */}
        <div className="relative" ref={dropdownRef}>
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => setDropdownOpen((prev) => !prev)}
            className="flex items-center gap-1.5 sm:gap-2 px-2.5 sm:px-3.5 py-1.5 rounded-lg
                       border border-[var(--border)] text-sm font-medium
                       hover:bg-white/5 transition-all"
          >
            <ActiveTheme.Icon className={`w-4 h-4 ${ActiveTheme.iconClass}`} />
            <span className="capitalize hidden sm:inline text-xs">{ActiveTheme.label}</span>
            <motion.span animate={{ rotate: dropdownOpen ? 180 : 0 }} transition={{ duration: 0.2 }}>
              <ChevronDown className="w-3 h-3 opacity-60" />
            </motion.span>
          </motion.button>

          <AnimatePresence>
            {dropdownOpen && (
              <motion.div
                initial={{ opacity: 0, y: -8, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -8, scale: 0.95 }}
                transition={{ duration: 0.15 }}
                className="absolute right-0 mt-2 w-48 rounded-xl glass-panel p-1.5
                           shadow-2xl border border-[var(--border)] flex flex-col gap-0.5 z-50"
              >
                <div className="px-3 py-2 border-b border-[var(--border)] mb-1">
                  <span className="text-[10px] uppercase tracking-wider text-gray-500 font-semibold">
                    Theme
                  </span>
                </div>
                {THEMES.map(({ id, label, Icon, iconClass }) => (
                  <button
                    key={id}
                    onClick={() => {
                      setTheme(id);
                      setDropdownOpen(false);
                    }}
                    className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg
                                text-sm transition-all duration-150
                                ${
                                  theme === id
                                    ? "bg-[var(--accent)]/15 text-[var(--accent)] border border-[var(--accent)]/20"
                                    : "hover:bg-white/5 text-gray-300"
                                }`}
                  >
                    <Icon className={`w-4 h-4 ${theme === id ? "text-[var(--accent)]" : iconClass}`} />
                    <span>{label}</span>
                    {theme === id && (
                      <motion.div
                        layoutId="activeTheme"
                        className="ml-auto w-1.5 h-1.5 rounded-full bg-[var(--accent)]"
                      />
                    )}
                  </button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Auth Buttons / User Badge */}
        <AuthSection />
      </div>
    </nav>
  );
}

// ─── Auth Section ───
function AuthSection() {
  const { user, isAuthenticated, logout } = useAuthStore();
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setDropdownOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleLogout = async () => {
    await authAPI.logout();
    logout();
    setDropdownOpen(false);
    window.location.href = "/login";
  };

  if (isAuthenticated && user) {
    return (
      <div className="relative" ref={dropdownRef}>
        <button
          onClick={() => setDropdownOpen(!dropdownOpen)}
          className="flex items-center gap-2 hover:opacity-90 transition-opacity"
        >
          <div className="hidden sm:flex flex-col items-end leading-tight">
            <span className="text-[10px] text-gray-500">Balance</span>
            <span className="text-xs font-bold text-foreground">
              ${user.balance.toFixed(2)}
            </span>
          </div>
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[var(--accent)] to-purple-500 flex items-center justify-center text-white font-bold text-xs shadow-lg">
            {user.email.charAt(0).toUpperCase()}
          </div>
        </button>

        <AnimatePresence>
          {dropdownOpen && (
            <motion.div
              initial={{ opacity: 0, y: -8, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -8, scale: 0.95 }}
              transition={{ duration: 0.15 }}
              className="absolute right-0 mt-2 w-56 rounded-xl glass-panel p-1.5 shadow-2xl border border-[var(--border)] z-50"
            >
              <div className="px-3 py-2 border-b border-[var(--border)] mb-1">
                <div className="text-xs font-semibold text-foreground truncate">
                  {user.email}
                </div>
                <div className="text-[10px] text-gray-500 mt-0.5">
                  Balance: ${user.balance.toFixed(2)}
                </div>
              </div>

              <Link href="/wallet" onClick={() => setDropdownOpen(false)}>
                <button className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm text-gray-300 hover:bg-white/5 transition-all">
                  <Wallet size={14} />
                  <span>Wallet</span>
                </button>
              </Link>

              <Link href="/security" onClick={() => setDropdownOpen(false)}>
                <button className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm text-gray-300 hover:bg-white/5 transition-all">
                  <Lock size={14} />
                  <span>Security</span>
                </button>
              </Link>

              <button
                onClick={handleLogout}
                className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm text-red-400 hover:bg-red-500/10 transition-all border-t border-[var(--border)] mt-1 pt-2.5"
              >
                <LogOut size={14} />
                <span>Sign Out</span>
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-1.5">
      <Link href="/login">
        <button className="hidden sm:flex px-3 py-1.5 text-xs font-semibold rounded-lg hover:bg-white/5 text-gray-300 hover:text-white transition-all border border-transparent hover:border-[var(--border)]">
          Log In
        </button>
      </Link>
      <Link href="/signup">
        <button className="px-3 sm:px-4 py-1.5 sm:py-2 text-xs font-bold rounded-lg bg-gradient-to-r from-yellow-500 to-amber-500 text-black hover:from-yellow-400 hover:to-amber-400 transition-all active:scale-95 shadow-lg shadow-yellow-500/20">
          Sign Up
        </button>
      </Link>
    </div>
  );
}

// ─── Live Status Badge ───
function LiveStatusBadge() {
  const { isLive } = useMarkets();

  return (
    <div className="hidden xl:flex items-center">
      <div
        className={`flex items-center gap-2 px-4 py-1.5 rounded-full border transition-colors ${
          isLive
            ? "border-green-500/20 bg-green-500/[0.05]"
            : "border-amber-500/20 bg-amber-500/[0.05]"
        }`}
      >
        <span className="relative flex h-2 w-2">
          <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${isLive ? "bg-green-400" : "bg-amber-400"}`} />
          <span className={`relative inline-flex rounded-full h-2 w-2 ${isLive ? "bg-green-500" : "bg-amber-500"}`} />
        </span>
        <span className={`text-xs font-semibold tracking-wide ${isLive ? "text-green-400" : "text-amber-400"}`}>
          {isLive ? "Live Markets" : "Connecting..."}
        </span>
      </div>
    </div>
  );
}