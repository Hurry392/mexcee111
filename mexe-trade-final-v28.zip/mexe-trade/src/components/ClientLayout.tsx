// src/components/ClientLayout.tsx
"use client";

import { useState, useEffect } from "react";
import { usePathname } from "next/navigation";
import { useThemeStore, useAdminThemeStore } from "@/store/themeStore";
import { useUIStore } from "@/store/uiStore";
import { useAuth } from "@/hooks/useAuth";
import Navbar from "@/components/Navbar";
import Sidebar from "@/components/Sidebar";
import BottomNav from "@/components/BottomNav";
import LiveTicker from "@/components/LiveTicker";

const AUTH_ROUTES = ["/login", "/signup", "/forgot-password"];

export default function ClientLayout({ children }: { children: React.ReactNode }) {
  const [mounted, setMounted] = useState(false);
  const pathname = usePathname();
  const { theme: userTheme } = useThemeStore();
  const { theme: adminTheme } = useAdminThemeStore();
  const { sidebarOpen } = useUIStore();

  // ─── Check route types ───
  const isAuthRoute = AUTH_ROUTES.includes(pathname);
  const isAdminRoute = pathname.startsWith("/admin");

  // ─── Pick correct theme based on route ───
  const activeTheme = isAdminRoute ? adminTheme : userTheme;

  useAuth();

  useEffect(() => {
    setMounted(true);
    document.documentElement.setAttribute("data-theme", activeTheme);
  }, [activeTheme]);

  useEffect(() => {
    if (sidebarOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [sidebarOpen]);

  if (!mounted) {
    return (
      <div className="flex items-center justify-center h-screen bg-[#030712]">
        <div className="flex flex-col items-center gap-4">
          <div className="relative w-12 h-12">
            <div className="absolute inset-0 rounded-full border-2 border-transparent border-t-[#3b82f6] animate-spin" />
            <div
              className="absolute inset-1 rounded-full border-2 border-transparent border-b-[#a855f7] animate-spin"
              style={{ animationDirection: "reverse", animationDuration: "1.5s" }}
            />
          </div>
          <span className="text-sm text-gray-500 font-medium tracking-wider">LOADING</span>
        </div>
      </div>
    );
  }

  // ─── Admin routes — render without user shell ───
  if (isAdminRoute) {
    return (
      <div className="min-h-screen bg-background text-foreground transition-colors duration-300">
        {children}
      </div>
    );
  }

  // ─── Auth pages: render without main shell ───
  if (isAuthRoute) {
    return (
      <div className="min-h-screen bg-background text-foreground transition-colors duration-300">
        {children}
      </div>
    );
  }

  // ─── Main app shell (user routes) ───
  return (
    <div className="flex h-screen overflow-hidden bg-background text-foreground transition-colors duration-300">
      <Sidebar />
      <div className="flex-1 flex flex-col h-screen overflow-hidden relative">
        <Navbar />
        <LiveTicker />
        <main className="flex-1 overflow-y-auto pb-16 lg:pb-0">{children}</main>
        <BottomNav />
      </div>
    </div>
  );
}