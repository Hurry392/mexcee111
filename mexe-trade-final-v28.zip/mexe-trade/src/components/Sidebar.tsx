// src/components/Sidebar.tsx
"use client";

import { useState } from "react";
import { useAuthStore } from "@/store/authStore";
import { authAPI } from "@/lib/api";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { useUIStore } from "@/store/uiStore";
import { PLATFORM_CONFIG } from "@/config/constants";
import {
  Home,
  LineChart,
  Zap,
  Wallet,
  ArrowDownUp,
  ShieldCheck,
  Users,
  Lock,
  LogOut,
  X,
  MessageCircle,

  ChevronRight,
  Copy,
  Check,
} from "lucide-react";

// Navigation items
const NAV_LINKS = [
  { name: "Home", href: "/", icon: Home },
  { name: "Markets", href: "/markets", icon: LineChart },
  { name: "Trade", href: "/trade", icon: Zap },
  { name: "Wallet", href: "/wallet", icon: Wallet },
  { name: "Funds", href: "/funds", icon: ArrowDownUp },
  { name: "Deposit & Withdrawal", href: "/records", icon: ArrowDownUp },
  { name: "KYC Verification", href: "/kyc", icon: ShieldCheck },
  { name: "Referrals", href: "/referrals", icon: Users },
  { name: "Security Center", href: "/security", icon: Lock },
  { name: "Chat Support", href: "/chat", icon: MessageCircle },
];

export default function Sidebar() {
  const pathname = usePathname();
  const { sidebarOpen, setSidebarOpen } = useUIStore();

  return (
    <>
      {/* Mobile Dark Overlay */}
      <AnimatePresence>
        {sidebarOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 lg:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}
      </AnimatePresence>

      {/* Sidebar Panel */}
      <aside
        className={`
          fixed top-0 left-0 h-full w-[280px] z-50
          bg-[var(--background)] border-r border-[var(--border)]
          transform transition-transform duration-300 ease-out
          flex flex-col
          ${sidebarOpen ? "translate-x-0" : "-translate-x-full"}
          lg:translate-x-0 lg:static lg:z-auto
          lg:w-[260px]
        `}
      >
        {/* ── Header ── */}
        <div className="flex items-center justify-between p-4 h-14 lg:h-16 border-b border-[var(--border)]">
          <div className="flex items-center gap-2.5">
            <div className="flex items-center justify-center w-8 h-8 rounded-lg overflow-hidden">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src="/logo.png" alt="Logo" className="w-full h-full object-cover" />
            </div>
            <div className="flex flex-col">
              <span className="font-bold text-sm gradient-text leading-tight">
                {PLATFORM_CONFIG.name}
              </span>
              <span className="text-[10px] text-gray-500 leading-tight">
                Trading Platform
              </span>
            </div>
          </div>
          <button
            onClick={() => setSidebarOpen(false)}
            className="lg:hidden p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-white/5 transition-all"
          >
            <X size={20} />
          </button>
        </div>

        {/* ── Navigation Links ── */}
        <nav className="flex-1 overflow-y-auto py-3 px-3 scrollbar-thin">
          <div className="space-y-0.5">
            {NAV_LINKS.map((link) => {
              const Icon = link.icon;
              const isActive = link.href === "/" 
                ? pathname === "/" 
                : pathname.startsWith(link.href);

              return (
                <Link
                  key={link.name}
                  href={link.href}
                  onClick={() => setSidebarOpen(false)}
                >
                  <motion.div
                    whileTap={{ scale: 0.98 }}
                    className={`
                      relative flex items-center gap-3 px-3 py-2.5 rounded-xl
                      text-sm font-medium transition-all duration-200 group
                      ${
                        isActive
                          ? "text-[var(--accent)]"
                          : "text-gray-400 hover:text-gray-200"
                      }
                    `}
                  >
                    {/* Active indicator bar */}
                    {isActive && (
                      <motion.div
                        layoutId="activeNavIndicator"
                        className="absolute left-0 top-1/2 -translate-y-1/2 w-[3px] h-6 rounded-full bg-[var(--accent)]"
                        transition={{ type: "spring", stiffness: 300, damping: 30 }}
                      />
                    )}

                    {/* Active background */}
                    {isActive && (
                      <motion.div
                        layoutId="activeNavBg"
                        className="absolute inset-0 rounded-xl bg-[var(--accent)]/[0.08] border border-[var(--accent)]/10"
                        transition={{ type: "spring", stiffness: 300, damping: 30 }}
                      />
                    )}

                    <Icon
                      size={19}
                      className={`relative z-10 transition-colors ${
                        isActive ? "text-[var(--accent)]" : "group-hover:text-gray-200"
                      }`}
                    />
                    <span className="relative z-10 flex-1">{link.name}</span>
                    {isActive && (
                      <ChevronRight size={14} className="relative z-10 text-[var(--accent)] opacity-60" />
                    )}
                  </motion.div>
                </Link>
              );
            })}
          </div>
        </nav>

        {/* ── User Section (Bottom) ── */}
        <UserSection />
      </aside>
    </>
  );
}

// ─── User Section sub-component ───
function UserSection() {
  const { user, isAuthenticated, logout } = useAuthStore();
  const [copied, setCopied] = useState(false);

  const handleLogout = async () => {
    await authAPI.logout();
    logout();
    // Full-page redirect (not router.push): a hard reload tears down the
    // mobile drawer overlay and all state, so the login/signup buttons on
    // the destination page are tappable. (router.push left the drawer's
    // fixed backdrop mounted, which silently ate taps after logout.)
    window.location.href = "/login";
  };

  const handleCopyUid = async () => {
    if (!user?.uid) return;
    try {
      await navigator.clipboard.writeText(String(user.uid));
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      // Clipboard unavailable — ignore silently
    }
  };

  const initial = user?.email?.charAt(0).toUpperCase() || "G";
  const displayName = user?.username || user?.email?.split("@")[0] || "Guest User";
  const subText = isAuthenticated ? user?.email : "Not Logged In";

  return (
    <div className="p-3 border-t border-[var(--border)]">
      <div className="flex items-center gap-3 p-3 rounded-xl bg-white/[0.03] border border-[var(--border)] mb-2">
        <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[var(--accent)] to-purple-500 flex items-center justify-center text-white font-bold text-sm shadow-lg shrink-0">
          {initial}
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium text-foreground truncate">
            {displayName}
          </p>
          <p className="text-[11px] text-gray-500 truncate">{subText}</p>
          {isAuthenticated && user?.uid && (
            <button
              onClick={handleCopyUid}
              className="mt-1 inline-flex items-center gap-1 text-[11px] font-mono text-[var(--accent)] hover:opacity-80 transition-opacity"
              title="Copy UID"
            >
              <span>UID: {user.uid}</span>
              {copied ? <Check size={11} /> : <Copy size={11} />}
            </button>
          )}
        </div>
      </div>

      {isAuthenticated ? (
        <button
          onClick={handleLogout}
          className="flex items-center gap-3 w-full px-3 py-2.5 text-sm text-gray-500 hover:text-red-400 rounded-xl hover:bg-red-500/[0.05] transition-all duration-200"
        >
          <LogOut size={18} />
          <span>Sign Out</span>
        </button>
      ) : (
        <Link href="/login">
          <button className="flex items-center gap-3 w-full px-3 py-2.5 text-sm text-[var(--accent)] rounded-xl hover:bg-[var(--accent)]/10 transition-all duration-200">
            <LogOut size={18} className="rotate-180" />
            <span>Log In</span>
          </button>
        </Link>
      )}
    </div>
  );
}