// src/components/admin/ScreenshotViewer.tsx
"use client";

import { motion, AnimatePresence } from "framer-motion";
import { X, ExternalLink, Download } from "lucide-react";

interface ScreenshotViewerProps {
  isOpen: boolean;
  onClose: () => void;
  imageUrl: string;
  title?: string;
}

export default function ScreenshotViewer({
  isOpen,
  onClose,
  imageUrl,
  title = "Deposit Screenshot",
}: ScreenshotViewerProps) {
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[60] bg-black/90 backdrop-blur-md flex flex-col"
          onClick={onClose}
        >
          {/* Top Bar */}
          <div
            className="flex items-center justify-between p-4 border-b border-white/10"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="text-sm font-bold text-white">{title}</h3>
            <div className="flex items-center gap-2">
              <a
                href={imageUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-lg hover:bg-white/10 text-gray-300 hover:text-white transition-all"
                title="Open in new tab"
              >
                <ExternalLink size={16} />
              </a>
              <a
                href={imageUrl}
                download
                className="p-2 rounded-lg hover:bg-white/10 text-gray-300 hover:text-white transition-all"
                title="Download"
              >
                <Download size={16} />
              </a>
              <button
                onClick={onClose}
                className="p-2 rounded-lg hover:bg-red-500/20 text-gray-300 hover:text-red-400 transition-all"
                title="Close"
              >
                <X size={18} />
              </button>
            </div>
          </div>

          {/* Image Container */}
          <div
            className="flex-1 overflow-auto p-4 flex items-center justify-center"
            onClick={(e) => e.stopPropagation()}
          >
            <motion.img
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.2 }}
              src={imageUrl}
              alt="Screenshot"
              className="max-w-full max-h-full object-contain rounded-lg shadow-2xl"
            />
          </div>

          {/* Bottom hint */}
          <div className="p-3 border-t border-white/10 text-center">
            <p className="text-[11px] text-gray-500">
              Click anywhere outside to close • Press <kbd className="px-1.5 py-0.5 rounded bg-white/10 text-gray-400 font-mono text-[10px]">ESC</kbd> to exit
            </p>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}