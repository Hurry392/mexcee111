// src/components/admin/WithdrawalDetailsCard.tsx
"use client";

import { useState } from "react";
import {
  Wallet,
  Building2,
  Smartphone,
  CreditCard,
  Copy,
  Check,
  ChevronDown,
  ChevronUp,
} from "lucide-react";

interface WithdrawalDetailsCardProps {
  method: string; // CRYPTO | BANK | UPI | PAYPAL
  network: string; // TRC20 | BEP20 | ERC20 | BANK | UPI | PAYPAL
  walletAddress: string | null; // Can be plain string (crypto) OR JSON string (bank/upi/paypal)
}

type MethodIcon = typeof Wallet;

const METHOD_META: Record<string, { icon: MethodIcon; label: string; color: string }> = {
  CRYPTO: { icon: Wallet, label: "Crypto Wallet", color: "text-blue-400 bg-blue-500/10 border-blue-500/20" },
  BANK: { icon: Building2, label: "Bank Transfer", color: "text-purple-400 bg-purple-500/10 border-purple-500/20" },
  UPI: { icon: Smartphone, label: "UPI Payment", color: "text-orange-400 bg-orange-500/10 border-orange-500/20" },
  PAYPAL: { icon: CreditCard, label: "PayPal", color: "text-cyan-400 bg-cyan-500/10 border-cyan-500/20" },
};

/**
 * Safely parse walletAddress field.
 * Returns null if parsing fails or field is empty.
 */
function parseDetails(walletAddress: string | null): Record<string, string> | string | null {
  if (!walletAddress) return null;

  // Try JSON parse first
  try {
    const parsed = JSON.parse(walletAddress);
    if (typeof parsed === "object" && parsed !== null) {
      return parsed as Record<string, string>;
    }
    return walletAddress; // Plain string wrapped
  } catch {
    // Not JSON — treat as plain string (crypto address)
    return walletAddress;
  }
}

/**
 * Human-readable field labels.
 */
const FIELD_LABELS: Record<string, string> = {
  walletAddress: "Wallet Address",
  bankName: "Bank Name",
  accountTitle: "Account Title",
  accountNumber: "Account Number",
  iban: "IBAN",
  swift: "SWIFT/BIC",
  upiId: "UPI ID",
  paypalEmail: "PayPal Email",
};

export default function WithdrawalDetailsCard({
  method,
  network,
  walletAddress,
}: WithdrawalDetailsCardProps) {
  const [expanded, setExpanded] = useState(false);
  const [copiedField, setCopiedField] = useState<string | null>(null);

  const meta = METHOD_META[method] || METHOD_META.CRYPTO;
  const Icon = meta.icon;
  const details = parseDetails(walletAddress);

  const copyToClipboard = (value: string, fieldName: string) => {
    navigator.clipboard.writeText(value);
    setCopiedField(fieldName);
    setTimeout(() => setCopiedField(null), 2000);
  };

  // Determine what to render
  const isCryptoOrString = typeof details === "string";
  const isObject = details && typeof details === "object";

  return (
    <div className="rounded-xl border border-[var(--border)] bg-white/[0.02] overflow-hidden">
      {/* Header (clickable to expand) */}
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full flex items-center justify-between p-3 hover:bg-white/[0.02] transition-all"
      >
        <div className="flex items-center gap-2.5">
          <div className={`w-8 h-8 rounded-lg border flex items-center justify-center ${meta.color}`}>
            <Icon className="w-4 h-4" />
          </div>
          <div className="text-left">
            <p className="text-xs font-bold text-foreground">{meta.label}</p>
            <p className="text-[10px] text-gray-500">{network}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {!expanded && isCryptoOrString && (
            <p className="text-[10px] font-mono text-gray-400 max-w-[120px] sm:max-w-[200px] truncate">
              {details as string}
            </p>
          )}
          {expanded ? (
            <ChevronUp size={14} className="text-gray-500" />
          ) : (
            <ChevronDown size={14} className="text-gray-500" />
          )}
        </div>
      </button>

      {/* Expanded Details */}
      {expanded && (
        <div className="border-t border-[var(--border)] p-3 space-y-2">
          {/* Case 1: Crypto (plain string) */}
          {isCryptoOrString && (
            <DetailRow
              label="Wallet Address"
              value={details as string}
              onCopy={() => copyToClipboard(details as string, "wallet")}
              copied={copiedField === "wallet"}
              mono
            />
          )}

          {/* Case 2: Bank/UPI/PayPal (JSON object) */}
          {isObject &&
            Object.entries(details).map(([key, value]) => (
              <DetailRow
                key={key}
                label={FIELD_LABELS[key] || key}
                value={String(value)}
                onCopy={() => copyToClipboard(String(value), key)}
                copied={copiedField === key}
                mono={key === "walletAddress" || key === "accountNumber" || key === "iban"}
              />
            ))}

          {/* Case 3: No details available */}
          {!details && (
            <p className="text-xs text-gray-500 italic text-center py-2">
              No withdrawal details available
            </p>
          )}
        </div>
      )}
    </div>
  );
}

// ─── Detail Row ───
function DetailRow({
  label,
  value,
  onCopy,
  copied,
  mono,
}: {
  label: string;
  value: string;
  onCopy: () => void;
  copied: boolean;
  mono?: boolean;
}) {
  return (
    <div className="flex items-start justify-between gap-2 p-2 rounded-lg bg-white/[0.02] border border-[var(--border)]">
      <div className="flex-1 min-w-0">
        <p className="text-[10px] uppercase tracking-wider text-gray-500 font-semibold mb-0.5">
          {label}
        </p>
        <p className={`text-xs text-foreground break-all ${mono ? "font-mono" : ""}`}>
          {value}
        </p>
      </div>
      <button
        onClick={onCopy}
        className="p-1.5 rounded-md hover:bg-white/5 text-gray-500 hover:text-[var(--accent)] transition-all shrink-0"
        title="Copy"
      >
        {copied ? (
          <Check size={12} className="text-green-400" />
        ) : (
          <Copy size={12} />
        )}
      </button>
    </div>
  );
}