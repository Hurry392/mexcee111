// src/components/admin/AdminSidebar.tsx
"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { useState, useEffect, useRef, useCallback } from "react";
import { useAdminStore } from "@/store/adminStore";
import { useUIStore } from "@/store/uiStore";
import {
  LayoutDashboard,
  Users,
  ArrowDownToLine,
  ArrowUpFromLine,
  ShieldCheck,
  MessageSquare,
  TrendingUp,
  Settings,
  ScrollText,
  LogOut,
  Shield,
  X,
  ChevronRight,
  ExternalLink,
  ShieldOff,
  AlertTriangle,
} from "lucide-react";

const ADMIN_NAV_LINKS = [
  { name: "Dashboard", href: "/admin/dashboard", icon: LayoutDashboard },
  { name: "Users", href: "/admin/users", icon: Users },
  { name: "Deposits", href: "/admin/deposits", icon: ArrowDownToLine },
  { name: "Withdrawals", href: "/admin/withdrawals", icon: ArrowUpFromLine },
  { name: "KYC Review", href: "/admin/kyc", icon: ShieldCheck },
  { name: "Chat Support", href: "/admin/chat", icon: MessageSquare },
  { name: "Trades", href: "/admin/trades", icon: TrendingUp },
  { name: "Settings", href: "/admin/settings", icon: Settings },
  { name: "Audit Logs", href: "/admin/logs", icon: ScrollText },
];

export default function AdminSidebar() {
  const pathname = usePathname();
  const router = useRouter();
  const { admin, logout } = useAdminStore();
  const { sidebarOpen, setSidebarOpen } = useUIStore();
  const [loggingOut, setLoggingOut] = useState(false);
  const [logoutAllConfirm, setLogoutAllConfirm] = useState(false);
  const [logoutAllPending, setLogoutAllPending] = useState(false);
  const [chatUnread, setChatUnread] = useState(0);
  const chatPollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // ─── Poll for unread chat messages so the sidebar badge stays live ───
  const fetchUnreadCount = useCallback(async () => {
    try {
      const res = await fetch("/api/admin/chat/conversations", {
        credentials: "include",
      });
      if (!res.ok) return;
      const data = await res.json();
      if (typeof data.totalUnread === "number") {
        setChatUnread(data.totalUnread);
      }
    } catch {
      // Silently fail — sidebar badge is non-critical
    }
  }, []);

  useEffect(() => {
    fetchUnreadCount();
    chatPollRef.current = setInterval(fetchUnreadCount, 30_000);
    return () => {
      if (chatPollRef.current) clearInterval(chatPollRef.current);
    };
  }, [fetchUnreadCount]);

  // Close sidebar on route change (mobile)
  useEffect(() => {
    setSidebarOpen(false);
  }, [pathname, setSidebarOpen]);

  const handleLogout = async () => {
    setLoggingOut(true);
    try {
      await fetch("/api/admin/logout", {
        method: "POST",
        credentials: "include",
      });
    } catch (err) {
      console.error("Logout error:", err);
    }
    logout();
    window.location.href = "/admin/login";
  };

  const handleLogoutAll = async () => {
    // First click — show confirmation state; auto-reset after 4 s if not confirmed
    if (!logoutAllConfirm) {
      setLogoutAllConfirm(true);
      setTimeout(() => setLogoutAllConfirm(false), 4000);
      return;
    }
    // Second click — execute
    setLogoutAllPending(true);
    try {
      await fetch("/api/admin/logout-all", {
        method: "POST",
        credentials: "include",
      });
    } catch (err) {
      console.error("Logout-all error:", err);
    }
    logout();
    window.location.href = "/admin/login";
  };

  return (
    <>
      {/* Mobile Overlay */}
      <AnimatePresence>
        {sidebarOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm z-40 lg:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}
      </AnimatePresence>

      {/* Sidebar Panel */}
      <aside
        className={`
          fixed top-0 left-0 h-full w-[280px] z-50
          bg-[var(--background)] border-r border-[var(--border)]
          transform transition-transform duration-300 ease-out
          flex flex-col
          ${sidebarOpen ? "translate-x-0" : "-translate-x-full"}
          lg:translate-x-0 lg:static lg:z-auto
          lg:w-[260px]
        `}
      >
        {/* ── Header ── */}
        <div className="flex items-center justify-between p-4 h-14 lg:h-16 border-b border-[var(--border)]">
          <div className="flex items-center gap-2.5">
            <div className="relative">
              <div className="flex items-center justify-center w-9 h-9 rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 shadow-lg shadow-blue-500/20">
                <Shield className="w-4.5 h-4.5 text-white" />
              </div>
              <div className="absolute -bottom-1 -right-1 w-3 h-3 rounded-full bg-green-500 border-2 border-[var(--background)]" />
            </div>
            <div className="flex flex-col">
              <span className="font-bold text-sm text-white leading-tight">
                Admin Panel
              </span>
              <span className="text-[10px] text-gray-500 leading-tight uppercase tracking-wider">
                MEXC Trade
              </span>
            </div>
          </div>
          <button
            onClick={() => setSidebarOpen(false)}
            className="lg:hidden p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-white/5 transition-all"
          >
            <X size={20} />
          </button>
        </div>

        {/* ── Navigation Links ── */}
        <nav className="flex-1 overflow-y-auto py-3 px-3 scrollbar-thin">
          <div className="mb-2 px-3">
            <span className="text-[10px] uppercase tracking-wider text-gray-600 font-semibold">
              Management
            </span>
          </div>

          <div className="space-y-0.5">
            {ADMIN_NAV_LINKS.map((link) => {
              const Icon = link.icon;
              const isActive = pathname === link.href || pathname.startsWith(link.href + "/");
              const isChat = link.href === "/admin/chat";
              // Clear badge when on chat page — messages are being read
              const badge = isChat && !isActive && chatUnread > 0 ? chatUnread : 0;

              return (
                <Link
                  key={link.name}
                  href={link.href}
                  onClick={() => setSidebarOpen(false)}
                >
                  <motion.div
                    whileTap={{ scale: 0.98 }}
                    className={`
                      relative flex items-center gap-3 px-3 py-2.5 rounded-xl
                      text-sm font-medium transition-all duration-200 group
                      ${
                        isActive
                          ? "text-[var(--accent)]"
                          : "text-gray-400 hover:text-gray-200"
                      }
                    `}
                  >
                    {isActive && (
                      <motion.div
                        layoutId="activeAdminNavIndicator"
                        className="absolute left-0 top-1/2 -translate-y-1/2 w-[3px] h-6 rounded-full bg-[var(--accent)]"
                        transition={{ type: "spring", stiffness: 300, damping: 30 }}
                      />
                    )}

                    {isActive && (
                      <motion.div
                        layoutId="activeAdminNavBg"
                        className="absolute inset-0 rounded-xl bg-[var(--accent)]/[0.08] border border-[var(--accent)]/10"
                        transition={{ type: "spring", stiffness: 300, damping: 30 }}
                      />
                    )}

                    {/* Icon — with unread dot for Chat when not on that page */}
                    <span className="relative z-10 shrink-0">
                      <Icon
                        size={19}
                        className={`transition-colors ${
                          isActive ? "text-[var(--accent)]" : "group-hover:text-gray-200"
                        }`}
                      />
                      {badge > 0 && (
                        <span className="absolute -top-1.5 -right-1.5 w-[14px] h-[14px] rounded-full bg-red-500 border border-[var(--background)] flex items-center justify-center">
                          <span className="text-[8px] font-bold text-white leading-none">
                            {badge > 9 ? "9+" : badge}
                          </span>
                        </span>
                      )}
                    </span>

                    <span className="relative z-10 flex-1">{link.name}</span>

                    {/* Unread pill badge (text label) */}
                    {badge > 0 && (
                      <span className="relative z-10 min-w-[20px] h-5 px-1.5 rounded-full bg-red-500 flex items-center justify-center">
                        <span className="text-[10px] font-bold text-white leading-none">
                          {badge > 99 ? "99+" : badge}
                        </span>
                      </span>
                    )}

                    {isActive && badge === 0 && (
                      <ChevronRight size={14} className="relative z-10 text-[var(--accent)] opacity-60" />
                    )}
                  </motion.div>
                </Link>
              );
            })}
          </div>

          {/* Quick Actions Section */}
          <div className="mt-6 mb-2 px-3">
            <span className="text-[10px] uppercase tracking-wider text-gray-600 font-semibold">
              Quick Access
            </span>
          </div>
          <Link href="/" target="_blank">
            <div className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-gray-400 hover:text-gray-200 hover:bg-white/[0.02] transition-all">
              <ExternalLink size={19} />
              <span className="flex-1">View User Site</span>
            </div>
          </Link>
        </nav>

        {/* ── Admin Section (Bottom) ── */}
        <div className="p-3 border-t border-[var(--border)]">
          <div className="flex items-center gap-3 p-3 rounded-xl bg-white/[0.03] border border-[var(--border)] mb-2">
            <div className="w-9 h-9 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-bold text-sm shadow-lg shrink-0">
              {admin?.email?.charAt(0).toUpperCase() || "A"}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-white truncate">
                {admin?.username || "Administrator"}
              </p>
              <p className="text-[11px] text-gray-500 truncate">{admin?.email}</p>
            </div>
          </div>

          <button
            onClick={handleLogout}
            disabled={loggingOut || logoutAllPending}
            className="flex items-center gap-3 w-full px-3 py-2.5 text-sm text-gray-500 hover:text-red-400 rounded-xl hover:bg-red-500/[0.05] transition-all duration-200 disabled:opacity-50"
          >
            <LogOut size={18} />
            <span>{loggingOut ? "Signing out..." : "Sign Out"}</span>
          </button>

          {/* Logout All Sessions — two-step confirmation */}
          {logoutAllConfirm ? (
            <button
              onClick={handleLogoutAll}
              disabled={logoutAllPending}
              className="flex items-center gap-3 w-full px-3 py-2.5 text-sm text-red-400 bg-red-500/[0.08] border border-red-500/20 rounded-xl transition-all duration-200 disabled:opacity-50"
            >
              <AlertTriangle size={18} className="shrink-0" />
              <span className="flex-1 text-left">
                {logoutAllPending ? "Logging out all…" : "Confirm — log out all?"}
              </span>
            </button>
          ) : (
            <button
              onClick={handleLogoutAll}
              disabled={loggingOut || logoutAllPending}
              className="flex items-center gap-3 w-full px-3 py-2.5 text-sm text-gray-500 hover:text-orange-400 rounded-xl hover:bg-orange-500/[0.05] transition-all duration-200 disabled:opacity-50"
            >
              <ShieldOff size={18} />
              <span>Log Out All Sessions</span>
            </button>
          )}
        </div>
      </aside>
    </>
  );
}