// src/components/admin/BalanceModal.tsx
"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, DollarSign, Plus, Minus, AlertCircle, CheckCircle2 } from "lucide-react";
import { adminAPI } from "@/lib/api";

interface BalanceModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: {
    id: string;
    email: string;
    username?: string | null;
    balance: number;
  };
  onSuccess: () => void;
}

export default function BalanceModal({ isOpen, onClose, user, onSuccess }: BalanceModalProps) {
  const [action, setAction] = useState<"ADD" | "DEDUCT">("ADD");
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSuccess("");

    const parsedAmount = parseFloat(amount);
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      setError("Please enter a valid positive amount");
      return;
    }

    if (action === "DEDUCT" && parsedAmount > user.balance) {
      setError(`Cannot deduct $${parsedAmount.toFixed(2)} — user only has $${user.balance.toFixed(2)}`);
      return;
    }

    setLoading(true);

    try {
      const result = await adminAPI.updateBalance(user.id, {
        action,
        amount: parsedAmount,
        note: note.trim() || undefined,
      });

      if (result.error) {
        setError(result.error);
        setLoading(false);
        return;
      }

      setSuccess(
        `Successfully ${action === "ADD" ? "added" : "deducted"} $${parsedAmount.toFixed(2)}`
      );

      // Auto close after 1.5s
      setTimeout(() => {
        onSuccess();
        handleClose();
      }, 1500);
    } catch (err) {
      console.error(err);
      setError("Network error. Please try again.");
      setLoading(false);
    }
  };

  const handleClose = () => {
    setAction("ADD");
    setAmount("");
    setNote("");
    setError("");
    setSuccess("");
    setLoading(false);
    onClose();
  };

  const parsedAmount = parseFloat(amount) || 0;
  const projectedBalance =
    action === "ADD" ? user.balance + parsedAmount : user.balance - parsedAmount;

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50"
            onClick={handleClose}
          />

          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ duration: 0.2 }}
            className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[95vw] max-w-md z-50"
          >
            <div className="glass-panel rounded-2xl overflow-hidden shadow-2xl border border-[var(--border)]">
              {/* Header */}
              <div className="flex items-center justify-between p-5 border-b border-[var(--border)]">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-[var(--accent)]/10 border border-[var(--accent)]/20 flex items-center justify-center">
                    <DollarSign className="w-5 h-5 text-[var(--accent)]" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-foreground">Manage Balance</h3>
                    <p className="text-[11px] text-gray-500 truncate max-w-[200px]">
                      {user.email}
                    </p>
                  </div>
                </div>
                <button
                  onClick={handleClose}
                  disabled={loading}
                  className="p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-white/5 transition-all disabled:opacity-50"
                >
                  <X size={18} />
                </button>
              </div>

              {/* Current Balance */}
              <div className="p-5 border-b border-[var(--border)] bg-white/[0.02]">
                <p className="text-[10px] uppercase tracking-wider text-gray-500 font-semibold mb-1">
                  Current Balance
                </p>
                <p className="text-2xl font-bold text-foreground">
                  ${user.balance.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </p>
              </div>

              {/* Form */}
              <form onSubmit={handleSubmit} className="p-5 space-y-4">
                {/* Action Selector */}
                <div>
                  <label className="block text-xs font-semibold text-gray-400 mb-2 uppercase tracking-wider">
                    Action
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setAction("ADD")}
                      disabled={loading}
                      className={`flex items-center justify-center gap-2 py-3 rounded-xl border-2 font-semibold text-sm transition-all ${
                        action === "ADD"
                          ? "bg-green-500/10 border-green-500 text-green-400"
                          : "bg-white/[0.02] border-[var(--border)] text-gray-400 hover:bg-white/5"
                      }`}
                    >
                      <Plus size={16} />
                      <span>Add</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setAction("DEDUCT")}
                      disabled={loading}
                      className={`flex items-center justify-center gap-2 py-3 rounded-xl border-2 font-semibold text-sm transition-all ${
                        action === "DEDUCT"
                          ? "bg-red-500/10 border-red-500 text-red-400"
                          : "bg-white/[0.02] border-[var(--border)] text-gray-400 hover:bg-white/5"
                      }`}
                    >
                      <Minus size={16} />
                      <span>Deduct</span>
                    </button>
                  </div>
                </div>

                {/* Amount Input */}
                <div>
                  <label className="block text-xs font-semibold text-gray-400 mb-2 uppercase tracking-wider">
                    Amount (USD)
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 font-medium">$</span>
                    <input
                      type="number"
                      step="0.01"
                      min="0.01"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      placeholder="0.00"
                      required
                      disabled={loading}
                      className="w-full pl-8 pr-4 py-3 rounded-xl bg-white/5 border border-white/10 text-foreground text-base font-bold placeholder:text-gray-600 focus:border-[var(--accent)]/50 focus:bg-white/[0.07] outline-none transition-all disabled:opacity-50"
                    />
                  </div>

                  {/* Projected Balance Preview */}
                  {parsedAmount > 0 && (
                    <div className="mt-2 flex items-center justify-between px-3 py-2 rounded-lg bg-white/[0.03] border border-[var(--border)]">
                      <span className="text-[11px] text-gray-500">New Balance</span>
                      <span className={`text-sm font-bold ${
                        projectedBalance < 0 ? "text-red-400" : "text-foreground"
                      }`}>
                        ${projectedBalance.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </span>
                    </div>
                  )}
                </div>

                {/* Note Input */}
                <div>
                  <label className="block text-xs font-semibold text-gray-400 mb-2 uppercase tracking-wider">
                    Note <span className="text-gray-600 normal-case font-normal">(optional)</span>
                  </label>
                  <textarea
                    value={note}
                    onChange={(e) => setNote(e.target.value)}
                    placeholder="Reason for balance change..."
                    rows={2}
                    disabled={loading}
                    className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-foreground text-sm placeholder:text-gray-600 focus:border-[var(--accent)]/50 focus:bg-white/[0.07] outline-none transition-all resize-none disabled:opacity-50"
                  />
                </div>

                {/* Error */}
                {error && (
                  <motion.div
                    initial={{ opacity: 0, y: -5 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex items-start gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/20"
                  >
                    <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                    <p className="text-xs text-red-400">{error}</p>
                  </motion.div>
                )}

                {/* Success */}
                {success && (
                  <motion.div
                    initial={{ opacity: 0, y: -5 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex items-start gap-2 p-3 rounded-lg bg-green-500/10 border border-green-500/20"
                  >
                    <CheckCircle2 className="w-4 h-4 text-green-400 shrink-0 mt-0.5" />
                    <p className="text-xs text-green-400">{success}</p>
                  </motion.div>
                )}

                {/* Submit */}
                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={handleClose}
                    disabled={loading}
                    className="flex-1 py-3 rounded-xl border border-[var(--border)] text-gray-400 font-semibold text-sm hover:bg-white/5 transition-all disabled:opacity-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={loading || !amount || !!success}
                    className={`flex-1 py-3 rounded-xl font-bold text-sm text-white shadow-lg disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-2 ${
                      action === "ADD"
                        ? "bg-gradient-to-r from-green-600 to-emerald-600 shadow-green-500/20"
                        : "bg-gradient-to-r from-red-600 to-rose-600 shadow-red-500/20"
                    }`}
                  >
                    {loading ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        <span>Processing...</span>
                      </>
                    ) : (
                      <>
                        {action === "ADD" ? <Plus size={16} /> : <Minus size={16} />}
                        <span>{action === "ADD" ? "Add Balance" : "Deduct Balance"}</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}