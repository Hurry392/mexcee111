// src/components/admin/KYCReviewModal.tsx
"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  X,
  User,
  Calendar,
  Hash,
  Mail,
  Globe,
  ShieldCheck,
  IdCard,
  Car,
  BookUser,
  CheckCircle2,
  XCircle,
  AlertCircle,
  ZoomIn,
  Clock,
  FileImage,
  Camera,
} from "lucide-react";
import { adminAPI } from "@/lib/api";
import ScreenshotViewer from "./ScreenshotViewer";

interface KYCSubmission {
  id: string;
  documentType: string;
  documentFrontUrl: string;
  documentBackUrl: string | null;
  selfieUrl: string | null;
  fullName: string;
  dateOfBirth: string | null;
  documentNumber: string | null;
  status: string;
  rejectionReason: string | null;
  createdAt: string;
  reviewedAt: string | null;
  user: {
    id: string;
    email: string;
    username: string | null;
    country: string | null;
    kycStatus: string;
    balance: number;
    createdAt: string;
  };
}

interface KYCReviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  submission: KYCSubmission;
  onSuccess: () => void;
}

const DOC_TYPE_META: Record<string, { label: string; icon: typeof IdCard; color: string }> = {
  NATIONAL_ID: { label: "National ID", icon: IdCard, color: "text-blue-400 bg-blue-500/10 border-blue-500/20" },
  DRIVING_LICENSE: { label: "Driving License", icon: Car, color: "text-green-400 bg-green-500/10 border-green-500/20" },
  PASSPORT: { label: "Passport", icon: BookUser, color: "text-purple-400 bg-purple-500/10 border-purple-500/20" },
};

export default function KYCReviewModal({
  isOpen,
  onClose,
  submission,
  onSuccess,
}: KYCReviewModalProps) {
  const [action, setAction] = useState<"NONE" | "APPROVE" | "REJECT">("NONE");
  const [rejectionReason, setRejectionReason] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [zoomImage, setZoomImage] = useState<string | null>(null);
  const [zoomTitle, setZoomTitle] = useState("");

  const docMeta = DOC_TYPE_META[submission.documentType] || DOC_TYPE_META.NATIONAL_ID;
  const DocIcon = docMeta.icon;
  const isPending = submission.status === "PENDING";

  const openZoom = (url: string, title: string) => {
    setZoomImage(url);
    setZoomTitle(title);
  };

  const handleConfirm = async () => {
    if (action === "NONE") return;

    if (action === "REJECT" && !rejectionReason.trim()) {
      setError("Rejection reason is required");
      return;
    }

    setLoading(true);
    setError("");

    try {
      const result = await adminAPI.processKyc(submission.id, {
        action,
        rejectionReason: action === "REJECT" ? rejectionReason.trim() : undefined,
      });

      if (result.error) {
        setError(result.error);
        setLoading(false);
        return;
      }

      onSuccess();
      handleClose();
    } catch (err) {
      console.error(err);
      setError("Network error. Please try again.");
      setLoading(false);
    }
  };

  const handleClose = () => {
    if (loading) return;
    setAction("NONE");
    setRejectionReason("");
    setError("");
    onClose();
  };

  return (
    <>
      <AnimatePresence>
        {isOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50"
              onClick={handleClose}
            />

            {/* Modal */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              transition={{ duration: 0.2 }}
              className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[95vw] max-w-4xl max-h-[90vh] z-50"
            >
              <div className="glass-panel rounded-2xl overflow-hidden shadow-2xl border border-[var(--border)] flex flex-col max-h-[90vh]">
                {/* ═══ Header ═══ */}
                <div className="flex items-center justify-between p-5 border-b border-[var(--border)] shrink-0">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-xl border flex items-center justify-center ${docMeta.color}`}>
                      <DocIcon className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="text-base font-bold text-foreground">
                        KYC Review — {docMeta.label}
                      </h3>
                      <p className="text-[11px] text-gray-500">
                        Submitted {new Date(submission.createdAt).toLocaleString()}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {isPending && (
                      <span className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-[10px] font-semibold bg-amber-500/10 border border-amber-500/20 text-amber-400">
                        <Clock size={10} />
                        PENDING REVIEW
                      </span>
                    )}
                    {submission.status === "APPROVED" && (
                      <span className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-[10px] font-semibold bg-green-500/10 border border-green-500/20 text-green-400">
                        <CheckCircle2 size={10} />
                        APPROVED
                      </span>
                    )}
                    {submission.status === "REJECTED" && (
                      <span className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-[10px] font-semibold bg-red-500/10 border border-red-500/20 text-red-400">
                        <XCircle size={10} />
                        REJECTED
                      </span>
                    )}
                    <button
                      onClick={handleClose}
                      disabled={loading}
                      className="p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-white/5 transition-all disabled:opacity-50"
                    >
                      <X size={18} />
                    </button>
                  </div>
                </div>

                {/* ═══ Scrollable Content ═══ */}
                <div className="flex-1 overflow-y-auto scrollbar-thin">
                  <div className="p-5 grid grid-cols-1 lg:grid-cols-2 gap-5">
                    {/* ═══ Left: User & Personal Info ═══ */}
                    <div className="space-y-4">
                      {/* User Card */}
                      <div className="p-4 rounded-xl bg-white/[0.02] border border-[var(--border)]">
                        <h4 className="text-xs font-bold uppercase tracking-wider text-gray-500 mb-3">
                          User Account
                        </h4>
                        <div className="flex items-center gap-3 mb-4">
                          <div className="w-11 h-11 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center text-white font-bold shrink-0">
                            {submission.user.email.charAt(0).toUpperCase()}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-bold text-foreground truncate">
                              {submission.user.username || submission.user.email.split("@")[0]}
                            </p>
                            <p className="text-[11px] text-gray-500 flex items-center gap-1 truncate">
                              <Mail size={10} />
                              {submission.user.email}
                            </p>
                          </div>
                        </div>

                        <div className="space-y-2">
                          <InfoRow label="Balance" value={`$${submission.user.balance.toFixed(2)}`} />
                          {submission.user.country && (
                            <InfoRow label="Country" value={submission.user.country} icon={Globe} />
                          )}
                          <InfoRow
                            label="Member Since"
                            value={new Date(submission.user.createdAt).toLocaleDateString()}
                          />
                          <InfoRow label="Current KYC Status" value={submission.user.kycStatus} badge />
                        </div>
                      </div>

                      {/* Personal Details */}
                      <div className="p-4 rounded-xl bg-white/[0.02] border border-[var(--border)]">
                        <h4 className="text-xs font-bold uppercase tracking-wider text-gray-500 mb-3">
                          Personal Details
                        </h4>
                        <div className="space-y-3">
                          <DetailField icon={User} label="Full Name" value={submission.fullName} />
                          {submission.dateOfBirth && (
                            <DetailField
                              icon={Calendar}
                              label="Date of Birth"
                              value={new Date(submission.dateOfBirth).toLocaleDateString("en-US", {
                                year: "numeric",
                                month: "long",
                                day: "numeric",
                              })}
                              subValue={calculateAge(submission.dateOfBirth)}
                            />
                          )}
                          {submission.documentNumber && (
                            <DetailField
                              icon={Hash}
                              label="Document Number"
                              value={submission.documentNumber}
                              mono
                            />
                          )}
                          <DetailField
                            icon={ShieldCheck}
                            label="Document Type"
                            value={docMeta.label}
                          />
                        </div>
                      </div>

                      {/* Previous Rejection Reason (if applicable) */}
                      {submission.status === "REJECTED" && submission.rejectionReason && (
                        <div className="p-4 rounded-xl bg-red-500/5 border border-red-500/20">
                          <h4 className="text-xs font-bold uppercase tracking-wider text-red-400 mb-2 flex items-center gap-1.5">
                            <XCircle size={12} />
                            Rejection Reason
                          </h4>
                          <p className="text-sm text-red-300">{submission.rejectionReason}</p>
                          {submission.reviewedAt && (
                            <p className="text-[10px] text-red-400/60 mt-2">
                              Reviewed {new Date(submission.reviewedAt).toLocaleString()}
                            </p>
                          )}
                        </div>
                      )}
                    </div>

                    {/* ═══ Right: Documents ═══ */}
                    <div className="space-y-4">
                      <div>
                        <h4 className="text-xs font-bold uppercase tracking-wider text-gray-500 mb-3">
                          Uploaded Documents
                        </h4>

                        <div className="space-y-3">
                          {/* Document Front */}
                          <DocumentPreview
                            label="Document (Front)"
                            imageUrl={submission.documentFrontUrl}
                            icon={FileImage}
                            onZoom={() => openZoom(submission.documentFrontUrl, "Document Front")}
                          />

                          {/* Document Back (optional — passport doesn't have it) */}
                          {submission.documentBackUrl && (
                            <DocumentPreview
                              label="Document (Back)"
                              imageUrl={submission.documentBackUrl}
                              icon={FileImage}
                              onZoom={() => openZoom(submission.documentBackUrl!, "Document Back")}
                            />
                          )}

                          {/* Selfie */}
                          {submission.selfieUrl && (
                            <DocumentPreview
                              label="Selfie with Document"
                              imageUrl={submission.selfieUrl}
                              icon={Camera}
                              onZoom={() => openZoom(submission.selfieUrl!, "Selfie")}
                            />
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* ═══ Action Area ═══ */}
                {isPending && (
                  <div className="border-t border-[var(--border)] p-5 shrink-0">
                    {action === "NONE" ? (
                      /* Initial state — Approve/Reject buttons */
                      <div className="flex gap-3">
                        <button
                          onClick={() => setAction("REJECT")}
                          disabled={loading}
                          className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 font-bold text-sm hover:bg-red-500/20 transition-all"
                        >
                          <XCircle size={16} />
                          <span>Reject KYC</span>
                        </button>
                        <button
                          onClick={() => setAction("APPROVE")}
                          disabled={loading}
                          className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl bg-gradient-to-r from-green-600 to-emerald-600 text-white font-bold text-sm shadow-lg shadow-green-500/20 hover:shadow-green-500/40 transition-all"
                        >
                          <CheckCircle2 size={16} />
                          <span>Approve KYC</span>
                        </button>
                      </div>
                    ) : (
                      /* Confirmation state */
                      <div className="space-y-3">
                        {/* Action banner */}
                        <div
                          className={`flex items-start gap-2.5 p-3 rounded-lg border ${
                            action === "APPROVE"
                              ? "bg-green-500/10 border-green-500/20"
                              : "bg-red-500/10 border-red-500/20"
                          }`}
                        >
                          {action === "APPROVE" ? (
                            <CheckCircle2 className="w-4 h-4 text-green-400 shrink-0 mt-0.5" />
                          ) : (
                            <XCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                          )}
                          <div className="flex-1">
                            <p className={`text-xs font-semibold ${
                              action === "APPROVE" ? "text-green-400" : "text-red-400"
                            }`}>
                              {action === "APPROVE" ? "Confirm Approval" : "Confirm Rejection"}
                            </p>
                            <p className={`text-[11px] mt-0.5 ${
                              action === "APPROVE" ? "text-green-300/70" : "text-red-300/70"
                            }`}>
                              {action === "APPROVE"
                                ? "User's withdrawals will be unlocked immediately."
                                : "User's KYC will be marked as rejected. They can re-submit with corrections."}
                            </p>
                          </div>
                        </div>

                        {/* Rejection reason (only for REJECT) */}
                        {action === "REJECT" && (
                          <div>
                            <label className="block text-xs font-semibold text-gray-400 mb-2 uppercase tracking-wider">
                              Rejection Reason <span className="text-red-400 normal-case">*</span>
                            </label>
                            <textarea
                              value={rejectionReason}
                              onChange={(e) => setRejectionReason(e.target.value)}
                              placeholder="e.g., Document image is blurry, selfie doesn't match document, information mismatch..."
                              rows={3}
                              disabled={loading}
                              autoFocus
                              className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-foreground text-sm placeholder:text-gray-600 focus:border-red-500/50 focus:bg-white/[0.07] outline-none transition-all resize-none disabled:opacity-50"
                            />
                            <p className="text-[10px] text-gray-500 mt-1.5">
                              This reason will be shown to the user so they know what to fix.
                            </p>
                          </div>
                        )}

                        {/* Error */}
                        {error && (
                          <motion.div
                            initial={{ opacity: 0, y: -5 }}
                            animate={{ opacity: 1, y: 0 }}
                            className="flex items-start gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/20"
                          >
                            <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                            <p className="text-xs text-red-400">{error}</p>
                          </motion.div>
                        )}

                        {/* Confirm/Cancel */}
                        <div className="flex gap-2">
                          <button
                            onClick={() => {
                              setAction("NONE");
                              setError("");
                              setRejectionReason("");
                            }}
                            disabled={loading}
                            className="flex-1 py-3 rounded-xl border border-[var(--border)] text-gray-400 font-semibold text-sm hover:bg-white/5 transition-all disabled:opacity-50"
                          >
                            Cancel
                          </button>
                          <button
                            onClick={handleConfirm}
                            disabled={loading || (action === "REJECT" && !rejectionReason.trim())}
                            className={`flex-1 py-3 rounded-xl font-bold text-sm text-white shadow-lg disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-2 bg-gradient-to-r ${
                              action === "APPROVE"
                                ? "from-green-600 to-emerald-600 shadow-green-500/20"
                                : "from-red-600 to-rose-600 shadow-red-500/20"
                            }`}
                          >
                            {loading ? (
                              <>
                                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                                <span>Processing...</span>
                              </>
                            ) : (
                              <>
                                {action === "APPROVE" ? <CheckCircle2 size={16} /> : <XCircle size={16} />}
                                <span>Confirm {action === "APPROVE" ? "Approval" : "Rejection"}</span>
                              </>
                            )}
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Reviewed info (if already processed) */}
                {!isPending && submission.reviewedAt && (
                  <div className="border-t border-[var(--border)] p-4 shrink-0 bg-white/[0.02]">
                    <p className="text-[11px] text-gray-500 text-center">
                      Reviewed on {new Date(submission.reviewedAt).toLocaleString()}
                    </p>
                  </div>
                )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Zoom image viewer */}
      {zoomImage && (
        <ScreenshotViewer
          isOpen={!!zoomImage}
          onClose={() => setZoomImage(null)}
          imageUrl={zoomImage}
          title={zoomTitle}
        />
      )}
    </>
  );
}

// ─── Helpers ───

function calculateAge(dob: string): string {
  try {
    const birthDate = new Date(dob);
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return `${age} years old`;
  } catch {
    return "";
  }
}

function InfoRow({
  label,
  value,
  icon: Icon,
  badge,
}: {
  label: string;
  value: string;
  icon?: typeof User;
  badge?: boolean;
}) {
  const badgeColors: Record<string, string> = {
    NONE: "bg-gray-500/10 text-gray-400",
    PENDING: "bg-amber-500/10 text-amber-400",
    APPROVED: "bg-green-500/10 text-green-400",
    REJECTED: "bg-red-500/10 text-red-400",
  };

  return (
    <div className="flex items-center justify-between gap-2">
      <span className="text-[11px] text-gray-500 flex items-center gap-1">
        {Icon && <Icon size={11} />}
        {label}
      </span>
      {badge ? (
        <span className={`text-[10px] px-2 py-0.5 rounded font-semibold ${badgeColors[value] || badgeColors.NONE}`}>
          {value === "NONE" ? "No KYC" : value}
        </span>
      ) : (
        <span className="text-xs font-semibold text-foreground text-right">{value}</span>
      )}
    </div>
  );
}

function DetailField({
  icon: Icon,
  label,
  value,
  subValue,
  mono,
}: {
  icon: typeof User;
  label: string;
  value: string;
  subValue?: string;
  mono?: boolean;
}) {
  return (
    <div className="flex items-start gap-3">
      <div className="w-8 h-8 rounded-lg bg-white/[0.03] border border-[var(--border)] flex items-center justify-center shrink-0 mt-0.5">
        <Icon className="w-3.5 h-3.5 text-gray-500" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-[10px] uppercase tracking-wider text-gray-500 font-semibold mb-0.5">
          {label}
        </p>
        <p className={`text-sm font-semibold text-foreground break-words ${mono ? "font-mono" : ""}`}>
          {value}
        </p>
        {subValue && (
          <p className="text-[10px] text-gray-500 mt-0.5">{subValue}</p>
        )}
      </div>
    </div>
  );
}

function DocumentPreview({
  label,
  imageUrl,
  icon: Icon,
  onZoom,
}: {
  label: string;
  imageUrl: string;
  icon: typeof FileImage;
  onZoom: () => void;
}) {
  return (
    <div className="rounded-xl border border-[var(--border)] overflow-hidden bg-white/[0.02]">
      <div className="flex items-center justify-between p-3 border-b border-[var(--border)]">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-[var(--accent)]/10 border border-[var(--accent)]/20 flex items-center justify-center">
            <Icon className="w-3.5 h-3.5 text-[var(--accent)]" />
          </div>
          <span className="text-xs font-semibold text-foreground">{label}</span>
        </div>
        <button
          onClick={onZoom}
          className="flex items-center gap-1 px-2 py-1 rounded-md bg-white/[0.03] hover:bg-[var(--accent)]/10 text-gray-400 hover:text-[var(--accent)] text-[10px] font-semibold transition-all"
        >
          <ZoomIn size={10} />
          Zoom
        </button>
      </div>
      <button
        onClick={onZoom}
        className="w-full block relative group"
      >
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={imageUrl}
          alt={label}
          className="w-full max-h-64 object-contain bg-black/40"
        />
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-all flex items-center justify-center opacity-0 group-hover:opacity-100">
          <div className="px-3 py-1.5 rounded-lg bg-white/10 backdrop-blur-sm text-white text-xs font-semibold flex items-center gap-1.5">
            <ZoomIn size={12} />
            Click to zoom
          </div>
        </div>
      </button>
    </div>
  );
}