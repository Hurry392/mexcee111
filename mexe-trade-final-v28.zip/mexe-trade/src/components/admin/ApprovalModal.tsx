// src/components/admin/ApprovalModal.tsx
"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  X,
  CheckCircle2,
  XCircle,
  AlertCircle,
  DollarSign,
  Hash,
} from "lucide-react";

export type ApprovalAction = "APPROVE" | "REJECT" | "COMPLETE";

interface ApprovalModalProps {
  isOpen: boolean;
  onClose: () => void;
  action: ApprovalAction;
  type: "deposit" | "withdrawal";
  amount: number;
  currency: string;
  userEmail: string;
  loading: boolean;
  error?: string;
  onConfirm: (data: { note: string; txId?: string }) => void;
}

export default function ApprovalModal({
  isOpen,
  onClose,
  action,
  type,
  amount,
  currency,
  userEmail,
  loading,
  error,
  onConfirm,
}: ApprovalModalProps) {
  const [note, setNote] = useState("");
  const [txId, setTxId] = useState("");

  const isApprove = action === "APPROVE";
  const isReject = action === "REJECT";
  const isComplete = action === "COMPLETE";

  const config = {
    APPROVE: {
      title: type === "deposit" ? "Approve Deposit" : "Approve Withdrawal",
      description:
        type === "deposit"
          ? `This will credit $${amount.toFixed(2)} ${currency} to the user's balance immediately.`
          : `This will approve the withdrawal for processing. Balance is already deducted.`,
      icon: CheckCircle2,
      iconColor: "text-green-400 bg-green-500/10 border-green-500/20",
      buttonText: type === "deposit" ? "Approve & Credit Balance" : "Approve Withdrawal",
      buttonColor: "from-green-600 to-emerald-600 shadow-green-500/20",
      noteRequired: false,
      showTxId: false,
    },
    REJECT: {
      title: type === "deposit" ? "Reject Deposit" : "Reject Withdrawal",
      description:
        type === "deposit"
          ? "This will reject the deposit request. No balance changes will occur."
          : `This will reject the withdrawal AND refund $${amount.toFixed(2)} to the user's balance.`,
      icon: XCircle,
      iconColor: "text-red-400 bg-red-500/10 border-red-500/20",
      buttonText: type === "deposit" ? "Reject Deposit" : "Reject & Refund",
      buttonColor: "from-red-600 to-rose-600 shadow-red-500/20",
      noteRequired: true,
      showTxId: false,
    },
    COMPLETE: {
      title: "Mark Withdrawal Completed",
      description: `Confirm that the withdrawal has been processed. Optionally add the blockchain transaction hash for user reference.`,
      icon: CheckCircle2,
      iconColor: "text-blue-400 bg-blue-500/10 border-blue-500/20",
      buttonText: "Mark as Completed",
      buttonColor: "from-blue-600 to-purple-600 shadow-blue-500/20",
      noteRequired: false,
      showTxId: true,
    },
  }[action];

  const Icon = config.icon;

  const handleClose = () => {
    if (loading) return;
    setNote("");
    setTxId("");
    onClose();
  };

  const handleSubmit = () => {
    if (config.noteRequired && !note.trim()) return;
    onConfirm({ note: note.trim(), txId: txId.trim() || undefined });
  };

  const isValid = !config.noteRequired || note.trim().length > 0;

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50"
            onClick={handleClose}
          />

          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ duration: 0.2 }}
            className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[95vw] max-w-md z-50"
          >
            <div className="glass-panel rounded-2xl overflow-hidden shadow-2xl border border-[var(--border)]">
              {/* Header */}
              <div className="flex items-center justify-between p-5 border-b border-[var(--border)]">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-xl border flex items-center justify-center ${config.iconColor}`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-foreground">{config.title}</h3>
                    <p className="text-[11px] text-gray-500 truncate max-w-[220px]">
                      {userEmail}
                    </p>
                  </div>
                </div>
                <button
                  onClick={handleClose}
                  disabled={loading}
                  className="p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-white/5 transition-all disabled:opacity-50"
                >
                  <X size={18} />
                </button>
              </div>

              {/* Amount Display */}
              <div className="p-5 border-b border-[var(--border)] bg-white/[0.02]">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-[10px] uppercase tracking-wider text-gray-500 font-semibold mb-1">
                      Amount
                    </p>
                    <p className={`text-2xl font-bold ${
                      type === "deposit" ? "text-green-400" : "text-red-400"
                    }`}>
                      {type === "deposit" ? "+" : "-"}${amount.toFixed(2)}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] uppercase tracking-wider text-gray-500 font-semibold mb-1">
                      Currency
                    </p>
                    <p className="text-sm font-bold text-foreground">{currency}</p>
                  </div>
                </div>
              </div>

              {/* Content */}
              <div className="p-5 space-y-4">
                <p className="text-sm text-gray-300 leading-relaxed">
                  {config.description}
                </p>

                {/* Warning for reject withdrawal */}
                {isReject && type === "withdrawal" && (
                  <div className="flex items-start gap-2.5 p-3 rounded-lg bg-amber-500/10 border border-amber-500/20">
                    <DollarSign className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <p className="text-xs text-amber-400">
                      <strong>Refund:</strong> ${amount.toFixed(2)} will be added back to user&apos;s balance automatically.
                    </p>
                  </div>
                )}

                {/* Info for approve deposit */}
                {isApprove && type === "deposit" && (
                  <div className="flex items-start gap-2.5 p-3 rounded-lg bg-green-500/10 border border-green-500/20">
                    <DollarSign className="w-4 h-4 text-green-400 shrink-0 mt-0.5" />
                    <p className="text-xs text-green-400">
                      <strong>Auto-credit:</strong> ${amount.toFixed(2)} will be instantly added to user&apos;s balance.
                    </p>
                  </div>
                )}

                {/* TxId Field (COMPLETE action) */}
                {config.showTxId && (
                  <div>
                    <label className="block text-xs font-semibold text-gray-400 mb-2 uppercase tracking-wider">
                      Transaction ID <span className="text-gray-600 normal-case font-normal">(optional)</span>
                    </label>
                    <div className="relative">
                      <Hash className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-500" />
                      <input
                        type="text"
                        value={txId}
                        onChange={(e) => setTxId(e.target.value)}
                        placeholder="0x1234...abcd"
                        disabled={loading}
                        className="w-full pl-9 pr-4 py-3 rounded-xl bg-white/5 border border-white/10 text-foreground text-xs font-mono placeholder:text-gray-600 focus:border-[var(--accent)]/50 focus:bg-white/[0.07] outline-none transition-all disabled:opacity-50"
                      />
                    </div>
                  </div>
                )}

                {/* Note Field */}
                <div>
                  <label className="block text-xs font-semibold text-gray-400 mb-2 uppercase tracking-wider">
                    {isReject ? "Rejection Reason" : "Note"}{" "}
                    {config.noteRequired ? (
                      <span className="text-red-400 normal-case">*</span>
                    ) : (
                      <span className="text-gray-600 normal-case font-normal">(optional)</span>
                    )}
                  </label>
                  <textarea
                    value={note}
                    onChange={(e) => setNote(e.target.value)}
                    placeholder={
                      isReject
                        ? "e.g., Screenshot doesn't match transaction details, insufficient funds visible..."
                        : "Add a note for the audit log..."
                    }
                    rows={3}
                    disabled={loading}
                    className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-foreground text-sm placeholder:text-gray-600 focus:border-[var(--accent)]/50 focus:bg-white/[0.07] outline-none transition-all resize-none disabled:opacity-50"
                  />
                </div>

                {/* Error */}
                {error && (
                  <motion.div
                    initial={{ opacity: 0, y: -5 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex items-start gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/20"
                  >
                    <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                    <p className="text-xs text-red-400">{error}</p>
                  </motion.div>
                )}

                {/* Buttons */}
                <div className="flex gap-2 pt-2">
                  <button
                    onClick={handleClose}
                    disabled={loading}
                    className="flex-1 py-3 rounded-xl border border-[var(--border)] text-gray-400 font-semibold text-sm hover:bg-white/5 transition-all disabled:opacity-50"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleSubmit}
                    disabled={loading || !isValid}
                    className={`flex-1 py-3 rounded-xl font-bold text-sm text-white shadow-lg disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-2 bg-gradient-to-r ${config.buttonColor}`}
                  >
                    {loading ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        <span>Processing...</span>
                      </>
                    ) : (
                      <>
                        <Icon size={16} />
                        <span>{config.buttonText}</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}