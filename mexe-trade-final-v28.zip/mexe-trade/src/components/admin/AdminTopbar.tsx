// src/components/admin/AdminTopbar.tsx
"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useAdminThemeStore, Theme } from "@/store/themeStore"; // ✅ Admin theme store
import { useUIStore } from "@/store/uiStore";
import Link from "next/link";
import {
  Menu,
  Moon,
  Sun,
  Terminal,
  ChevronDown,
  Shield,
  MessageSquare,
} from "lucide-react";

const THEMES: { id: Theme; label: string; Icon: React.ElementType; iconClass: string }[] = [
  { id: "deep-space", label: "Deep Space", Icon: Moon, iconClass: "text-blue-400" },
  { id: "cyberpunk", label: "Cyberpunk", Icon: Terminal, iconClass: "text-green-400" },
  { id: "light", label: "Light", Icon: Sun, iconClass: "text-amber-400" },
];

export default function AdminTopbar() {
  const { theme, setTheme } = useAdminThemeStore(); // ✅ Admin theme store
  const { setSidebarOpen } = useUIStore();
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const [chatUnread, setChatUnread] = useState(0);
  const chatPollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setDropdownOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // ─── Poll for unread chat messages ───
  const fetchUnread = useCallback(async () => {
    try {
      const res = await fetch("/api/admin/chat/conversations", {
        credentials: "include",
      });
      if (!res.ok) return;
      const data = await res.json();
      if (typeof data.totalUnread === "number") {
        setChatUnread(data.totalUnread);
      }
    } catch {
      // Non-critical — silently skip
    }
  }, []);

  useEffect(() => {
    fetchUnread();
    chatPollRef.current = setInterval(fetchUnread, 30_000);
    return () => {
      if (chatPollRef.current) clearInterval(chatPollRef.current);
    };
  }, [fetchUnread]);

  const ActiveTheme = THEMES.find((t) => t.id === theme) ?? THEMES[0];

  return (
    <nav className="sticky top-0 left-0 w-full h-14 lg:h-16 glass-panel z-40 px-3 lg:px-6 flex items-center justify-between border-b border-[var(--border)]">
      {/* Left: Hamburger + Title */}
      <div className="flex items-center gap-3">
        <button
          onClick={() => setSidebarOpen(true)}
          className="lg:hidden p-1.5 rounded-lg text-gray-400 hover:text-[var(--accent)] hover:bg-white/5 transition-all active:scale-95"
        >
          <Menu size={22} />
        </button>

        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
          <span className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
            Admin Console
          </span>
        </div>
      </div>

      {/* Center: Admin Badge */}
      <div className="hidden xl:flex items-center">
        <div className="flex items-center gap-2 px-4 py-1.5 rounded-full border border-red-500/20 bg-red-500/[0.05]">
          <Shield className="w-3.5 h-3.5 text-red-400" />
          <span className="text-xs font-semibold tracking-wide text-red-400">
            Admin Mode
          </span>
        </div>
      </div>

      {/* Right: Chat Bell + Theme Switcher */}
      <div className="flex items-center gap-2">
        {/* Chat unread indicator */}
        <Link href="/admin/chat">
          <motion.button
            whileTap={{ scale: 0.95 }}
            className="relative p-1.5 sm:p-2 rounded-lg border border-[var(--border)] text-gray-400 hover:text-[var(--accent)] hover:bg-white/5 hover:border-[var(--accent)]/30 transition-all"
            title={chatUnread > 0 ? `${chatUnread} unread message${chatUnread > 1 ? "s" : ""}` : "Chat Support"}
          >
            <MessageSquare size={18} />
            {chatUnread > 0 && (
              <span className="absolute -top-1 -right-1 min-w-[16px] h-4 px-0.5 rounded-full bg-red-500 border border-[var(--background)] flex items-center justify-center">
                <span className="text-[9px] font-bold text-white leading-none">
                  {chatUnread > 99 ? "99+" : chatUnread}
                </span>
              </span>
            )}
          </motion.button>
        </Link>
        <div className="relative" ref={dropdownRef}>
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => setDropdownOpen((prev) => !prev)}
            className="flex items-center gap-1.5 sm:gap-2 px-2.5 sm:px-3.5 py-1.5 rounded-lg
                       border border-[var(--border)] text-sm font-medium
                       hover:bg-white/5 transition-all"
          >
            <ActiveTheme.Icon className={`w-4 h-4 ${ActiveTheme.iconClass}`} />
            <span className="capitalize hidden sm:inline text-xs">{ActiveTheme.label}</span>
            <motion.span animate={{ rotate: dropdownOpen ? 180 : 0 }} transition={{ duration: 0.2 }}>
              <ChevronDown className="w-3 h-3 opacity-60" />
            </motion.span>
          </motion.button>

          <AnimatePresence>
            {dropdownOpen && (
              <motion.div
                initial={{ opacity: 0, y: -8, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -8, scale: 0.95 }}
                transition={{ duration: 0.15 }}
                className="absolute right-0 mt-2 w-48 rounded-xl glass-panel p-1.5
                           shadow-2xl border border-[var(--border)] flex flex-col gap-0.5 z-50"
              >
                <div className="px-3 py-2 border-b border-[var(--border)] mb-1">
                  <span className="text-[10px] uppercase tracking-wider text-gray-500 font-semibold">
                    Theme
                  </span>
                </div>
                {THEMES.map(({ id, label, Icon, iconClass }) => (
                  <button
                    key={id}
                    onClick={() => {
                      setTheme(id);
                      setDropdownOpen(false);
                    }}
                    className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg
                                text-sm transition-all duration-150
                                ${
                                  theme === id
                                    ? "bg-[var(--accent)]/15 text-[var(--accent)] border border-[var(--accent)]/20"
                                    : "hover:bg-white/5 text-gray-300"
                                }`}
                  >
                    <Icon className={`w-4 h-4 ${theme === id ? "text-[var(--accent)]" : iconClass}`} />
                    <span>{label}</span>
                  </button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </nav>
  );
}