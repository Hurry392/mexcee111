// src/components/admin/UserActionsModal.tsx
"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  X,
  AlertTriangle,
  Ban,
  CheckCircle,
  Shield,
  UserMinus,
  Trash2,
  AlertCircle,
  Snowflake,
  Unlock,
} from "lucide-react";
import { adminAPI } from "@/lib/api";

type ActionType =
  | "SUSPEND"
  | "ACTIVATE"
  | "PROMOTE"
  | "DEMOTE"
  | "DELETE"
  | "FREEZE_WITHDRAWALS"
  | "UNFREEZE_WITHDRAWALS";

interface UserActionsModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: {
    id: string;
    email: string;
    username?: string | null;
    role: string;
    isActive: boolean;
  };
  action: ActionType;
  onSuccess: () => void;
}

const ACTION_CONFIG = {
  SUSPEND: {
    title: "Suspend User",
    description: "This will deactivate the account and force logout from all devices.",
    warning: "The user will not be able to login until reactivated.",
    icon: Ban,
    color: "amber" as const,
    buttonText: "Suspend User",
    requireConfirmText: false,
  },
  ACTIVATE: {
    title: "Activate User",
    description: "This will reactivate the suspended account.",
    warning: "The user will be able to login again.",
    icon: CheckCircle,
    color: "green" as const,
    buttonText: "Activate User",
    requireConfirmText: false,
  },
  PROMOTE: {
    title: "Promote to Admin",
    description: "This will grant the user FULL admin privileges.",
    warning: "The user will have complete access to the admin panel including balance management, KYC review, and all sensitive operations.",
    icon: Shield,
    color: "blue" as const,
    buttonText: "Promote to Admin",
    requireConfirmText: true,
  },
  DEMOTE: {
    title: "Demote to Regular User",
    description: "This will revoke admin privileges from this user.",
    warning: "The user will lose access to the admin panel.",
    icon: UserMinus,
    color: "amber" as const,
    buttonText: "Demote to User",
    requireConfirmText: false,
  },
  FREEZE_WITHDRAWALS: {
    title: "Freeze Withdrawals",
    description: "This will put the user's withdrawals on hold (TOS enforcement). Deposits, trading, and login remain unaffected.",
    warning: "The user will see the reason you provide below on the withdraw page and in a notification. A reason is required.",
    icon: Snowflake,
    color: "red" as const,
    buttonText: "Freeze Withdrawals",
    requireConfirmText: false,
  },
  UNFREEZE_WITHDRAWALS: {
    title: "Re-enable Withdrawals",
    description: "This will lift the withdrawal hold and allow the user to withdraw funds again.",
    warning: "The user will be notified that their withdrawals have been re-enabled.",
    icon: Unlock,
    color: "green" as const,
    buttonText: "Re-enable Withdrawals",
    requireConfirmText: false,
  },
  DELETE: {
    title: "Delete User Permanently",
    description: "This will PERMANENTLY delete the user account and ALL their data.",
    warning: "This action CANNOT be undone. All deposits, withdrawals, trades, chat messages, and KYC data will be permanently erased.",
    icon: Trash2,
    color: "red" as const,
    buttonText: "Delete Forever",
    requireConfirmText: true,
  },
};

const COLOR_MAP = {
  amber: {
    icon: "text-amber-400 bg-amber-500/10 border-amber-500/20",
    button: "from-amber-600 to-orange-600 shadow-amber-500/20",
    alert: "bg-amber-500/10 border-amber-500/20 text-amber-400",
  },
  green: {
    icon: "text-green-400 bg-green-500/10 border-green-500/20",
    button: "from-green-600 to-emerald-600 shadow-green-500/20",
    alert: "bg-green-500/10 border-green-500/20 text-green-400",
  },
  blue: {
    icon: "text-blue-400 bg-blue-500/10 border-blue-500/20",
    button: "from-blue-600 to-purple-600 shadow-blue-500/20",
    alert: "bg-blue-500/10 border-blue-500/20 text-blue-400",
  },
  red: {
    icon: "text-red-400 bg-red-500/10 border-red-500/20",
    button: "from-red-600 to-rose-600 shadow-red-500/20",
    alert: "bg-red-500/10 border-red-500/20 text-red-400",
  },
};

export default function UserActionsModal({
  isOpen,
  onClose,
  user,
  action,
  onSuccess,
}: UserActionsModalProps) {
  const config = ACTION_CONFIG[action];
  const colors = COLOR_MAP[config.color];
  const Icon = config.icon;

  const [confirmText, setConfirmText] = useState("");
  const [note, setNote] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const requiredConfirmText = user.email;
  const reasonRequired = action === "FREEZE_WITHDRAWALS";
  const isConfirmed =
    (!config.requireConfirmText || confirmText === requiredConfirmText) &&
    (!reasonRequired || note.trim().length > 0);

  const handleSubmit = async () => {
    setError("");
    setLoading(true);

    try {
      let result;

      if (action === "DELETE") {
        result = await adminAPI.deleteUser(user.id);
      } else {
        result = await adminAPI.updateUser(user.id, {
          action,
          note: note.trim() || undefined,
        });
      }

      if (result.error) {
        setError(result.error);
        setLoading(false);
        return;
      }

      onSuccess();
      handleClose();
    } catch (err) {
      console.error(err);
      setError("Network error. Please try again.");
      setLoading(false);
    }
  };

  const handleClose = () => {
    setConfirmText("");
    setNote("");
    setError("");
    setLoading(false);
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50"
            onClick={handleClose}
          />

          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ duration: 0.2 }}
            className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[95vw] max-w-md z-50"
          >
            <div className="glass-panel rounded-2xl overflow-hidden shadow-2xl border border-[var(--border)]">
              {/* Header */}
              <div className="flex items-center justify-between p-5 border-b border-[var(--border)]">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-xl border flex items-center justify-center ${colors.icon}`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-foreground">{config.title}</h3>
                    <p className="text-[11px] text-gray-500 truncate max-w-[220px]">
                      {user.email}
                    </p>
                  </div>
                </div>
                <button
                  onClick={handleClose}
                  disabled={loading}
                  className="p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-white/5 transition-all disabled:opacity-50"
                >
                  <X size={18} />
                </button>
              </div>

              {/* Content */}
              <div className="p-5 space-y-4">
                {/* Description */}
                <p className="text-sm text-gray-300 leading-relaxed">{config.description}</p>

                {/* Warning */}
                <div className={`flex items-start gap-2.5 p-3 rounded-lg border ${colors.alert}`}>
                  <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                  <p className="text-xs">{config.warning}</p>
                </div>

                {/* Confirmation Input (for dangerous actions) */}
                {config.requireConfirmText && (
                  <div>
                    <label className="block text-xs font-semibold text-gray-400 mb-2 uppercase tracking-wider">
                      Type <span className="text-red-400 font-mono normal-case">{requiredConfirmText}</span> to confirm
                    </label>
                    <input
                      type="text"
                      value={confirmText}
                      onChange={(e) => setConfirmText(e.target.value)}
                      placeholder={requiredConfirmText}
                      disabled={loading}
                      className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-foreground text-sm font-mono placeholder:text-gray-600 focus:border-[var(--accent)]/50 focus:bg-white/[0.07] outline-none transition-all disabled:opacity-50"
                    />
                  </div>
                )}

                {/* Note Input (for non-delete actions) */}
                {action !== "DELETE" && (
                  <div>
                    <label className="block text-xs font-semibold text-gray-400 mb-2 uppercase tracking-wider">
                      Reason{" "}
                      {reasonRequired ? (
                        <span className="text-red-400 normal-case">* (shown to the user)</span>
                      ) : (
                        <span className="text-gray-600 normal-case font-normal">(optional)</span>
                      )}
                    </label>
                    <textarea
                      value={note}
                      onChange={(e) => setNote(e.target.value)}
                      placeholder={
                        reasonRequired
                          ? "e.g. Multiple accounts detected — violation of Terms of Service"
                          : "Add a note for the audit log..."
                      }
                      rows={2}
                      disabled={loading}
                      className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-foreground text-sm placeholder:text-gray-600 focus:border-[var(--accent)]/50 focus:bg-white/[0.07] outline-none transition-all resize-none disabled:opacity-50"
                    />
                  </div>
                )}

                {/* Error */}
                {error && (
                  <motion.div
                    initial={{ opacity: 0, y: -5 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex items-start gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/20"
                  >
                    <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                    <p className="text-xs text-red-400">{error}</p>
                  </motion.div>
                )}

                {/* Actions */}
                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={handleClose}
                    disabled={loading}
                    className="flex-1 py-3 rounded-xl border border-[var(--border)] text-gray-400 font-semibold text-sm hover:bg-white/5 transition-all disabled:opacity-50"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleSubmit}
                    disabled={loading || !isConfirmed}
                    className={`flex-1 py-3 rounded-xl font-bold text-sm text-white shadow-lg disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-2 bg-gradient-to-r ${colors.button}`}
                  >
                    {loading ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        <span>Processing...</span>
                      </>
                    ) : (
                      <>
                        <Icon size={16} />
                        <span>{config.buttonText}</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}