// src/components/BottomNav.tsx
"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion } from "framer-motion";
import {
  LayoutGrid,
  LineChart,
  Zap,
  Wallet,
  ArrowDownUp,
} from "lucide-react";

const BOTTOM_TABS = [
  { name: "Home", href: "/", icon: LayoutGrid },
  { name: "Markets", href: "/markets", icon: LineChart },
  { name: "Trade", href: "/trade", icon: Zap },
  { name: "Wallet", href: "/wallet", icon: Wallet },
  { name: "Funds", href: "/funds", icon: ArrowDownUp },
];

export default function BottomNav() {
  const pathname = usePathname();

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 lg:hidden">
      {/* Gradient fade effect above the nav */}
      <div className="h-6 bg-gradient-to-t from-[var(--background)] to-transparent pointer-events-none" />

      {/* Navigation Bar */}
      <nav className="bg-[var(--background)]/95 backdrop-blur-xl border-t border-[var(--border)] px-2 pb-[env(safe-area-inset-bottom)]">
        <div className="flex items-center justify-around h-14">
          {BOTTOM_TABS.map((tab) => {
            const Icon = tab.icon;
            const isActive = tab.href === "/" 
              ? pathname === "/" 
              : pathname.startsWith(tab.href);
            // Trade tab gets special "center" styling
            const isTrade = tab.name === "Trade";

            return (
              <Link
                key={tab.name}
                href={tab.href}
                className="relative flex flex-col items-center justify-center flex-1 h-full"
              >
                {/* Active indicator dot */}
                {isActive && !isTrade && (
                  <motion.div
                    layoutId="bottomNavIndicator"
                    className="absolute -top-[1px] w-8 h-[2px] rounded-full bg-[var(--accent)]"
                    transition={{ type: "spring", stiffness: 400, damping: 30 }}
                  />
                )}

                {isTrade ? (
                  /* Special Trade button — center prominent */
                  <div
                    className={`
                      flex items-center justify-center w-11 h-11 -mt-3 rounded-xl
                      shadow-lg transition-all duration-200
                      ${
                        isActive
                          ? "bg-gradient-to-br from-[var(--accent)] to-purple-500 shadow-[var(--accent)]/30"
                          : "bg-[var(--accent)]/10 border border-[var(--accent)]/20"
                      }
                    `}
                  >
                    <Icon
                      size={20}
                      className={isActive ? "text-white" : "text-[var(--accent)]"}
                    />
                  </div>
                ) : (
                  <Icon
                    size={20}
                    className={`transition-colors duration-200 ${
                      isActive ? "text-[var(--accent)]" : "text-gray-500"
                    }`}
                  />
                )}

                <span
                  className={`text-[10px] mt-1 font-medium transition-colors duration-200 ${
                    isActive ? "text-[var(--accent)]" : "text-gray-500"
                  } ${isTrade ? "mt-1.5" : ""}`}
                >
                  {tab.name}
                </span>
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}