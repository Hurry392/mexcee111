// src/components/markets/AnimatedPrice.tsx
"use client";

import { useEffect, useRef, useState } from "react";
import { formatPrice } from "@/lib/markets";

interface Props {
  price: number;
  className?: string;
  prefix?: string;
}

export default function AnimatedPrice({ price, className = "", prefix = "$" }: Props) {
  const previousPriceRef = useRef(price);
  const [flashClass, setFlashClass] = useState("");

  useEffect(() => {
    const prev = previousPriceRef.current;
    if (price > prev) {
      setFlashClass("flash-up");
    } else if (price < prev) {
      setFlashClass("flash-down");
    }
    previousPriceRef.current = price;

    const timeout = setTimeout(() => setFlashClass(""), 600);
    return () => clearTimeout(timeout);
  }, [price]);

  return (
    <span className={`inline-block px-1 rounded transition-colors ${flashClass} ${className}`}>
      {prefix}{formatPrice(price)}
    </span>
  );
}