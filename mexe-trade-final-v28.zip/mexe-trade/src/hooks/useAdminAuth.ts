// src/hooks/useAdminAuth.ts
"use client";

import { useEffect } from "react";
import { useAdminStore } from "@/store/adminStore";

/**
 * Hook to verify admin session on mount.
 * If session is invalid → force redirect to admin login.
 */
export function useAdminAuth() {
  const { admin, token, isAuthenticated, setAuth, logout } = useAdminStore();

  useEffect(() => {
    const verifyAdminSession = async () => {
      if (!isAuthenticated || !token) return;

      try {
        const response = await fetch("/api/admin/me", {
          method: "GET",
          credentials: "include",
        });

        const data = await response.json();

        if (!response.ok || !data.admin) {
          console.warn("Admin session invalid — clearing state");
          logout();
          if (typeof window !== "undefined") {
            window.location.href = "/admin/login";
          }
        } else {
          // Refresh admin data from server
          setAuth(data.admin, token);
        }
      } catch {
        console.warn("Admin session check failed");
        logout();
        if (typeof window !== "undefined") {
          window.location.href = "/admin/login";
        }
      }
    };

    verifyAdminSession();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return { admin, isAuthenticated };
}