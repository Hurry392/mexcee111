// src/hooks/useNotifications.ts
"use client";

import { useState, useEffect, useCallback, useRef } from "react";
import { notificationsAPI } from "@/lib/api";
import { useAuthStore } from "@/store/authStore";

export interface UserNotification {
  id: string;
  title: string;
  message: string;
  type: string;
  actionUrl: string | null;
  relatedId: string | null;
  isRead: boolean;
  createdAt: string;
}

export function useNotifications(pollingInterval: number = 30000) {
  const { isAuthenticated } = useAuthStore();
  const [notifications, setNotifications] = useState<UserNotification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const previousUnreadRef = useRef<number>(0);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const isFirstLoadRef = useRef(true);

  // ─── Initialize audio (Web Audio API — no external file needed) ───
  useEffect(() => {
    if (typeof window === "undefined") return;

    // Create a subtle notification sound using Web Audio API
    // Frequency: pleasant "ding" tone
    const createDingSound = () => {
      try {
        // Use AudioContext with vendor prefix fallback
        interface WindowWithWebkit extends Window {
          webkitAudioContext?: typeof AudioContext;
        }
        const AudioContextClass =
          window.AudioContext || (window as WindowWithWebkit).webkitAudioContext;
        if (!AudioContextClass) return null;

        const ctx = new AudioContextClass();
        return ctx;
      } catch {
        return null;
      }
    };

    const playDing = () => {
      try {
        const ctx = createDingSound();
        if (!ctx) return;

        // Create a pleasant "ding" using two overlapping tones
        const osc1 = ctx.createOscillator();
        const osc2 = ctx.createOscillator();
        const gain = ctx.createGain();

        osc1.frequency.value = 880; // A5
        osc2.frequency.value = 1320; // E6 (harmony)
        osc1.type = "sine";
        osc2.type = "sine";

        gain.gain.setValueAtTime(0, ctx.currentTime);
        gain.gain.linearRampToValueAtTime(0.15, ctx.currentTime + 0.01);
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.3);

        osc1.connect(gain);
        osc2.connect(gain);
        gain.connect(ctx.destination);

        osc1.start(ctx.currentTime);
        osc2.start(ctx.currentTime);
        osc1.stop(ctx.currentTime + 0.3);
        osc2.stop(ctx.currentTime + 0.3);

        // Cleanup
        setTimeout(() => ctx.close(), 500);
      } catch {
        // Silent fail — audio may be blocked
      }
    };

    // Store the play function
    audioRef.current = { play: playDing } as unknown as HTMLAudioElement;
  }, []);

  const fetchNotifications = useCallback(async () => {
    if (!isAuthenticated) return;

    try {
      const result = await notificationsAPI.list({ limit: 20 });

      if (result.notifications) {
        const newNotifs = result.notifications as UserNotification[];
        const newUnreadCount = result.unreadCount || 0;

        setNotifications(newNotifs);
        setUnreadCount(newUnreadCount);

        // Play sound if unread count increased (new notification arrived)
        // Skip on first load — only play for actually new ones
        if (
          !isFirstLoadRef.current &&
          newUnreadCount > previousUnreadRef.current
        ) {
          audioRef.current?.play?.();
        }

        previousUnreadRef.current = newUnreadCount;
        isFirstLoadRef.current = false;
      }
    } catch (err) {
      console.error("Failed to fetch notifications:", err);
    } finally {
      setLoading(false);
    }
  }, [isAuthenticated]);

  // Polling
  useEffect(() => {
    if (!isAuthenticated) return;

    fetchNotifications();
    const interval = setInterval(fetchNotifications, pollingInterval);

    return () => clearInterval(interval);
  }, [isAuthenticated, pollingInterval, fetchNotifications]);

  const markAsRead = useCallback(async (id: string) => {
    try {
      await notificationsAPI.markAsRead(id);
      setNotifications((prev) =>
        prev.map((n) => (n.id === id ? { ...n, isRead: true } : n))
      );
      setUnreadCount((prev) => Math.max(0, prev - 1));
    } catch (err) {
      console.error("Failed to mark as read:", err);
    }
  }, []);

  const markAllAsRead = useCallback(async () => {
    try {
      await notificationsAPI.markAllAsRead();
      setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
      setUnreadCount(0);
    } catch (err) {
      console.error("Failed to mark all as read:", err);
    }
  }, []);

  return {
    notifications,
    unreadCount,
    loading,
    markAsRead,
    markAllAsRead,
    refresh: fetchNotifications,
  };
}