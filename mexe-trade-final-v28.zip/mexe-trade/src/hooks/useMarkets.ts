// src/hooks/useMarkets.ts
"use client";

import { useEffect, useState, useMemo, useCallback, useRef } from "react";
import { MarketCoin } from "@/lib/markets";
import { useLivePrices } from "./useLivePrices";

interface UseMarketsReturn {
  markets: MarketCoin[];
  loading: boolean;
  error: string | null;
  isLive: boolean;
  refetch: () => Promise<void>;
}

/**
 * Combines REST API metadata (coin name, image, rank) with
 * real-time WebSocket prices for the best of both worlds.
 *
 * Retry strategy:
 *   - Retries on failure every 8 s, up to 5 times
 *   - Then falls back to polling every 5 minutes
 */
export function useMarkets(_refreshInterval: number = 30000): UseMarketsReturn {
  const [baseMarkets, setBaseMarkets] = useState<MarketCoin[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { prices: livePrices, isConnected } = useLivePrices();

  const retryCountRef    = useRef(0);
  const retryTimerRef    = useRef<ReturnType<typeof setTimeout> | null>(null);
  const pollingTimerRef  = useRef<ReturnType<typeof setInterval> | null>(null);
  const isMountedRef     = useRef(true);

  const MAX_RETRIES = 5;
  const RETRY_DELAY = 8_000;          // 8 seconds between fast retries
  const POLL_INTERVAL = 5 * 60_000;  // 5 minutes polling once stable

  const fetchData = useCallback(async () => {
    try {
      const response = await fetch("/api/markets");
      const data = await response.json();

      if (!isMountedRef.current) return;

      if (response.ok && data.markets && data.markets.length > 0) {
        setBaseMarkets(data.markets);
        setError(null);
        retryCountRef.current = 0; // reset on success

        // Start 5-minute polling if not already running
        if (!pollingTimerRef.current) {
          pollingTimerRef.current = setInterval(fetchData, POLL_INTERVAL);
        }
      } else {
        const msg = data.error || "Failed to fetch markets";
        setError(msg);

        // Schedule a fast retry if we haven't hit the limit
        if (retryCountRef.current < MAX_RETRIES) {
          retryCountRef.current++;
          retryTimerRef.current = setTimeout(fetchData, RETRY_DELAY);
        }
      }
    } catch (err) {
      console.error("useMarkets fetch error:", err);
      if (!isMountedRef.current) return;
      setError("Network error — retrying…");

      if (retryCountRef.current < MAX_RETRIES) {
        retryCountRef.current++;
        retryTimerRef.current = setTimeout(fetchData, RETRY_DELAY);
      }
    } finally {
      if (isMountedRef.current) setLoading(false);
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    isMountedRef.current = true;
    fetchData();

    return () => {
      isMountedRef.current = false;
      if (retryTimerRef.current) clearTimeout(retryTimerRef.current);
      if (pollingTimerRef.current) clearInterval(pollingTimerRef.current);
    };
  }, [fetchData]);

  // ─── Merge REST data with live WebSocket prices ───
  const markets = useMemo(() => {
    return baseMarkets.map((coin) => {
      const live = livePrices[coin.id];
      if (!live) return coin;
      return {
        ...coin,
        current_price: live.price,
        price_change_percentage_24h: live.priceChangePercent,
        high_24h: live.high24h,
        low_24h: live.low24h,
        total_volume: live.volume24h,
        last_updated: new Date(live.lastUpdate).toISOString(),
      };
    });
  }, [baseMarkets, livePrices]);

  const refetch = useCallback(async () => {
    retryCountRef.current = 0;
    setLoading(true);
    await fetchData();
  }, [fetchData]);

  return {
    markets,
    loading,
    error,
    isLive: isConnected,
    refetch,
  };
}
