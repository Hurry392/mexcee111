// src/hooks/useAuth.ts
"use client";

import { useEffect } from "react";
import { usePathname } from "next/navigation";
import { useAuthStore } from "@/store/authStore";
import { authAPI } from "@/lib/api";

/**
 * Hook to sync USER auth state with server on mount.
 * SKIPS execution on /admin/* routes (admin uses useAdminAuth instead).
 */
export function useAuth() {
  const { user, token, isAuthenticated, setAuth, logout } = useAuthStore();
  const pathname = usePathname();

  useEffect(() => {
    // ✅ Skip user auth check on admin routes
    if (pathname.startsWith("/admin")) return;

    const verifySession = async () => {
      if (!isAuthenticated) return;

      const result = await authAPI.me();

      // If session invalid OR user deleted → force logout + redirect
      if (result.error || !result.user) {
        console.warn("Session invalid — clearing local state");
        logout();
        if (typeof window !== "undefined") {
          window.location.href = "/login";
        }
      } else {
        setAuth(result.user, result.token || token || "");
      }
    };

    verifySession();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pathname]);

  return { user, isAuthenticated };
}