// src/hooks/useBalance.ts
"use client";

import { useCallback } from "react";
import { useAuthStore } from "@/store/authStore";
import { authAPI } from "@/lib/api";

/**
 * Hook to refresh user balance from server
 * Use this after ANY action that changes balance (trade, deposit, withdrawal, etc.)
 */
export function useBalance() {
  const { user, setAuth, token } = useAuthStore();

  const refreshBalance = useCallback(async () => {
    const result = await authAPI.me();
    if (result.user) {
      setAuth(result.user, token || "");
    }
    return result.user;
  }, [setAuth, token]);

  return {
    balance: user?.balance ?? 0,
    refreshBalance,
  };
}