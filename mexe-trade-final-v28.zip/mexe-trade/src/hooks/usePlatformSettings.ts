// src/hooks/usePlatformSettings.ts
"use client";

import { useState, useEffect } from "react";

export interface PlatformSettings {
  trc20WalletAddress: string;
  minDeposit: number;
  maxDeposit: number;
  minWithdrawal: number;
  maxWithdrawal: number;
  dailyWithdrawalLimit: number;
}

// Fallback defaults (used only if API fails)
const FALLBACK_SETTINGS: PlatformSettings = {
  trc20WalletAddress: "TSG7K6nrDdAzPPuDHTFEHucfA35yHhEWMZ",
  minDeposit: 10,
  maxDeposit: 100000,
  minWithdrawal: 0,
  maxWithdrawal: 50000,
  dailyWithdrawalLimit: 10000,
};

/**
 * Hook to fetch live platform settings from the database.
 * Falls back to hardcoded defaults if API fails.
 */
export function usePlatformSettings() {
  const [settings, setSettings] = useState<PlatformSettings>(FALLBACK_SETTINGS);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let mounted = true;

    const fetchSettings = async () => {
      try {
        const response = await fetch("/api/settings", {
          credentials: "include",
        });
        const data = await response.json();

        if (!mounted) return;

        if (data.success && data.settings) {
          setSettings({
            trc20WalletAddress: data.settings.trc20WalletAddress || FALLBACK_SETTINGS.trc20WalletAddress,
            minDeposit: data.settings.minDeposit ?? FALLBACK_SETTINGS.minDeposit,
            maxDeposit: data.settings.maxDeposit ?? FALLBACK_SETTINGS.maxDeposit,
            minWithdrawal: data.settings.minWithdrawal ?? FALLBACK_SETTINGS.minWithdrawal,
            maxWithdrawal: data.settings.maxWithdrawal ?? FALLBACK_SETTINGS.maxWithdrawal,
            dailyWithdrawalLimit: data.settings.dailyWithdrawalLimit ?? FALLBACK_SETTINGS.dailyWithdrawalLimit,
          });
        }
      } catch (err) {
        console.error("Failed to fetch platform settings:", err);
        if (mounted) setError("Failed to load settings");
        // Keep fallback settings on error
      } finally {
        if (mounted) setLoading(false);
      }
    };

    fetchSettings();

    return () => {
      mounted = false;
    };
  }, []);

  return { settings, loading, error };
}