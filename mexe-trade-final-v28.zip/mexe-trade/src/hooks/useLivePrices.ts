// src/hooks/useLivePrices.ts
"use client";

import { useEffect, useRef, useState } from "react";
import { COINGECKO_TO_BINANCE, BINANCE_TO_COINGECKO } from "@/lib/markets";

export interface LivePrice {
  symbol: string;
  coingeckoId: string;
  price: number;
  priceChangePercent: number;
  high24h: number;
  low24h: number;
  volume24h: number;
  lastUpdate: number;
}

const RECONNECT_DELAY_MS = 3000;
const MAX_RECONNECT_ATTEMPTS = 10;

/**
 * Subscribes to Binance WebSocket for real-time price updates
 * Handles reconnection, cleanup, and dev hot-reload gracefully
 */
export function useLivePrices(): {
  prices: Record<string, LivePrice>;
  isConnected: boolean;
} {
  const [prices, setPrices] = useState<Record<string, LivePrice>>({});
  const [isConnected, setIsConnected] = useState(false);

  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const reconnectAttemptsRef = useRef(0);
  const isCleanedUpRef = useRef(false);
  const hasLoggedConnectionRef = useRef(false);

  useEffect(() => {
    isCleanedUpRef.current = false;

    const symbols = Object.values(COINGECKO_TO_BINANCE);
    const streams = symbols.map((s) => `${s.toLowerCase()}@ticker`).join("/");
    const wsUrl = `wss://stream.binance.com:9443/stream?streams=${streams}`;

    const connect = () => {
      // Don't connect if component unmounted
      if (isCleanedUpRef.current) return;

      // Stop trying after too many failures
      if (reconnectAttemptsRef.current >= MAX_RECONNECT_ATTEMPTS) {
        console.warn("⚠️ Max WebSocket reconnect attempts reached");
        return;
      }

      try {
        const ws = new WebSocket(wsUrl);
        wsRef.current = ws;

        ws.onopen = () => {
          if (isCleanedUpRef.current) {
            ws.close(1000, "Component unmounted");
            return;
          }

          // Only log first successful connection (avoid spam on reconnects)
          if (!hasLoggedConnectionRef.current) {
            console.log("✅ Binance WebSocket connected");
            hasLoggedConnectionRef.current = true;
          }

          setIsConnected(true);
          reconnectAttemptsRef.current = 0;
        };

        ws.onmessage = (event) => {
          if (isCleanedUpRef.current) return;

          try {
            const message = JSON.parse(event.data);
            const data = message.data;
            if (!data || !data.s) return;

            const binanceSymbol = data.s;
            const coingeckoId = BINANCE_TO_COINGECKO[binanceSymbol];
            if (!coingeckoId) return;

            const update: LivePrice = {
              symbol: binanceSymbol,
              coingeckoId,
              price: parseFloat(data.c),
              priceChangePercent: parseFloat(data.P),
              high24h: parseFloat(data.h),
              low24h: parseFloat(data.l),
              volume24h: parseFloat(data.q),
              lastUpdate: Date.now(),
            };

            setPrices((prev) => ({
              ...prev,
              [coingeckoId]: update,
            }));
          } catch {
            // Silently ignore parse errors (rare malformed messages)
          }
        };

        // Silent error handler — these are expected during dev hot-reload
        // Real connection failures are handled by onclose + reconnect logic
        ws.onerror = () => {
          // Intentionally empty — we don't log noisy reconnect events
          // The onclose handler will trigger reconnection
        };

        ws.onclose = (event) => {
          setIsConnected(false);

          // Don't reconnect if cleanup or normal close
          if (isCleanedUpRef.current || event.code === 1000) {
            return;
          }

          // Schedule reconnect with backoff
          reconnectAttemptsRef.current++;
          if (reconnectTimeoutRef.current) {
            clearTimeout(reconnectTimeoutRef.current);
          }
          reconnectTimeoutRef.current = setTimeout(connect, RECONNECT_DELAY_MS);
        };
      } catch {
        // Connection creation failed — schedule retry
        if (!isCleanedUpRef.current) {
          reconnectAttemptsRef.current++;
          reconnectTimeoutRef.current = setTimeout(connect, RECONNECT_DELAY_MS);
        }
      }
    };

    connect();

    // ─── Cleanup on unmount ───
    return () => {
      isCleanedUpRef.current = true;

      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
        reconnectTimeoutRef.current = null;
      }

      if (wsRef.current) {
        // Remove all listeners BEFORE closing to prevent error events
        wsRef.current.onopen = null;
        wsRef.current.onmessage = null;
        wsRef.current.onerror = null;
        wsRef.current.onclose = null;

        // Close with normal closure code (1000 = normal)
        if (
          wsRef.current.readyState === WebSocket.OPEN ||
          wsRef.current.readyState === WebSocket.CONNECTING
        ) {
          wsRef.current.close(1000, "Component unmounting");
        }
        wsRef.current = null;
      }
    };
  }, []);

  return { prices, isConnected };
}