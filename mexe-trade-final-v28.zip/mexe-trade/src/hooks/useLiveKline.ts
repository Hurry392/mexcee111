// src/hooks/useLiveKline.ts
"use client";

import { useEffect, useRef, useState } from "react";
import { CandlestickData, getBinanceInterval } from "@/lib/markets";

interface UseLiveKlineProps {
  binanceSymbol: string | null;
  days: number;
}

/**
 * Subscribes to Binance kline (candlestick) WebSocket stream
 * Emits live candle updates as they form
 */
export function useLiveKline({ binanceSymbol, days }: UseLiveKlineProps): {
  liveCandle: CandlestickData | null;
  isStreaming: boolean;
} {
  const [liveCandle, setLiveCandle] = useState<CandlestickData | null>(null);
  const [isStreaming, setIsStreaming] = useState(false);

  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const isCleanedUpRef = useRef(false);

  useEffect(() => {
    if (!binanceSymbol) return;

    isCleanedUpRef.current = false;
    const { interval } = getBinanceInterval(days);
    const streamName = `${binanceSymbol.toLowerCase()}@kline_${interval}`;
    const wsUrl = `wss://stream.binance.com:9443/ws/${streamName}`;

    const connect = () => {
      if (isCleanedUpRef.current) return;

      try {
        const ws = new WebSocket(wsUrl);
        wsRef.current = ws;

        ws.onopen = () => {
          if (isCleanedUpRef.current) {
            ws.close(1000);
            return;
          }
          setIsStreaming(true);
        };

        ws.onmessage = (event) => {
          if (isCleanedUpRef.current) return;
          try {
            const data = JSON.parse(event.data);
            const k = data.k; // Kline data
            if (!k) return;

            const candle: CandlestickData = {
              time: Math.floor(k.t / 1000), // Open time → seconds
              open: parseFloat(k.o),
              high: parseFloat(k.h),
              low: parseFloat(k.l),
              close: parseFloat(k.c),
            };

            setLiveCandle(candle);
          } catch {
            // Silent
          }
        };

        ws.onerror = () => {
          // Silent — reconnect handles it
        };

        ws.onclose = (event) => {
          setIsStreaming(false);
          if (isCleanedUpRef.current || event.code === 1000) return;
          reconnectTimeoutRef.current = setTimeout(connect, 3000);
        };
      } catch {
        if (!isCleanedUpRef.current) {
          reconnectTimeoutRef.current = setTimeout(connect, 3000);
        }
      }
    };

    connect();

    return () => {
      isCleanedUpRef.current = true;

      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
        reconnectTimeoutRef.current = null;
      }

      if (wsRef.current) {
        wsRef.current.onopen = null;
        wsRef.current.onmessage = null;
        wsRef.current.onerror = null;
        wsRef.current.onclose = null;
        if (
          wsRef.current.readyState === WebSocket.OPEN ||
          wsRef.current.readyState === WebSocket.CONNECTING
        ) {
          wsRef.current.close(1000);
        }
        wsRef.current = null;
      }
    };
  }, [binanceSymbol, days]);

  return { liveCandle, isStreaming };
}