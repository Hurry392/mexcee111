// src/store/themeStore.ts
import { create } from "zustand";
import { persist } from "zustand/middleware";

export type Theme = "deep-space" | "cyberpunk" | "light";

interface ThemeState {
  theme: Theme;
  setTheme: (theme: Theme) => void;
}

// ═══════════════════════════════════════════════
// USER THEME STORE
// ═══════════════════════════════════════════════
export const useThemeStore = create<ThemeState>()(
  persist(
    (set) => ({
      theme: "deep-space", // Default user theme
      setTheme: (theme) => set({ theme }),
    }),
    {
      name: "pe-user-theme", // ✅ User-specific localStorage key
    }
  )
);

// ═══════════════════════════════════════════════
// ADMIN THEME STORE (Separate from user)
// ═══════════════════════════════════════════════
export const useAdminThemeStore = create<ThemeState>()(
  persist(
    (set) => ({
      theme: "deep-space", // Default admin theme
      setTheme: (theme) => set({ theme }),
    }),
    {
      name: "pe-admin-theme", // ✅ Admin-specific localStorage key
    }
  )
);