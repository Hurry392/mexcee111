// src/lib/imageCompress.ts
"use client";

// Compress/resize an image in the browser before upload.
//
// Why: phone cameras routinely produce photos well over the server's 5MB
// limit, which blocked users with a "too large" error. This resizes the
// image down and re-encodes it as JPEG so the result is comfortably under
// the cap — the user just picks any photo and it works. It also converts
// whatever the browser can decode (PNG, WEBP, and on supported devices
// HEIC) into a universally accepted JPEG.

const MAX_DIMENSION = 1600; // px on the longest side — plenty for KYC review
const TARGET_MAX_BYTES = 3.5 * 1024 * 1024; // stay safely under the 5MB server cap

export async function compressImage(file: File): Promise<File> {
  // Load the file into an <img> via an object URL.
  const objectUrl = URL.createObjectURL(file);

  try {
    const img = await loadImage(objectUrl);

    // Work out target dimensions (only ever shrink, never enlarge).
    let { width, height } = img;
    if (width > MAX_DIMENSION || height > MAX_DIMENSION) {
      if (width >= height) {
        height = Math.round((height / width) * MAX_DIMENSION);
        width = MAX_DIMENSION;
      } else {
        width = Math.round((width / height) * MAX_DIMENSION);
        height = MAX_DIMENSION;
      }
    }

    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext("2d");
    if (!ctx) {
      // Canvas unavailable — fall back to the original file untouched.
      return file;
    }
    // White backdrop so transparent PNGs don't turn black when flattened to JPEG.
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, width, height);
    ctx.drawImage(img, 0, 0, width, height);

    // Try progressively lower JPEG quality until it fits under the target.
    let quality = 0.9;
    let blob = await canvasToBlob(canvas, quality);
    while (blob && blob.size > TARGET_MAX_BYTES && quality > 0.4) {
      quality -= 0.12;
      blob = await canvasToBlob(canvas, quality);
    }

    if (!blob) return file; // encoding failed — use original

    // Build a proper File so FormData sends a clean filename + type.
    const newName = file.name.replace(/\.[^.]+$/, "") + ".jpg";
    return new File([blob], newName, { type: "image/jpeg", lastModified: Date.now() });
  } catch {
    // Anything unexpected (e.g. an undecodable format): return the original
    // and let the normal validation/upload path handle it.
    return file;
  } finally {
    URL.revokeObjectURL(objectUrl);
  }
}

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("Could not decode image"));
    img.src = src;
  });
}

function canvasToBlob(canvas: HTMLCanvasElement, quality: number): Promise<Blob | null> {
  return new Promise((resolve) => {
    canvas.toBlob((b) => resolve(b), "image/jpeg", quality);
  });
}
