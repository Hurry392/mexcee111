// src/lib/api.ts
import { AuthUser } from "@/store/authStore";

interface APIResponse<T = unknown> {
  success?: boolean;
  message?: string;
  error?: string;
  user?: AuthUser;
  token?: string;
  data?: T;
  deposit?: unknown;
  withdrawal?: unknown;
  deposits?: unknown[];
  withdrawals?: unknown[];
  messages?: unknown[];
  chatMessage?: unknown;
  submission?: unknown;
  kycStatus?: string;
  isSet?: boolean;
  // ─── Referrals fields ───
  referralCode?: string;
  invitedUsers?: Array<{
    id: string;
    maskedEmail: string;
    username: string | null;
    kycStatus: string;
    isActive: boolean;
    joinedAt: string | Date;
  }>;
  // ─── Trade fields ───
  trade?: unknown;
  trades?: unknown[];
  pnl?: number;
  pnlPercent?: number;
  amountReturned?: number;
  closingFee?: number;
  // ─── Combined stats (works for both referrals AND trades) ───
  stats?: {
    // Referrals stats
    totalInvited?: number;
    activeUsers?: number;
    pendingUsers?: number;
    totalEarnings?: number;
    // Trade stats
    openCount?: number;
    closedCount?: number;
    totalMarginInPositions?: number;
    totalRealizedPnL?: number;
  };
   // ─── Admin fields ───
  admin?: {
    id: string;
    email: string;
    username?: string | null;
    role: string;
  };
  users?: unknown[];
  pagination?: {
    total: number;
    page: number;
    limit: number;
    totalPages: number;
  };
  change?: {
    previousBalance: number;
    newBalance: number;
    amount: number;
  };
  recentUsers?: unknown[];
  recentDeposits?: unknown[];
  pendingCount?: number;
   // ─── Admin KYC ───
  submissions?: unknown[];
  // ─── Admin chat ───
  conversations?: unknown[];
  totalUnread?: number;
  markedAsRead?: number;
   // ─── Notifications ───
  notifications?: unknown[];
  unreadCount?: number;
}

const BASE_URL = "/api";

async function apiCall<T = unknown>(
  endpoint: string,
  options: RequestInit = {}
): Promise<APIResponse<T>> {
  try {
    const response = await fetch(`${BASE_URL}${endpoint}`, {
      ...options,
      credentials: "include",
      headers: {
        "Content-Type": "application/json",
        ...options.headers,
      },
    });

    const data = await response.json();

    if (!response.ok) {
      return { error: data.error || "Request failed" };
    }

    return data;
  } catch (error) {
    console.error("API call failed:", error);
    return { error: "Network error. Please check your connection." };
  }
}

async function apiCallFormData<T = unknown>(
  endpoint: string,
  formData: FormData
): Promise<APIResponse<T>> {
  try {
    const response = await fetch(`${BASE_URL}${endpoint}`, {
      method: "POST",
      credentials: "include",
      body: formData,
    });

    // The response may not be JSON — e.g. a gateway timeout (504) or size
    // limit (413) returns an HTML/text error page. Parsing that as JSON
    // would throw and get masked as a generic "Network error", so read it
    // defensively and surface a useful message instead.
    let data: APIResponse<T> = {};
    try {
      data = await response.json();
    } catch {
      if (response.status === 413) {
        return { error: "Your images are too large. Please use smaller photos and try again." };
      }
      if (response.status === 504 || response.status === 408) {
        return { error: "Upload timed out. Please check your connection and try again." };
      }
      return { error: `Upload failed (server responded ${response.status}). Please try again.` };
    }

    if (!response.ok) {
      return { error: data.error || "Request failed" };
    }

    return data;
  } catch (error) {
    console.error("API call failed:", error);
    return { error: "Network error. Please check your connection." };
  }
}

// ─── Auth API ───
export const authAPI = {
  register: (data: {
    email?: string;
    phone?: string;
    password: string;
    referralCode?: string;
    method: "email" | "phone";
  }) =>
    apiCall("/auth/register", {
      method: "POST",
      body: JSON.stringify(data),
    }),

  login: (data: {
    email?: string;
    phone?: string;
    password: string;
    method: "email" | "phone";
  }) =>
    apiCall("/auth/login", {
      method: "POST",
      body: JSON.stringify(data),
    }),

  logout: () =>
    apiCall("/auth/logout", {
      method: "POST",
    }),

  me: () =>
    apiCall("/auth/me", {
      method: "GET",
    }),
};

// ─── Deposits API ───
export const depositsAPI = {
  create: (formData: FormData) =>
    apiCallFormData("/deposits", formData),

  list: () =>
    apiCall("/deposits", {
      method: "GET",
    }),
};

// ─── Withdrawals API ───
export const withdrawalsAPI = {
  create: (data: {
    amount: number;
    methodId: string;
    methodFields: Record<string, string>;
    withdrawalPassword: string;
  }) =>
    apiCall("/withdrawals", {
      method: "POST",
      body: JSON.stringify(data),
    }),

  list: () =>
    apiCall("/withdrawals", {
      method: "GET",
    }),
};

// ─── Chat API ───
export const chatAPI = {
  getMessages: () =>
    apiCall("/chat", {
      method: "GET",
    }),

  sendMessage: (data: { message: string }) =>
    apiCall("/chat", {
      method: "POST",
      body: JSON.stringify(data),
    }),

  sendMessageWithImage: (formData: FormData) =>
    apiCallFormData("/chat", formData),

  deleteMessage: (messageId: string, type: "forMe" | "forEveryone") =>
    apiCall(`/chat/${messageId}`, {
      method: "PATCH",
      body: JSON.stringify({ type }),
    }),
};

// ─── KYC API ───
export const kycAPI = {
  submit: (formData: FormData) =>
    apiCallFormData("/kyc", formData),

  getStatus: () =>
    apiCall("/kyc", {
      method: "GET",
    }),
};

// ─── Security API ───
export const securityAPI = {
  changePassword: (data: {
    currentPassword: string;
    newPassword: string;
  }) =>
    apiCall("/security/change-password", {
      method: "POST",
      body: JSON.stringify(data),
    }),

  setWithdrawalPassword: (data: {
    accountPassword: string;
    newWithdrawalPassword: string;
    currentWithdrawalPassword?: string;
  }) =>
    apiCall("/security/withdrawal-password", {
      method: "POST",
      body: JSON.stringify(data),
    }),

  checkWithdrawalPassword: () =>
    apiCall("/security/withdrawal-password", {
      method: "GET",
    }),
};

// ─── Referrals API ───
export const referralsAPI = {
  getStats: () =>
    apiCall("/referrals", {
      method: "GET",
    }),
};

// ─── Trades API ───
export const tradesAPI = {
  // Open new trade position
  open: (data: {
    coinId: string;
    coinSymbol: string;
    side: "BUY" | "SELL";
    orderType: "MARKET" | "LIMIT";
    leverage: number;
    marginAmount: number;
    entryPrice: number;
  }) =>
    apiCall("/trades", {
      method: "POST",
      body: JSON.stringify(data),
    }),

  // Close an open trade
  close: (data: { tradeId: string; exitPrice: number }) =>
    apiCall("/trades/close", {
      method: "POST",
      body: JSON.stringify(data),
    }),

  // Fetch trades (optional filter)
  list: (status?: "OPEN" | "CLOSED") => {
    const query = status ? `?status=${status}` : "";
    return apiCall(`/trades${query}`, {
      method: "GET",
    });
  },
};

// ─── Notifications API ───
export const notificationsAPI = {
  list: (params?: { unreadOnly?: boolean; limit?: number }) => {
    const query = new URLSearchParams();
    if (params?.unreadOnly) query.set("unreadOnly", "true");
    if (params?.limit) query.set("limit", String(params.limit));
    const queryStr = query.toString() ? `?${query.toString()}` : "";
    return apiCall(`/notifications${queryStr}`, { method: "GET" });
  },

  markAsRead: (id: string) =>
    apiCall(`/notifications/${id}/read`, { method: "PATCH" }),

  markAllAsRead: () =>
    apiCall(`/notifications/read-all`, { method: "PATCH" }),
};

// ─── Admin API ───
export const adminAPI = {
  // Auth
  login: (data: { email: string; password: string }) =>
    apiCall("/admin/login", {
      method: "POST",
      body: JSON.stringify(data),
    }),

  logout: () =>
    apiCall("/admin/logout", {
      method: "POST",
    }),

  me: () =>
    apiCall("/admin/me", {
      method: "GET",
    }),

  // Dashboard stats
  getStats: () =>
    apiCall("/admin/stats", {
      method: "GET",
    }),

  // Users
  listUsers: (params?: {
    search?: string;
    kyc?: string;
    status?: string;
    role?: string;
    page?: number;
    limit?: number;
  }) => {
    const query = new URLSearchParams();
    if (params?.search) query.set("search", params.search);
    if (params?.kyc) query.set("kyc", params.kyc);
    if (params?.status) query.set("status", params.status);
    if (params?.role) query.set("role", params.role);
    if (params?.page) query.set("page", String(params.page));
    if (params?.limit) query.set("limit", String(params.limit));

    const queryStr = query.toString() ? `?${query.toString()}` : "";
    return apiCall(`/admin/users${queryStr}`, {
      method: "GET",
    });
  },

  getUser: (id: string) =>
    apiCall(`/admin/users/${id}`, {
      method: "GET",
    }),

  updateUser: (id: string, data: { action: string; note?: string }) =>
    apiCall(`/admin/users/${id}`, {
      method: "PATCH",
      body: JSON.stringify(data),
    }),

  resetPassword: (
    id: string,
    data: { newPassword?: string; note?: string } = {}
  ) =>
    apiCall(`/admin/users/${id}/reset-password`, {
      method: "POST",
      body: JSON.stringify(data),
    }),

  resetWithdrawalPassword: (
    id: string,
    data: { newPassword?: string; clear?: boolean; note?: string } = {}
  ) =>
    apiCall(`/admin/users/${id}/reset-withdrawal-password`, {
      method: "POST",
      body: JSON.stringify(data),
    }),

  deleteUser: (id: string) =>
    apiCall(`/admin/users/${id}`, {
      method: "DELETE",
    }),

  updateBalance: (
    id: string,
    data: { action: "ADD" | "DEDUCT"; amount: number; note?: string }
  ) =>
    apiCall(`/admin/users/${id}/balance`, {
      method: "POST",
      body: JSON.stringify(data),
    }),

      // ─── Deposits ───
  listDeposits: (params?: {
    status?: string;
    search?: string;
    page?: number;
    limit?: number;
  }) => {
    const query = new URLSearchParams();
    if (params?.status) query.set("status", params.status);
    if (params?.search) query.set("search", params.search);
    if (params?.page) query.set("page", String(params.page));
    if (params?.limit) query.set("limit", String(params.limit));

    const queryStr = query.toString() ? `?${query.toString()}` : "";
    return apiCall(`/admin/deposits${queryStr}`, { method: "GET" });
  },

  processDeposit: (
    id: string,
    data: { action: "APPROVE" | "REJECT"; note?: string }
  ) =>
    apiCall(`/admin/deposits/${id}`, {
      method: "PATCH",
      body: JSON.stringify(data),
    }),

  // ─── Withdrawals ───
  listWithdrawals: (params?: {
    status?: string;
    method?: string;
    search?: string;
    page?: number;
    limit?: number;
  }) => {
    const query = new URLSearchParams();
    if (params?.status) query.set("status", params.status);
    if (params?.method) query.set("method", params.method);
    if (params?.search) query.set("search", params.search);
    if (params?.page) query.set("page", String(params.page));
    if (params?.limit) query.set("limit", String(params.limit));

    const queryStr = query.toString() ? `?${query.toString()}` : "";
    return apiCall(`/admin/withdrawals${queryStr}`, { method: "GET" });
  },

  processWithdrawal: (
    id: string,
    data: {
      action: "APPROVE" | "REJECT" | "COMPLETE";
      note?: string;
      txId?: string;
    }
  ) =>
    apiCall(`/admin/withdrawals/${id}`, {
      method: "PATCH",
      body: JSON.stringify(data),
    }),

      // ─── KYC ───
  listKyc: (params?: {
    status?: string;
    documentType?: string;
    search?: string;
    page?: number;
    limit?: number;
  }) => {
    const query = new URLSearchParams();
    if (params?.status) query.set("status", params.status);
    if (params?.documentType) query.set("documentType", params.documentType);
    if (params?.search) query.set("search", params.search);
    if (params?.page) query.set("page", String(params.page));
    if (params?.limit) query.set("limit", String(params.limit));

    const queryStr = query.toString() ? `?${query.toString()}` : "";
    return apiCall(`/admin/kyc${queryStr}`, { method: "GET" });
  },

  processKyc: (
    id: string,
    data: { action: "APPROVE" | "REJECT"; rejectionReason?: string }
  ) =>
    apiCall(`/admin/kyc/${id}`, {
      method: "PATCH",
      body: JSON.stringify(data),
    }),

      // ─── Chat ───
  listConversations: (params?: { search?: string }) => {
    const query = new URLSearchParams();
    if (params?.search) query.set("search", params.search);
    const queryStr = query.toString() ? `?${query.toString()}` : "";
    return apiCall(`/admin/chat/conversations${queryStr}`, { method: "GET" });
  },

  getConversation: (userId: string) =>
    apiCall(`/admin/chat/${userId}`, { method: "GET" }),

  sendChatReply: (userId: string, data: { message: string }) =>
    apiCall(`/admin/chat/${userId}`, {
      method: "POST",
      body: JSON.stringify(data),
    }),

  sendChatReplyWithImage: (userId: string, formData: FormData) =>
    apiCallFormData(`/admin/chat/${userId}`, formData),

  markConversationRead: (userId: string) =>
    apiCall(`/admin/chat/${userId}/read`, { method: "PATCH" }),

  deleteChatMessage: (
    userId: string,
    messageId: string,
    action: "DELETE_FOR_ME" | "DELETE_FOR_EVERYONE"
  ) =>
    apiCall(`/admin/chat/${userId}/${messageId}`, {
      method: "PATCH",
      body: JSON.stringify({ action }),
    }),

  editChatMessage: (userId: string, messageId: string, newMessage: string) =>
    apiCall(`/admin/chat/${userId}/${messageId}`, {
      method: "PATCH",
      body: JSON.stringify({ action: "EDIT", newMessage }),
    }),

    // ─── Trades ───
  listTrades: (params?: {
    status?: string;
    side?: string;
    coin?: string;
    search?: string;
    page?: number;
    limit?: number;
  }) => {
    const query = new URLSearchParams();
    if (params?.status) query.set("status", params.status);
    if (params?.side) query.set("side", params.side);
    if (params?.coin) query.set("coin", params.coin);
    if (params?.search) query.set("search", params.search);
    if (params?.page) query.set("page", String(params.page));
    if (params?.limit) query.set("limit", String(params.limit));
    const queryStr = query.toString() ? `?${query.toString()}` : "";
    return apiCall(`/admin/trades${queryStr}`, { method: "GET" });
  },

  setTradeResult: (id: string, data: { exitPrice?: number; profitPercent?: number; clear?: boolean; note?: string }) =>
    apiCall(`/admin/trades/${id}/set-result`, {
      method: "PATCH",
      body: JSON.stringify(data),
    }),

  // ─── Settings ───
  getSettings: () =>
    apiCall("/admin/settings", { method: "GET" }),

  updateSettings: (settings: Record<string, string>) =>
    apiCall("/admin/settings", {
      method: "POST",
      body: JSON.stringify({ settings }),
    }),

  // ─── Session management ───
  /** Revoke every active session for this admin (all devices) and clear the cookie. */
  logoutAll: () =>
    apiCall("/admin/logout-all", { method: "POST" }),

  // ─── Password management ───
  /** Change the currently-logged-in admin's own password. */
  changePassword: (data: {
    currentPassword: string;
    newPassword: string;
    confirmPassword: string;
  }) =>
    apiCall("/admin/change-password", {
      method: "POST",
      body: JSON.stringify(data),
    }),
};