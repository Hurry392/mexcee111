// src/lib/upload.ts
import { v2 as cloudinary } from "cloudinary";

// ─── Configure Cloudinary (runs once on server startup) ───
cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
  secure: true, // Always use HTTPS URLs
});

/**
 * Upload a file to Cloudinary
 * @param file — File object from FormData
 * @param subfolder — "deposits" | "kyc" | "chat"
 * @returns Cloudinary URL to access the uploaded image
 */
export async function saveUploadedFile(
  file: File,
  subfolder: "deposits" | "kyc" | "chat"
): Promise<string> {
  // Convert File to Buffer
  const bytes = await file.arrayBuffer();
  const buffer = Buffer.from(bytes);

  // Convert buffer to base64 data URI (Cloudinary accepts this)
  const base64 = buffer.toString("base64");
  const dataUri = `data:${file.type};base64,${base64}`;

  // Generate unique public_id (just the filename, no folder path)
  const timestamp = Date.now();
  const randomStr = Math.random().toString(36).substring(2, 8);
  const publicId = `${timestamp}_${randomStr}`;


  try {
    // Upload to Cloudinary with proper folder nesting
    const result = await cloudinary.uploader.upload(dataUri, {
      public_id: publicId,
      folder: `mexc-trade/${subfolder}`, // ← FIXED: proper nested folder
      resource_type: "image",
      overwrite: false,
      // Auto-optimize images. Cap dimensions — KYC docs are reviewed by
      // eye, not pixel-peeped, so 1600px is plenty and keeps uploads fast.
      transformation: [
        { width: 1600, height: 1600, crop: "limit" },
        { quality: "auto:good" },
        { fetch_format: "auto" },
      ],
    });

    // Return the secure HTTPS URL
    return result.secure_url;
  } catch (error) {
    console.error("Cloudinary upload error:", error);
    throw new Error("Failed to upload image. Please try again.");
  }
}

/**
 * Validate file before upload
 */
export function validateFile(
  file: File,
  options: { maxSizeMB?: number; allowedTypes?: string[] } = {}
): { valid: boolean; error?: string } {
  const {
    maxSizeMB = 5,
    allowedTypes = ["image/jpeg", "image/png", "image/jpg", "image/webp"],
  } = options;

  if (file.size > maxSizeMB * 1024 * 1024) {
    return { valid: false, error: `File size must be less than ${maxSizeMB}MB` };
  }

  if (!allowedTypes.includes(file.type)) {
    return { valid: false, error: "Invalid file type. Only images allowed." };
  }

  return { valid: true };
}

/**
 * Delete a file from Cloudinary (for admin panel later)
 * @param imageUrl — Full Cloudinary URL
 */
export async function deleteUploadedFile(imageUrl: string): Promise<void> {
  try {
    // Extract public_id from URL
    const urlParts = imageUrl.split("/upload/");
    if (urlParts.length !== 2) return;

    const pathWithVersion = urlParts[1];
    const publicId = pathWithVersion
      .replace(/^v\d+\//, "")
      .replace(/\.[^.]+$/, "");

    await cloudinary.uploader.destroy(publicId);
  } catch (error) {
    console.error("Cloudinary delete error:", error);
  }
}
