// src/lib/markets.ts

// ============================================================
// TYPES
// ============================================================

export interface MarketCoin {
  id: string;
  symbol: string;
  name: string;
  image: string;
  current_price: number;
  market_cap: number;
  market_cap_rank: number;
  total_volume: number;
  high_24h: number;
  low_24h: number;
  price_change_24h: number;
  price_change_percentage_24h: number;
  last_updated: string;
}

export interface MarketChartData {
  prices: [number, number][];
  market_caps: [number, number][];
  total_volumes: [number, number][];
}

// ============================================================
// STATIC COIN METADATA
// Keeps name / image / rank without a runtime API call.
// coinpaprikaId  → CoinPaprika API (primary market-data source)
// kucoinSymbol   → KuCoin API     (primary kline / chart source)
// ============================================================

interface StaticCoinMeta {
  id: string;               // CoinGecko ID (used by WebSocket mapping)
  symbol: string;           // e.g. "BTC"
  name: string;
  image: string;
  market_cap_rank: number;
  circulating_supply: number;
  coinpaprikaId: string;    // e.g. "btc-bitcoin"
  kucoinSymbol: string;     // e.g. "BTC-USDT"
}

/** Keyed by Binance WebSocket symbol (BTCUSDT) — used for WS stream mapping only */
const COIN_META: Record<string, StaticCoinMeta> = {
  BTCUSDT: {
    id: "bitcoin", symbol: "BTC", name: "Bitcoin",
    image: "https://assets.coingecko.com/coins/images/1/large/bitcoin.png",
    market_cap_rank: 1, circulating_supply: 19_700_000,
    coinpaprikaId: "btc-bitcoin", kucoinSymbol: "BTC-USDT",
  },
  ETHUSDT: {
    id: "ethereum", symbol: "ETH", name: "Ethereum",
    image: "https://assets.coingecko.com/coins/images/279/large/ethereum.png",
    market_cap_rank: 2, circulating_supply: 120_300_000,
    coinpaprikaId: "eth-ethereum", kucoinSymbol: "ETH-USDT",
  },
  USDCUSDT: {
    // Tether has no USDT/USDT pair; USDC/USDT ≈ $1 is the proxy
    id: "tether", symbol: "USDT", name: "Tether",
    image: "https://assets.coingecko.com/coins/images/325/large/Tether.png",
    market_cap_rank: 3, circulating_supply: 118_000_000_000,
    coinpaprikaId: "usdt-tether", kucoinSymbol: "USDC-USDT",
  },
  BNBUSDT: {
    id: "binancecoin", symbol: "BNB", name: "BNB",
    image: "https://assets.coingecko.com/coins/images/825/large/bnb-icon2_2x.png",
    market_cap_rank: 4, circulating_supply: 153_000_000,
    coinpaprikaId: "bnb-binance-coin", kucoinSymbol: "BNB-USDT",
  },
  SOLUSDT: {
    id: "solana", symbol: "SOL", name: "Solana",
    image: "https://assets.coingecko.com/coins/images/4128/large/solana.png",
    market_cap_rank: 5, circulating_supply: 430_000_000,
    coinpaprikaId: "sol-solana", kucoinSymbol: "SOL-USDT",
  },
  XRPUSDT: {
    id: "ripple", symbol: "XRP", name: "XRP",
    image: "https://assets.coingecko.com/coins/images/44/large/xrp-symbol-white-128.png",
    market_cap_rank: 6, circulating_supply: 55_000_000_000,
    coinpaprikaId: "xrp-xrp", kucoinSymbol: "XRP-USDT",
  },
  ADAUSDT: {
    id: "cardano", symbol: "ADA", name: "Cardano",
    image: "https://assets.coingecko.com/coins/images/975/large/cardano.png",
    market_cap_rank: 8, circulating_supply: 35_000_000_000,
    coinpaprikaId: "ada-cardano", kucoinSymbol: "ADA-USDT",
  },
  DOGEUSDT: {
    id: "dogecoin", symbol: "DOGE", name: "Dogecoin",
    image: "https://assets.coingecko.com/coins/images/5/large/dogecoin.png",
    market_cap_rank: 9, circulating_supply: 144_000_000_000,
    coinpaprikaId: "doge-dogecoin", kucoinSymbol: "DOGE-USDT",
  },
  AVAXUSDT: {
    id: "avalanche-2", symbol: "AVAX", name: "Avalanche",
    image: "https://assets.coingecko.com/coins/images/12559/large/Avalanche_Circle_RedWhite_Trans.png",
    market_cap_rank: 11, circulating_supply: 400_000_000,
    coinpaprikaId: "avax-avalanche", kucoinSymbol: "AVAX-USDT",
  },
  TRXUSDT: {
    id: "tron", symbol: "TRX", name: "TRON",
    image: "https://assets.coingecko.com/coins/images/1094/large/tron-logo.png",
    market_cap_rank: 10, circulating_supply: 86_000_000_000,
    coinpaprikaId: "trx-tron", kucoinSymbol: "TRX-USDT",
  },
  DOTUSDT: {
    id: "polkadot", symbol: "DOT", name: "Polkadot",
    image: "https://assets.coingecko.com/coins/images/12171/large/polkadot.png",
    market_cap_rank: 20, circulating_supply: 1_400_000_000,
    coinpaprikaId: "dot-polkadot", kucoinSymbol: "DOT-USDT",
  },
  LINKUSDT: {
    id: "chainlink", symbol: "LINK", name: "Chainlink",
    image: "https://assets.coingecko.com/coins/images/877/large/chainlink-new-logo.png",
    market_cap_rank: 15, circulating_supply: 600_000_000,
    coinpaprikaId: "link-chainlink", kucoinSymbol: "LINK-USDT",
  },
};

// ─── Top coins to fetch (CoinGecko IDs) ───
export const SUPPORTED_COIN_IDS = [
  "bitcoin", "ethereum", "tether", "binancecoin", "solana",
  "ripple", "cardano", "dogecoin", "avalanche-2", "tron",
  "polkadot", "chainlink",
];

// Map our internal symbols to CoinGecko IDs
export const SYMBOL_TO_ID: Record<string, string> = {
  BTC: "bitcoin", ETH: "ethereum", USDT: "tether", BNB: "binancecoin",
  SOL: "solana", XRP: "ripple", ADA: "cardano", DOGE: "dogecoin",
  AVAX: "avalanche-2", TRX: "tron", DOT: "polkadot", LINK: "chainlink",
};

// ============================================================
// COINPAPRIKA — PRIMARY MARKET DATA SOURCE
// Free, no API key, works from all cloud regions (including Vercel US).
// ============================================================

interface CoinPaprikaTicker {
  id: string;
  name: string;
  symbol: string;
  rank: number;
  circulating_supply: number;
  last_updated: string;
  quotes: {
    USD: {
      price: number;
      volume_24h: number;
      market_cap: number;
      percent_change_24h: number;
    };
  };
}

/** Fetch all tickers from CoinPaprika and map to our MarketCoin shape. */
async function fetchFromCoinPaprika(): Promise<MarketCoin[]> {
  const url = "https://api.coinpaprika.com/v1/tickers?quotes=USD";

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 10_000);

  try {
    const res = await fetch(url, {
      headers: { Accept: "application/json" },
      signal: controller.signal,
    });
    if (!res.ok) {
      const body = await res.text().catch(() => "");
      throw new Error(`CoinPaprika HTTP ${res.status}: ${body.slice(0, 120)}`);
    }

    const tickers: CoinPaprikaTicker[] = await res.json();

    // Build a fast lookup: coinpaprikaId → ticker
    const byId: Record<string, CoinPaprikaTicker> = {};
    for (const t of tickers) byId[t.id] = t;

    const results: MarketCoin[] = [];

    for (const meta of Object.values(COIN_META)) {
      const t = byId[meta.coinpaprikaId];
      if (!t?.quotes?.USD) continue;

      const usd = t.quotes.USD;
      const price = usd.price ?? 0;
      const pct   = usd.percent_change_24h ?? 0;

      // CoinPaprika doesn't expose 24h high/low.
      // Estimate from price + % change — Binance WebSocket will overwrite
      // these on the client within seconds of page load.
      const prevPrice = price / (1 + pct / 100);
      const high_24h  = Math.max(price, prevPrice);
      const low_24h   = Math.min(price, prevPrice);

      results.push({
        id:                        meta.id,
        symbol:                    meta.symbol.toLowerCase(),
        name:                      meta.name,
        image:                     meta.image,
        current_price:             price,
        market_cap:                usd.market_cap ?? price * meta.circulating_supply,
        market_cap_rank:           t.rank ?? meta.market_cap_rank,
        total_volume:              usd.volume_24h ?? 0,
        high_24h,
        low_24h,
        price_change_24h:          price - prevPrice,
        price_change_percentage_24h: pct,
        last_updated:              t.last_updated ?? new Date().toISOString(),
      });
    }

    return results.sort((a, b) => a.market_cap_rank - b.market_cap_rank);
  } finally {
    clearTimeout(timer);
  }
}

// ============================================================
// COINGECKO — FALLBACK MARKET DATA SOURCE
// ============================================================

const COINGECKO_BASE = "https://api.coingecko.com/api/v3";

/** Fetch markets from CoinGecko (optionally authenticated with COINGECKO_API_KEY). */
async function fetchFromCoinGecko(): Promise<MarketCoin[]> {
  const ids = SUPPORTED_COIN_IDS.join(",");
  const url =
    `${COINGECKO_BASE}/coins/markets?vs_currency=usd&ids=${ids}` +
    `&order=market_cap_desc&per_page=20&page=1&sparkline=false&price_change_percentage=24h`;

  const headers: Record<string, string> = {
    Accept: "application/json",
    "User-Agent": "MexcTradeApp/1.0",
  };

  const apiKey = process.env.COINGECKO_API_KEY;
  if (apiKey) headers["x-cg-demo-api-key"] = apiKey;

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 10_000);

  try {
    const res = await fetch(url, { headers, signal: controller.signal });
    if (!res.ok) {
      const body = await res.text().catch(() => "");
      throw new Error(`CoinGecko HTTP ${res.status}: ${body.slice(0, 120)}`);
    }
    return await res.json() as MarketCoin[];
  } finally {
    clearTimeout(timer);
  }
}

// ============================================================
// SERVER-SIDE CACHE  (module-level, survives warm Lambda)
// ============================================================

let _cache: { data: MarketCoin[]; ts: number } | null = null;
const CACHE_TTL = 60_000; // 60 s

/**
 * Fetch top markets.
 * 1️⃣  CoinPaprika  (free, no key, works from Vercel US)
 * 2️⃣  CoinGecko    (optional COINGECKO_API_KEY env var)
 * 3️⃣  Stale cache  (better than empty on all-source failure)
 */
export async function fetchMarkets(): Promise<MarketCoin[]> {
  if (_cache && Date.now() - _cache.ts < CACHE_TTL) return _cache.data;

  try {
    const markets = await fetchFromCoinPaprika();
    if (markets.length > 0) {
      _cache = { data: markets, ts: Date.now() };
      return markets;
    }
  } catch (err) {
    console.warn("CoinPaprika failed, trying CoinGecko:", err instanceof Error ? err.message : err);
  }

  try {
    const markets = await fetchFromCoinGecko();
    if (markets.length > 0) {
      _cache = { data: markets, ts: Date.now() };
      return markets;
    }
  } catch (err) {
    console.warn("CoinGecko failed:", err instanceof Error ? err.message : err);
  }

  if (_cache) {
    console.warn("All market sources failed — returning stale cache");
    return _cache.data;
  }

  return [];
}

// ============================================================
// FORMAT HELPERS
// ============================================================

export function formatPrice(price: number): string {
  if (price >= 1000)  return price.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  if (price >= 1)     return price.toFixed(2);
  if (price >= 0.01)  return price.toFixed(4);
  return price.toFixed(6);
}

export function formatLargeNumber(num: number): string {
  if (num >= 1_000_000_000) return `${(num / 1_000_000_000).toFixed(2)}B`;
  if (num >= 1_000_000)     return `${(num / 1_000_000).toFixed(2)}M`;
  if (num >= 1_000)         return `${(num / 1_000).toFixed(2)}K`;
  return num.toFixed(2);
}

export function formatPercent(percent: number): string {
  const sign = percent >= 0 ? "+" : "";
  return `${sign}${percent.toFixed(2)}%`;
}

// ============================================================
// CHART DATA TYPES
// ============================================================

export interface CandlestickData {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
}

/** Convert CoinGecko price history to candlestick format */
export function pricesToCandlesticks(
  prices: [number, number][],
  intervalMinutes: number = 60
): CandlestickData[] {
  if (prices.length === 0) return [];

  const candles: CandlestickData[] = [];
  const intervalMs = intervalMinutes * 60 * 1000;
  let currentBucket: { time: number; prices: number[] } | null = null;

  for (const [timestamp, price] of prices) {
    const bucketTime = Math.floor(timestamp / intervalMs) * intervalMs;
    if (!currentBucket || currentBucket.time !== bucketTime) {
      if (currentBucket) candles.push(bucketToCandle(currentBucket));
      currentBucket = { time: bucketTime, prices: [price] };
    } else {
      currentBucket.prices.push(price);
    }
  }
  if (currentBucket) candles.push(bucketToCandle(currentBucket));
  return candles;
}

function bucketToCandle(bucket: { time: number; prices: number[] }): CandlestickData {
  const p = bucket.prices;
  return {
    time:  Math.floor(bucket.time / 1000),
    open:  p[0],
    high:  Math.max(...p),
    low:   Math.min(...p),
    close: p[p.length - 1],
  };
}

// ============================================================
// KUCOIN KLINES — PRIMARY CHART DATA SOURCE
// Free, no API key, works from Vercel US.
// KuCoin candle format: [time, open, close, high, low, volume, turnover]
// ============================================================

function getKuCoinInterval(days: number): { type: string; limit: number } {
  if (days <= 1)  return { type: "15min", limit: 96  };
  if (days <= 7)  return { type: "1hour", limit: 168 };
  if (days <= 30) return { type: "4hour", limit: 180 };
  return               { type: "1day",  limit: 90  };
}

async function fetchFromKuCoin(kucoinSymbol: string, days: number): Promise<CandlestickData[]> {
  const { type, limit } = getKuCoinInterval(days);
  const endAt   = Math.floor(Date.now() / 1000);
  const startAt = endAt - days * 24 * 3600;

  const url =
    `https://api.kucoin.com/api/v1/market/candles` +
    `?type=${type}&symbol=${kucoinSymbol}&startAt=${startAt}&endAt=${endAt}`;

  const res = await fetch(url, { next: { revalidate: 30 } });
  if (!res.ok) throw new Error(`KuCoin klines HTTP ${res.status}`);

  const json: { code: string; data: string[][] } = await res.json();
  if (!json.data?.length) return [];

  // KuCoin returns newest-first; reverse so oldest candle comes first
  const candles: CandlestickData[] = json.data
    .map((k) => ({
      time:  parseInt(k[0]),
      open:  parseFloat(k[1]),
      high:  parseFloat(k[3]),
      low:   parseFloat(k[4]),
      close: parseFloat(k[2]),
    }))
    .reverse()
    .slice(-limit);

  return candles;
}

// ============================================================
// BINANCE KLINES — FALLBACK (may be blocked from some regions)
// ============================================================

export function getBinanceInterval(days: number): { interval: string; limit: number } {
  if (days <= 1)  return { interval: "15m", limit: 96  };
  if (days <= 7)  return { interval: "1h",  limit: 168 };
  if (days <= 30) return { interval: "4h",  limit: 180 };
  return               { interval: "1d",  limit: 90  };
}

/**
 * Fetch candlestick data.
 * 1️⃣  KuCoin  (primary — no key, no geo-block)
 * 2️⃣  Binance (fallback — may be blocked from US cloud IPs)
 * 3️⃣  CoinGecko OHLC (last resort)
 */
export async function fetchBinanceKlines(binanceSymbol: string, days: number = 1): Promise<CandlestickData[]> {
  const meta = COIN_META[binanceSymbol];

  // 1️⃣  KuCoin
  if (meta?.kucoinSymbol) {
    try {
      const candles = await fetchFromKuCoin(meta.kucoinSymbol, days);
      if (candles.length > 0) return candles;
    } catch (err) {
      console.warn(`KuCoin klines failed for ${binanceSymbol}:`, err instanceof Error ? err.message : err);
    }
  }

  // 2️⃣  Binance
  try {
    const { interval, limit } = getBinanceInterval(days);
    const url = `https://api.binance.com/api/v3/klines?symbol=${binanceSymbol}&interval=${interval}&limit=${limit}`;
    const res = await fetch(url, { next: { revalidate: 30 } });
    if (res.ok) {
      const data: Array<Array<string | number>> = await res.json();
      if (data.length > 0) {
        return data.map((k) => ({
          time:  Math.floor(Number(k[0]) / 1000),
          open:  parseFloat(String(k[1])),
          high:  parseFloat(String(k[2])),
          low:   parseFloat(String(k[3])),
          close: parseFloat(String(k[4])),
        }));
      }
    }
  } catch (err) {
    console.warn(`Binance klines failed for ${binanceSymbol}:`, err instanceof Error ? err.message : err);
  }

  // 3️⃣  CoinGecko OHLC
  if (meta?.id) {
    try {
      const candles = await fetchOHLC(meta.id, days);
      if (candles.length > 0) return candles;
    } catch { /* ignore */ }
  }

  return [];
}

export function getKlineStreamName(binanceSymbol: string, interval: string): string {
  return `${binanceSymbol.toLowerCase()}@kline_${interval}`;
}

// ============================================================
// COINGECKO OHLC — used as chart last resort
// ============================================================

/** Fetch OHLC from CoinGecko (uses COINGECKO_API_KEY env var if set). */
export async function fetchOHLC(coinId: string, days: number = 1): Promise<CandlestickData[]> {
  try {
    const headers: Record<string, string> = { Accept: "application/json" };
    const apiKey = process.env.COINGECKO_API_KEY;
    if (apiKey) headers["x-cg-demo-api-key"] = apiKey;

    const res = await fetch(
      `${COINGECKO_BASE}/coins/${coinId}/ohlc?vs_currency=usd&days=${days}`,
      { next: { revalidate: 60 }, headers }
    );
    if (!res.ok) return [];
    const data: [number, number, number, number, number][] = await res.json();
    return data.map(([time, open, high, low, close]) => ({
      time: Math.floor(time / 1000), open, high, low, close,
    }));
  } catch (err) {
    console.error("fetchOHLC error:", err);
    return [];
  }
}

/** Fetch coin market chart (used by some components). */
export async function fetchCoinChart(coinId: string, days: string = "1"): Promise<MarketChartData | null> {
  try {
    const headers: Record<string, string> = { Accept: "application/json" };
    const apiKey = process.env.COINGECKO_API_KEY;
    if (apiKey) headers["x-cg-demo-api-key"] = apiKey;

    const res = await fetch(
      `${COINGECKO_BASE}/coins/${coinId}/market_chart?vs_currency=usd&days=${days}`,
      { next: { revalidate: 60 }, headers }
    );
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  }
}

// ============================================================
// BINANCE WEBSOCKET CONFIGURATION  (client-side — always works)
// ============================================================

/** Map CoinGecko IDs to Binance WebSocket symbols */
export const COINGECKO_TO_BINANCE: Record<string, string> = {
  bitcoin:       "BTCUSDT",
  ethereum:      "ETHUSDT",
  tether:        "USDCUSDT",
  binancecoin:   "BNBUSDT",
  solana:        "SOLUSDT",
  ripple:        "XRPUSDT",
  cardano:       "ADAUSDT",
  dogecoin:      "DOGEUSDT",
  "avalanche-2": "AVAXUSDT",
  tron:          "TRXUSDT",
  polkadot:      "DOTUSDT",
  chainlink:     "LINKUSDT",
};

export const BINANCE_TO_COINGECKO: Record<string, string> = Object.fromEntries(
  Object.entries(COINGECKO_TO_BINANCE).map(([k, v]) => [v, k])
);

export function getBinanceSymbol(coingeckoId: string): string | null {
  return COINGECKO_TO_BINANCE[coingeckoId] || null;
}

export function getCoinGeckoId(binanceSymbol: string): string | null {
  return BINANCE_TO_COINGECKO[binanceSymbol] || null;
}

// ============================================================
// SERVER-SIDE PRICE VERIFICATION  (security-critical for trade API)
// ============================================================

/**
 * Fetch current live price for a coin, server-side.
 * Used to validate client-supplied prices before executing trades.
 *
 * 1️⃣  CoinPaprika  (free, no key, works from Vercel US)
 * 2️⃣  KuCoin level-1 orderbook
 * 3️⃣  CoinGecko simple price (with optional key)
 */
export async function fetchLivePrice(binanceSymbol: string): Promise<number | null> {
  const meta = COIN_META[binanceSymbol];
  if (!meta) return null;

  // 1️⃣  CoinPaprika
  try {
    const res = await fetch(
      `https://api.coinpaprika.com/v1/tickers/${meta.coinpaprikaId}?quotes=USD`,
      { cache: "no-store", headers: { Accept: "application/json" } }
    );
    if (res.ok) {
      const data: CoinPaprikaTicker = await res.json();
      const price = data?.quotes?.USD?.price;
      if (Number.isFinite(price) && price > 0) return price;
    }
  } catch (err) {
    console.warn("CoinPaprika live price failed:", err instanceof Error ? err.message : err);
  }

  // 2️⃣  KuCoin level-1 orderbook
  if (meta.kucoinSymbol) {
    try {
      const res = await fetch(
        `https://api.kucoin.com/api/v1/market/orderbook/level1?symbol=${meta.kucoinSymbol}`,
        { cache: "no-store" }
      );
      if (res.ok) {
        const json: { code: string; data?: { price?: string } } = await res.json();
        const price = parseFloat(json.data?.price ?? "");
        if (Number.isFinite(price) && price > 0) return price;
      }
    } catch (err) {
      console.warn("KuCoin live price failed:", err instanceof Error ? err.message : err);
    }
  }

  // 3️⃣  CoinGecko simple price
  try {
    const headers: Record<string, string> = { Accept: "application/json" };
    const apiKey = process.env.COINGECKO_API_KEY;
    if (apiKey) headers["x-cg-demo-api-key"] = apiKey;

    const res = await fetch(
      `${COINGECKO_BASE}/simple/price?ids=${meta.id}&vs_currencies=usd`,
      { cache: "no-store", headers }
    );
    if (res.ok) {
      const data: Record<string, { usd?: number }> = await res.json();
      const price = data?.[meta.id]?.usd;
      return Number.isFinite(price) && (price as number) > 0 ? (price as number) : null;
    }
  } catch (err) {
    console.warn("CoinGecko live price failed:", err instanceof Error ? err.message : err);
  }

  return null;
}

/** Max allowed deviation between client-shown price and live server price (2%). */
export const PRICE_TOLERANCE_PERCENT = 2;

export function isPriceWithinTolerance(clientPrice: number, livePrice: number): boolean {
  if (!Number.isFinite(clientPrice) || clientPrice <= 0) return false;
  const deviation = Math.abs(clientPrice - livePrice) / livePrice;
  return deviation <= PRICE_TOLERANCE_PERCENT / 100;
}
