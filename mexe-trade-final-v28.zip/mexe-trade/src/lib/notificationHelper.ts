// src/lib/notificationHelper.ts
import { prisma } from "@/lib/prisma";

export type NotificationType = "DEPOSIT" | "WITHDRAWAL" | "KYC" | "CHAT" | "TRADE" | "SYSTEM";

interface CreateNotificationInput {
  userId: string;
  title: string;
  message: string;
  type: NotificationType;
  actionUrl?: string;
  relatedId?: string;
}

/**
 * Create an in-app notification for a user.
 * Silent failure — never throws (so it doesn't break main flow).
 */
export async function createNotification(input: CreateNotificationInput): Promise<void> {
  try {
    await prisma.notification.create({
      data: {
        userId: input.userId,
        title: input.title,
        message: input.message,
        type: input.type,
        actionUrl: input.actionUrl,
        relatedId: input.relatedId,
        isRead: false,
      },
    });
  } catch (err) {
    console.error("Failed to create notification:", err);
  }
}

/**
 * Preset notification builders for common events.
 */
export const NotificationTemplates = {
  withdrawalsFrozen: (userId: string, reason: string) => ({
    userId,
    title: "Withdrawals Suspended ⚠️",
    message: `Your withdrawals have been temporarily suspended due to a Terms of Service review. Reason: ${reason}. Please contact support if you believe this is a mistake.`,
    type: "SYSTEM" as const,
    actionUrl: "/funds?tab=withdraw",
  }),

  withdrawalsUnfrozen: (userId: string) => ({
    userId,
    title: "Withdrawals Re-enabled ✅",
    message: "The hold on your withdrawals has been lifted. You can now withdraw funds normally.",
    type: "SYSTEM" as const,
    actionUrl: "/funds?tab=withdraw",
  }),

  depositApproved: (userId: string, amount: number, depositId: string) => ({
    userId,
    title: "Deposit Approved ✅",
    message: `Your deposit of $${amount.toFixed(2)} USDT has been approved and credited to your balance.`,
    type: "DEPOSIT" as const,
    actionUrl: "/records",
    relatedId: depositId,
  }),

  depositRejected: (userId: string, amount: number, depositId: string, reason?: string) => ({
    userId,
    title: "Deposit Rejected ❌",
    message: reason
      ? `Your deposit of $${amount.toFixed(2)} was rejected. Reason: ${reason}`
      : `Your deposit of $${amount.toFixed(2)} was rejected. Please contact support.`,
    type: "DEPOSIT" as const,
    actionUrl: "/records",
    relatedId: depositId,
  }),

  withdrawalApproved: (userId: string, amount: number, withdrawalId: string) => ({
    userId,
    title: "Withdrawal Approved ✅",
    message: `Your withdrawal of $${amount.toFixed(2)} has been approved and will be processed shortly.`,
    type: "WITHDRAWAL" as const,
    actionUrl: "/records",
    relatedId: withdrawalId,
  }),

  withdrawalCompleted: (userId: string, amount: number, withdrawalId: string, txId?: string) => ({
    userId,
    title: "Withdrawal Completed ✅",
    message: txId
      ? `Your withdrawal of $${amount.toFixed(2)} was successfully sent. TxID: ${txId.slice(0, 20)}...`
      : `Your withdrawal of $${amount.toFixed(2)} was successfully processed.`,
    type: "WITHDRAWAL" as const,
    actionUrl: "/records",
    relatedId: withdrawalId,
  }),

  withdrawalRejected: (userId: string, amount: number, withdrawalId: string, reason?: string) => ({
    userId,
    title: "Withdrawal Rejected ❌",
    message: reason
      ? `Your withdrawal of $${amount.toFixed(2)} was rejected and refunded. Reason: ${reason}`
      : `Your withdrawal of $${amount.toFixed(2)} was rejected. Amount refunded to your balance.`,
    type: "WITHDRAWAL" as const,
    actionUrl: "/records",
    relatedId: withdrawalId,
  }),

  kycApproved: (userId: string, kycId: string) => ({
    userId,
    title: "KYC Verified ✅",
    message: "Your identity has been verified. Withdrawals are now unlocked!",
    type: "KYC" as const,
    actionUrl: "/kyc",
    relatedId: kycId,
  }),

  kycRejected: (userId: string, kycId: string, reason: string) => ({
    userId,
    title: "KYC Rejected ❌",
    message: `Your KYC submission was rejected. Reason: ${reason}. You can re-submit with corrections.`,
    type: "KYC" as const,
    actionUrl: "/kyc",
    relatedId: kycId,
  }),

  chatReply: (userId: string, chatId: string, preview: string) => ({
    userId,
    title: "New Reply from Support 💬",
    message: preview.length > 100 ? preview.slice(0, 100) + "..." : preview,
    type: "CHAT" as const,
    actionUrl: "/chat",
    relatedId: chatId,
  }),

  balanceAdded: (userId: string, amount: number, note?: string) => ({
    userId,
    title: "Balance Credited 💰",
    message: note
      ? `$${amount.toFixed(2)} was added to your balance. Note: ${note}`
      : `$${amount.toFixed(2)} was added to your balance.`,
    type: "SYSTEM" as const,
    actionUrl: "/wallet",
  }),

  balanceDeducted: (userId: string, amount: number, note?: string) => ({
    userId,
    title: "Balance Deducted",
    message: note
      ? `$${amount.toFixed(2)} was deducted from your balance. Note: ${note}`
      : `$${amount.toFixed(2)} was deducted from your balance.`,
    type: "SYSTEM" as const,
    actionUrl: "/wallet",
  }),
};