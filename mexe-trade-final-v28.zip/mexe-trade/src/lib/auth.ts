// src/lib/auth.ts
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { prisma } from "./prisma";

// SECURITY: never fall back to a hardcoded secret in production —
// anyone who reads the source could forge admin tokens.
// Checked lazily (at first use) so `next build` doesn't require the env var.
function getJwtSecret(): string {
  const secret = process.env.JWT_SECRET;
  if (secret) return secret;
  if (process.env.NODE_ENV === "production") {
    throw new Error("JWT_SECRET environment variable must be set in production");
  }
  console.warn("⚠️ JWT_SECRET not set — using insecure dev-only fallback");
  return "dev-only-insecure-secret";
}
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || "7d";

// ============================================================
// PASSWORD HASHING
// ============================================================

export async function hashPassword(password: string): Promise<string> {
  const saltRounds = 12;
  return bcrypt.hash(password, saltRounds);
}

export async function verifyPassword(
  password: string,
  hash: string
): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

// ============================================================
// JWT TOKEN MANAGEMENT
// ============================================================

export interface JWTPayload {
  userId: string;
  email: string;
  role: string;
}

export function generateToken(payload: JWTPayload): string {
  // @ts-expect-error - jsonwebtoken types are picky about string literals
  return jwt.sign(payload, getJwtSecret(), { expiresIn: JWT_EXPIRES_IN });
}

export function verifyToken(token: string): JWTPayload | null {
  try {
    return jwt.verify(token, getJwtSecret()) as JWTPayload;
  } catch {
    return null;
  }
}

// ============================================================
// REFERRAL CODE GENERATOR
// ============================================================

export function generateReferralCode(length: number = 8): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // No confusing chars (0/O, 1/I)
  let code = "";
  for (let i = 0; i < length; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}

export async function generateUniqueReferralCode(): Promise<string> {
  let code = generateReferralCode();
  let attempts = 0;
  
  // Ensure uniqueness (retry if collision)
  while (attempts < 10) {
    const existing = await prisma.user.findUnique({
      where: { referralCode: code },
    });
    if (!existing) return code;
    code = generateReferralCode();
    attempts++;
  }
  
  // Fallback — add timestamp
  return generateReferralCode() + Date.now().toString(36).slice(-4).toUpperCase();
}

// ============================================================
// EMAIL & PASSWORD VALIDATION
// ============================================================

export function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

export function validatePassword(password: string): {
  valid: boolean;
  message?: string;
} {
  if (password.length < 8) {
    return { valid: false, message: "Password must be at least 8 characters" };
  }
  if (!/[A-Z]/.test(password)) {
    return { valid: false, message: "Password must contain an uppercase letter" };
  }
  if (!/[a-z]/.test(password)) {
    return { valid: false, message: "Password must contain a lowercase letter" };
  }
  if (!/[0-9]/.test(password)) {
    return { valid: false, message: "Password must contain a number" };
  }
  return { valid: true };
}

// ============================================================
// GET USER FROM TOKEN (Server-side helper)
// ============================================================

export async function getUserFromToken(token: string | undefined) {
  if (!token) return null;
  
  const payload = verifyToken(token);
  if (!payload) return null;
  
  const user = await prisma.user.findUnique({
    where: { id: payload.userId },
    select: {
      id: true,
      uid: true,
      email: true,
      username: true,
      balance: true,
      role: true,
      isActive: true,
      isVerified: true,
      kycStatus: true,
      withdrawalsFrozen: true,
      withdrawalFreezeReason: true,
      referralCode: true,
      createdAt: true,
    },
  });

  // Suspended users lose access immediately (not only at next login)
  if (!user || !user.isActive) return null;

  return user;
}