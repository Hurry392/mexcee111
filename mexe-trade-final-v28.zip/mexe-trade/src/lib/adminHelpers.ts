// src/lib/adminHelpers.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getAdminToken } from "@/lib/cookies"; // ✅ Admin cookie
import { verifyToken } from "@/lib/auth";

/**
 * Verify admin authentication for API routes.
 */
export async function requireAdmin(): Promise<
  | { admin: { id: string; email: string; role: string }; error?: undefined }
  | { admin?: undefined; error: NextResponse }
> {
  const token = await getAdminToken(); // ✅ Get admin cookie

  if (!token) {
    return {
      error: NextResponse.json({ error: "Unauthorized" }, { status: 401 }),
    };
  }

  const payload = verifyToken(token);
  if (!payload) {
    return {
      error: NextResponse.json({ error: "Invalid token" }, { status: 401 }),
    };
  }

  if (payload.role !== "ADMIN") {
    return {
      error: NextResponse.json({ error: "Admin access required" }, { status: 403 }),
    };
  }

  const session = await prisma.session.findUnique({
    where: { token },
  });

  if (!session || session.expiresAt < new Date()) {
    return {
      error: NextResponse.json({ error: "Session expired" }, { status: 401 }),
    };
  }

  const admin = await prisma.user.findUnique({
    where: { id: payload.userId },
    select: {
      id: true,
      email: true,
      role: true,
      isActive: true,
    },
  });

  if (!admin || admin.role !== "ADMIN" || !admin.isActive) {
    return {
      error: NextResponse.json({ error: "Admin not found or suspended" }, { status: 403 }),
    };
  }

  return { admin };
}

/**
 * Log admin action to audit trail.
 */
export async function logAdminAction(data: {
  adminId: string;
  adminEmail: string;
  action: string;
  category: "DEPOSIT" | "WITHDRAWAL" | "KYC" | "BALANCE" | "USER" | "SETTINGS" | "CHAT" | "GENERAL";
  targetUserId?: string;
  targetId?: string;
  note?: string;
  amount?: number;
  metadata?: Record<string, unknown>;
}) {
  try {
    await prisma.adminAction.create({
      data: {
        adminId: data.adminId,
        adminEmail: data.adminEmail,
        action: data.action,
        category: data.category,
        targetUserId: data.targetUserId,
        targetId: data.targetId,
        note: data.note,
        amount: data.amount,
        metadata: data.metadata ? JSON.stringify(data.metadata) : null,
      },
    });
  } catch (err) {
    console.error("Failed to log admin action:", err);
  }
}

export function getClientIp(req: NextRequest): string {
  return (
    req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
    req.headers.get("x-real-ip") ||
    "unknown"
  );
}