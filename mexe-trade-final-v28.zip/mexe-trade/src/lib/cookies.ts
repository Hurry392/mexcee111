// src/lib/cookies.ts
import { cookies } from "next/headers";
import { NextResponse } from "next/server";

// ─── Cookie names (SEPARATE for user and admin) ───
const USER_COOKIE = "pe-session";
const ADMIN_COOKIE = "pe-admin-session";
const COOKIE_MAX_AGE = 60 * 60 * 24 * 7; // 7 days

// ═══════════════════════════════════════════════
// USER COOKIE HELPERS
// ═══════════════════════════════════════════════

export function setAuthCookie(response: NextResponse, token: string) {
  response.cookies.set({
    name: USER_COOKIE,
    value: token,
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: COOKIE_MAX_AGE,
    path: "/",
  });
  return response;
}

export function clearAuthCookie(response: NextResponse) {
  response.cookies.set({
    name: USER_COOKIE,
    value: "",
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: 0,
    path: "/",
  });
  return response;
}

export async function getAuthToken(): Promise<string | undefined> {
  const cookieStore = await cookies();
  return cookieStore.get(USER_COOKIE)?.value;
}

// ═══════════════════════════════════════════════
// ADMIN COOKIE HELPERS
// ═══════════════════════════════════════════════

export function setAdminCookie(response: NextResponse, token: string) {
  response.cookies.set({
    name: ADMIN_COOKIE,
    value: token,
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: COOKIE_MAX_AGE,
    path: "/",
  });
  return response;
}

export function clearAdminCookie(response: NextResponse) {
  response.cookies.set({
    name: ADMIN_COOKIE,
    value: "",
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: 0,
    path: "/",
  });
  return response;
}

export async function getAdminToken(): Promise<string | undefined> {
  const cookieStore = await cookies();
  return cookieStore.get(ADMIN_COOKIE)?.value;
}

export { USER_COOKIE, ADMIN_COOKIE };