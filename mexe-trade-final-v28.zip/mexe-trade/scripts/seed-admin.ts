// scripts/seed-admin.ts
import "dotenv/config";
import { PrismaClient } from "@prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";
import bcrypt from "bcryptjs";

// ─── Setup Prisma ───
const adapter = new PrismaPg({
  connectionString: process.env.DATABASE_URL!,
});
const prisma = new PrismaClient({ adapter });

// ─── Referral code generator ───
function generateReferralCode(length: number = 8): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  for (let i = 0; i < length; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}

async function seedAdmin() {
  console.log("\n🦾 MEXC Trade — Admin Seed Script");
  console.log("═══════════════════════════════════════\n");

  const email = process.env.ADMIN_EMAIL;
  const password = process.env.ADMIN_PASSWORD;

  // ─── Validation ───
  if (!email || !password) {
    console.error("❌ ERROR: ADMIN_EMAIL or ADMIN_PASSWORD not set in .env");
    console.error("   Please set these variables and try again.\n");
    process.exit(1);
  }

  if (password.length < 8) {
    console.error("❌ ERROR: ADMIN_PASSWORD must be at least 8 characters");
    process.exit(1);
  }

  try {
    // ─── Check if admin already exists ───
    const existing = await prisma.user.findUnique({
      where: { email: email.toLowerCase().trim() },
    });

    if (existing) {
      if (existing.role === "ADMIN") {
        console.log("⚠️  Admin already exists with this email!");
        console.log(`   Email: ${existing.email}`);
        console.log(`   Role: ${existing.role}`);
        console.log("\n   Would you like to reset the password? (Update the script)\n");

        // Reset password automatically
        const newHash = await bcrypt.hash(password, 12);
        await prisma.user.update({
          where: { id: existing.id },
          data: {
            passwordHash: newHash,
            isActive: true,
            isVerified: true,
          },
        });

        console.log("✅ Admin password updated successfully!");
        console.log(`   Email: ${existing.email}`);
        console.log(`   New Password: ${password}\n`);
      } else {
        // Existing user is not admin — promote them
        const newHash = await bcrypt.hash(password, 12);
        await prisma.user.update({
          where: { id: existing.id },
          data: {
            role: "ADMIN",
            passwordHash: newHash,
            isActive: true,
            isVerified: true,
          },
        });

        console.log("✅ Existing user promoted to ADMIN!");
        console.log(`   Email: ${existing.email}`);
        console.log(`   Role: USER → ADMIN\n`);
      }
    } else {
      // ─── Create new admin ───
      const passwordHash = await bcrypt.hash(password, 12);
      let referralCode = generateReferralCode();

      // Ensure unique referral code
      let attempts = 0;
      while (attempts < 10) {
        const codeExists = await prisma.user.findUnique({
          where: { referralCode },
        });
        if (!codeExists) break;
        referralCode = generateReferralCode();
        attempts++;
      }

      const admin = await prisma.user.create({
        data: {
          email: email.toLowerCase().trim(),
          passwordHash,
          username: "admin",
          role: "ADMIN",
          isActive: true,
          isVerified: true,
          kycStatus: "APPROVED",
          referralCode,
          balance: 0,
        },
      });

      console.log("✅ Admin created successfully!\n");
      console.log(`   ID:       ${admin.id}`);
      console.log(`   Email:    ${admin.email}`);
      console.log(`   Password: ${password}`);
      console.log(`   Role:     ${admin.role}\n`);
    }

    console.log("═══════════════════════════════════════");
    console.log("🌐 Login at: http://localhost:3000/admin/login");
    console.log("═══════════════════════════════════════\n");
  } catch (error) {
    console.error("❌ ERROR:", error);
    process.exit(1);
  } finally {
    await prisma.$disconnect();
  }
}

seedAdmin();